"use strict";
(() => {
  // src/winforms-url-automation.ts
  var WINFORMS_SITE_PATTERN = /^[a-z0-9][a-z0-9_-]{0,31}$/i;
  function isValidWinFormsSite(value) {
    return WINFORMS_SITE_PATTERN.test(value);
  }

  // src/mediprisma.ts
  var MEDIPRISMA_CONTROL_PARAMS = /* @__PURE__ */ new Set(["medcloud2", "site"]);
  function isAllowedMediPrismaAppUrl(raw) {
    try {
      const url = new URL(raw ?? "");
      if (url.origin === "https://mediprisma.tw" && (url.pathname === "/app" || url.pathname === "/app/") && url.hash === "") {
        const keys = [];
        url.searchParams.forEach((_value, key) => keys.push(key));
        if (keys.some((key) => !MEDIPRISMA_CONTROL_PARAMS.has(key))) return false;
        if (keys.length === 0) return true;
        const modes = url.searchParams.getAll("medcloud2");
        const sites = url.searchParams.getAll("site");
        return modes.length <= 1 && (modes.length === 0 || modes[0] === "auto") && sites.length <= 1 && (sites.length === 0 || isValidWinFormsSite(sites[0] ?? "")) && modes.length + sites.length > 0;
      }
      return false;
    } catch {
      return false;
    }
  }

  // src/mediprisma-viewer-protocol.ts
  var OPEN_NHI_VIEWER = "medcloud:open-nhi-viewer";
  var MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST = "MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST";
  var MEDIPRISMA_NHI_VIEWER_OPEN_RESULT = "MEDIPRISMA_NHI_VIEWER_OPEN_RESULT";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function safePart(value, maxLength) {
    return typeof value === "string" && value.length <= maxLength && !/[\u0000-\u001f\u007f@]/u.test(value);
  }
  function isNhiImagingViewerRequestDescriptor(value) {
    if (!isRecord(value)) return false;
    return value.version === 1 && value.procId === "IMUE0130" && safePart(value.iplCaseSeqNo, 256) && value.iplCaseSeqNo.length > 0 && safePart(value.readPos, 128) && (value.ordMark === "" || value.ordMark === "Y") && safePart(value.fileType, 128) && safePart(value.fileQty, 32) && safePart(value.feeYm, 64);
  }
  function isRequestId(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{8,128}$/u.test(value);
  }
  function isPatientContextHash(value) {
    return typeof value === "string" && /^[a-f0-9]{64}$/iu.test(value);
  }
  function isMediPrismaViewerPageRequest(value) {
    return isRecord(value) && value.source === "mediprisma" && value.type === MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST && value.version === 1 && isRequestId(value.requestId) && isPatientContextHash(value.patientContextHash) && isNhiImagingViewerRequestDescriptor(value.descriptor);
  }
  function viewerPageResult(requestId, response) {
    return {
      source: "medcloud2-extension",
      type: MEDIPRISMA_NHI_VIEWER_OPEN_RESULT,
      version: 1,
      requestId,
      ok: response.ok,
      ...!response.ok ? { code: response.code } : {}
    };
  }

  // src/mediprisma-viewer-bridge.ts
  function allowedMediPrismaViewerOrigin(rawUrl) {
    if (isAllowedMediPrismaAppUrl(rawUrl)) return "https://mediprisma.tw";
    return void 0;
  }
  function invalidRequestId(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    const candidate = value;
    return candidate.source === "mediprisma" && candidate.type === "MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST" && candidate.version === 1 && typeof candidate.requestId === "string" && /^[A-Za-z0-9_-]{8,128}$/u.test(candidate.requestId) ? candidate.requestId : void 0;
  }
  function runtimeResponse(value) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      const response = value;
      if (response.ok === true) return { ok: true };
      if (response.ok === false && [
        "INVALID_REQUEST",
        "REQUEST_IN_PROGRESS",
        "MEDCLOUD_TAB_NOT_FOUND",
        "PATIENT_MISMATCH",
        "SESSION_EXPIRED",
        "VIEWER_UNAVAILABLE",
        "OPEN_FAILED"
      ].includes(String(response.code))) {
        return { ok: false, code: response.code };
      }
    }
    return { ok: false, code: "OPEN_FAILED" };
  }
  function startMediPrismaViewerBridge(runtime) {
    const initialOrigin = allowedMediPrismaViewerOrigin(runtime.currentUrl());
    if (!initialOrigin) return null;
    const inFlight = /* @__PURE__ */ new Set();
    let stopped = false;
    const removeMessageListener = runtime.addMessageListener((event) => {
      if (stopped || event.origin !== initialOrigin || event.source !== runtime.pageWindow || allowedMediPrismaViewerOrigin(runtime.currentUrl()) !== initialOrigin) {
        return;
      }
      if (!isMediPrismaViewerPageRequest(event.data)) {
        const requestId = invalidRequestId(event.data);
        if (requestId) {
          runtime.postMessage(
            viewerPageResult(requestId, { ok: false, code: "INVALID_REQUEST" }),
            initialOrigin
          );
        }
        return;
      }
      const request = event.data;
      if (inFlight.has(request.requestId)) return;
      inFlight.add(request.requestId);
      void runtime.sendRuntimeMessage({
        type: OPEN_NHI_VIEWER,
        requestId: request.requestId,
        patientContextHash: request.patientContextHash,
        descriptor: request.descriptor
      }).then((response) => {
        if (stopped || allowedMediPrismaViewerOrigin(runtime.currentUrl()) !== initialOrigin) return;
        runtime.postMessage(
          viewerPageResult(request.requestId, runtimeResponse(response)),
          initialOrigin
        );
      }).catch(() => {
        if (stopped || allowedMediPrismaViewerOrigin(runtime.currentUrl()) !== initialOrigin) return;
        runtime.postMessage(
          viewerPageResult(request.requestId, { ok: false, code: "OPEN_FAILED" }),
          initialOrigin
        );
      }).finally(() => {
        inFlight.delete(request.requestId);
      });
    });
    return {
      stop: () => {
        if (stopped) return;
        stopped = true;
        inFlight.clear();
        removeMessageListener();
      }
    };
  }
  function startDefaultMediPrismaViewerBridge() {
    return startMediPrismaViewerBridge({
      currentUrl: () => location.href,
      pageWindow: window,
      postMessage: (message, targetOrigin) => window.postMessage(message, targetOrigin),
      addMessageListener: (listener) => {
        const wrapped = (event) => listener(event);
        window.addEventListener("message", wrapped);
        return () => window.removeEventListener("message", wrapped);
      },
      sendRuntimeMessage: (message) => chrome.runtime.sendMessage(message)
    });
  }

  // src/mediprisma-viewer-launcher.ts
  startDefaultMediPrismaViewerBridge();
})();
