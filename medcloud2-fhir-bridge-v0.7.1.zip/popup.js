"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // (disabled):crypto
  var require_crypto = __commonJS({
    "(disabled):crypto"() {
    }
  });

  // (disabled):../../../../../../../node_modules/buffer/index.js
  var require_buffer = __commonJS({
    "(disabled):../../../../../../../node_modules/buffer/index.js"() {
    }
  });

  // ../node_modules/js-sha1/src/sha1.js
  var require_sha1 = __commonJS({
    "../node_modules/js-sha1/src/sha1.js"(exports, module) {
      (function() {
        "use strict";
        var INPUT_ERROR = "input is invalid type";
        var FINALIZE_ERROR = "finalize already called";
        var WINDOW = typeof window === "object";
        var root = WINDOW ? window : {};
        if (root.JS_SHA1_NO_WINDOW) {
          WINDOW = false;
        }
        var WEB_WORKER = !WINDOW && typeof self === "object";
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
        if (NODE_JS) {
          root = global;
        } else if (WEB_WORKER) {
          root = self;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var ARRAY_BUFFER = !root.JS_SHA1_NO_ARRAY_BUFFER && typeof ArrayBuffer !== "undefined";
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var isArray = Array.isArray;
        if (root.JS_SHA1_NO_NODE_JS || !isArray) {
          isArray = function(obj) {
            return Object.prototype.toString.call(obj) === "[object Array]";
          };
        }
        var isView = ArrayBuffer.isView;
        if (ARRAY_BUFFER && (root.JS_SHA1_NO_ARRAY_BUFFER_IS_VIEW || !isView)) {
          isView = function(obj) {
            return typeof obj === "object" && obj.buffer && obj.buffer.constructor === ArrayBuffer;
          };
        }
        var formatMessage = function(message2) {
          var type = typeof message2;
          if (type === "string") {
            return [message2, true];
          }
          if (type !== "object" || message2 === null) {
            throw new Error(INPUT_ERROR);
          }
          if (ARRAY_BUFFER && message2.constructor === ArrayBuffer) {
            return [new Uint8Array(message2), false];
          }
          if (!isArray(message2) && !isView(message2)) {
            throw new Error(INPUT_ERROR);
          }
          return [message2, false];
        };
        var createOutputMethod = function(outputType) {
          return function(message2) {
            return new Sha1(true).update(message2)[outputType]();
          };
        };
        var createMethod = function() {
          var method = createOutputMethod("hex");
          if (NODE_JS) {
            method = nodeWrap(method);
          }
          method.create = function() {
            return new Sha1();
          };
          method.update = function(message2) {
            return method.create().update(message2);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createOutputMethod(type);
          }
          return method;
        };
        var nodeWrap = function(method) {
          var crypto2 = require_crypto();
          var Buffer2 = require_buffer().Buffer;
          var bufferFrom;
          if (Buffer2.from && !root.JS_SHA1_NO_BUFFER_FROM) {
            bufferFrom = Buffer2.from;
          } else {
            bufferFrom = function(message2) {
              return new Buffer2(message2);
            };
          }
          var nodeMethod = function(message2) {
            if (typeof message2 === "string") {
              return crypto2.createHash("sha1").update(message2, "utf8").digest("hex");
            } else {
              if (message2 === null || message2 === void 0) {
                throw new Error(INPUT_ERROR);
              } else if (message2.constructor === ArrayBuffer) {
                message2 = new Uint8Array(message2);
              }
            }
            if (isArray(message2) || isView(message2) || message2.constructor === Buffer2) {
              return crypto2.createHash("sha1").update(bufferFrom(message2)).digest("hex");
            } else {
              return method(message2);
            }
          };
          return nodeMethod;
        };
        var createHmacOutputMethod = function(outputType) {
          return function(key, message2) {
            return new HmacSha1(key, true).update(message2)[outputType]();
          };
        };
        var createHmacMethod = function() {
          var method = createHmacOutputMethod("hex");
          method.create = function(key) {
            return new HmacSha1(key);
          };
          method.update = function(key, message2) {
            return method.create(key).update(message2);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createHmacOutputMethod(type);
          }
          return method;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message2) {
          if (this.finalized) {
            throw new Error(FINALIZE_ERROR);
          }
          var result = formatMessage(message2);
          message2 = result[0];
          var isString = result[1];
          var code, index = 0, i, length = message2.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              this.block = blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (isString) {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message2.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >>> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >>> 2] |= (192 | code >>> 6) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >>> 2] |= (224 | code >>> 12) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message2.charCodeAt(++index) & 1023);
                  blocks2[i >>> 2] |= (240 | code >>> 18) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >>> 2] |= message2[index] << SHIFT[i++ & 3];
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >>> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >>> 28 & 15] + HEX_CHARS[h0 >>> 24 & 15] + HEX_CHARS[h0 >>> 20 & 15] + HEX_CHARS[h0 >>> 16 & 15] + HEX_CHARS[h0 >>> 12 & 15] + HEX_CHARS[h0 >>> 8 & 15] + HEX_CHARS[h0 >>> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >>> 28 & 15] + HEX_CHARS[h1 >>> 24 & 15] + HEX_CHARS[h1 >>> 20 & 15] + HEX_CHARS[h1 >>> 16 & 15] + HEX_CHARS[h1 >>> 12 & 15] + HEX_CHARS[h1 >>> 8 & 15] + HEX_CHARS[h1 >>> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >>> 28 & 15] + HEX_CHARS[h2 >>> 24 & 15] + HEX_CHARS[h2 >>> 20 & 15] + HEX_CHARS[h2 >>> 16 & 15] + HEX_CHARS[h2 >>> 12 & 15] + HEX_CHARS[h2 >>> 8 & 15] + HEX_CHARS[h2 >>> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >>> 28 & 15] + HEX_CHARS[h3 >>> 24 & 15] + HEX_CHARS[h3 >>> 20 & 15] + HEX_CHARS[h3 >>> 16 & 15] + HEX_CHARS[h3 >>> 12 & 15] + HEX_CHARS[h3 >>> 8 & 15] + HEX_CHARS[h3 >>> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >>> 28 & 15] + HEX_CHARS[h4 >>> 24 & 15] + HEX_CHARS[h4 >>> 20 & 15] + HEX_CHARS[h4 >>> 16 & 15] + HEX_CHARS[h4 >>> 12 & 15] + HEX_CHARS[h4 >>> 8 & 15] + HEX_CHARS[h4 >>> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >>> 24 & 255,
            h0 >>> 16 & 255,
            h0 >>> 8 & 255,
            h0 & 255,
            h1 >>> 24 & 255,
            h1 >>> 16 & 255,
            h1 >>> 8 & 255,
            h1 & 255,
            h2 >>> 24 & 255,
            h2 >>> 16 & 255,
            h2 >>> 8 & 255,
            h2 & 255,
            h3 >>> 24 & 255,
            h3 >>> 16 & 255,
            h3 >>> 8 & 255,
            h3 & 255,
            h4 >>> 24 & 255,
            h4 >>> 16 & 255,
            h4 >>> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        function HmacSha1(key, sharedMemory) {
          var i, result = formatMessage(key);
          key = result[0];
          if (result[1]) {
            var bytes = [], length = key.length, index = 0, code;
            for (i = 0; i < length; ++i) {
              code = key.charCodeAt(i);
              if (code < 128) {
                bytes[index++] = code;
              } else if (code < 2048) {
                bytes[index++] = 192 | code >>> 6;
                bytes[index++] = 128 | code & 63;
              } else if (code < 55296 || code >= 57344) {
                bytes[index++] = 224 | code >>> 12;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              } else {
                code = 65536 + ((code & 1023) << 10 | key.charCodeAt(++i) & 1023);
                bytes[index++] = 240 | code >>> 18;
                bytes[index++] = 128 | code >>> 12 & 63;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              }
            }
            key = bytes;
          }
          if (key.length > 64) {
            key = new Sha1(true).update(key).array();
          }
          var oKeyPad = [], iKeyPad = [];
          for (i = 0; i < 64; ++i) {
            var b = key[i] || 0;
            oKeyPad[i] = 92 ^ b;
            iKeyPad[i] = 54 ^ b;
          }
          Sha1.call(this, sharedMemory);
          this.update(iKeyPad);
          this.oKeyPad = oKeyPad;
          this.inner = true;
          this.sharedMemory = sharedMemory;
        }
        HmacSha1.prototype = new Sha1();
        HmacSha1.prototype.finalize = function() {
          Sha1.prototype.finalize.call(this);
          if (this.inner) {
            this.inner = false;
            var innerHash = this.array();
            Sha1.call(this, this.sharedMemory);
            this.update(this.oKeyPad);
            this.update(innerHash);
            Sha1.prototype.finalize.call(this);
          }
        };
        var exports2 = createMethod();
        exports2.sha1 = exports2;
        exports2.sha1.hmac = createHmacMethod();
        if (COMMON_JS) {
          module.exports = exports2;
        } else {
          root.sha1 = exports2;
          if (AMD) {
            define(function() {
              return exports2;
            });
          }
        }
      })();
    }
  });

  // ../packages/medcloud-adapter/src/constants.ts
  var MEDCLOUD_ADAPTER_VERSION = "0.7.1";
  var IMUE0060_SOURCE_MODULE = "IMUE0060";
  var IMUE0060_DATASET_SCOPE = "/imu/api/imue0060/imue0060s02/get-data";
  var IMUE0008_SOURCE_MODULE = "IMUE0008";
  var IMUE0008_DATASET_SCOPE = "/imu/api/imue0008/imue0008s02/get-data";
  var IMUE0130_SOURCE_MODULE = "IMUE0130";
  var IMUE0130_DATASET_SCOPE = "/imu/api/imue0130/imue0130s02/get-data";
  var IMUE0030_SOURCE_MODULE = "IMUE0030";
  var IMUE0030_DATASET_SCOPE = "/imu/api/imue0030/imue0030s02/get-data";
  var IMUE0010_SOURCE_MODULE = "IMUE0010";
  var IMUE0010_DATASET_SCOPE = "/imu/api/imue0010/imue0010s02/get-data";
  var IMUE0120_SOURCE_MODULE = "IMUE0120";
  var IMUE0120_DATASET_SCOPE = "/imu/api/imue0120/imue0120s01/pres-med-day";
  var IMUE0140_SOURCE_MODULE = "IMUE0140";
  var IMUE0140_DATASET_SCOPE = "/imu/api/imue0140/imue0140s01/hpa-data";
  var IMUE0070_SOURCE_MODULE = "IMUE0070";
  var IMUE0070_DATASET_SCOPE = "/imu/api/imue0070/imue0070s02/get-data";
  var IMUE0080_SOURCE_MODULE = "IMUE0080";
  var IMUE0080_DATASET_SCOPE = "/imu/api/imue0080/imue0080s02/get-data";
  var IMUE0150_SOURCE_MODULE = "IMUE0150";
  var IMUE0150_DATASET_SCOPE = "/imu/api/imue0150/imue0150s01/hpa-data";
  var MEDCLOUD_CLINICAL_MODULES = [
    { sourceModule: IMUE0060_SOURCE_MODULE, datasetScope: IMUE0060_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C" },
    { sourceModule: IMUE0008_SOURCE_MODULE, datasetScope: IMUE0008_DATASET_SCOPE, label: "\u897F\u91AB\u7528\u85E5" },
    { sourceModule: IMUE0130_SOURCE_MODULE, datasetScope: IMUE0130_DATASET_SCOPE, label: "\u6587\u5B57\u5831\u544A" },
    { sourceModule: IMUE0030_SOURCE_MODULE, datasetScope: IMUE0030_DATASET_SCOPE, label: "\u7259\u79D1\u8655\u7F6E" },
    { sourceModule: IMUE0010_SOURCE_MODULE, datasetScope: IMUE0010_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D00\u9304" },
    { sourceModule: IMUE0070_SOURCE_MODULE, datasetScope: IMUE0070_DATASET_SCOPE, label: "\u4F4F\u9662\u53CA\u51FA\u9662\u75C5\u6B77\u6458\u8981" },
    { sourceModule: IMUE0080_SOURCE_MODULE, datasetScope: IMUE0080_DATASET_SCOPE, label: "\u5FA9\u5065\u91AB\u7642\u7D00\u9304" },
    { sourceModule: IMUE0120_SOURCE_MODULE, datasetScope: IMUE0120_DATASET_SCOPE, label: "\u9580\u8A3A\u85E5\u54C1\u9918\u85E5\u65E5\u6578" },
    { sourceModule: IMUE0140_SOURCE_MODULE, datasetScope: IMUE0140_DATASET_SCOPE, label: "\u6210\u4EBA\u9810\u9632\u4FDD\u5065" },
    { sourceModule: IMUE0150_SOURCE_MODULE, datasetScope: IMUE0150_DATASET_SCOPE, label: "\u764C\u75C7\u7BE9\u6AA2\u7D50\u679C" }
  ];

  // ../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message2;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message2 = "Required";
        } else {
          message2 = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message2 = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message2 = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message2 = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message2 = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message2 = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message2 = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message2 = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message2 = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message2 = `${message2} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message2 = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message2 = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message2 = `Invalid ${issue.validation}`;
        } else {
          message2 = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message2 = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message2 = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message2 = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message2 = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message2 = "Number must be finite";
        break;
      default:
        message2 = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message: message2 };
  };
  var en_default = errorMap;

  // ../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message2) => typeof message2 === "string" ? { message: message2 } : message2 || {};
    errorUtil2.toString = (message2) => typeof message2 === "string" ? message2 : message2?.message;
  })(errorUtil || (errorUtil = {}));

  // ../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message: message2 } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message2 ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message2 ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message2 ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message2) {
      const getIssueProperties = (val) => {
        if (typeof message2 === "string" || typeof message2 === "undefined") {
          return { message: message2 };
        } else if (typeof message2 === "function") {
          return message2(val);
        } else {
          return message2;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message2) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message2)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message2) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message2) });
    }
    url(message2) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message2) });
    }
    emoji(message2) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message2) });
    }
    uuid(message2) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message2) });
    }
    nanoid(message2) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message2) });
    }
    cuid(message2) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message2) });
    }
    cuid2(message2) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message2) });
    }
    ulid(message2) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message2) });
    }
    base64(message2) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message2) });
    }
    base64url(message2) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message2)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message2) {
      return this._addCheck({ kind: "date", message: message2 });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message2) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message2) });
    }
    regex(regex, message2) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message2)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message2) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    endsWith(value, message2) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    min(minLength, message2) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message2)
      });
    }
    max(maxLength, message2) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message2)
      });
    }
    length(len, message2) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message2)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message2) {
      return this.min(1, errorUtil.errToObj(message2));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message2) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message2)
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    finite(message2) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message2)
      });
    }
    safe(message2) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message2) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    max(maxDate, message2) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message2) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message2) }
      });
    }
    max(maxLength, message2) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message2) }
      });
    }
    length(len, message2) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message2) }
      });
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message2) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message2 !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message2).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message2) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message2) }
      });
    }
    max(maxSize, message2) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message2) }
      });
    }
    size(size, message2) {
      return this.min(size, message2).max(size, message2);
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = /* @__PURE__ */ Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: ((arg) => ZodString.create({ ...arg, coerce: true })),
    number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
    boolean: ((arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    })),
    bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
    date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
  };
  var NEVER = INVALID;

  // ../packages/contracts/src/completeness.ts
  var CompletenessSchema = external_exports.enum(["complete", "empty", "partial", "failed"]);

  // ../packages/contracts/src/context.ts
  var PatientContextHashSchema = external_exports.string().min(16).max(256).regex(/^[A-Za-z0-9_-]+$/, "patientContextHash must be hex or base64url-like");
  var ProviderContextSchema = external_exports.object({
    identifier: external_exports.string().min(1).optional(),
    display: external_exports.string().min(1).optional()
  }).strict();
  var RecordContextSchema = external_exports.object({
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    sourceRecordKeyHmac: external_exports.string().min(16).optional(),
    capturedAt: external_exports.string().datetime({ offset: true }),
    adapterVersion: external_exports.string().min(1),
    patientContextHash: PatientContextHashSchema,
    provider: ProviderContextSchema.optional()
  }).strict();

  // ../packages/contracts/src/date.ts
  var DatePrecisionSchema = external_exports.enum(["year", "month", "day", "minute", "second"]);
  var DateSourceFormatSchema = external_exports.enum([
    "iso-date",
    "iso-date-time",
    "gregorian-slash",
    "roc-slash",
    "compact-date"
  ]);
  var NormalizedDateSchema = external_exports.object({
    value: external_exports.string().min(4),
    original: external_exports.string().min(1),
    precision: DatePrecisionSchema,
    sourceFormat: DateSourceFormatSchema,
    /** Present only when the source explicitly supplied Z or a numeric offset. */
    timezoneOffset: external_exports.string().regex(/^(?:Z|[+-]\d{2}:\d{2})$/).optional()
  }).strict();

  // ../packages/contracts/src/warning.ts
  var AdapterWarningCodeSchema = external_exports.enum([
    "access-restricted",
    "http-error",
    "invalid-json",
    "invalid-response",
    "invalid-row",
    "unknown-field",
    "invalid-date",
    "missing-clinical-content"
  ]);
  var WarningSeveritySchema = external_exports.enum(["info", "warning", "error"]);
  var AdapterWarningSchema = external_exports.object({
    code: AdapterWarningCodeSchema,
    severity: WarningSeveritySchema,
    path: external_exports.string().min(1),
    field: external_exports.string().min(1).optional(),
    message: external_exports.string().min(1)
  }).strict();

  // ../packages/contracts/src/module-result.ts
  var MapperPageTypeSchema = external_exports.enum([
    "observations",
    "medications",
    "diagnostic_reports",
    "procedures",
    "encounters",
    "document_references",
    "service_requests"
  ]);
  var ModuleErrorSchema = external_exports.object({
    code: external_exports.string().min(1),
    message: external_exports.string().min(1)
  }).strict();
  var ModuleResultBaseSchema = external_exports.object({
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    adapterVersion: external_exports.string().min(1),
    capturedAt: external_exports.string().datetime({ offset: true }),
    patientContextHash: PatientContextHashSchema,
    pageType: MapperPageTypeSchema,
    completeness: CompletenessSchema,
    warnings: external_exports.array(AdapterWarningSchema),
    error: ModuleErrorSchema.optional()
  });
  var ModuleResultSchema = ModuleResultBaseSchema.extend({
    records: external_exports.array(external_exports.unknown())
  }).strict();

  // ../packages/contracts/src/source-envelope.ts
  var SourceEnvelopeBaseSchema = external_exports.object({
    schemaVersion: external_exports.string().min(1),
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    adapterVersion: external_exports.string().min(1),
    runId: external_exports.string().min(1),
    capturedAt: external_exports.string().datetime({ offset: true }),
    sourceEventTime: external_exports.string().min(1).optional(),
    timePrecision: DatePrecisionSchema.optional(),
    authoritativeWindow: external_exports.object({
      start: external_exports.string().min(1).optional(),
      end: external_exports.string().min(1).optional()
    }).strict().optional(),
    completeness: CompletenessSchema,
    sourceRecordKeyHmac: external_exports.string().min(16).optional(),
    providerIdentifier: external_exports.string().min(1).optional(),
    patientContextHash: PatientContextHashSchema
  });
  var SourceEnvelopeSchema = SourceEnvelopeBaseSchema.extend({
    payload: external_exports.unknown()
  }).strict();

  // ../packages/medcloud-adapter/src/common.ts
  var import_js_sha1 = __toESM(require_sha1(), 1);

  // ../packages/medcloud-adapter/src/parser.ts
  var ResponseBodySchema = external_exports.object({
    log2time: external_exports.string().nullable().optional(),
    robject: external_exports.array(external_exports.unknown())
  });

  // ../packages/medcloud-adapter/src/schemas.ts
  var nullableString = external_exports.string().nullable().optional();
  var nullableNumber = external_exports.number().nullable().optional();
  var presentationString = external_exports.string().nullable().optional().transform((value) => value ?? "");
  var Imue0060RowSchema = external_exports.object({
    assay_item_name: external_exports.string(),
    assay_mark: nullableString,
    assay_method: presentationString,
    assay_tp_cname: nullableString,
    assay_value: external_exports.string(),
    case_time: external_exports.string(),
    consult_value: presentationString,
    data_mark: nullableString,
    fee_ym: external_exports.string(),
    func_type: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    inspect_mode: nullableString,
    inspect_result: nullableString,
    memo_data: nullableString,
    order_code: external_exports.string(),
    order_name: external_exports.string(),
    path_diag_1: nullableString,
    path_diag_2: nullableString,
    path_diag_3: nullableString,
    r: external_exports.number(),
    real_inspect_date: external_exports.string(),
    recipe_date: nullableString,
    unit_data: presentationString
  });
  var Imue0008RowSchema = external_exports.object({
    ay_flag: external_exports.string(),
    chr_hosp_id: nullableString,
    cure_e_date: nullableString,
    day: external_exports.number(),
    drug_65_mark: nullableString,
    drug_atc3_code: external_exports.string(),
    drug_atc5_code: external_exports.string(),
    drug_atc5_name: presentationString,
    drug_atc7_code: external_exports.string(),
    drug_code: external_exports.string(),
    drug_date: external_exports.string(),
    drug_ename: presentationString,
    drug_fre: presentationString,
    drug_group11_name: nullableString,
    drug_ing_code: external_exports.string(),
    drug_ing_name: presentationString,
    drug_left: external_exports.number(),
    drug_multi_mark: nullableString,
    drug_std_qty: nullableNumber,
    dup_drug_mark: nullableString,
    fee_ym: nullableString,
    func_seq_no: external_exports.string(),
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: presentationString,
    icd_code: external_exports.string(),
    qty: external_exports.number(),
    r: external_exports.number()
  });
  var Imue0130RowSchema = external_exports.object({
    assay_item_name: nullableString,
    assay_tp_cname: external_exports.string(),
    assay_value: nullableString,
    case_report_type: external_exports.string(),
    case_time: nullableString,
    ctmri: nullableString,
    ctmri_mark: external_exports.string(),
    cure_path: nullableString,
    cure_path_name: nullableString,
    data_mark: external_exports.string(),
    eec_link: nullableString,
    eec_mark: external_exports.string(),
    fee_ym: external_exports.string(),
    file_qty: nullableNumber,
    file_type: nullableString,
    func_type: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    inspect_mode: nullableString,
    inspect_result: nullableString,
    ipl_case_seq_no: nullableString,
    memo_data: nullableString,
    ord_mark: nullableString,
    order_code: external_exports.string(),
    order_name: external_exports.string(),
    path_diag_1: nullableString,
    path_diag_2: nullableString,
    path_diag_3: nullableString,
    r: external_exports.number(),
    read_pos: nullableString,
    real_inspect_date: external_exports.string(),
    recipe_date: nullableString,
    unit_data: nullableString
  });
  var Imue0030RowSchema = external_exports.object({
    ctmri_mark: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    exe_e_date: nullableString,
    exe_s_date: external_exports.string(),
    fee_ym: nullableString,
    file_qty: nullableNumber,
    file_type: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    ipl_case_seq_no: nullableString,
    ord_mark: nullableString,
    order_code: external_exports.string(),
    order_ename: nullableString,
    order_qty: nullableNumber,
    r: external_exports.number(),
    read_pos: nullableString
  });
  var Imue0010RowSchema = external_exports.object({
    child_birthday: nullableString,
    child_mark: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    exam_type: nullableString,
    exe_e_date: nullableString,
    exe_s_date: external_exports.string(),
    fee_ym: nullableString,
    func_date: nullableString,
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_code: external_exports.string(),
    order_ename: external_exports.string(),
    order_qty: nullableNumber,
    r: external_exports.number()
  });
  var Imue0120RowSchema = external_exports.object({
    atc5: nullableString,
    drug_group_code: nullableString,
    drug_type: nullableString,
    edate: nullableString,
    funcDate: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_code: nullableString,
    ingredient: nullableString,
    order_drug_day: external_exports.union([external_exports.string(), external_exports.number()]).nullable().optional(),
    pres_med_day: external_exports.union([external_exports.string(), external_exports.number()])
  });
  var Imue0140RowSchema = external_exports.object({});
  var Imue0070RowSchema = external_exports.object({
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    in_date: external_exports.string(),
    mds_file: nullableString,
    mds_pdf_file: nullableString,
    out_date: nullableString,
    pdf_mark: nullableString,
    pdf_reply_mark: nullableString,
    r: external_exports.number()
  });
  var Imue0080RowSchema = external_exports.object({
    cure_e_date: nullableString,
    cure_grade: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    cure_type: nullableString,
    exe_e_date: nullableString,
    exe_s_date: nullableString,
    fee_ym: nullableString,
    func_date: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_qty: nullableNumber,
    r: external_exports.number()
  });

  // src/mediprisma.ts
  var MEDIPRISMA_APP_URL = "https://mediprisma.tw/app/";
  var MEDIPRISMA_ORIGIN_PATTERNS = [
    "https://mediprisma.tw/app",
    "https://mediprisma.tw/app/*"
  ];

  // src/background-job.ts
  var BACKGROUND_JOB_STATUS_KEY = "cloud-wildcatch:medcloud-job-status-v1";
  var BACKGROUND_JOB_REQUEST_KEY = "cloud-wildcatch:medcloud-job-request-v1";
  var BACKGROUND_RESULT_ENCRYPTION_KEY = "cloud-wildcatch:result-encryption-key-v1";
  var START_BACKGROUND_JOB = "medcloud:start-background-job";
  var MARK_BACKGROUND_JOB_DOWNLOADED = "medcloud:mark-background-job-downloaded";
  var CLEAR_BACKGROUND_JOB = "medcloud:clear-background-job";
  var ARM_MEDIPRISMA_HANDOFF = "medcloud:arm-mediprisma-handoff";
  var DISARM_MEDIPRISMA_HANDOFF = "medcloud:disarm-mediprisma-handoff";
  var OPEN_PENDING_BUNDLE_IN_MEDIPRISMA = "medcloud:open-pending-bundle-in-mediprisma";
  var BACKGROUND_RESULT_TTL_MS = 60 * 60 * 1e3;
  var BACKGROUND_JOB_RECOVERY_WINDOW_MS = 10 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isBackgroundJobStatus(value) {
    if (!isRecord(value)) return false;
    return value.schemaVersion === 1 && typeof value.runId === "string" && ["running", "complete", "error", "downloaded", "handed-off"].includes(String(value.phase)) && typeof value.patientContextHash === "string" && typeof value.startedAt === "number" && typeof value.updatedAt === "number" && (value.completedAt === void 0 || typeof value.completedAt === "number" && Number.isFinite(value.completedAt)) && typeof value.message === "string" && typeof value.hasResult === "boolean" && typeof value.includeImagingViewerLinks === "boolean" && (value.tabId === void 0 || Number.isInteger(value.tabId) && Number(value.tabId) > 0) && (value.deliveryMode === void 0 || ["manual", "mediprisma"].includes(String(value.deliveryMode))) && (value.downloadedAt === void 0 || typeof value.downloadedAt === "number" && Number.isFinite(value.downloadedAt)) && (value.handedOffAt === void 0 || typeof value.handedOffAt === "number" && Number.isFinite(value.handedOffAt)) && (value.resultBytes === void 0 || Number.isInteger(value.resultBytes) && Number(value.resultBytes) >= 0) && (value.moduleProgress === void 0 || isRecord(value.moduleProgress) && Number.isInteger(value.moduleProgress.completed) && Number(value.moduleProgress.completed) >= 0 && Number.isInteger(value.moduleProgress.total) && Number(value.moduleProgress.total) >= 0 && Number(value.moduleProgress.completed) <= Number(value.moduleProgress.total));
  }
  function isBackgroundJobResult(value) {
    if (!isRecord(value)) return false;
    const hasCommonFields = typeof value.runId === "string" && typeof value.patientContextHash === "string" && typeof value.generatedAt === "number" && typeof value.expiresAt === "number" && typeof value.filename === "string";
    if (!hasCommonFields) return false;
    if (value.schemaVersion === 1) return "bundle" in value;
    const hasValidUncompressedSize = Number.isInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) >= 0;
    if (value.schemaVersion === 2) {
      return value.encoding === "gzip-base64" && typeof value.data === "string" && value.data.length > 0 && hasValidUncompressedSize;
    }
    if (value.schemaVersion === 3) return value.schemaVersion === 3 && value.encoding === "gzip" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && hasValidUncompressedSize;
    return value.schemaVersion === 4 && value.encoding === "gzip+aes-gcm" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && value.iv instanceof ArrayBuffer && value.iv.byteLength === 12 && hasValidUncompressedSize && (value.rawCapture === void 0 || isEncodedRawCapture(value.rawCapture));
  }
  function isEncodedRawCapture(value) {
    if (!isRecord(value)) return false;
    return value.encoding === "gzip+aes-gcm" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && value.iv instanceof ArrayBuffer && value.iv.byteLength === 12 && Number.isInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) >= 0 && typeof value.filename === "string" && value.filename.length > 0;
  }
  function runningJobStatus(request, startedAt = Date.now(), recovered = false) {
    return {
      schemaVersion: 1,
      runId: request.runId,
      phase: "running",
      patientContextHash: request.expectedPatientContextHash,
      startedAt,
      updatedAt: Date.now(),
      message: recovered ? "\u6B63\u5728\u7E7C\u7E8C\u53D6\u5F97\u96F2\u7AEF\u75C5\u6B77\u8CC7\u6599\u2026" : runningJobElapsedMessage(startedAt, startedAt),
      hasResult: false,
      tabId: request.tabId,
      deliveryMode: request.deliveryMode ?? "manual",
      includeImagingViewerLinks: request.includeImagingViewerLinks
    };
  }
  function runningJobElapsedMessage(startedAt, now = Date.now(), moduleProgress) {
    const elapsedSeconds = Number.isFinite(startedAt) && Number.isFinite(now) ? Math.max(0, Math.floor((now - startedAt) / 1e3)) : 0;
    const progress = moduleProgress && Number.isInteger(moduleProgress.total) && moduleProgress.total > 0 && Number.isInteger(moduleProgress.completed) ? `\uFF08${Math.min(Math.max(0, moduleProgress.completed), moduleProgress.total)}/${moduleProgress.total} \u9805\uFF09` : "";
    return `\u6B63\u5728\u53D6\u5F97\u8CC7\u6599 ${elapsedSeconds} \u79D2${progress}\uFF0C\u53EF\u95DC\u9589\u8996\u7A97\u3002`;
  }
  function hasAvailableBackgroundResult(status) {
    return status.hasResult && ["complete", "downloaded", "handed-off"].includes(status.phase);
  }

  // src/background-result-storage.ts
  var RESULT_DATABASE_NAME = "cloud-wildcatch-background-results-v1";
  var RESULT_DATABASE_VERSION = 1;
  var RESULT_STORE_NAME = "results";
  var CURRENT_RESULT_KEY = "current";
  var databasePromise = null;
  function base64ToBytes(value) {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }
  async function decodeBackgroundPayload(payload, runId) {
    const stored = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
    const keyRecord = stored[BACKGROUND_RESULT_ENCRYPTION_KEY];
    if (!isSessionEncryptionKey(keyRecord) || keyRecord.runId !== runId) {
      throw new Error("\u9019\u6B21\u66AB\u5B58\u8CC7\u6599\u7684\u89E3\u5BC6\u91D1\u9470\u5DF2\u5931\u6548");
    }
    const rawKey = base64ToBytes(keyRecord.rawKey);
    const rawKeyBuffer = new ArrayBuffer(rawKey.byteLength);
    new Uint8Array(rawKeyBuffer).set(rawKey);
    const encryptionKey = await crypto.subtle.importKey(
      "raw",
      rawKeyBuffer,
      { name: "AES-GCM" },
      false,
      ["decrypt"]
    );
    const compressedBuffer = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(payload.iv) },
      encryptionKey,
      payload.data
    );
    const json = await new Response(
      new Blob([compressedBuffer]).stream().pipeThrough(new DecompressionStream("gzip"))
    ).text();
    if (new TextEncoder().encode(json).byteLength !== payload.uncompressedBytes) {
      throw new Error("\u66AB\u5B58\u8CC7\u6599\u5927\u5C0F\u4E0D\u7B26");
    }
    return json;
  }
  async function decodeBackgroundBundle(result) {
    if (result.schemaVersion === 1) return JSON.stringify(result.bundle);
    let compressedBuffer;
    if (result.schemaVersion === 2) {
      const compressed = base64ToBytes(result.data);
      compressedBuffer = new ArrayBuffer(compressed.byteLength);
      new Uint8Array(compressedBuffer).set(compressed);
    } else if (result.schemaVersion === 3) {
      compressedBuffer = result.data;
    } else {
      const stored = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
      const keyRecord = stored[BACKGROUND_RESULT_ENCRYPTION_KEY];
      if (!isSessionEncryptionKey(keyRecord) || keyRecord.runId !== result.runId) {
        throw new Error("\u9019\u6B21\u5065\u5EB7\u7D00\u9304\u7684\u66AB\u5B58\u89E3\u5BC6\u91D1\u9470\u5DF2\u5931\u6548");
      }
      const rawKey = base64ToBytes(keyRecord.rawKey);
      const rawKeyBuffer = new ArrayBuffer(rawKey.byteLength);
      new Uint8Array(rawKeyBuffer).set(rawKey);
      const encryptionKey = await crypto.subtle.importKey(
        "raw",
        rawKeyBuffer,
        { name: "AES-GCM" },
        false,
        ["decrypt"]
      );
      compressedBuffer = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: new Uint8Array(result.iv) },
        encryptionKey,
        result.data
      );
    }
    const json = await new Response(
      new Blob([compressedBuffer]).stream().pipeThrough(new DecompressionStream("gzip"))
    ).text();
    const actualBytes = new TextEncoder().encode(json).byteLength;
    if (actualBytes !== result.uncompressedBytes) {
      throw new Error("\u66AB\u5B58\u5065\u5EB7\u7D00\u9304\u5927\u5C0F\u4E0D\u7B26");
    }
    if (result.schemaVersion !== 4) JSON.parse(json);
    return json;
  }
  function openResultDatabase() {
    if (databasePromise) return databasePromise;
    const opening = new Promise((resolve, reject) => {
      const request = indexedDB.open(RESULT_DATABASE_NAME, RESULT_DATABASE_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(RESULT_STORE_NAME)) {
          database.createObjectStore(RESULT_STORE_NAME, { keyPath: "key" });
        }
      };
      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => {
          database.close();
          databasePromise = null;
        };
        resolve(database);
      };
      request.onerror = () => reject(request.error ?? new Error("\u7121\u6CD5\u958B\u555F\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593"));
      request.onblocked = () => reject(new Error("\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593\u6B63\u5728\u66F4\u65B0\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66"));
    }).catch((error) => {
      databasePromise = null;
      throw error;
    });
    databasePromise = opening;
    return opening;
  }
  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u64CD\u4F5C\u5931\u6557"));
    });
  }
  function transactionComplete(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u5931\u6557"));
      transaction.onabort = () => reject(transaction.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u5DF2\u4E2D\u6B62"));
    });
  }
  async function readBackgroundResult(runId) {
    const database = await openResultDatabase();
    const transaction = database.transaction(RESULT_STORE_NAME, "readonly");
    const completed = transactionComplete(transaction);
    const record = await requestResult(
      transaction.objectStore(RESULT_STORE_NAME).get(CURRENT_RESULT_KEY)
    );
    await completed;
    if (!record || !isStoredResultRecord(record)) return null;
    if (runId && record.result.runId !== runId) return null;
    return record.result;
  }
  async function clearBackgroundResults(runId) {
    const database = await openResultDatabase();
    const transaction = database.transaction(RESULT_STORE_NAME, "readwrite");
    const completed = transactionComplete(transaction);
    const store = transaction.objectStore(RESULT_STORE_NAME);
    if (runId) {
      const record = await requestResult(store.get(CURRENT_RESULT_KEY));
      if (!record || !isStoredResultRecord(record) || record.result.runId === runId) {
        store.delete(CURRENT_RESULT_KEY);
      }
    } else {
      store.clear();
    }
    await completed;
    const stored = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
    const keyRecord = stored[BACKGROUND_RESULT_ENCRYPTION_KEY];
    if (!runId || !isSessionEncryptionKey(keyRecord) || keyRecord.runId === runId) {
      await chrome.storage.session.remove(BACKGROUND_RESULT_ENCRYPTION_KEY);
    }
  }
  function isStoredResultRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    if (record.key !== CURRENT_RESULT_KEY) return false;
    return isBackgroundJobResult(record.result);
  }
  function isSessionEncryptionKey(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return record.schemaVersion === 1 && typeof record.runId === "string" && typeof record.rawKey === "string" && record.rawKey.length > 0;
  }

  // src/module-labels.ts
  var MEDCLOUD_MODULE_LABELS = Object.fromEntries(
    MEDCLOUD_CLINICAL_MODULES.map((module) => [module.sourceModule, module.label])
  );

  // src/popup-model.ts
  function buildMedcloudFilename(maskedId, capturedAt, version, partial = false) {
    const pad = (value) => String(value).padStart(2, "0");
    const capturedDate = `${capturedAt.getFullYear()}${pad(capturedAt.getMonth() + 1)}${pad(capturedAt.getDate())}`;
    const rawId = String(maskedId ?? "").trim().toUpperCase();
    const privacySafeId = /^[A-Z][12]\d{8}$/.test(rawId) ? `${rawId.slice(0, 6)}XXXX` : rawId;
    const normalizedId = privacySafeId.trim().replace(/[Xx*＊•●．・]/g, "X");
    const safeId = (normalizedId || "unknown").replace(/[^A-Za-z0-9_-]/g, "_");
    const safeVersion = String(version || "unknown").replace(/[^A-Za-z0-9._-]/g, "_");
    return `medcloud-${safeId}-${capturedDate}-v${safeVersion}${partial ? "-partial" : ""}.json`;
  }
  function buildMedcloudRawFilename(maskedId, capturedAt, version) {
    return buildMedcloudFilename(maskedId, capturedAt, version).replace(/^medcloud-/, "medcloud-raw-");
  }
  function normalizeWizardStep(step) {
    if (!Number.isFinite(step)) return 1;
    return Math.max(1, Math.min(3, Math.trunc(step)));
  }
  var RESOURCE_LABELS = {
    Patient: "\u75C5\u4EBA\u8CC7\u6599",
    Encounter: "\u5C31\u91AB\u7D00\u9304",
    Condition: "\u8A3A\u65B7\u7D00\u9304",
    Observation: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C",
    DiagnosticReport: "\u6AA2\u67E5\u5831\u544A",
    ServiceRequest: "\u6AA2\u67E5\u5B89\u6392",
    ImagingStudy: "\u5F71\u50CF\u6AA2\u67E5",
    MedicationRequest: "\u7528\u85E5\u7D00\u9304",
    MedicationDispense: "\u9818\u85E5\u7D00\u9304",
    Procedure: "\u8655\u7F6E\u7D00\u9304",
    DocumentReference: "\u75C5\u6B77\u6458\u8981",
    AllergyIntolerance: "\u904E\u654F\u7D00\u9304",
    Immunization: "\u9810\u9632\u63A5\u7A2E",
    Organization: "\u91AB\u7642\u9662\u6240",
    Provenance: "\u8CC7\u6599\u4F86\u6E90\u7D00\u9304"
  };
  var DETAIL_LABEL_ORDER = [
    "\u75C5\u4EBA\u8CC7\u6599",
    "\u5C31\u91AB\u7D00\u9304",
    "\u8A3A\u65B7\u7D00\u9304",
    "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C",
    "\u6AA2\u67E5\u5831\u544A",
    "\u6AA2\u67E5\u5B89\u6392",
    "\u5F71\u50CF\u6AA2\u67E5",
    "\u7528\u85E5\u7D00\u9304",
    "\u9818\u85E5\u7D00\u9304",
    "\u8655\u7F6E\u7D00\u9304",
    "\u75C5\u6B77\u6458\u8981",
    "\u904E\u654F\u7D00\u9304",
    "\u9810\u9632\u63A5\u7A2E",
    "\u91AB\u7642\u9662\u6240",
    "\u8CC7\u6599\u4F86\u6E90\u7D00\u9304",
    "\u5176\u4ED6\u8CC7\u6599"
  ];
  function formatResultElapsed(milliseconds) {
    if (!Number.isFinite(milliseconds) || Number(milliseconds) < 0) return "";
    const seconds = Math.max(0, Math.round(Number(milliseconds) / 1e3));
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return remainingSeconds > 0 ? `${minutes}m ${remainingSeconds}s` : `${minutes}m`;
  }
  function formatResultAge(completedAt, now = Date.now()) {
    if (!Number.isFinite(completedAt) || Number(completedAt) <= 0) return "";
    const elapsed = Math.max(0, now - Number(completedAt));
    const minutes = Math.floor(elapsed / 6e4);
    if (minutes < 1) return "\u525B\u525B\u5B8C\u6210";
    if (minutes < 60) return `${minutes} \u5206\u9418\u524D`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} \u5C0F\u6642\u524D`;
    return `${Math.floor(hours / 24)} \u5929\u524D`;
  }
  var ERROR_REASON = {
    HTTP_0: "\u4F86\u6E90\u7AEF\u9EDE\u6C92\u6709\u56DE\u61C9",
    HTTP_413: "\u4F86\u6E90\u56DE\u61C9\u8D85\u904E\u53EF\u5B89\u5168\u8655\u7406\u7684\u5927\u5C0F",
    INVALID_JSON: "\u4F86\u6E90\u56DE\u50B3\u5167\u5BB9\u4E0D\u662F\u6709\u6548 JSON",
    INVALID_RESPONSE: "\u4F86\u6E90\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u7248\u672C\u4E0D\u7B26",
    NO_VALID_ROWS: "\u4F86\u6E90\u5217\u5168\u90E8\u4E0D\u7B26\u5408\u76EE\u524D\u652F\u63F4\u683C\u5F0F",
    ADAPTER_EXCEPTION: "\u6A21\u7D44\u8F49\u63DB\u7A0B\u5F0F\u767C\u751F\u4F8B\u5916"
  };
  var WARNING_REASON = {
    "access-restricted": () => "\u76EE\u524D\u91AB\u4E8B\u4EBA\u54E1\u5361\u7121\u6B64\u9805\u8CC7\u6599\u6B0A\u9650",
    "http-error": () => "\u4F86\u6E90\u7AEF\u9EDE\u53D6\u5F97\u5931\u6557",
    "invalid-json": () => "\u4F86\u6E90\u56DE\u50B3\u5167\u5BB9\u4E0D\u662F\u6709\u6548 JSON",
    "invalid-response": () => "\u4F86\u6E90\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u7248\u672C\u4E0D\u7B26",
    "invalid-row": (count) => `${count} \u500B\u4F86\u6E90\u6B04\u4F4D\u4E0D\u7B26\u5408\u76EE\u524D\u652F\u63F4\u683C\u5F0F`,
    "unknown-field": (count) => `\u4F86\u6E90\u51FA\u73FE ${count} \u500B\u5C1A\u672A\u652F\u63F4\u7684\u65B0\u6B04\u4F4D\uFF08\u5DF2\u5FFD\u7565\uFF09`,
    "invalid-date": (count) => `${count} \u500B\u65E5\u671F\u7121\u6CD5\u8FA8\u8B58`,
    "missing-clinical-content": (count) => `${count} \u7B46\u7F3A\u5C11\u53EF\u8F49\u63DB\u7684\u81E8\u5E8A\u5167\u5BB9`
  };
  var FHIR_ISSUE_REASON = {
    "duplicate-resource-identity": "\u8F49\u63DB\u5F8C\u767C\u751F\u91CD\u8907\u8CC7\u6E90\u8B58\u5225",
    "unresolved-reference": "FHIR \u8CC7\u6E90\u542B\u7121\u6CD5\u89E3\u6790\u7684\u53C3\u7167",
    "duplicate-full-url": "FHIR Bundle \u51FA\u73FE\u91CD\u8907 fullUrl",
    "resource-identity-mismatch": "FHIR resource id \u8207 fullUrl \u4E0D\u4E00\u81F4"
  };
  function positiveInteger(value) {
    return Number.isInteger(value) && Number(value) > 0 ? Number(value) : 0;
  }
  function moduleReason(module) {
    const dropped = positiveInteger(module.droppedResourceCount);
    const errorCode = typeof module.errorCode === "string" ? module.errorCode : "";
    if (errorCode) return ERROR_REASON[errorCode] ?? `\u6A21\u7D44\u8655\u7406\u5931\u6557\uFF08${errorCode}\uFF09`;
    if (dropped > 0) {
      const issueReason = (module.issueCodes ?? []).map((code) => FHIR_ISSUE_REASON[code]).find(Boolean);
      return `${dropped} \u7B46\u8F49\u63DB\u5F8C\u672A\u7D0D\u5165${issueReason ? `\uFF1A${issueReason}` : ""}`;
    }
    const warnings = Object.entries(module.warningCounts ?? {}).filter(([, count]) => positiveInteger(count) > 0).sort(([left], [right]) => left.localeCompare(right));
    const actionableWarning = warnings.map(([code, count]) => WARNING_REASON[code]?.(positiveInteger(count))).find(Boolean);
    if (actionableWarning) return actionableWarning;
    const warningCount = positiveInteger(module.warningCount);
    if (warningCount > 0) return `\u6709 ${warningCount} \u500B\u683C\u5F0F\u8B66\u544A`;
    return module.completeness === "failed" ? "\u6B64\u6A21\u7D44\u6C92\u6709\u7522\u751F\u53EF\u7528\u8CC7\u6599" : "\u6B64\u6A21\u7D44\u8CC7\u6599\u4E0D\u5B8C\u6574";
  }
  function moduleDiagnostic(module) {
    const parts = [module.sourceModule, module.completeness.toUpperCase()];
    const records = positiveInteger(module.sourceRecordCount);
    if (records > 0) parts.push(`RECORDS=${records}`);
    if (module.errorCode) parts.push(`ERROR=${module.errorCode}`);
    const warnings = Object.entries(module.warningCounts ?? {}).filter(([, count]) => positiveInteger(count) > 0).sort(([left], [right]) => left.localeCompare(right)).map(([code, count]) => `${code}:${positiveInteger(count)}`);
    if (warnings.length > 0) parts.push(`WARN=${warnings.join(",")}`);
    const dropped = positiveInteger(module.droppedResourceCount);
    if (dropped > 0) parts.push(`DROPPED=${dropped}`);
    if (module.issueCodes?.length) parts.push(`ISSUE=${[...module.issueCodes].sort().join(",")}`);
    return parts.join(" | ");
  }
  function incompleteModuleDetails(moduleStatuses, droppedResources = []) {
    return (moduleStatuses ?? []).filter(
      (module) => module.completeness === "partial" || module.completeness === "failed"
    ).map((module) => {
      const sourceWarnings = (module.warningLocations ?? []).map((warning) => {
        const documentRow = /^_cloudWildcatchDocuments\[(\d+)\]\.html$/.exec(warning.path);
        const sourceRow = /^robject\[(\d+)\](?:\.(.+))?$/.exec(warning.path);
        const label = documentRow ? `\u4F86\u6E90\u7B2C ${Number(documentRow[1]) + 1} \u7B46\uFF08robject[${documentRow[1]}]\uFF09\uFF1A\u672A\u5EFA\u7ACB DocumentReference` : sourceRow ? `\u4F86\u6E90\u7B2C ${Number(sourceRow[1]) + 1} \u7B46\uFF08robject[${sourceRow[1]}]\uFF09${sourceRow[2] ? `\u6B04\u4F4D ${sourceRow[2]}` : ""}` : `\u4F86\u6E90\u4F4D\u7F6E ${warning.path}${warning.field ? `\uFF08\u6B04\u4F4D ${warning.field}\uFF09` : ""}`;
        return {
          kind: "source",
          label,
          diagnostic: `${warning.code} | PATH=${warning.path}`
        };
      });
      const dropped = droppedResources.filter((resource) => resource.sourceModule === module.sourceModule).map((resource) => ({
        kind: "resource",
        label: `${resource.resourceType}/${resource.id ?? "(\u7121 ID)"}`,
        diagnostic: [...resource.issueCodes].sort().join(",")
      }));
      return {
        sourceModule: module.sourceModule,
        label: MEDCLOUD_MODULE_LABELS[module.sourceModule] ?? module.sourceModule,
        completeness: module.completeness,
        reason: moduleReason(module),
        diagnostic: moduleDiagnostic(module),
        affectedRecords: [...sourceWarnings, ...dropped]
      };
    });
  }
  function partialDiagnosticText(summary, version) {
    const modules = incompleteModuleDetails(summary.moduleStatuses, summary.droppedResources);
    const lines = [
      `Cloud Wildcatch v${version} partial diagnostics`,
      ...modules.flatMap((module) => [
        `${module.label}: ${module.diagnostic}`,
        ...module.affectedRecords.map(
          (record) => `  ${record.kind === "source" ? "SOURCE" : "RESOURCE"} ${record.label} | ${record.diagnostic}`
        )
      ])
    ];
    const dropped = positiveInteger(summary.droppedResourceCount);
    if (dropped > 0) lines.push(`TOTAL_DROPPED=${dropped}`);
    if (modules.length === 0 && dropped === 0) lines.push("NO_PARTIAL_DETAILS");
    return lines.join("\n");
  }
  function presentBundleSummary(summary) {
    const resourceEntries = Object.entries(summary.resourceCounts).filter(([, count]) => Number.isFinite(count) && count > 0).sort(([left], [right]) => left.localeCompare(right));
    const totalResources = resourceEntries.reduce((sum, [, count]) => sum + count, 0);
    const detailCountByLabel = /* @__PURE__ */ new Map();
    for (const [resourceType, count] of resourceEntries) {
      const label = RESOURCE_LABELS[resourceType] ?? "\u5176\u4ED6\u8CC7\u6599";
      detailCountByLabel.set(label, (detailCountByLabel.get(label) ?? 0) + count);
    }
    const detailRows = DETAIL_LABEL_ORDER.filter((label) => detailCountByLabel.has(label)).map((label) => ({ label, count: detailCountByLabel.get(label) }));
    const incompleteModuleCount = summary.moduleStatuses.filter(
      (module) => module.completeness === "partial" || module.completeness === "failed"
    ).length;
    const droppedResourceCount = Number.isFinite(summary.droppedResourceCount) ? Math.max(0, Number(summary.droppedResourceCount)) : 0;
    const baseNote = "\u4ECD\u53EF\u4E0B\u8F09\u6216\u65BC MediPrisma \u67E5\u770B\uFF1B\u6A94\u6848\u6703\u4FDD\u7559\u300C\u8CC7\u6599\u4E0D\u5B8C\u6574\u300D\u6A19\u8A18\uFF0C\u4F7F\u7528\u6642\u8ACB\u56DE\u539F\u59CB\u7CFB\u7D71\u6838\u5C0D\u7F3A\u6F0F\u5167\u5BB9\u3002";
    const incompleteModules = incompleteModuleDetails(summary.moduleStatuses, summary.droppedResources);
    const problemScope = incompleteModules.length > 0 ? `\u554F\u984C\u4F86\u6E90\uFF1A${incompleteModules.map((module) => module.label).join("\u3001")}\u3002` : "";
    return {
      canDownload: summary.validation.valid,
      hasIncompleteModules: incompleteModuleCount > 0 || droppedResourceCount > 0,
      incompleteModuleCount,
      droppedResourceCount,
      totalResources,
      summaryText: `\u5171 ${totalResources} \u7B46\u5065\u5EB7\u7D00\u9304`,
      completenessNote: `${problemScope}${droppedResourceCount > 0 ? `\u5176\u4E2D ${droppedResourceCount} \u7B46\u56E0\u683C\u5F0F\u7121\u6CD5\u8F49\u63DB\u800C\u672A\u7D0D\u5165\u3002` : ""}${baseNote}`,
      incompleteModules,
      detailRows
    };
  }

  // src/mediprisma-permission.ts
  async function requestMediPrismaPermission(runId) {
    const manifest = chrome.runtime.getManifest();
    const declared = manifest.host_permissions ?? [];
    const optionalDeclared = manifest.optional_host_permissions ?? [];
    const required = MEDIPRISMA_ORIGIN_PATTERNS.filter((pattern) => declared.includes(pattern));
    const optional = MEDIPRISMA_ORIGIN_PATTERNS.filter(
      (pattern) => optionalDeclared.includes(pattern)
    );
    if (required.length === 0 && optional.length === 0) {
      return {
        granted: false,
        reason: "\u76EE\u524D\u8F09\u5165\u7684\u64F4\u5145\u529F\u80FD\u9084\u6C92\u6709 MediPrisma \u6B0A\u9650\u8A2D\u5B9A\uFF0C\u8ACB\u5230 chrome://extensions \u91CD\u65B0\u8F09\u5165\u5F8C\u518D\u8A66\u3002"
      };
    }
    const armPromise = chrome.runtime.sendMessage({
      type: ARM_MEDIPRISMA_HANDOFF,
      runId
    });
    if (required.length > 0) {
      const armed = await armPromise.catch(() => void 0);
      return armed?.ok ? { granted: true } : {
        granted: false,
        reason: armed?.error || "\u76EE\u524D\u7121\u6CD5\u6E96\u5099\u5728 MediPrisma \u67E5\u770B\u3002"
      };
    }
    const disarm = async () => {
      await armPromise.catch(() => void 0);
      await chrome.runtime.sendMessage({ type: DISARM_MEDIPRISMA_HANDOFF }).catch(() => void 0);
    };
    try {
      const granted = await chrome.permissions.request({
        origins: [...optional]
      });
      if (!granted) {
        await disarm();
        return {
          granted: false,
          reason: "\u5C1A\u672A\u5141\u8A31 MediPrisma \u7DB2\u7AD9\u5B58\u53D6\uFF1B\u5065\u5EB7\u7D00\u9304\u6C92\u6709\u9001\u51FA\u3002"
        };
      }
      const armed = await armPromise;
      if (!armed?.ok) {
        return {
          granted: false,
          reason: armed?.error || "\u76EE\u524D\u7121\u6CD5\u6E96\u5099\u5728 MediPrisma \u67E5\u770B\u3002"
        };
      }
      return { granted: true };
    } catch {
      await disarm();
      return {
        granted: false,
        reason: "Chrome \u7121\u6CD5\u986F\u793A MediPrisma \u6B0A\u9650\u8981\u6C42\uFF1B\u5065\u5EB7\u7D00\u9304\u6C92\u6709\u9001\u51FA\u3002"
      };
    }
  }

  // src/source/medcloud.ts
  var MEDCLOUD_ORIGIN = "https://medcloud2.nhi.gov.tw";
  var MEDCLOUD_MODULES = MEDCLOUD_CLINICAL_MODULES;
  var MediCloudAcquisitionError = class extends Error {
    constructor(code, sourceModule) {
      super(code);
      this.code = code;
      this.sourceModule = sourceModule;
      this.name = "MediCloudAcquisitionError";
    }
    code;
    sourceModule;
  };
  var PATIENT_CONTEXT_HMAC_KEY = "cloud-wildcatch:patient-context-hmac-key-v1";
  var patientContextHmacKeyPromise = null;
  function randomPatientContextHmacKey() {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/u, "");
  }
  async function readOrCreatePatientContextHmacKey() {
    const stored = await chrome.storage.session.get(PATIENT_CONTEXT_HMAC_KEY);
    const existing = stored[PATIENT_CONTEXT_HMAC_KEY];
    if (typeof existing === "string" && /^[A-Za-z0-9_-]{43}$/u.test(existing)) {
      return existing;
    }
    const created = randomPatientContextHmacKey();
    await chrome.storage.session.set({ [PATIENT_CONTEXT_HMAC_KEY]: created });
    return created;
  }
  async function getPatientContextHmacKey() {
    if (!patientContextHmacKeyPromise) {
      const create = () => readOrCreatePatientContextHmacKey();
      const pending = typeof navigator !== "undefined" && navigator.locks ? navigator.locks.request(
        PATIENT_CONTEXT_HMAC_KEY,
        create
      ) : create();
      patientContextHmacKeyPromise = pending;
      void pending.catch(() => {
        patientContextHmacKeyPromise = null;
      });
    }
    return patientContextHmacKeyPromise;
  }
  async function probeMediCloudPatientInPage(origin, patientContextHmacKey) {
    if (location.origin !== origin || !location.pathname.startsWith("/imu/")) {
      return { ok: false, code: "NOT_MEDCLOUD" };
    }
    const readPatientIdentity = () => {
      let roots = Array.from(document.querySelectorAll(".member-info"));
      if (roots.length === 0) {
        roots = Array.from(document.querySelectorAll(
          ".patient-info, .patient-data, [class*='memberInfo'], [class*='patient-info']"
        ));
      }
      const candidates = roots.slice(0, 50).flatMap((root) => {
        const text = (value) => (value ?? "").replace(/\s+/g, " ").trim();
        const field = (selector) => text(root.querySelector(selector)?.textContent);
        const rootText = text(root.textContent);
        const idText = field(".idno") || rootText;
        const fullId2 = /\b[A-Z][12]\d{8}\b/i.exec(idText)?.[0] ?? "";
        const maskedId2 = /\b[A-Z][12]\d{2}[Xx*•●．・]{2,4}\d{2,4}/i.exec(idText)?.[0] ?? "";
        const idToken = (fullId2 || maskedId2).toUpperCase().replace(/[Xx*•●．・]/g, "X");
        if (!idToken) return [];
        const structuredName = field(".name");
        const name = structuredName ? text(structuredName.replace(/^(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*/, "")) : /(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*([^\s｜|,，;；]{2,8})/.exec(rootText)?.[1] ?? "";
        const structuredBirth = field(".birth");
        const birth2 = structuredBirth ? text(structuredBirth.replace(/^(?:出生年月日|出生日期|生日)\s*[:：]?\s*/, "")) : /(?:出生年月日|出生日期|生日)\s*[:：]?\s*(\d{2,4}[\/.\-年]\d{1,2}[\/.\-月]\d{1,2})/.exec(rootText)?.[1] ?? "";
        const structuredSex = field(".sex");
        const sex = structuredSex ? text(structuredSex.replace(/^(?:生理性別|性別)\s*[:：]?\s*/, "")) : /(?:生理性別|性別)\s*[:：]?\s*(男|女|其他|未知|male|female)/i.exec(rootText)?.[1] ?? "";
        const context = [idToken, name, birth2, sex].join("\n");
        return [{ context, idToken, name, birth: birth2, sex, visible: root.getClientRects().length > 0 }];
      });
      const preferred = candidates.some((candidate) => candidate.visible) ? candidates.filter((candidate) => candidate.visible) : candidates;
      const unique = new Map(preferred.map((candidate) => [candidate.context, candidate]));
      if (unique.size !== 1) return null;
      const identity2 = unique.values().next().value;
      if (!identity2) return null;
      return {
        context: identity2.context,
        idToken: identity2.idToken,
        name: identity2.name,
        birth: identity2.birth,
        sex: identity2.sex
      };
    };
    const identity = readPatientIdentity();
    if (!identity) return { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    let digest;
    try {
      const padded = patientContextHmacKey.replace(/-/g, "+").replace(/_/g, "/") + "=";
      const rawKey = Uint8Array.from(atob(padded), (character) => character.charCodeAt(0));
      if (rawKey.byteLength !== 32) throw new Error("invalid patient-context key");
      const key = await crypto.subtle.importKey(
        "raw",
        rawKey,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      digest = await crypto.subtle.sign(
        "HMAC",
        key,
        new TextEncoder().encode(`nhi-medcloud-patient-context-v1
${identity.context}`)
      );
    } catch {
      return { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    }
    const patientContextHash = Array.from(
      new Uint8Array(digest),
      (byte) => byte.toString(16).padStart(2, "0")
    ).join("");
    const fullId = /\b[A-Z][12]\d{8}\b/i.exec(identity.idToken)?.[0] ?? "";
    const privacySafeId = fullId ? `${fullId.slice(0, 6)}XXXX` : identity.idToken.replace(/X/g, "X");
    const maskedName = identity.name ? `${identity.name[0] ?? ""}O${identity.name.length > 2 ? identity.name.at(-1) ?? "" : ""}` : "";
    const maskedId = privacySafeId.replace(/X/g, "\u2022");
    const birth = /(\d{2,4})[\/.\-年](\d{1,2})[\/.\-月](\d{1,2})/.exec(identity.birth);
    let age = "";
    let birthDate = "";
    if (birth) {
      const yearToken = birth[1] ?? "";
      let year = Number(yearToken);
      if (yearToken.length <= 3 && year > 0) year += 1911;
      const month = Number(birth[2]);
      const day = Number(birth[3]);
      const candidate = new Date(Date.UTC(year, month - 1, day));
      if (candidate.getUTCFullYear() === year && candidate.getUTCMonth() + 1 === month && candidate.getUTCDate() === day) {
        const now = /* @__PURE__ */ new Date();
        let years = now.getFullYear() - year;
        if (now.getMonth() + 1 < month || now.getMonth() + 1 === month && now.getDate() < day) years -= 1;
        if (years >= 0 && years <= 150) {
          birthDate = `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
          age = `${years}\u6B72`;
        }
      }
    }
    const genderRaw = identity.sex.toLowerCase();
    const gender = genderRaw === "male" ? "\u7537" : genderRaw === "female" ? "\u5973" : genderRaw;
    const genderCode = genderRaw === "male" || genderRaw === "\u7537" || genderRaw === "\u7537\u6027" ? "male" : genderRaw === "female" || genderRaw === "\u5973" || genderRaw === "\u5973\u6027" ? "female" : genderRaw === "\u5176\u4ED6" ? "other" : "unknown";
    const display = [maskedName, age, gender, maskedId].filter(Boolean).join("  \xB7  ") || `\u75C5\u4EBA ${patientContextHash.slice(0, 8)}\u2026`;
    return {
      ok: true,
      patientContextHash,
      display,
      identity: {
        maskedId: privacySafeId,
        name: identity.name,
        ...birthDate ? { birthDate } : {},
        gender: genderCode
      }
    };
  }
  async function probeMediCloudPatient(tabId) {
    try {
      const patientContextHmacKey = await getPatientContextHmacKey();
      const results = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: probeMediCloudPatientInPage,
        args: [MEDCLOUD_ORIGIN, patientContextHmacKey]
      });
      return results[0]?.result ?? { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    } catch {
      return { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    }
  }
  async function captureMediCloudInPage(request) {
    const fail = (code, sourceModule) => ({
      ok: false,
      code,
      ...sourceModule && /^IMUE\d{4}$/.test(sourceModule) ? { sourceModule } : {}
    });
    if (location.origin !== request.origin || !location.pathname.startsWith("/imu/")) {
      return fail("NOT_MEDCLOUD");
    }
    const CAPTURE_REGISTRY_KEY = "__cloudWildcatchCaptureRegistryV1";
    const CLINICAL_RESPONSE_LIMIT_BYTES = 5e7;
    const MODULE_REQUEST_TIMEOUT_MS = 3e4;
    const VIEWER_REQUEST_TIMEOUT_MS = 15e3;
    const OVERALL_CAPTURE_TIMEOUT_MS = 3 * 6e4;
    const pageWindow = window;
    const registry = pageWindow[CAPTURE_REGISTRY_KEY] instanceof Map ? pageWindow[CAPTURE_REGISTRY_KEY] : /* @__PURE__ */ new Map();
    pageWindow[CAPTURE_REGISTRY_KEY] = registry;
    const supersededState = registry.get(request.runId);
    if (supersededState) {
      supersededState.cancelled = true;
      for (const controller of supersededState.controllers ?? []) controller.abort();
    }
    const captureState = {
      controllers: /* @__PURE__ */ new Set(),
      cancelled: false,
      completedModules: 0,
      totalModules: request.modules.length
    };
    registry.set(request.runId, captureState);
    const captureDeadline = Date.now() + OVERALL_CAPTURE_TIMEOUT_MS;
    const originalFetch = window.fetch;
    const boundedFetchText = async (input, init, timeoutMs, maxBytes) => {
      if (captureState.cancelled) throw new DOMException("Capture cancelled", "AbortError");
      const remainingMs = captureDeadline - Date.now();
      if (remainingMs <= 0) throw new DOMException("Capture deadline exceeded", "TimeoutError");
      const controller = new AbortController();
      captureState.controllers.add(controller);
      const timer = window.setTimeout(
        () => controller.abort(new DOMException("Request timed out", "TimeoutError")),
        Math.max(1, Math.min(timeoutMs, remainingMs))
      );
      try {
        const response = await originalFetch.call(window, input, {
          ...init,
          signal: controller.signal
        });
        const declaredLength = Number(response.headers.get("content-length"));
        if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
          controller.abort();
          return { status: response.status, ok: response.ok, text: "", tooLarge: true };
        }
        if (!response.body) {
          return { status: response.status, ok: response.ok, text: "", tooLarge: false };
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        const parts = [];
        let totalBytes = 0;
        while (true) {
          const chunk = await reader.read();
          if (chunk.done) break;
          totalBytes += chunk.value.byteLength;
          if (totalBytes > maxBytes) {
            await reader.cancel().catch(() => void 0);
            controller.abort();
            return { status: response.status, ok: response.ok, text: "", tooLarge: true };
          }
          parts.push(decoder.decode(chunk.value, { stream: true }));
        }
        parts.push(decoder.decode());
        return { status: response.status, ok: response.ok, text: parts.join(""), tooLarge: false };
      } finally {
        window.clearTimeout(timer);
        captureState.controllers.delete(controller);
      }
    };
    try {
      let patchedSetRequestHeader2 = function(name, value) {
        if (name.toLowerCase() === "authorization") captureAuthorization(value);
        originalSetRequestHeader.call(this, name, value);
      }, patchedFetch2 = function(input, init) {
        const headers = new Headers(input instanceof Request ? input.headers : void 0);
        new Headers(init?.headers).forEach((value, name) => headers.set(name, value));
        captureAuthorization(headers.get("authorization"));
        return originalFetch.call(window, input, init);
      };
      var patchedSetRequestHeader = patchedSetRequestHeader2, patchedFetch = patchedFetch2;
      const patientContextText = () => {
        let roots = Array.from(document.querySelectorAll(".member-info"));
        if (roots.length === 0) {
          roots = Array.from(document.querySelectorAll(
            ".patient-info, .patient-data, [class*='memberInfo'], [class*='patient-info']"
          ));
        }
        const candidates = roots.slice(0, 50).flatMap((root) => {
          const text = (value) => (value ?? "").replace(/\s+/g, " ").trim();
          const field = (selector) => text(root.querySelector(selector)?.textContent);
          const rootText = text(root.textContent);
          const idText = field(".idno") || rootText;
          const fullId = /\b[A-Z][12]\d{8}\b/i.exec(idText)?.[0] ?? "";
          const maskedId = /\b[A-Z][12]\d{2}[Xx*•●．・]{2,4}\d{2,4}/i.exec(idText)?.[0] ?? "";
          const idToken = (fullId || maskedId).toUpperCase().replace(/[Xx*•●．・]/g, "X");
          if (!idToken) return [];
          const structuredName = field(".name");
          const name = structuredName ? text(structuredName.replace(/^(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*/, "")) : /(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*([^\s｜|,，;；]{2,8})/.exec(rootText)?.[1] ?? "";
          const structuredBirth = field(".birth");
          const birth = structuredBirth ? text(structuredBirth.replace(/^(?:出生年月日|出生日期|生日)\s*[:：]?\s*/, "")) : /(?:出生年月日|出生日期|生日)\s*[:：]?\s*(\d{2,4}[\/.\-年]\d{1,2}[\/.\-月]\d{1,2})/.exec(rootText)?.[1] ?? "";
          const structuredSex = field(".sex");
          const sex = structuredSex ? text(structuredSex.replace(/^(?:生理性別|性別)\s*[:：]?\s*/, "")) : /(?:生理性別|性別)\s*[:：]?\s*(男|女|其他|未知|male|female)/i.exec(rootText)?.[1] ?? "";
          const context = [idToken, name, birth, sex].join("\n");
          return [{ context, visible: root.getClientRects().length > 0 }];
        });
        const preferred = candidates.some((candidate) => candidate.visible) ? candidates.filter((candidate) => candidate.visible) : candidates;
        const unique = new Set(preferred.map((candidate) => candidate.context));
        return unique.size === 1 ? unique.values().next().value ?? null : null;
      };
      const patientContextKeyBytes = Uint8Array.from(
        atob(request.patientContextHmacKey.replace(/-/g, "+").replace(/_/g, "/") + "="),
        (character) => character.charCodeAt(0)
      );
      const patientContextKey = await crypto.subtle.importKey(
        "raw",
        patientContextKeyBytes,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      const hashContext = async (value) => {
        const bytes = new TextEncoder().encode(`nhi-medcloud-patient-context-v1
${value}`);
        const digest = await crypto.subtle.sign("HMAC", patientContextKey, bytes);
        return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
      };
      const contextBeforeText = patientContextText();
      if (!contextBeforeText) return fail("PATIENT_CONTEXT_UNAVAILABLE");
      const patientContextHash = await hashContext(contextBeforeText);
      const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
      let resolveAuthorization;
      let authorization = "";
      const authorizationPromise = new Promise((resolve) => {
        resolveAuthorization = resolve;
      });
      const captureAuthorization = (value) => {
        const candidate = typeof value === "string" ? value.trim() : "";
        if (!authorization && /^Bearer\s+\S+$/i.test(candidate)) {
          authorization = candidate;
          resolveAuthorization?.(candidate);
        }
      };
      const waitForAuthorization = async (timeoutMs) => {
        if (authorization) return authorization;
        return Promise.race([
          authorizationPromise,
          new Promise((resolve) => window.setTimeout(() => resolve(null), timeoutMs))
        ]);
      };
      const visibleRouteLinks = () => Array.from(document.querySelectorAll('a[href^="/imu/IMUE1000/"]')).filter(
        (anchor) => anchor.getClientRects().length > 0
      );
      let authorizationForRun = null;
      const originalPath = location.pathname;
      let changedRoute = false;
      const routePaths = Array.from(new Set(
        visibleRouteLinks().map((anchor) => new URL(anchor.href, location.href).pathname)
      ));
      const candidatePaths = [
        originalPath,
        ...routePaths.filter((path) => path !== originalPath)
      ].slice(0, 6);
      XMLHttpRequest.prototype.setRequestHeader = patchedSetRequestHeader2;
      window.fetch = patchedFetch2;
      try {
        for (const [index, routePath] of candidatePaths.entries()) {
          if (captureState.cancelled) break;
          const route = visibleRouteLinks().find(
            (anchor) => new URL(anchor.href, location.href).pathname === routePath
          );
          if (!route) continue;
          route.click();
          if (routePath !== originalPath) changedRoute = true;
          authorizationForRun = await waitForAuthorization(index === 0 ? 1500 : 2500);
          if (authorizationForRun) break;
        }
      } finally {
        XMLHttpRequest.prototype.setRequestHeader = originalSetRequestHeader;
        window.fetch = originalFetch;
        if (changedRoute) {
          visibleRouteLinks().find((anchor) => new URL(anchor.href, location.href).pathname === originalPath)?.click();
        }
      }
      if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
      if (!authorizationForRun) return fail("AUTHORIZATION_UNAVAILABLE");
      if (await hashContext(patientContextText() ?? "") !== patientContextHash) {
        return fail("PATIENT_CONTEXT_CHANGED");
      }
      if (request.viewerRequest) {
        if (request.viewerRequest.expectedPatientContextHash !== patientContextHash) {
          return fail("PATIENT_CONTEXT_CHANGED");
        }
        const descriptor = request.viewerRequest.descriptor;
        const safePart = (value, maxLength) => {
          if (typeof value !== "string" || value.length > maxLength) return null;
          if (/[\u0000-\u001f\u007f@]/u.test(value)) return null;
          return value;
        };
        const iplCaseSeqNo = safePart(descriptor?.iplCaseSeqNo, 256);
        const readPos = safePart(descriptor?.readPos, 128);
        const fileType = safePart(descriptor?.fileType, 128);
        const fileQty = safePart(descriptor?.fileQty, 32);
        const feeYm = safePart(descriptor?.feeYm, 64);
        if (descriptor?.version !== 1 || descriptor?.procId !== "IMUE0130" || !iplCaseSeqNo || readPos === null || !["", "Y"].includes(descriptor?.ordMark ?? "invalid") || fileType === null || fileQty === null || feeYm === null) {
          return fail("VIEWER_REQUEST_INVALID");
        }
        const normalizeRocFeeYm = (value) => {
          const digits = value.replace(/\D/g, "");
          if (digits.length === 5) {
            const month = Number(digits.slice(3, 5));
            return month >= 1 && month <= 12 ? digits : "";
          }
          if (digits.length >= 6) {
            const year = Number(digits.slice(0, 4));
            const month = Number(digits.slice(4, 6));
            if (month < 1 || month > 12) return "";
            return year > 1911 ? `${year - 1911}${digits.slice(4, 6)}` : digits.slice(0, 5);
          }
          return "";
        };
        const basicFeeYmFromResponse = (value) => {
          const candidates = [value];
          const keys = [
            "body",
            "data",
            "value",
            "basic_fee_ym",
            "basicFeeYm",
            "fee_ym",
            "feeYm"
          ];
          for (let index = 0; index < candidates.length && index < 16; index += 1) {
            const candidate = candidates[index];
            if (typeof candidate === "string" || typeof candidate === "number") {
              const normalized = normalizeRocFeeYm(String(candidate));
              if (normalized) return normalized;
              continue;
            }
            if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue;
            const record = candidate;
            for (const key of keys) if (key in record) candidates.push(record[key]);
          }
          return "";
        };
        const isTrustedViewerUrl = (value) => {
          if (typeof value !== "string" || value.length === 0 || value.length > 1e5) return false;
          try {
            const viewerUrl = new URL(value);
            return viewerUrl.protocol === "https:" && viewerUrl.port === "" && viewerUrl.username === "" && viewerUrl.password === "" && (viewerUrl.hostname === "nhi.gov.tw" || viewerUrl.hostname.endsWith(".nhi.gov.tw"));
          } catch {
            return false;
          }
        };
        let basicFeeYm = "";
        try {
          const basicFeeResponse = await boundedFetchText(
            new URL("/imu/api/imuecommon/imuecommon/basic-fee-ym", request.origin).toString(),
            {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: { Accept: "application/json", Authorization: authorizationForRun }
            },
            VIEWER_REQUEST_TIMEOUT_MS,
            2e5
          );
          if (basicFeeResponse.status === 401 || basicFeeResponse.status === 403) {
            return fail("AUTHORIZATION_FAILED");
          }
          if (basicFeeResponse.tooLarge) return fail("RESPONSE_TOO_LARGE");
          const text = basicFeeResponse.text;
          let value = text;
          try {
            value = JSON.parse(text);
          } catch {
            value = text;
          }
          basicFeeYm = basicFeeYmFromResponse(value);
        } catch {
          basicFeeYm = "";
        }
        const rowFeeYm = normalizeRocFeeYm(feeYm);
        const ordMark = descriptor.ordMark === "Y" && (!basicFeeYm || !rowFeeYm || Number(rowFeeYm) <= Number(basicFeeYm)) ? "Y" : "";
        const clientData = [iplCaseSeqNo, readPos, ordMark, fileType, fileQty].join("@");
        for (let attempt = 0; attempt < 3; attempt += 1) {
          if (attempt > 0) await new Promise((resolve) => window.setTimeout(resolve, 750));
          if (await hashContext(patientContextText() ?? "") !== patientContextHash) {
            return fail("PATIENT_CONTEXT_CHANGED");
          }
          let response;
          try {
            response = await boundedFetchText(
              new URL("/imu/api/imuecommon/imuecommon/get-ctmri2", request.origin).toString(),
              {
                method: "POST",
                credentials: "include",
                cache: "no-store",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json;charset=UTF-8",
                  Authorization: authorizationForRun
                },
                body: JSON.stringify({ ProcID: descriptor.procId, ClientData: clientData })
              },
              VIEWER_REQUEST_TIMEOUT_MS,
              2e5
            );
          } catch {
            continue;
          }
          if (response.status === 401 || response.status === 403) {
            return fail("AUTHORIZATION_FAILED");
          }
          const text = response.text;
          if (response.ok && !response.tooLarge) {
            try {
              const parsed = JSON.parse(text);
              const viewerUrl = parsed.ctmri_url ?? parsed.body?.ctmri_url;
              if (isTrustedViewerUrl(viewerUrl)) {
                return {
                  ok: true,
                  capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
                  patientContextHash,
                  modules: [],
                  viewerUrl
                };
              }
            } catch {
            }
          }
          const retryable = response.ok || response.status === 408 || response.status === 425 || response.status === 429 || response.status >= 500;
          if (!retryable) break;
        }
        return fail("VIEWER_UNAVAILABLE");
      }
      const pad = (value) => String(value).padStart(2, "0");
      const now = /* @__PURE__ */ new Date();
      const clientDateTime = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
      const query = new URLSearchParams({ cli_datetime: clientDateTime, insert_log: "true" });
      const modules = [];
      for (const module of request.modules) {
        if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
        captureState.completedModules = modules.length;
        const currentContext = patientContextText();
        if (!currentContext || await hashContext(currentContext) !== patientContextHash) {
          return fail("PATIENT_CONTEXT_CHANGED");
        }
        const url = new URL(module.datasetScope, request.origin);
        url.search = query.toString();
        let response;
        try {
          response = await boundedFetchText(
            url.toString(),
            {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: {
                Accept: "application/json",
                Authorization: authorizationForRun
              }
            },
            MODULE_REQUEST_TIMEOUT_MS,
            CLINICAL_RESPONSE_LIMIT_BYTES
          );
        } catch {
          modules.push({
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 0,
            body: ""
          });
          continue;
        }
        if (response.status === 401) {
          return fail("AUTHORIZATION_FAILED", module.sourceModule);
        }
        if (response.status === 403) {
          modules.push({
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 403,
            body: ""
          });
          continue;
        }
        if (response.tooLarge) {
          modules.push({
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 413,
            body: ""
          });
          continue;
        }
        let body = response.text;
        if (module.sourceModule === "IMUE0070" && !response.ok) body = "";
        if (module.sourceModule === "IMUE0070" && response.ok) {
          try {
            const parsedBody = JSON.parse(body);
            const rows = Array.isArray(parsedBody.robject) ? parsedBody.robject : [];
            const documentJobs = rows.flatMap((row, rowIndex) => {
              const handle = typeof row?.mds_file === "string" ? row.mds_file.trim() : "";
              return handle ? [{ rowIndex, handle }] : [];
            });
            const documentRowIndexes = documentJobs.map(({ rowIndex }) => rowIndex);
            const documents = new Array(documentJobs.length);
            const SHOW_XML_CONCURRENCY = 3;
            const SHOW_XML_TIMEOUT_MS = 3e4;
            const documentState = { nextJobIndex: 0, fatalError: null };
            const stopDocumentFetches = (error) => {
              if (documentState.fatalError) return;
              documentState.fatalError = error;
              for (const controller of captureState.controllers) controller.abort();
            };
            const fetchDocumentWorker = async () => {
              while (!documentState.fatalError) {
                const jobIndex = documentState.nextJobIndex;
                documentState.nextJobIndex += 1;
                const job = documentJobs[jobIndex];
                if (!job) return;
                const currentContext2 = patientContextText();
                if (!currentContext2 || await hashContext(currentContext2) !== patientContextHash) {
                  stopDocumentFetches("PATIENT_CONTEXT_CHANGED");
                  return;
                }
                const detailNow = /* @__PURE__ */ new Date();
                const detailTimestamp = `${detailNow.getFullYear()}${pad(detailNow.getMonth() + 1)}${pad(detailNow.getDate())}${pad(detailNow.getHours())}${pad(detailNow.getMinutes())}${pad(detailNow.getSeconds())}${String(Math.floor(detailNow.getMilliseconds() / 10)).padStart(2, "0")}${String(detailNow.getMilliseconds()).padStart(3, "0")}`;
                try {
                  const detailResponse = await boundedFetchText(
                    new URL("/imu/api/imue0070/imue0070s01/show-xml", request.origin).toString(),
                    {
                      method: "POST",
                      credentials: "include",
                      cache: "no-store",
                      headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json;charset=UTF-8",
                        Authorization: authorizationForRun
                      },
                      body: JSON.stringify({ FileName: `${job.handle}@${detailTimestamp}` })
                    },
                    SHOW_XML_TIMEOUT_MS,
                    CLINICAL_RESPONSE_LIMIT_BYTES
                  );
                  if (detailResponse.status === 401) {
                    stopDocumentFetches("AUTHORIZATION_FAILED");
                    return;
                  }
                  if (detailResponse.status === 403) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 403 };
                    continue;
                  }
                  if (detailResponse.tooLarge) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 413 };
                    continue;
                  }
                  const detailBody = detailResponse.text;
                  const contextAfterFetch = patientContextText();
                  if (!contextAfterFetch || await hashContext(contextAfterFetch) !== patientContextHash) {
                    stopDocumentFetches("PATIENT_CONTEXT_CHANGED");
                    return;
                  }
                  let html = "";
                  if (detailResponse.ok) {
                    try {
                      const detail = JSON.parse(detailBody);
                      const returnedHtml = typeof detail.html === "string" ? detail.html : detail.body?.html;
                      if (typeof returnedHtml === "string") html = returnedHtml;
                    } catch {
                      html = "";
                    }
                  }
                  documents[jobIndex] = {
                    rowIndex: job.rowIndex,
                    status: detailResponse.status,
                    ...html ? { html } : {}
                  };
                } catch {
                  if (!documentState.fatalError) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 0 };
                  }
                }
              }
            };
            const documentWorkerCount = Math.min(
              SHOW_XML_CONCURRENCY,
              documentJobs.length
            );
            await Promise.all(
              Array.from({ length: documentWorkerCount }, () => fetchDocumentWorker())
            );
            if (documentState.fatalError) {
              return fail(documentState.fatalError, module.sourceModule);
            }
            for (const row of rows) {
              row.mds_file = null;
              row.mds_pdf_file = null;
            }
            parsedBody._cloudWildcatchDocumentsAttempted = true;
            parsedBody._cloudWildcatchDocumentRowIndexes = documentRowIndexes;
            parsedBody._cloudWildcatchDocuments = documents.filter(
              (document2) => document2 !== void 0
            );
            body = JSON.stringify(parsedBody);
            if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
              modules.push({
                sourceModule: module.sourceModule,
                datasetScope: module.datasetScope,
                status: 413,
                body: ""
              });
              continue;
            }
          } catch {
            return fail("RESPONSE_SHAPE_INVALID", module.sourceModule);
          }
        }
        if (module.sourceModule === "IMUE0130" && response.ok) {
          try {
            const parsedBody = JSON.parse(body);
            const rows = Array.isArray(parsedBody.robject) ? parsedBody.robject : [];
            const rowIndexes = rows.map((row, rowIndex) => row?.ctmri_mark === "Y" ? rowIndex : -1).filter((rowIndex) => rowIndex >= 0).slice(0, 200);
            const sourceValue = (value) => value === null || value === void 0 ? "" : String(value);
            const viewerRequests = rowIndexes.flatMap((rowIndex) => {
              const row = rows[rowIndex] ?? {};
              const iplCaseSeqNo = sourceValue(row.ipl_case_seq_no).trim();
              if (!iplCaseSeqNo) return [];
              return [{
                rowIndex,
                descriptor: {
                  version: 1,
                  procId: "IMUE0130",
                  iplCaseSeqNo,
                  readPos: sourceValue(row.read_pos),
                  ordMark: row.ord_mark === "Y" ? "Y" : "",
                  fileType: sourceValue(row.file_type),
                  fileQty: sourceValue(row.file_qty),
                  feeYm: sourceValue(row.fee_ym)
                }
              }];
            });
            const descriptorRowCount = rowIndexes.filter(
              (rowIndex) => sourceValue(rows[rowIndex]?.ipl_case_seq_no).trim() !== ""
            ).length;
            if (viewerRequests.length !== descriptorRowCount) {
              return fail("RESPONSE_SHAPE_INVALID", module.sourceModule);
            }
            parsedBody._cloudWildcatchViewerRequestsAttempted = true;
            parsedBody._cloudWildcatchViewerRequestRowIndexes = rowIndexes;
            parsedBody._cloudWildcatchViewerRequests = viewerRequests;
            body = JSON.stringify(parsedBody);
            if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
              modules.push({
                sourceModule: module.sourceModule,
                datasetScope: module.datasetScope,
                status: 413,
                body: ""
              });
              continue;
            }
          } catch {
          }
        }
        modules.push({
          sourceModule: module.sourceModule,
          datasetScope: module.datasetScope,
          status: response.status,
          body
        });
      }
      const contextAfterText = patientContextText();
      if (!contextAfterText || await hashContext(contextAfterText) !== patientContextHash) {
        return fail("PATIENT_CONTEXT_CHANGED");
      }
      return {
        ok: true,
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        patientContextHash,
        modules
      };
    } finally {
      for (const controller of captureState.controllers) controller.abort();
      if (registry.get(request.runId) === captureState) registry.delete(request.runId);
    }
  }
  async function loadMediCloudEnvelopes(tabId, runId) {
    let executionResults;
    try {
      const patientContextHmacKey = await getPatientContextHmacKey();
      executionResults = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: captureMediCloudInPage,
        args: [
          {
            origin: MEDCLOUD_ORIGIN,
            runId,
            patientContextHmacKey,
            modules: MEDCLOUD_MODULES.map(({ sourceModule, datasetScope }) => ({
              sourceModule,
              datasetScope
            }))
          }
        ]
      });
    } catch {
      throw new MediCloudAcquisitionError("CAPTURE_INJECTION_FAILED");
    }
    const capture = executionResults[0]?.result;
    if (!capture) throw new MediCloudAcquisitionError("CAPTURE_RESULT_MISSING");
    if (!capture.ok) throw new MediCloudAcquisitionError(capture.code, capture.sourceModule);
    return capture.modules.map((module) => {
      const candidate = {
        schemaVersion: "1.0.0",
        sourceSystem: "nhi-medcloud",
        sourceModule: module.sourceModule,
        datasetScope: module.datasetScope,
        adapterVersion: MEDCLOUD_ADAPTER_VERSION,
        runId,
        capturedAt: capture.capturedAt,
        completeness: module.status >= 200 && module.status < 300 ? "complete" : module.status === 403 ? "partial" : "failed",
        patientContextHash: capture.patientContextHash,
        payload: { status: module.status, body: module.body }
      };
      try {
        return SourceEnvelopeSchema.parse(candidate);
      } catch {
        throw new MediCloudAcquisitionError("SOURCE_ENVELOPE_INVALID", module.sourceModule);
      }
    });
  }

  // src/popup.ts
  var MEDCLOUD_LANDING = "https://medcloud2.nhi.gov.tw/imu/IMUE1000";
  var MODULES = MEDCLOUD_CLINICAL_MODULES.map((module) => module.sourceModule);
  var byId = (id) => document.getElementById(id);
  var runButton = byId("run");
  var rawButton = byId("raw-data-btn");
  var message = byId("message");
  var resultZone = byId("result-zone");
  var resultActions = byId("result-actions");
  var downloadButton = byId("download-btn");
  var openInMediPrismaButton = byId("open-in-mediprisma-btn");
  var clearStateButton = byId("clear-state-btn");
  var cancelJobButton = byId("cancel-job-btn");
  var copyErrorButton = byId("copy-error-btn");
  var resultFile = byId("result-file");
  var resultFilename = byId("result-filename");
  var resultFileMeta = byId("result-file-meta");
  var resultSummary = byId("result-summary");
  var resultCompletenessWarning = byId("result-completeness-warning");
  var resultCompletenessNote = byId("result-completeness-note");
  var resultCompletenessIssues = byId("result-completeness-issues");
  var copyPartialButton = byId("copy-partial-btn");
  var resultProgressIcon = byId("result-progress-icon");
  var resultSuccessIcon = byId("result-success-icon");
  var resultErrorIcon = byId("result-error-icon");
  var resultDetails = byId("result-details");
  var resultDetailsLabel = byId("result-details-label");
  var resultBreakdown = byId("result-breakdown");
  var resultSafety = byId("result-safety");
  var downloadButtonLabel = byId("download-btn-label");
  var moduleStatusSummary = byId("module-status-summary");
  var activePatient = byId("active-patient");
  var activePatientValue = byId("active-patient-value");
  var redetectNote = byId("redetect-note");
  var activeStep = 1;
  var medCloudTabId = null;
  var loggedIn = false;
  var patient = null;
  var backgroundStatus = null;
  var pendingResultReady = false;
  var pendingPatientKey = "";
  var pendingFilename = "";
  var jobRunning = false;
  var downloadCompleted = false;
  var maskNameEnabled = true;
  var includeImagingViewerLinks = true;
  var patientProbeInFlight = false;
  var firstPatientProbeSettled = false;
  var handoffStarting = false;
  var clearStarting = false;
  var cancelStarting = false;
  var popupInitialized = false;
  function isMedCloudUrl(raw) {
    try {
      return new URL(raw ?? "").hostname === "medcloud2.nhi.gov.tw";
    } catch {
      return false;
    }
  }
  function patientKey(value) {
    return value?.patientContextHash ?? "";
  }
  function displayPatient(value) {
    return value?.display || (value ? `\u75C5\u4EBA ${value.patientContextHash.slice(0, 8)}\u2026` : "");
  }
  function patientMismatch() {
    return Boolean(patient && pendingPatientKey && patientKey(patient) !== pendingPatientKey);
  }
  function formatBytes(value) {
    if (!Number.isFinite(value) || Number(value) < 0) return "";
    const bytes = Number(value);
    if (bytes < 1024) return `${bytes} bytes`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  function completionTime(status) {
    if (!status) return void 0;
    if (status.completedAt) return status.completedAt;
    return status.phase === "complete" ? status.updatedAt : void 0;
  }
  function setMessage(text, kind) {
    if (!message || !resultZone) return;
    message.textContent = text;
    message.className = `status${kind ? ` ${kind}` : ""}`;
    if (resultSuccessIcon) {
      resultSuccessIcon.toggleAttribute("hidden", !(kind === "success" && pendingResultReady));
    }
    resultProgressIcon?.toggleAttribute("hidden", !jobRunning || kind !== void 0 || !text);
    resultErrorIcon?.toggleAttribute("hidden", kind !== "error" || !text);
    resultZone.hidden = !text && !pendingResultReady && !jobRunning;
  }
  function moduleElement(module) {
    return document.querySelector(`[data-module="${module}"]`);
  }
  function renderModules(statuses, fallback = "\u5F85\u53D6\u5F97") {
    const map = new Map((statuses ?? []).map((item) => [item.sourceModule, item.completeness]));
    const counts = { complete: 0, empty: 0, partial: 0, failed: 0, pending: 0 };
    for (const module of MODULES) {
      const element = moduleElement(module);
      if (!element) continue;
      const state = map.get(module);
      if (state) counts[state] += 1;
      else counts.pending += 1;
      element.textContent = state === "complete" ? "\u5DF2\u53D6\u5F97" : state === "empty" ? "\u7121\u8CC7\u6599" : state === "partial" ? "\u4E0D\u5B8C\u6574" : state === "failed" ? "\u5931\u6557" : fallback;
      element.className = `module-state${state ? ` ${state}` : ""}`;
    }
    if (!moduleStatusSummary) return;
    if (!statuses?.length) {
      moduleStatusSummary.textContent = fallback === "\u5F85\u53D6\u5F97" ? `${MODULES.length} \u9805\u5F85\u53D6\u5F97` : fallback === "\u5931\u6557" ? `${MODULES.length} \u9805\u53D6\u5F97\u5931\u6557` : `\u6B63\u5728\u53D6\u5F97 ${MODULES.length} \u9805\u8CC7\u6599`;
      return;
    }
    const parts = [
      counts.complete > 0 ? `${counts.complete} \u9805\u5DF2\u53D6\u5F97` : "",
      counts.empty > 0 ? `${counts.empty} \u9805\u7121\u8CC7\u6599` : "",
      counts.partial > 0 ? `${counts.partial} \u9805\u4E0D\u5B8C\u6574` : "",
      counts.failed > 0 ? `${counts.failed} \u9805\u5931\u6557` : "",
      counts.pending > 0 ? `${counts.pending} \u9805\u5F85\u53D6\u5F97` : ""
    ].filter(Boolean);
    moduleStatusSummary.textContent = parts.join(" \xB7 ");
  }
  function clearLocalResult() {
    backgroundStatus = null;
    pendingResultReady = false;
    pendingPatientKey = "";
    pendingFilename = "";
    jobRunning = false;
    downloadCompleted = false;
    handoffStarting = false;
    if (resultSummary) resultSummary.hidden = true;
    if (resultCompletenessWarning) resultCompletenessWarning.hidden = true;
    resultCompletenessIssues?.replaceChildren();
    if (copyPartialButton) {
      copyPartialButton.hidden = true;
      copyPartialButton.textContent = "\u8907\u88FD\u554F\u984C\u660E\u7D30";
    }
    resultSuccessIcon?.setAttribute("hidden", "");
    resultProgressIcon?.setAttribute("hidden", "");
    resultErrorIcon?.setAttribute("hidden", "");
    if (resultDetails) {
      resultDetails.hidden = true;
      resultDetails.open = false;
    }
    if (resultDetailsLabel) resultDetailsLabel.textContent = "\u67E5\u770B\u660E\u7D30";
    resultBreakdown?.replaceChildren();
    if (resultSafety) resultSafety.hidden = true;
  }
  function renderBundleSummary(summary) {
    const presentation = presentBundleSummary(summary);
    if (resultCompletenessWarning) {
      resultCompletenessWarning.hidden = !presentation.hasIncompleteModules;
    }
    if (resultCompletenessNote) {
      resultCompletenessNote.textContent = presentation.completenessNote;
    }
    if (resultCompletenessIssues) {
      resultCompletenessIssues.replaceChildren();
      for (const issue of presentation.incompleteModules) {
        const item = document.createElement("li");
        const head = document.createElement("span");
        head.className = "partial-issue-head";
        const label = document.createElement("span");
        label.textContent = issue.label;
        const state = document.createElement("span");
        state.className = `partial-issue-state${issue.completeness === "failed" ? " failed" : ""}`;
        state.textContent = issue.completeness === "failed" ? "\u5931\u6557" : "\u90E8\u5206";
        head.append(label, state);
        const reason = document.createElement("span");
        reason.className = "partial-issue-reason";
        reason.textContent = issue.reason;
        const diagnostic = document.createElement("code");
        diagnostic.className = "partial-issue-code";
        diagnostic.textContent = issue.diagnostic;
        item.append(head, reason, diagnostic);
        if (issue.affectedRecords.length > 0) {
          const records = document.createElement("ul");
          records.className = "partial-record-list";
          for (const affected of issue.affectedRecords) {
            const record = document.createElement("li");
            const recordLabel = document.createElement("span");
            recordLabel.className = "partial-record-label";
            recordLabel.textContent = affected.kind === "source" ? affected.label : `\u672A\u7D0D\u5165\u8CC7\u6E90 ${affected.label}`;
            const recordCode = document.createElement("code");
            recordCode.className = "partial-record-code";
            recordCode.textContent = affected.diagnostic;
            record.append(recordLabel, recordCode);
            records.append(record);
          }
          item.append(records);
        }
        resultCompletenessIssues.append(item);
      }
    }
    if (copyPartialButton) {
      copyPartialButton.hidden = !presentation.hasIncompleteModules;
      copyPartialButton.textContent = "\u8907\u88FD\u554F\u984C\u660E\u7D30";
    }
    if (resultSummary) {
      resultSummary.hidden = false;
      const completedAt = completionTime(backgroundStatus);
      const elapsed = backgroundStatus && completedAt ? formatResultElapsed(completedAt - backgroundStatus.startedAt) : "";
      resultSummary.textContent = [
        presentation.summaryText,
        elapsed ? `\u8017\u6642 ${elapsed}` : ""
      ].filter(Boolean).join(" \xB7 ");
    }
    if (resultBreakdown && resultDetails) {
      resultBreakdown.replaceChildren();
      for (const detail of presentation.detailRows) {
        const row = document.createElement("div");
        row.className = "result-breakdown-row";
        const label = document.createElement("span");
        label.className = "result-breakdown-label";
        label.textContent = detail.label;
        const value = document.createElement("span");
        value.className = "result-breakdown-value";
        value.textContent = `${detail.count} \u7B46`;
        row.append(label, value);
        resultBreakdown.append(row);
      }
      resultDetails.hidden = presentation.detailRows.length === 0;
    }
    return presentation.canDownload;
  }
  function stepDone(step) {
    if (step === 1) return loggedIn && Boolean(patientKey(patient));
    if (step === 2) return pendingResultReady || downloadCompleted;
    return false;
  }
  function renderWizard() {
    document.body.dataset.activeStep = String(activeStep);
    document.querySelectorAll("#wizard-stepper li[data-step]").forEach((item) => {
      const step = Number(item.dataset.step);
      item.toggleAttribute("aria-current", step === activeStep);
      item.setAttribute("aria-selected", String(step === activeStep));
      if (stepDone(step)) item.dataset.done = "true";
      else delete item.dataset.done;
    });
    const onTab = medCloudTabId !== null;
    byId("open-medcloud-section").hidden = onTab;
    byId("medcloud-needs-login-section").hidden = !onTab || loggedIn;
    byId("login-ok-section").hidden = !onTab || !loggedIn;
    if (runButton) runButton.disabled = !stepDone(1) || jobRunning;
    if (rawButton) rawButton.disabled = !stepDone(1) || jobRunning;
    if (activePatient && activePatientValue) {
      const label = displayPatient(patient);
      activePatient.hidden = !label;
      activePatientValue.textContent = label;
    }
    const downloadReady = pendingResultReady && firstPatientProbeSettled && !patientMismatch();
    const incompleteResult = backgroundStatus?.summary ? presentBundleSummary(backgroundStatus.summary).hasIncompleteModules : false;
    if (resultActions) resultActions.hidden = !downloadReady;
    if (resultFile) resultFile.hidden = !downloadReady;
    if (resultSafety) resultSafety.hidden = !downloadReady;
    if (resultCompletenessWarning) {
      resultCompletenessWarning.hidden = !downloadReady || !incompleteResult;
    }
    if (downloadReady && resultFilename && resultFileMeta) {
      resultFilename.textContent = pendingFilename || "medcloud-health-record.json";
      const size = formatBytes(backgroundStatus?.resultBytes);
      const age = formatResultAge(completionTime(backgroundStatus));
      resultFileMeta.textContent = [
        incompleteResult ? "\u90E8\u5206\u5065\u5EB7\u7D00\u9304\u6A94" : "\u5065\u5EB7\u7D00\u9304\u6A94",
        size,
        age
      ].filter(Boolean).join(" \xB7 ");
    }
    if (downloadButton) downloadButton.disabled = !downloadReady;
    if (downloadButtonLabel) {
      downloadButtonLabel.textContent = backgroundStatus?.downloadedAt || downloadCompleted ? "\u518D\u6B21\u4E0B\u8F09" : "\u4E0B\u8F09\u6A94\u6848";
    }
    if (openInMediPrismaButton) {
      openInMediPrismaButton.disabled = !downloadReady || handoffStarting;
    }
    const clearableState = Boolean(backgroundStatus && backgroundStatus.phase !== "running");
    if (clearStateButton) {
      clearStateButton.hidden = !clearableState;
      clearStateButton.disabled = !clearableState || clearStarting;
    }
    if (cancelJobButton) {
      cancelJobButton.hidden = !jobRunning;
      cancelJobButton.disabled = !jobRunning || cancelStarting;
      cancelJobButton.textContent = cancelStarting ? "\u6B63\u5728\u53D6\u6D88\u2026" : "\u53D6\u6D88\u53D6\u5F97";
    }
    if (copyErrorButton) {
      copyErrorButton.hidden = !reportableErrorCode();
    }
  }
  function reportableErrorCode() {
    const code = backgroundStatus?.errorCode;
    return typeof code === "string" && /^[A-Z][A-Z0-9_]{2,63}$/.test(code) ? code : "";
  }
  function setStep(step) {
    activeStep = normalizeWizardStep(step);
    renderWizard();
  }
  function renderBackgroundMessage() {
    if (!backgroundStatus) return;
    if (backgroundStatus.phase === "running") {
      setMessage(runningJobElapsedMessage(
        backgroundStatus.startedAt,
        Date.now(),
        backgroundStatus.moduleProgress
      ));
      return;
    }
    if (hasAvailableBackgroundResult(backgroundStatus) && !backgroundStatus.errorCode) {
      const isIncomplete = backgroundStatus.summary ? presentBundleSummary(backgroundStatus.summary).hasIncompleteModules : false;
      setMessage(
        isIncomplete ? backgroundStatus.message || "\u90E8\u5206\u8CC7\u6599\u672A\u5B8C\u6574\u53D6\u5F97\uFF1B\u8ACB\u67E5\u770B\u4E0B\u65B9\u554F\u984C\u660E\u7D30\u3002" : "\u8CC7\u6599\u5DF2\u6E96\u5099\u5B8C\u6210",
        "success"
      );
      return;
    }
    setMessage(
      backgroundStatus.message,
      backgroundStatus.phase === "error" || backgroundStatus.errorCode ? "error" : void 0
    );
  }
  async function clearMismatchedBackgroundJob(status) {
    const response = await chrome.runtime.sendMessage({
      type: CLEAR_BACKGROUND_JOB,
      runId: status.runId
    }).catch(() => void 0);
    if (response?.ok) return;
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const current = stored[BACKGROUND_JOB_STATUS_KEY];
    if (isBackgroundJobStatus(current) && current.runId === status.runId && current.phase !== "running") {
      await clearBackgroundResults(status.runId);
      await chrome.storage.session.remove([
        BACKGROUND_JOB_STATUS_KEY,
        BACKGROUND_JOB_REQUEST_KEY
      ]);
    }
  }
  async function verifyPendingPatientAtEgress() {
    const status = backgroundStatus;
    if (!status?.tabId) {
      await failEgress(status, "unreachable");
      return false;
    }
    const probe = await probeMediCloudPatient(status.tabId).catch(() => null);
    if (probe?.ok && probe.patientContextHash === status.patientContextHash && probe.patientContextHash === pendingPatientKey) {
      patient = {
        patientContextHash: probe.patientContextHash,
        display: probe.display,
        identity: probe.identity
      };
      loggedIn = true;
      return true;
    }
    await failEgress(status, probe?.ok ? "changed" : "unreachable");
    return false;
  }
  async function failEgress(status, cause) {
    patient = null;
    loggedIn = false;
    if (status) await clearMismatchedBackgroundJob(status);
    clearLocalResult();
    renderModules();
    setMessage(
      cause === "changed" ? "\u756B\u9762\u4E0A\u7684\u75C5\u4EBA\u5DF2\u6539\u8B8A\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u66AB\u5B58\u7D50\u679C\u5DF2\u6E05\u9664\uFF0C\u8ACB\u91CD\u65B0\u53D6\u5F97\u3002" : "\u627E\u4E0D\u5230\u539F\u672C\u7684\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\uFF0C\u7121\u6CD5\u78BA\u8A8D\u75C5\u4EBA\uFF0C\u66AB\u5B58\u7D50\u679C\u5DF2\u6E05\u9664\uFF1B\u8ACB\u91CD\u65B0\u958B\u555F\u96F2\u7AEF\u75C5\u6B77\u5F8C\u518D\u53D6\u5F97\u4E00\u6B21\u3002",
      "error"
    );
    renderWizard();
  }
  async function clearCurrentBackgroundState() {
    const status = backgroundStatus;
    if (!status || status.phase === "running" || clearStarting) return;
    clearStarting = true;
    renderWizard();
    const response = await chrome.runtime.sendMessage({
      type: CLEAR_BACKGROUND_JOB,
      runId: status.runId
    }).catch(() => void 0);
    if (!response?.ok) {
      clearStarting = false;
      setMessage("\u76EE\u524D\u7121\u6CD5\u79FB\u9664\u66AB\u5B58\u8CC7\u6599\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\uFF1B\u539F\u6709\u7D50\u679C\u4ECD\u4FDD\u7559\u3002", "error");
      renderWizard();
      return;
    }
    clearLocalResult();
    clearStarting = false;
    renderModules();
    setMessage("");
    setStep(2);
  }
  async function cancelRunningBackgroundJob() {
    const status = backgroundStatus;
    if (!status || status.phase !== "running" || cancelStarting) return;
    cancelStarting = true;
    renderWizard();
    const response = await chrome.runtime.sendMessage({
      type: CLEAR_BACKGROUND_JOB,
      runId: status.runId
    }).catch(() => void 0);
    cancelStarting = false;
    if (!response?.ok) {
      setMessage("\u76EE\u524D\u7121\u6CD5\u53D6\u6D88\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\u3002", "error");
      renderWizard();
      return;
    }
    clearLocalResult();
    renderModules();
    setMessage("\u5DF2\u53D6\u6D88\u9019\u6B21\u53D6\u5F97\uFF1B\u53EF\u91CD\u65B0\u958B\u59CB\u3002");
    setStep(2);
  }
  function resetForMismatchedPatient(status) {
    if (status.phase === "running") {
      backgroundStatus = status;
      pendingPatientKey = status.patientContextHash;
      pendingFilename = "";
      pendingResultReady = false;
      downloadCompleted = false;
      jobRunning = true;
      if (resultSummary) resultSummary.hidden = true;
      renderModules();
      setMessage("\u5DF2\u5075\u6E2C\u5230\u5207\u63DB\u75C5\u4EBA\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u8CC7\u6599\u6B63\u5728\u5B89\u5168\u505C\u6B62\uFF0C\u53D6\u5F97\u72C0\u614B\u5DF2\u6E05\u7A7A\u3002", "error");
      setStep(2);
      void clearMismatchedBackgroundJob(status);
      return;
    }
    clearLocalResult();
    renderModules();
    setMessage("\u5DF2\u5075\u6E2C\u5230\u5207\u63DB\u75C5\u4EBA\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u53D6\u5F97\u72C0\u614B\u8207\u5F85\u4E0B\u8F09\u7D50\u679C\u5DF2\u6E05\u9664\u3002", "success");
    setStep(2);
    void clearMismatchedBackgroundJob(status);
  }
  function applyBackgroundStatus(value) {
    if (!isBackgroundJobStatus(value)) {
      clearLocalResult();
      renderModules();
      setMessage("");
      renderWizard();
      return;
    }
    if (patient && patientKey(patient) !== value.patientContextHash) {
      resetForMismatchedPatient(value);
      return;
    }
    backgroundStatus = value;
    pendingPatientKey = value.patientContextHash;
    pendingFilename = value.filename ?? "";
    jobRunning = value.phase === "running";
    pendingResultReady = hasAvailableBackgroundResult(value);
    downloadCompleted = Boolean(value.downloadedAt) || value.phase === "downloaded";
    if (value.phase === "running") {
      if (resultSummary) resultSummary.hidden = true;
      renderModules(void 0, "\u53D6\u5F97\u4E2D");
      setStep(2);
    } else if (pendingResultReady) {
      renderModules(value.summary?.moduleStatuses);
      if (!value.summary || !renderBundleSummary(value.summary)) pendingResultReady = false;
      setStep(2);
    } else if (value.phase === "error") {
      if (resultSummary) resultSummary.hidden = true;
      renderModules(value.summary?.moduleStatuses, "\u5931\u6557");
      setStep(2);
    } else {
      if (resultSummary) resultSummary.hidden = true;
      renderModules(value.summary?.moduleStatuses);
      setStep(3);
    }
    renderBackgroundMessage();
    renderWizard();
  }
  async function restoreBackgroundStatus() {
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    applyBackgroundStatus(stored[BACKGROUND_JOB_STATUS_KEY]);
  }
  function loadPreferences() {
    try {
      maskNameEnabled = localStorage.getItem("cloud-wildcatch:maskNameEnabled") !== "false";
    } catch {
    }
    const maskOn = byId("mask-name-on");
    const maskOff = byId("mask-name-off");
    if (maskOn) maskOn.checked = maskNameEnabled;
    if (maskOff) maskOff.checked = !maskNameEnabled;
  }
  async function probePatient(showFeedback = false) {
    if (!medCloudTabId || patientProbeInFlight) return;
    patientProbeInFlight = true;
    if (showFeedback && redetectNote) {
      redetectNote.hidden = false;
      redetectNote.textContent = "\u6B63\u5728\u91CD\u65B0\u5075\u6E2C\u76EE\u524D\u75C5\u4EBA\u2026";
    }
    try {
      const response = await probeMediCloudPatient(medCloudTabId);
      patient = response.ok ? {
        patientContextHash: response.patientContextHash,
        display: response.display,
        identity: response.identity
      } : null;
      loggedIn = response.ok;
      firstPatientProbeSettled = true;
      if (backgroundStatus && patientMismatch()) applyBackgroundStatus(backgroundStatus);
      else {
        renderBackgroundMessage();
        renderWizard();
      }
      if (showFeedback && redetectNote) {
        redetectNote.textContent = patientKey(patient) ? "\u5DF2\u91CD\u65B0\u5075\u6E2C\u96F2\u7AEF\u75C5\u6B77\u76EE\u524D\u75C5\u4EBA\u3002" : "\u5C1A\u672A\u5075\u6E2C\u5230\u75C5\u4EBA\uFF0C\u8ACB\u78BA\u8A8D\u8B80\u5361\u8207\u767B\u5165\u72C0\u614B\u3002";
      }
    } catch {
      loggedIn = false;
      patient = null;
      if (showFeedback && redetectNote) redetectNote.textContent = "\u75C5\u4EBA\u5075\u6E2C\u5931\u6557\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u96F2\u7AEF\u75C5\u6B77\u3002";
      renderWizard();
    } finally {
      patientProbeInFlight = false;
      firstPatientProbeSettled = true;
    }
  }
  async function detectContext() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    medCloudTabId = tab?.id !== void 0 && isMedCloudUrl(tab.url) ? tab.id : null;
    if (!medCloudTabId) {
      firstPatientProbeSettled = true;
      loggedIn = false;
      patient = null;
      renderWizard();
      return;
    }
    await probePatient();
    if (!backgroundStatus && stepDone(1) && activeStep === 1) setStep(2);
  }
  async function downloadBundle() {
    if (!pendingResultReady || patientMismatch()) return;
    if (!await verifyPendingPatientAtEgress()) return;
    const result = await readBackgroundResult(backgroundStatus?.runId);
    if (!isBackgroundJobResult(result) || result.runId !== backgroundStatus?.runId || result.patientContextHash !== pendingPatientKey || result.expiresAt <= Date.now()) {
      setMessage("\u9019\u6B21\u8CC7\u6599\u5DF2\u904E\u671F\u6216\u4E0D\u5B58\u5728\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u91CD\u65B0\u53D6\u5F97\u3002", "error");
      pendingResultReady = false;
      renderWizard();
      return;
    }
    let json;
    try {
      json = await decodeBackgroundBundle(result);
    } catch {
      setMessage("\u9019\u6B21\u66AB\u5B58\u8CC7\u6599\u7121\u6CD5\u8B80\u53D6\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u91CD\u65B0\u53D6\u5F97\u3002", "error");
      return;
    }
    if (!await verifyPendingPatientAtEgress()) return;
    const blob = new Blob([json], { type: "application/fhir+json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename || pendingFilename || "medcloud-health-record.json";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
    const response = await chrome.runtime.sendMessage({
      type: MARK_BACKGROUND_JOB_DOWNLOADED,
      runId: result.runId
    }).catch(() => void 0);
    downloadCompleted = true;
    if (!response?.ok) {
      setMessage("\u6A94\u6848\u4E0B\u8F09\u5DF2\u958B\u59CB\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u518D\u6B21\u4E0B\u8F09\u6216\u5728 MediPrisma \u67E5\u770B\u3002", "success");
    }
    renderWizard();
    setStep(2);
  }
  async function openPendingBundleInMediPrisma() {
    if (!pendingResultReady || patientMismatch() || !backgroundStatus || handoffStarting) {
      return;
    }
    const runId = backgroundStatus.runId;
    if (!await verifyPendingPatientAtEgress()) return;
    handoffStarting = true;
    if (openInMediPrismaButton) openInMediPrismaButton.textContent = "\u6B63\u5728\u958B\u555F\u2026";
    renderWizard();
    try {
      const permission = await requestMediPrismaPermission(runId);
      if (!permission.granted) {
        setMessage(
          `${permission.reason || "\u672A\u6388\u6B0A\u5B58\u53D6 MediPrisma\uFF1B\u5065\u5EB7\u7D00\u9304\u6C92\u6709\u9001\u51FA\u3002"}\u4ECD\u53EF\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002`,
          "error"
        );
        return;
      }
      if (!await verifyPendingPatientAtEgress()) return;
      const response = await chrome.runtime.sendMessage({
        type: OPEN_PENDING_BUNDLE_IN_MEDIPRISMA
      });
      if (!response?.ok) {
        throw new Error(response?.error || "\u7121\u6CD5\u5728 MediPrisma \u958B\u555F");
      }
      if (openInMediPrismaButton) openInMediPrismaButton.textContent = "MediPrisma \u5DF2\u958B\u555F";
    } catch {
      setMessage("\u7121\u6CD5\u5728 MediPrisma \u958B\u555F\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002", "error");
    } finally {
      handoffStarting = false;
      if (openInMediPrismaButton?.textContent !== "MediPrisma \u5DF2\u958B\u555F") {
        if (openInMediPrismaButton) openInMediPrismaButton.textContent = "\u5728 MediPrisma \u67E5\u770B";
      }
      renderWizard();
    }
  }
  function triggerJsonDownload(json, filename, mimeType) {
    const blob = new Blob([json], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function downloadRetainedRawCapture() {
    const runId = backgroundStatus?.runId;
    if (!runId || patientMismatch()) return false;
    const result = await readBackgroundResult(runId).catch(() => null);
    if (!isBackgroundJobResult(result) || result.schemaVersion !== 4 || !result.rawCapture || result.runId !== runId || result.patientContextHash !== pendingPatientKey || result.expiresAt <= Date.now()) {
      return false;
    }
    if (!await verifyPendingPatientAtEgress()) return true;
    let json;
    try {
      json = await decodeBackgroundPayload(result.rawCapture, runId);
    } catch {
      return false;
    }
    if (!await verifyPendingPatientAtEgress()) return true;
    triggerJsonDownload(json, result.rawCapture.filename, "application/json");
    setMessage("\u5DF2\u7528\u9019\u6B21\u53D6\u5F97\u7684\u539F\u59CB\u8CC7\u6599\u76F4\u63A5\u4E0B\u8F09\uFF0C\u672A\u91CD\u65B0\u8B80\u53D6\u96F2\u7AEF\u75C5\u6B77\u3002", "success");
    renderWizard();
    return true;
  }
  async function downloadRawCapture(tabId, detectedPatient) {
    jobRunning = true;
    renderModules(void 0, "\u64F7\u53D6\u4E2D");
    setMessage("\u6B63\u5728\u53D6\u5F97\u539F\u59CB\u8CC7\u6599\uFF08\u901A\u5E38\u6578\u79D2\u5167\u5B8C\u6210\uFF09\uFF1B\u5B8C\u6210\u524D\u8ACB\u52FF\u9EDE\u64CA\u8996\u7A97\u5916\uFF0C\u5426\u5247\u6703\u4E2D\u65B7\u4E14\u4E0D\u6703\u7522\u751F\u6A94\u6848\u3002", void 0);
    renderWizard();
    try {
      const envelopes = await loadMediCloudEnvelopes(tabId, crypto.randomUUID());
      if (envelopes.length === 0 || envelopes.some((envelope) => envelope.patientContextHash !== detectedPatient.patientContextHash)) {
        throw new Error("patient-context-mismatch");
      }
      const endpoints = Object.fromEntries(envelopes.map((envelope) => [
        envelope.datasetScope,
        {
          status: envelope.payload.status,
          body: typeof envelope.payload.body === "string" ? envelope.payload.body : JSON.stringify(envelope.payload.body)
        }
      ]));
      const payload = {
        patient: detectedPatient.identity.maskedId || `context-${detectedPatient.patientContextHash.slice(0, 12)}`,
        capturedAt: envelopes[0].capturedAt,
        endpoints
      };
      triggerJsonDownload(
        JSON.stringify(payload, null, 2),
        buildMedcloudRawFilename(
          detectedPatient.identity.maskedId,
          new Date(envelopes[0].capturedAt),
          chrome.runtime.getManifest().version
        ),
        "application/json"
      );
      renderModules(envelopes.map((envelope) => ({
        sourceModule: envelope.sourceModule,
        completeness: envelope.completeness
      })));
      setMessage("\u539F\u59CB\u8CC7\u6599\u5DF2\u4E0B\u8F09\uFF1B\u672C\u5DE5\u5177\u4E0D\u6703\u4FDD\u5B58\u9019\u4EFD\u8CC7\u6599\u3002", "success");
    } catch {
      renderModules(void 0, "\u5931\u6557");
      setMessage("\u539F\u59CB\u8CC7\u6599\u53D6\u5F97\u5931\u6557\uFF1B\u672A\u7522\u751F\u6A94\u6848\u3002", "error");
    } finally {
      jobRunning = false;
      renderWizard();
    }
  }
  runButton?.addEventListener("click", async () => {
    if (!medCloudTabId || !patientKey(patient) || !patient) {
      setStep(1);
      return;
    }
    const request = {
      tabId: medCloudTabId,
      runId: crypto.randomUUID(),
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      expectedPatientContextHash: patient.patientContextHash,
      maskNameEnabled,
      includeImagingViewerLinks,
      patientIdentity: patient.identity
    };
    applyBackgroundStatus(runningJobStatus(request));
    try {
      const response = await chrome.runtime.sendMessage({
        type: START_BACKGROUND_JOB,
        payload: request
      });
      if (!response?.ok) {
        await restoreBackgroundStatus();
        if (response?.code !== "JOB_RUNNING") {
          setMessage("\u76EE\u524D\u7121\u6CD5\u958B\u59CB\u53D6\u5F97\u8CC7\u6599\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u64F4\u5145\u529F\u80FD\u5F8C\u518D\u8A66\u3002", "error");
        }
      }
    } catch {
      await restoreBackgroundStatus().catch(() => void 0);
      setMessage("\u64F4\u5145\u529F\u80FD\u76EE\u524D\u6C92\u6709\u56DE\u61C9\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u5F8C\u518D\u8A66\u3002", "error");
    }
  });
  rawButton?.addEventListener("click", async () => {
    if (!medCloudTabId || !patientKey(patient) || !patient) {
      setStep(1);
      return;
    }
    if (await downloadRetainedRawCapture()) return;
    void downloadRawCapture(medCloudTabId, patient);
  });
  byId("open-medcloud-btn")?.addEventListener("click", async () => {
    const [existing] = await chrome.tabs.query({ url: "https://medcloud2.nhi.gov.tw/imu/*" }).catch(() => []);
    if (existing?.id !== void 0) {
      await chrome.tabs.update(existing.id, { active: true });
      if (existing.windowId !== void 0) {
        await chrome.windows.update(existing.windowId, { focused: true }).catch(() => void 0);
      }
    } else {
      await chrome.tabs.create({ url: MEDCLOUD_LANDING });
    }
    window.close();
  });
  byId("medcloud-reload-btn")?.addEventListener("click", async () => {
    if (medCloudTabId) await chrome.tabs.update(medCloudTabId, { url: MEDCLOUD_LANDING, active: true });
    else await chrome.tabs.create({ url: MEDCLOUD_LANDING });
    window.close();
  });
  byId("redetect-patient-btn")?.addEventListener("click", () => {
    void probePatient(true);
  });
  byId("download-btn")?.addEventListener("click", () => {
    void downloadBundle();
  });
  byId("open-in-mediprisma-btn")?.addEventListener("click", () => {
    void openPendingBundleInMediPrisma();
  });
  clearStateButton?.addEventListener("click", () => {
    void clearCurrentBackgroundState();
  });
  cancelJobButton?.addEventListener("click", () => {
    void cancelRunningBackgroundJob();
  });
  copyErrorButton?.addEventListener("click", async () => {
    const code = reportableErrorCode();
    if (!code || !copyErrorButton) return;
    const payload = `${code} (v${chrome.runtime.getManifest().version})`;
    try {
      await navigator.clipboard.writeText(payload);
      copyErrorButton.textContent = "\u5DF2\u8907\u88FD";
    } catch {
      copyErrorButton.textContent = "\u7121\u6CD5\u8907\u88FD";
    }
    window.setTimeout(() => {
      if (copyErrorButton) copyErrorButton.textContent = "\u8907\u88FD\u4EE3\u78BC";
    }, 2e3);
  });
  copyPartialButton?.addEventListener("click", async () => {
    const summary = backgroundStatus?.summary;
    if (!summary || !copyPartialButton) return;
    const payload = partialDiagnosticText(summary, chrome.runtime.getManifest().version);
    try {
      await navigator.clipboard.writeText(payload);
      copyPartialButton.textContent = "\u5DF2\u8907\u88FD";
    } catch {
      copyPartialButton.textContent = "\u7121\u6CD5\u8907\u88FD";
    }
    window.setTimeout(() => {
      if (copyPartialButton) copyPartialButton.textContent = "\u8907\u88FD\u554F\u984C\u660E\u7D30";
    }, 2e3);
  });
  resultDetails?.addEventListener("toggle", () => {
    if (resultDetailsLabel) {
      resultDetailsLabel.textContent = resultDetails.open ? "\u6536\u5408\u660E\u7D30" : "\u67E5\u770B\u660E\u7D30";
    }
  });
  byId("login-ok-next")?.addEventListener("click", () => setStep(2));
  byId("back-to-download-btn")?.addEventListener("click", () => setStep(2));
  byId("open-smart-app-btn")?.addEventListener("click", async () => {
    await chrome.tabs.create({ url: MEDIPRISMA_APP_URL });
  });
  byId("mask-name-toggle")?.addEventListener("change", () => {
    maskNameEnabled = byId("mask-name-on")?.checked === true;
    try {
      localStorage.setItem("cloud-wildcatch:maskNameEnabled", String(maskNameEnabled));
    } catch {
    }
  });
  document.querySelectorAll("#wizard-stepper li[data-step]").forEach((item) => {
    const activate = () => setStep(Number(item.dataset.step));
    item.addEventListener("click", activate);
    item.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        activate();
      }
    });
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "session" && changes[BACKGROUND_JOB_STATUS_KEY]) {
      applyBackgroundStatus(changes[BACKGROUND_JOB_STATUS_KEY]?.newValue);
    }
  });
  window.setInterval(() => {
    if (medCloudTabId) void probePatient();
  }, 3e3);
  window.setInterval(() => {
    if (backgroundStatus?.phase === "running") renderBackgroundMessage();
  }, 1e3);
  renderWizard();
  if (typeof chrome !== "undefined" && chrome.runtime?.id) {
    if (byId("version")) byId("version").textContent = `v${chrome.runtime.getManifest().version}`;
    const initializePopup = async () => {
      if (popupInitialized) return;
      popupInitialized = true;
      loadPreferences();
      await restoreBackgroundStatus();
      await detectContext();
    };
    void initializePopup().catch(() => {
      renderWizard();
    });
  }
})();
/*! Bundled license information:

js-sha1/src/sha1.js:
  (*
   * [js-sha1]{@link https://github.com/emn178/js-sha1}
   *
   * @version 0.7.0
   * @author Chen, Yi-Cyuan [emn178@gmail.com]
   * @copyright Chen, Yi-Cyuan 2014-2024
   * @license MIT
   *)
*/
