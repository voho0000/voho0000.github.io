(() => {
  const HOST_ID = "vgh-wildcatch-emergency-launcher";
  if (document.getElementById(HOST_ID)) return;
  const inEr = () => location.origin === "https://rkeprd.vghtpe.gov.tw" &&
    (location.pathname === "/ERS" || location.pathname.startsWith("/ERS/"));
  const hasPatient = () => inEr() && /^\/ERS\/patientMainPage\/\d{1,12}\/[A-Za-z0-9]+\/?$/.test(location.pathname);
  const preview = () => new URL(location.href).searchParams.get("wildcatchErTest") === "identity";
  let href = location.href, context = crypto.randomUUID(), requestId = null, busy = false;
  const host = document.createElement("div");
  host.id = HOST_ID;
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      :host { all:initial; position:fixed; z-index:2147483647; right:16px; top:52%; transform:translateY(-50%); color-scheme:light; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC",sans-serif; }
      :host([hidden]) { display:none; } * { box-sizing:border-box; } [hidden] { display:none!important; }
      .launcher { display:flex; align-items:center; gap:8px; width:62px; min-height:62px; padding:6px; overflow:hidden; border:1px solid #b5c5de; border-radius:32px; background:#fff; color:#172554; box-shadow:0 8px 26px #1e3a8a26; transition:width .2s ease; }
      .launcher:hover,.launcher:focus-within,.launcher[data-state]:not([data-state="idle"]):not([data-state="selection"]) { width:min(340px,calc(100vw - 24px)); }
      button { font:inherit; cursor:pointer; border:0; background:transparent; color:inherit; }
      .launch { display:flex; align-items:center; gap:10px; padding:0; min-width:0; flex:1; text-align:left; }
      .launch:disabled { cursor:default; } button:focus-visible { outline:3px solid #93c5fd; outline-offset:2px; border-radius:24px; }
      .mark { position:relative; display:grid; place-items:center; width:48px; height:48px; flex:0 0 48px; border-radius:50%; background:#eff6ff; }
      img { display:block; width:46px; height:46px; object-fit:contain; }
      .badge { position:absolute; right:-2px; bottom:-2px; min-width:21px; height:21px; padding:1px 4px; border:2px solid #fff; border-radius:11px; background:#b45309; color:#fff; font-size:12px; line-height:15px; font-weight:700; text-align:center; }
      .copy { min-width:0; padding-right:8px; opacity:0; transition:opacity .15s ease; }
      .launcher:hover .copy,.launcher:focus-within .copy,.launcher[data-state]:not([data-state="idle"]):not([data-state="selection"]) .copy { opacity:1; }
      .label { display:block; font-size:14px; line-height:1.4; font-weight:700; white-space:nowrap; }
      .hint { display:block; margin-top:3px; font-size:12px; line-height:1.45; color:#536781; min-width:160px; }
      .stop { padding:8px; flex:0 0 auto; font-size:12px; color:#9f1239; border-radius:8px; border:1px solid #fecdd3; }
      [data-state="reading"] .mark::before,[data-state="sending"] .mark::before,[data-state="waiting"] .mark::before { content:""; position:absolute; inset:-2px; border:3px solid #dbeafe; border-top-color:#2563eb; border-radius:50%; animation:spin .9s linear infinite; }
      [data-state="done"] { background:#f0fdf4; border-color:#86bfa4; } [data-state="error"] { background:#fffafa; border-color:#e4a1a1; }
      [data-state="error"] .label { color:#991b1b; }
      @keyframes spin { to { transform:rotate(360deg); } }
      @media (prefers-reduced-motion:reduce) { .launcher,.copy { transition:none; } .mark::before { animation:none!important; } }
      @media(max-width:640px) { :host { right:10px; top:auto; bottom:18px; transform:none; } }
    </style>
    <div class="launcher" data-state="idle" role="group" aria-label="北榮急診醫析" tabindex="0">
      <button class="launch" type="button"><span class="mark"><img alt=""><span class="badge" aria-hidden="true">急</span></span><span class="copy"><span class="label"></span><span class="hint" role="status" aria-live="polite"></span></span></button>
      <button class="stop" type="button" aria-label="停止急診流程" hidden>停止</button>
    </div>`;
  shadow.querySelector("img").src = chrome.runtime.getURL("icons/icon48.png");
  const launcher = shadow.querySelector(".launcher"), button = shadow.querySelector(".launch");
  const label = shadow.querySelector(".label"), hint = shadow.querySelector(".hint"), stop = shadow.querySelector(".stop");
  function render(state, title, detail) {
    launcher.dataset.state = state;
    label.textContent = title; hint.textContent = detail;
    launcher.title = detail;
    button.setAttribute("aria-label", title);
    button.title = detail;
    button.disabled = busy || !hasPatient();
    button.setAttribute("aria-busy", String(busy));
    stop.hidden = !busy;
  }
  function idle() {
    host.hidden = !inEr();
    render(hasPatient() ? "idle" : "selection", hasPatient() ? (preview() ? "驗證急診資料傳遞" : "急診醫析") : "請先選擇病人",
      hasPatient() ? (preview() ? "僅驗證接收，不啟動健保查詢" : "急診醫析：自動帶入證號與生日") : "在急診系統選定病人後，即可使用急診醫析");
  }
  function refresh() {
    if (href !== location.href) {
      href = location.href; context = crypto.randomUUID(); requestId = null; busy = false; idle();
    }
  }
  document.documentElement.appendChild(host);
  idle();
  new MutationObserver(refresh).observe(document.documentElement, { childList:true, subtree:true });
  setInterval(refresh,250);
  chrome.runtime.onMessage.addListener((message,sender,reply) => {
    if (sender.id !== chrome.runtime.id) return false;
    refresh();
    if (message?.type === "er:context") reply({context,href});
    if (message?.type === "er:status" && message.context === context && message.requestId === requestId) {
      const phase = message.phase || "reading";
      busy = ["reading","sending","waiting","retained"].includes(phase);
      render(phase, phase === "retained" ? "結果已保存於雲端" : phase === "done" ? "已交接醫析" : phase === "error" ? "未完成，點此重試" : phase === "cancelled" ? "已停止，點此重試" : phase === "sending" ? "正在交給雲端" : phase === "waiting" ? "請完成健保讀卡" : "正在讀取病人資料", message.message);
    }
    return false;
  });
  button.onclick = async () => {
    refresh();
    if (busy || !hasPatient()) return;
    const launchContext = context, launchId = crypto.randomUUID();
    requestId = launchId; busy = true;
    render("reading","正在讀取病人資料","正在從院內病歷取得證號與生日");
    try {
      const result = await chrome.runtime.sendMessage({type:"er:start",context:launchContext,requestId:launchId,preview:preview()});
      refresh();
      if (context !== launchContext || requestId !== launchId) return;
      if (["done", "cancelled", "error"].includes(launcher.dataset.state)) return;
      if (result?.ok) {
        busy = !result.preview;
        render(result.preview ? "done" : "waiting", result.preview ? "資料傳遞驗證成功" : "請完成健保讀卡",
          result.preview ? "身分證與生日已由雲端驗證接收（未啟動健保查詢）。" : "已交給雲端，讀卡完成後會接續急診流程");
      } else {
        busy = false;
        const detail = {ER_BUSY:"另一個工作正在處理，請稍後重試",LAUNCH_BUSY:"雲端另一個急診工作正在處理，請稍後重試",REQUEST_ALREADY_USED:"本次要求已使用，請重新啟動",EMERGENCY_SOURCE_LOST:"原急診來源已失效，請重新啟動",UNTRUSTED_PEER:"套件配對不符，請檢查串接設定",INVALID_PATIENT:"病人資料驗證未通過，請重新啟動",NOT_PAIRED:"請先完成北榮與雲端的串接設定",CHART_LINK_UNAVAILABLE:"無法辨識病歷查詢入口，請重新整理後重試",PATIENT_CONTEXT_CHANGED:"病人已切換，請在目前病人重新啟動",CHART_UNAVAILABLE:"無法開啟對應病歷，請確認院內登入",IDENTITY_UNAVAILABLE:"無法取得完整證號與生日，請確認院內登入與調閱理由"}[result?.code] || "請確認院內登入與套件配對後重試";
        render("error","未完成，點此重試",detail);
      }
    } catch {
      if (context !== launchContext || requestId !== launchId) return;
      busy = false; render("error","未完成，點此重試","套件連線中斷，請重新整理頁面後重試");
    }
  };
  stop.onclick = async () => {
    const stoppedContext = context, stoppedId = requestId;
    requestId = null; busy = false;
    render("cancelled","已停止，點此重試","已停止本次急診流程");
    await chrome.runtime.sendMessage({type:"er:cancel",context:stoppedContext,requestId:stoppedId}).catch(()=>undefined);
  };
})();
