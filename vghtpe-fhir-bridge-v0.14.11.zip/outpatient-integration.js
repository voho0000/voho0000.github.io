// Versioned cross-extension contract. Identity is transient and never logged.
import { recordDate } from "./record-range.js";
export const OP_PROTOCOL = "WILDCATCH_OUTPATIENT_V1";
export const OP_TTL = 15 * 60_000;
export const OP_CHUNK_SIZE = 256_000;
export const normalizeName = value => String(value || "").normalize("NFKC").replace(/[\s\uFE00-\uFE0F\u{E0100}-\u{E01EF}]/gu, "");
// A source replacement character represents exactly one unknown code point.
// Keep all visible positions; a partial-name search is never identity evidence.
export function matchesOutpatientName(expected, actual) {
  const source = [...normalizeName(expected)], target = [...normalizeName(actual)];
  return source.length > 0 && source.length === target.length
    && source.some(char => !/[*�]/u.test(char))
    && source.every((char, index) => /[*�]/u.test(char) || char === target[index]);
}
export function matchesMaskedIdentifier(masked, full) {
  const token = String(masked || "").normalize("NFKC").trim().toUpperCase();
  const expected = String(full || "").trim().toUpperCase();
  if (!/^[A-Z][A-Z0-9][0-9]{8}$/.test(expected) || token.length !== 10) return false;
  let visible = 0;
  for (let i = 0; i < 10; i++) {
    if (i >= 2 && /[X*•●.・]/.test(token[i])) continue;
    if (token[i] !== expected[i]) return false;
    visible++;
  }
  return visible >= 6;
}
export function verifyOutpatientIdentity(expected, actual) {
  if (!matchesMaskedIdentifier(expected?.sourceId, actual?.id_no)) return false;
  if (expected.name && !matchesOutpatientName(expected.name, actual.name)) return false;
  if (expected.birthDate && expected.birthDateSource !== "vghtpe-er-his" && expected.birthDate !== actual.birthDate) return false;
  if (["male", "female"].includes(expected.gender) && expected.gender !== actual.gender) return false;
  return true;
}
export function hasComparableOutpatientIdentity(expected, actual) {
  return typeof (actual?.identifier || actual?.id) === "string" && !!(actual.identifier || actual.id).trim()
    && typeof actual?.name === "string" && !!normalizeName(actual.name)
    && typeof actual?.id_no === "string" && /^[A-Z][A-Z0-9][0-9]{8}$/i.test(actual.id_no.trim())
    && (!expected?.birthDate || expected.birthDateSource === "vghtpe-er-his" || /^\d{4}-\d{2}-\d{2}$/.test(actual.birthDate || ""))
    && (!["male", "female"].includes(expected?.gender) || ["male", "female"].includes(actual.gender));
}
export function validOutpatientRequest(message) {
  const source = String(message?.identity?.sourceId || "").normalize("NFKC").toUpperCase();
  return message?.protocol === OP_PROTOCOL && message.action === "start"
    && /^[0-9a-f-]{36}$/i.test(message.jobId || "")
    && /^[0-9a-f-]{36}$/i.test(message.token || "")
    && Number.isFinite(message.issuedAt) && Math.abs(Date.now() - message.issuedAt) < 30_000
    && typeof message.identity?.sourceId === "string" && message.identity.sourceId.length === 10
    && /^[A-Z][A-Z0-9][0-9X*•●.・]{8}$/.test(source) && source.slice(2).replace(/[X*•●.・]/g, "").length >= 4
    && typeof message.identity.name === "string" && normalizeName(message.identity.name).replace(/[*�]/gu, "").length > 0 && message.identity.name.length <= 100
    && (!message.identity.birthDate || /^\d{4}-\d{2}-\d{2}$/.test(message.identity.birthDate));
}
export function reportIssuedToday(item, reportDate, today, updatedDate) {
  // Explicit updates still count today. A catalog publication date is only a
  // fallback when the detail has no release date, matching the existing flow.
  return reportIssuedInRange(item, item?.issued || item?.reported_at ? "" : reportDate,
    { start: today, end: today }, updatedDate);
}

export function reportIssuedInRange(item, reportDate, range, updatedDate) {
  // Never substitute request/specimen/encounter date for release date.
  const inRange = value => {
    let day = recordDate(value);
    if (!day) return false;
    if (/Z$|[+-]\d\d:\d\d$/.test(value) && Number.isFinite(Date.parse(value))) {
      day = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Taipei", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(value));
    }
    return day >= range.start && day <= range.end;
  };
  return inRange(item?.updated_at || "") || inRange(updatedDate || "")
    || inRange(item?.issued || item?.reported_at || "") || inRange(reportDate || "");
}

// Serialized into an isolated world. Only use the normal search/audit UI.
export async function outpatientPageStep(action, expected) {
  const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
  const norm = value => String(value || "").normalize("NFKC").replace(/[\s\uFE00-\uFE0F\u{E0100}-\u{E01EF}]/gu, "");
  // This function is serialized into HIS; imported helpers are unavailable.
  const nameMatches = (sourceName, targetName) => {
    const source = [...norm(sourceName)], target = [...norm(targetName)];
    return source.length > 0 && source.length === target.length
      && source.some(char => !/[*�]/u.test(char))
      && source.every((char, index) => /[*�]/u.test(char) || char === target[index]);
  };
  const partialName = /[*�]/u.test(norm(expected.name));
  // Joining fragments around a missing middle character would invent a name
  // that HIS substring search cannot find. Use the longest intact fragment.
  const searchName = partialName
    ? norm(expected.name).split(/[*�]+/u).reduce((longest, part) => [...part].length > [...longest].length ? part : longest, "")
    : expected.name;
  const url = new URL(location.href);
  if (url.protocol !== "https:" || !/(^|\.)vghtpe\.gov\.tw$/.test(url.hostname) || !url.pathname.startsWith("/emr/qemr/")) return { phase: "login", message: "請先登入 HIS，再回門診工作分頁。" };
  const permit = expected.actionPermit;
  if (["search", "select", "audit"].includes(action)) {
    if (!permit?.token || !Number.isFinite(permit.expiresAt) || Date.now() >= permit.expiresAt) return { phase: "waiting" };
    let authorization;
    try { authorization = await chrome.runtime.sendMessage({ type: "authorizeOutpatientPageAction", action, token: permit.token }); }
    catch { return { phase: "waiting" }; }
    if (!authorization?.ok || Date.now() >= permit.expiresAt || location.href !== url.href) return { phase: "waiting" };
  }
  const histno = url.searchParams.get("histno");
  const header = document.querySelector("ul.jd_menu > li:first-child")?.textContent || "";
  if (histno && /^\d{1,12}$/.test(histno) && header.includes(histno)) {
    const birthday = /\((\d{4})(\d{2})(\d{2})\)/.exec(header);
    const name = header.split(histno)[0]?.trim();
    if ((expected.name && !nameMatches(expected.name, name)) ||
      (expected.birthDate && expected.birthDateSource !== "vghtpe-er-his" && birthday && `${birthday[1]}-${birthday[2]}-${birthday[3]}` !== expected.birthDate)) return { phase: "mismatch" };
    const audit = document.querySelector("#divNotify02Panel");
    if (visible(audit)) {
      // A pre-existing chart is not proof of selection for this job. Require
      // independent identity evidence before submitting its access audit.
      const independentMatch = !partialName && expected.name && expected.birthDate && !expected.birthDateSource && birthday;
      if (!independentMatch) return { phase: "selection", message: "請核對目前病人，並在 HIS 手動完成調閱理由後接續。" };
      const radio = audit.querySelector('#form_Pchkau input[name="p_reason"][value="0"]');
      const button = audit.querySelector("#btn_pchkau");
      const reason = () => radio?.labels?.length ? [...radio.labels].map(label => label.textContent).join("") : radio?.nextSibling?.textContent;
      const controlsValid = () => visible(radio) && visible(button) && !radio.disabled && !button.disabled
        && radio.name === "p_reason" && radio.value === "0" && audit.contains(radio) && audit.contains(button)
        && norm(reason()) === "醫療需要" && norm(button.value || button.textContent) === "確定送出";
      if (!controlsValid()) return { phase: "audit", message: "請在 HIS 完成調閱理由。" };
      if (action === "audit") {
        if (!radio.checked) radio.click();
        if (!radio.checked || !radio.isConnected || !button.isConnected || !visible(audit) || !controlsValid()
          || location.href !== url.href || document.querySelector("ul.jd_menu > li:first-child")?.textContent !== header
          || Date.now() >= permit.expiresAt) return { phase: "waiting" };
        button.click();
      }
      return { phase: "audit", automatic: true, message: "正在完成醫療需要調閱稽核…" };
    }
    return { phase: "chart", histno, baseUrl: url.origin };
  }
  const input = document.querySelector('input[name="namec"]');
  if (!visible(input)) return { phase: "login", message: "等待 HIS 登入／病人查詢頁。" };
  const canSearch = !!norm(searchName) && /^\d{4}-\d{2}-\d{2}$/.test(expected.birthDate || "") && !expected.birthDateSource;
  if (!canSearch) return { phase: "selection", message: "雲端缺少可獨立核對的姓名或生日，請在 HIS 選定目前病人。" };
  if (action === "search") {
    const button = document.querySelector("#btn00");
    const results = document.querySelector('#detail');
    if (!visible(button) || !results || !expected.queryId) return { phase: "selection", message: "無法辨識 HIS 查詢區塊，請手動選定病人。" };
    if (button.disabled) return {phase:'waiting-query',message:'等待 HIS 上一次查詢完成…'};
    const form = input.form || input.parentElement;
    const selectors = [...form.querySelectorAll('select')].map(select => ({select,
      option:[...select.options].find(option => !option.value.trim() || /^(請選擇|選擇類別|天數|全部|不限)/.test(norm(option.textContent)))}));
    // The verified HIS nametype=er checkbox limits name lookup to emergency
    // patients. Other checkbox semantics are unknown and require confirmation.
    const unknownCheckbox = [...form.querySelectorAll('input[type="checkbox"]')].some(field => field.name !== 'nametype' || field.value !== 'er');
    if (selectors.some(item => !item.option) || unknownCheckbox || form.querySelector('input[type="radio"]')) {
      return {phase:'selection',message:'無法確認 HIS 查詢篩選條件，請手動選定病人。'};
    }
    // Use the normal query form; never put identity fields into a navigation URL.
    input.form?.reset();
    for (const field of form.querySelectorAll('input')) {
      if (['text','search','number','date'].includes(field.type)) field.value = '';
      if (field.type === 'checkbox') field.checked = false;
    }
    for (const {select,option} of selectors) select.value = option.value;
    input.value = searchName;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    // HIS disables the button during its POST and replaces #detail atomically
    // on completion. A marker prevents treating the previous result as fresh.
    const marker = document.createComment('wildcatch pending query');
    results.append(marker);
    window.__wildcatchOutpatientQuery = {id:expected.queryId,marker};
    if (location.href !== url.href || input.value !== searchName || !button.isConnected || button.disabled
      || Date.now() >= permit.expiresAt) return { phase: "waiting" };
    button.click();
    return { phase: "searching", message: "正在 HIS 查詢並核對目前病人…" };
  }
  if (action === "select") {
    const query = window.__wildcatchOutpatientQuery;
    if (!query || query.id !== expected.queryId) return {phase:'retry-query',message:'正在重新準備 HIS 查詢…'};
    if (document.querySelector('#btn00')?.disabled || query.marker.isConnected) {
      return {phase:'searching',message:'等待 HIS 查詢結果完整載入…'};
    }
    if (input.value !== searchName) return {phase:'retry-query',message:'查詢條件已變更，正在重新查詢…'};
    // Consume this completed query once. Later filtering or hidden rows must
    // never turn an ambiguous result into an automatic choice.
    delete window.__wildcatchOutpatientQuery;
    if (partialName) return { phase: "selection", queryCompleted: true, message: "姓名含無法辨識的字，已用部分姓名搜尋；請在 HIS 核對並選定病人。" };
    const paging = document.querySelector('#detail [rel="next"], #detail [rel="prev"], #detail .pagination, #detail .pager')
      || [...document.querySelectorAll('#detail a, #detail button')].some(el=>/^(下一頁|下頁|上一頁|末頁|next|previous|last)$/i.test(norm(el.textContent)));
    if (paging) return {phase:'selection',queryCompleted:true,message:'HIS 結果有分頁，請手動核對並選定病人。'};
    const candidates = new Map();
    let invalidMatchingRow = false;
    for (const table of document.querySelectorAll("#detail table")) {
      const headers = [...(table.rows[0]?.cells || [])].map(cell => norm(cell.textContent));
      const nameColumn = headers.indexOf("姓名"), birthColumn = headers.findIndex(text => text.includes("出生日"));
      if (nameColumn < 0 || birthColumn < 0) continue;
      for (const row of [...table.rows].slice(1)) {
        if (norm(row.cells[nameColumn]?.textContent) !== norm(expected.name)) continue;
        const birth = row.cells[birthColumn]?.textContent?.match(/\d{4}[/-]?\d{2}[/-]?\d{2}/)?.[0].replace(/[/-]/g, "");
        if (!birth) { invalidMatchingRow = true; continue; }
        if (birth !== expected.birthDate.replaceAll("-", "")) continue;
        const link = row.querySelector('a[href*="action=findEmr"]');
        if (!link) { invalidMatchingRow = true; continue; }
        const target = new URL(link.href, location.href);
        const ids = target.searchParams.getAll("histno");
        if (target.origin !== url.origin || target.pathname !== url.pathname || target.searchParams.get("action") !== "findEmr" || ids.length !== 1 || !/^\d{1,12}$/.test(ids[0])) { invalidMatchingRow = true; continue; }
        candidates.set(ids[0], link);
      }
    }
    if (invalidMatchingRow) return {phase:'selection',queryCompleted:true,message:'相符病人的部分結果無法確認，請在 HIS 手動核對病人。'};
    if (candidates.size === 1) {
      const link = [...candidates.values()][0];
      if (!visible(link)) return {phase:'selection',queryCompleted:true,message:'相符結果目前不可操作，請在 HIS 確認病人。'};
      if (location.href !== url.href || !link.isConnected || Date.now() >= permit.expiresAt) return { phase: "waiting" };
      link.click();
      return { phase: "opening", message: "已找到唯一相符病人，正在開啟並核對病歷…" };
    }
    return { phase: "selection", queryCompleted: true, matches: candidates.size, message: candidates.size > 1
      ? "同姓名同生日有多位病人，請在 HIS 選定目前病人。" : "未找到姓名與生日都相符的病人，請在 HIS 確認。" };
  }
  return { phase: "selection", canSearch: true, message: "正在準備查詢目前病人…" };
}
