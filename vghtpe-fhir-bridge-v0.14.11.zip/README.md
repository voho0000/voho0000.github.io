# EHR-FHIR Bridge — Chrome Extension

醫師在 qemr 上正常瀏覽，按 extension 圖示就把當下病人的資料抽出來轉成 FHIR R4。**Extension 在瀏覽器內直接解析 qemr DOM**，不上傳 HTML，不依賴 LLM。

目前版本為 **v0.14.11**，獨立 FHIR／HTML 下載遇到 HIS 調閱視窗時，會以「醫療需要」完成調閱後再擷取；未出現視窗時不點選或送出。每日是否需要調閱理由以 HIS 為準。支援「門診版」：近一年每位主治醫師最新一次門診，保留完整診斷、SOAP 四段、當次用藥與醫囑；popup 與 qemr 浮動 icon 共用取得／停止狀態。詳見 [門診版說明](../docs/OUTPATIENT-MODE.md) 與 [更新紀錄](../CHANGELOG.md)。

v0.14.2 已移除 NIIS 預防接種查詢與 token 設定；啟動新版時刪除舊版 local／sync token。

---

## 安裝

1. Chrome 開 `chrome://extensions/`
2. 右上角開 **Developer mode**
3. 按 **Load unpacked** → 選這個 `extension/` 資料夾

`manifest.json` 的 `host_permissions` 已涵蓋 `*.vghtpe.gov.tw`、`localhost:8000`，以及精準限縮的 MediPrisma `/app` 匯入路徑。要支援其他 HIS 網域，append 一個 entry，重新 load extension。

---

## 兩種輸出模式

Popup 上方的「輸出方式」radio：

| 模式 | 行為 |
|---|---|
| **🔵 上傳後端 (Backend)** | 資料寫進本機 backend FHIR Server，Dashboard 看得到、SMART App 可 launch。跑完會呼叫 `/sync/finalize` 清掉 HIS 已消失的舊資源（tombstone）。 |
| **💾 下載 Bundle (Download)** | **完全在瀏覽器內** map + 打包成 FHIR Bundle 直接下載（`extension/mapper/` 的 JS mapper），**不需要 backend**。 |

✅ **下載模式已是真正的純-extension 模式**（v0.7.0）：mapper 已 port 成 JS（`extension/mapper/`，架構仿 [NHI-FHIR-BRIDGE](https://github.com/voho0000/NHI-FHIR-BRIDGE) 的 `packages/mapper`）。上傳後端模式仍用 backend 的 Python mapper（兩套 mapper 用相同的 SHA-1 stable-ID 演算法，local bundle 與 backend `/sync/import` 不會重複）。

下載的 FHIR JSON、去識別化 JSON、原始 HTML ZIP，以及交付 MediPrisma 的 JSON 檔名，皆與 medcloud2 一樣在副檔名前加上 `-v{版本號}`。版本號自動取自 Extension 的 `manifest.json`，例如 `ehr-fhir-bridge-TEST-001-20261001-v0.12.2.json`。

### JS mapper 架構（`extension/mapper/`）

`sha1.js`（同步 SHA-1 / HMAC-SHA1，對齊 Python stable ID）→ `helpers.js`（stableId / 去識別化）→ 各類 resource mapper → `dispatch.js`（page_type → mapper）→ `build-bundle.js`（本地組 Bundle）。LOINC 兩張表：`loinc-tables.js`（NHI 醫令碼，機械 port 自 NHI repo）+ `vgh-loinc-tables.js`（VGH 院內縮寫，本 repo 新建）。差異詳見 [docs/LOINC-NHI-vs-HIS.md](../docs/LOINC-NHI-vs-HIS.md)。

測試：`cd extension && npm test`（零依賴，合成 fixture，不含 PHI）。

### 去識別化下載

Popup 的「去識別化下載」checkbox（**只影響下載模式**）：Patient.id 以完整病歷號和瀏覽器本機祕密金鑰產生 HMAC 假名、姓名改為 `DEID-xxxxxxxx`、生日只保留年份、電話/地址/身分識別碼移除，並排除原始文件、附件與自由文字。檔名只含假名且帶 `-deid-`。這是降低暴露面的假名化，不等同正式匿名化。

### 一般檢驗報告

v0.11.12 起，檢驗只抓 **`findRes` 一般報告**清單與逐份明細，保留原始結果、單位、參考值與 H/L。`findResd` 累積矩陣是由一般報告整理的資料，因此同步、MediPrisma 交付、合併下載和獨立 HTML ZIP 都不再抓取它，避免重複檢驗與額外請求。舊矩陣的 parser / mapper 仍保留供離線測試既有擷取資料；不會加入新抓取流程。院內縮寫 LOINC 對照仍用於一般報告。

目前一般報告共用下述病歷範圍；年度補查包含門診、住院及急診報告，急診報告依就醫編號連回 EMER Encounter。數值及定性檢驗、短篇心電圖與影像／培養文字報告皆納入。詳見 [急診檢查驗說明](../docs/EMERGENCY-REPORTS.md)。

### 全部病歷共用時間範圍

勾選 **門診版** 時固定近一年，僅擷取每位主治醫師最新一次門診與病人基本資料／過敏；取消勾選恢復原年限。下載、上傳、MediPrisma 浮動一鍵取得與原始 HTML ZIP 共用設定。SOAP 四段按院方標題直接解析，A 區全部 ICD-10 診斷建立 Condition 並連回就診，檢查／檢驗／處置醫令建立 ServiceRequest；耗材保留在原始文件。下述一般範圍規則適用於未勾選門診版的取得。

Popup 步驟 ② 的「病歷範圍」提供 **近 1 年、近 3 年、近 5 年、全部歷史**，預設近 3 年。瀏覽器儲存 `recordYears`，下載 Bundle、後端上傳、合併原始 ZIP、獨立原始 ZIP 與浮動 MediPrisma 一鍵取得共用這個設定；舊累積檢驗的 `labYears` 不沿用。

- 每次取得開始時固定台灣日期，近 N 年從當天往前 N 個曆年計算，包含起訖日；2 月 29 日遇非閏年以 2 月 28 日為起日。畫面顯示實際起訖日期。
- 門診、急診、診斷、用藥、檢驗、影像、手術、植入物與化療依實際日期篩選。住院、出院病摘及癌症治療計畫依期間是否重疊納入；尚未結束的住院／治療計畫保留。生命徵象先按同一期間篩選，再保留每次就醫各類項目最早一筆。
- 病人基本資料及沒有有效日期的紀錄（例如過敏）保留，不將下載時間冒充為發生日期。
- 一般報告近 1 年使用 12 個月清單，其他選項先查 24 個月，再查所選範圍內的院內年度選項；若未提供年度選項，以已知就診年份補查。各年度清單及明細去重，不限於急診，也不查 `findResd`。
- 「全部歷史」以院內系統提供的紀錄與可查年度為限，生命徵象不再以 300 個請求截斷。原有請求節流、取消與錯誤回報持續生效。
- 只上傳近 N 年時不執行全病人的舊資料刪除；完整、無錯誤的全部歷史上傳才可整理後端過期資料。後端先前儲存的更早紀錄因此仍可能出現在 Dashboard。

原始 ZIP 依時間範圍選擇詳情請求，但保留完整原始回應；原始清單、同次住院的用藥／生命徵象頁面可能包含範圍外紀錄。FHIR 的結構化輸出仍依上述日期篩選。ZIP manifest、取得狀態與歷史紀錄會記下此次的時間範圍。

---

## 使用流程

### qemr 頁面一鍵開啟 MediPrisma

進入網址含 `histno=` 的 qemr 病人頁後，右側會出現「北榮院徽 + FHIR 火焰」浮動 icon。點一次會：

1. 重新確認目前 qemr 病人並開始取得資料。
2. 完全在 Extension 內轉成 FHIR R4 Bundle，不上傳 bridge backend。
3. 取得完成後再次確認 qemr 仍是同一位病人。
4. 開啟 `https://mediprisma.tw/app/`，透過 MediPrisma 的本機檔案匯入元件交付 Bundle，等待匯入完成；不啟用 `medcloud2=auto` 模式。

Bundle 不放進 URL、頁面文字或長期 storage；若擷取期間切換病人，會停止交付。浮動 icon 會顯示取得、匯入、完成或錯誤狀態。原有工具列 popup 仍保留後端同步、Bundle 下載與除錯功能。

v0.11.9 起，浮動工具執行中會顯示獨立的 **停止** 按鈕。可停止啟動準備、正在送出的 qemr 請求、排隊與退避等待；停止後顯示「已停止取得」，可再點工具重新開始。若已進入 MediPrisma 交付階段，停止會中斷等待並關閉此次工具新建的 MediPrisma 分頁；已完成匯入的資料不會回滾。更新 Extension 後，請重新整理 qemr 分頁以載入新版浮動工具。

v0.12.2 起，popup 啟動的下載、後端上傳與原始資料取得也會同步到來源 qemr 分頁的浮動 icon，顯示相同進度並可按 **停止**。工具列顯示藍色執行徽章，popup 標誌及浮動 icon 顯示執行動畫；完成或部分完成時三處會出現紅點。開啟 popup 查看同一病人的已完成結果，或完成後切到取得／查看步驟，會清除紅點。查看標記按工作與病人比對，舊視窗不會清除新工作的提醒；重新取得及取消會清除舊紅點，切換病人不沿用前一位的浮動狀態。

1. （只有「上傳後端」模式需要）確認 backend 有跑：`docker compose up -d`。下載模式免 backend。
2. 登入 qemr、進到病人主頁（URL 帶 `histno=`）
3. 按右上 **🏥 EHR-FHIR Bridge** 圖示
4. Popup 顯示 Patient ID = histno；選輸出方式 → 按 **🔄 Sync This Patient**
5. Extension 用 `fetch()` 抓以下頁面，解析後上傳 backend 或本地組 Bundle。v0.11.10 因加速後遇到限流，恢復原本節流：detail pool=2、每 0.4–0.6 秒最多啟動一個 request，每 50 次休息 10–15 秒。429/502/503/504 仍依 `Retry-After` 或指數退避重試，退避會延後所有尚未開始的請求；重試後仍失敗或 qemr 回 403 時停止整次工作。更新後需重新載入 Extension 才會套用新流程：
   - 病人首頁（findEmr）→ patient_info + allergies；findPba → 補身份證號/地址/電話
   - 診斷清單（findPdiagHistory）→ conditions
   - 門診清單（findOpd）+ 每筆 SOAP 詳情 → encounters
   - 住院清單（findAdm）→ encounters
   - **急診紀錄（findErn 清單 + 逐次 caseno 明細）→ Encounter (EMER) + ICD-10 Condition + DocumentReference**：保留掛號時間、主訴、病歷全文與急診 HTML 文件；只解析 ICD-10，不建立 ICD-9 診斷。同一天不同就醫編號分開保存，診斷與文件連回該次急診。
   - **急診摘要（ERS/download/pdf）→ DocumentReference (application/pdf)**：依急診清單的「摘要」表單使用 POST，保留 PDF 原始 bytes；直接 GET 此網址會回 405。下載回應必須有 PDF header，錯誤頁或登入頁不會被當成文件。
   - **住院診斷（findPdiags，逐次就醫編號）→ Condition + Encounter.diagnosis**：保留完整 ICD-10、原始 A/D 類別、序號、輸入日期、生效日期及輸入者；同時保留預設診斷表與逐次查詢回應，合併重複紀錄後連回該次住院。
   - 手術（findOpn）清單 + 每筆 detail → procedures（含 ICD-10-PCS、術前/術後診斷）
   - 一般檢驗與報告清單（findRes，近兩年）+ 每筆 #resdata → observations + diagnostic_reports + procedures
   - 用藥清單（findUd）+ 每筆 #udorder → medications
   - **出院病摘（findDis）→ DocumentReference**（全文 HTML base64 保存，連結到住院 Encounter）；FHIR 同步與原始 HTML 下載皆只抓出院病摘，不抓入院病摘。
   - **人工植入物（findImplant）→ Device**（PORT 等，含廠牌/規格/側別/部位）
   - **生命徵象（findVts，就醫編號 × 量測類型）→ Observation(vital-signs)**：每次就醫各類項目只保留量測時間最早的一筆；同筆血壓與脈搏、身高體重/BMI/BSA 均保留。同一天不同就醫編號分開處理，跳過「全部住院期間」總覽。僅涵蓋 findVts 下拉選單提供的就醫紀錄。
   - **癌症治療計畫書（findPbc）→ CarePlan**（ICD9/療程別/主責醫師/治療起訖日）；**化療計畫（findChem）→ 每週期一個 Procedure**（regimen 全文存 note）
6. Sync 進行中可按 **⏹ 中止同步**（保留已抓取部分）；完成後 popup 顯示明細 + **同步紀錄**
   - 進度區每秒顯示「已用秒數 / 預估總秒數」與已完成/預估請求數；總秒數會依實際展開的明細頁數動態修正
7. 「查看紀錄」與 medcloud2 採相同的 MediPrisma 查看流程與 360px 緊湊介面。按 **開啟 MediPrisma** 直接開啟 `https://mediprisma.tw/app/`，可手動匯入先前下載的 FHIR 檔案；此按鈕不需要 bridge backend，也不會再次取得或自動傳送病歷。若透過 qemr 浮動工具取得，仍沿用自動交付流程。開啟中與失敗訊息直接顯示在查看頁，可重試；**回到取得結果** 返回步驟 2。
   - 使用自架後端時，展開 **自架後端查看**，再按 **開啟後端 SMART App** 或 **開啟 EHR-FHIR Dashboard**。SMART launch 需要病人已上傳；後端離線、找不到病人、驗證失敗與回應逾時會在同頁顯示提示。

### 📥 一次下載 FHIR Bundle + 原始 HTML (ZIP)

Sync 按鈕下方的 **一次下載 FHIR Bundle + 原始 HTML (ZIP)**：

- 只向 qemr 抓一次；每個成功回應同時交給 parser/mapper 產生 FHIR Bundle，並原樣收進 HTML ZIP，不會為兩種輸出重抓
- 完全不經過 backend，完成後直接下載 `ehr-fhir-bridge-{histno}-{日期}-v{版本號}.json` 與 `ehr-html-{histno}-{日期}-v{版本號}.zip`
- 包含 sync 會用到的所有原始 qemr 頁面：findEmr、findPba、findPdiagHistory、findOpd / findAdm / findOpn / findRes / findUd 清單 + 全部 detail 頁（門診 SOAP、手術、用藥、報告）
- ZIP 內含 `capture-manifest.json`，記錄每個檔案的來源 URL 與抓取時間，可直接拿來當 parser 的 regression fixture
- 急診清單與每次急診明細 HTML、可取得的急診摘要 PDF 都會納入 ZIP；合併下載與單獨原始資料擷取皆支援。PDF 保留原始 bytes，manifest 記錄 POST 方法及 application/pdf。ICD-9 不轉成結構化診斷，原始 HTML/PDF 保留原樣。
- 檔案是 UTF-8 重新編碼（瀏覽器解碼後的文字）；頁面裡若有 Big5 的 `<meta charset>` 請忽略，一律用 UTF-8 開

---

## 跟後端的合約

Extension POST `${backend}/sync/upload-structured`，body：

```json
{
  "page_type": "observations",
  "patient_id": "50205180",
  "host": "web9.vghtpe.gov.tw",
  "his_user": "DOC4544L",
  "items": [
    { "date": "2025-12-26", "code": "WBC", "display": "WBC",
      "value": "2830", "unit": "/uL", "reference_range": "4180 ~ 9380",
      "interpretation": "low", "hospital": "臺北榮民總醫院",
      "order_code": "0EAXEBP", "order_name": "WBC,DC,Hb,Plt," }
  ]
}
```

| Field | 說明 |
|---|---|
| `page_type` | 必填 — `patient_info` / `observations` / `medications` / `conditions` / `allergies` / `diagnostic_reports` / `procedures` / `encounters` / `document_references` / `devices` / `careplans` / `service_requests` |
| `patient_id` | `patient_info` 不需要；其他必填 |
| `host` | Canonical host（`web9.vghtpe.gov.tw`），決定 backend 用哪個 grouping handler |
| `his_user` | qemr 登入帳號（從 navbar `使用者:` 解析），記到 audit log |
| `items` | 結構化 dict 陣列，shape 對應 `backend/app/mapper/*.py` 的輸入 |

回傳：

```json
{
  "page_type": "observations",
  "patient_id": "50205180",
  "count": 24,
  "resources": [
    { "resourceType": "DiagnosticReport", "id": "..." },
    { "resourceType": "Observation", "id": "..." }
  ]
}
```

---

## 程式結構

| 檔案 | 角色 |
|---|---|
| `manifest.json` | MV3 — declare SW + host_permissions |
| `background.js` | Service worker。`runSync()` 抓 qemr 頁面 → 在 qemr tab 執行 parser → backend 模式 POST `/sync/upload-structured`；download 模式則直接用 JS mapper 建 Bundle 並下載，不經 backend |
| `qemr-parser.js` | 注入到 qemr tab 的 parser（用 DOMParser）。Exposes `window.__vghParse(pageType, html, opts)` |
| `popup.html` / `popup.css` / `popup.js` | UI — 輸出設定、取得/停止、MediPrisma 查看、進度與紀錄 |
| `viewer.js` | 直接開啟 MediPrisma，以及進階後端 SMART launch 與錯誤提示 |

### DOM Parser 如何拿 DOMParser

MV3 service worker context 沒有 DOMParser。我們的解法是：
1. SW 用 `fetch(...)` 抓回 HTML 字串
2. SW 用 `chrome.scripting.executeScript({tabId, files: ["qemr-parser.js"]})` 把 parser 注入到使用者已開的 qemr tab
3. 接著用 `executeScript({func: () => window.__vghParse(...)})` 在 tab context 跑 parser，回傳結構化 items
4. SW 拿到 items，再走 POST

這比 OffscreenDocument 簡單，而且使用者本來就有 qemr tab 開著，「順便用 tab 當 DOM 沙盒」是合理的。

---

## 加新 qemr 頁面 / 加新 HIS

### 加新 qemr 頁面

1. `qemr-parser.js` — 新增 `parseFooBar(doc)` 函式 + 在 `__vghParse` switch 加一個 case
2. `background.js` — 在 `runSync()` 加 fetch + parse + post
3. backend mappers 若需要新欄位，更新 `backend/app/mapper/<resource>.py`

### 加新 HIS（例：另一家醫院）

1. 寫新 `<hospital>-parser.js`，同樣 expose `window.__vghParse`
2. `background.js` — 加新 host regex + 新的 `runSync` 變體（不同 URL patterns）
3. `popup.js` — host 偵測 dispatch
4. `manifest.json` — 加 host_permissions

詳見 [../docs/HIS_INTEGRATION.md](../docs/HIS_INTEGRATION.md)。

---

## 已知限制

- **Manifest v3** 需要在 `host_permissions` 預先列出 HIS / backend 網域。**生產部署前一定要改**，不要用萬用字元
- **iframe 內容** 抓不到 — 需要時用 `allFrames: true`
- **管理 API 採共享金鑰**，不是每位使用者各自登入；有真實資料時務必設定強 `SYNC_API_KEY`，並限制 backend 只在 loopback 或可信網路上提供

---

## 開發 Tip

**改任何檔案後務必到 `chrome://extensions/` 按 reload**。Service worker log 在 `chrome://extensions/` → 點 extension → Inspect views: service worker。

### HIS 手動選人後繼續抓取

搭配雲端抓抓 0.15.10 以上，部分姓名搜尋需要手動確認時，請先選定正確病人並完成調閱確認，再點病歷頁的「繼續抓取」。按鈕會重新核對病人並由原雲端分頁開始新一輪擷取。接續紀錄保留 5 分鐘；逾時或原雲端病人已切換時，請回雲端重新取得。
