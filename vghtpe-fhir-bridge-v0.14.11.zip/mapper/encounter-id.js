import { stableId } from "./helpers.js";

export function encounterInstance(raw) {
  const encClass = (raw.encounter_class || raw.class || "AMB").toUpperCase();
  if (encClass === "IMP") return "";
  if (raw.encounter_instance !== undefined) return raw.encounter_instance;
  if (encClass === "EMER") return raw.case_no || raw.encounter_id || raw.caseno || "";
  return raw.case_no || raw.encounter_id || raw.visit_time || [raw.department, raw.provider].filter(Boolean).join("|");
}

export function encounterId(raw, patientId) {
  return stableId(patientId, raw.encounter_ref_date || raw.date || "",
    (raw.encounter_class || raw.class || "AMB").toUpperCase(), encounterInstance(raw));
}
