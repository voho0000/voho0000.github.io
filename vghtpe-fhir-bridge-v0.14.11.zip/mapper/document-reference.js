// DocumentReference mapper — discharge/admission/ED HTML and ED summary PDF.
// HTML from qemr and PDF from ERS are stored as base64 attachments. Mirrors NHI's
// document-reference transport: the HTML is preserved faithfully (base64) — no
// sanitising, so the SMART app can render the real discharge summary.
//
// Input dict (from qemr-parser parseSummaryDetail):
//   { doc_type: "discharge"|"admission", date, admit_date, discharge_date,
//     department, physician, encounter_ref_date, html, caseno? }

import { stableId, b64utf8, SRC_META } from "./helpers.js";
import { encounterId } from "./encounter-id.js";

const TYPE = {
  discharge:  { code: "18842-5", display: "Discharge summary", title: "出院病摘" },
  admission:  { code: "34117-2", display: "History and physical note", title: "入院病摘" },
  emergency: { code: "34111-5", display: "Emergency Department Note", title: "急診病歷" },
  "emergency-summary": { code: "96335-5", display: "Emergency department Summary note", title: "急診摘要" },
  outpatient: { display: "Outpatient SOAP note", title: "門診 SOAP 與醫囑" },
};

export function mapDocumentReference(raw, patientId) {
  const html = raw.html || "";
  const pdf = raw.pdf_base64 || "";
  if (!html.trim() && !pdf) return null;

  const docType = Object.hasOwn(TYPE, raw.doc_type) ? raw.doc_type : "discharge";
  const t = TYPE[docType];
  const anchorDate = raw.admit_date || raw.date || "";

  const resource = {
    resourceType: "DocumentReference",
    id: stableId(patientId, docType, anchorDate, raw.doc_type === "outpatient" ? raw.encounter_instance || "" : raw.caseno || ""),
    meta: { ...SRC_META },
    status: "current",
    type: {
      ...(t.code ? { coding: [{ system: "http://loinc.org", code: t.code, display: t.display }] } : {}),
      text: t.title,
    },
    category: [{
      coding: [{
        system: "http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category",
        code: "clinical-note", display: "Clinical Note",
      }],
    }],
    subject: { reference: `Patient/${patientId}` },
    content: [{
      attachment: {
        contentType: pdf ? "application/pdf" : "text/html",
        language: "zh-TW",
        data: pdf || b64utf8(html),
        title: t.title,
      },
    }],
  };

  if (raw.datetime) resource.date = raw.datetime;
  else if (raw.date) resource.date = raw.date + "T00:00:00+08:00";

  const context = {};
  if (raw.admit_date || raw.discharge_date) {
    const period = {};
    if (raw.admit_date) period.start = raw.admit_date + "T00:00:00+08:00";
    if (raw.discharge_date) period.end = raw.discharge_date + "T00:00:00+08:00";
    context.period = period;
  }
  // ED documents use the case number; inpatient document IDs stay unchanged.
  if (raw.encounter_ref_date) {
    const encClass = raw.encounter_class || "IMP";
    context.encounter = [{ reference: `Encounter/${encounterId({ ...raw, encounter_class: encClass }, patientId)}` }];
  }
  if (Object.keys(context).length) resource.context = context;

  if (raw.department) resource.description = raw.department;
  const physician = (raw.physician || "").trim();
  if (physician) resource.author = [{ display: physician }];

  return resource;
}
