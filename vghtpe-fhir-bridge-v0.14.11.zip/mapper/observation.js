// Observation + DiagnosticReport(panel) mapper.
//
// Two entry points, matching the two VGH lab data models (see
// docs/LOINC-NHI-vs-HIS.md):
//
//   1. mapObservationsGrouped(items, patientId) — port of
//      backend/app/mapper/observation.py `map_observations_grouped`. Groups
//      findRes #RSCONTENT detail rows by (order_code, date, hospital) → one
//      DiagnosticReport + N Observations. Rows carry their own display/unit/
//      reference_range/H-L flag. Used for the (A) findRes path.
//
//   2. mapVghCumulative(items, patientId) — NEW, for the (B) findResd 累積
//      矩陣. Each item is one cell {panel, date, abbrev, value, abnormal}.
//      LOINC + unit come from vgh-loinc-tables (the matrix has none), and
//      interpretation is Abnormal-only (colour gives no H/L direction).

import { stableId, SRC_META } from "./helpers.js";
import { reportIdentityDate } from "./report-identity.js";
import { reportEncounter, applyReportOrder, reportDateExtensions } from "./report-context.js";
import { lookupVghLab, normalizeVghPanel } from "./vgh-loinc-tables.js";
import { isLabMetadataRow, labPanel, labResultKey, normalizeLabQuantity, normalizeLabRange } from "./lab-results.js";

const IMAGING_KEYWORDS = [
  "ultrasound", "sonogram", "sonography", "echo",
  "ct ", "ct/", "ct-", "computed tomography", "mri", "magnetic resonance",
  "x-ray", "xray", "x ray", "mammography", "mammo", "ekg", "ecg", "electrocardiogram",
  "endoscop", "colonoscop", "gastroscop", "bronchoscop", "pet/ct", "pet ", "spect",
  "影像", "超音波", "電腦斷層", "核磁共振", "心電圖", "內視鏡", "乳房攝影",
];

function looksLikeImaging(display, code) {
  const hay = `${display} ${code}`.toLowerCase();
  return IMAGING_KEYWORDS.some((kw) => hay.includes(kw));
}

const MEANINGFUL_INTERP = ["normal", "abnormal", "high", "low", "critical", "positive", "negative"];

function hasValue(v) {
  return v != null && !["", "—", "-", "N/A", "null"].includes(String(v).trim());
}

function mapInterpretation(interp) {
  const table = {
    high: ["H", "High"], low: ["L", "Low"], normal: ["N", "Normal"],
    critical: ["AA", "Critical abnormal"], abnormal: ["A", "Abnormal"],
  };
  const entry = table[(interp || "").toLowerCase()];
  if (!entry) return null;
  return { system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation", code: entry[0], display: entry[1] };
}

function valueField(value, unit) {
  const num = Number(String(value).replace(/,/g, ""));
  if (!Number.isNaN(num) && String(value).trim() !== "") {
    return { valueQuantity: { value: num, unit: unit || "", system: "http://unitsofmeasure.org", code: unit || "" } };
  }
  return { valueString: String(value) };
}

// ── (A) findRes #RSCONTENT grouped-by-order-code path ─────────────────────────

export function mapObservationsGrouped(rawItems, patientId) {
  const cleaned = (rawItems || []).filter((raw) => {
    if (!raw || typeof raw !== "object") return false;
    const display = raw.display || raw.code || "";
    if (isLabMetadataRow(raw)) return false;
    if (looksLikeImaging(display, raw.code || "")) return false;
    return hasValue(raw.value) || MEANINGFUL_INTERP.includes((raw.interpretation || "").toLowerCase());
  });

  // Group by order and the most precise source occurrence identifier. Using
  // only the calendar date merges repeated tests from the same day.
  // items — never recover them by splitting the joined key (values can contain
  // the delimiter).
  const groups = new Map();
  for (const raw of cleaned) {
    const occurrence = raw.request_no || raw.work_no || reportIdentityDate(raw);
    const parts = [raw.order_code || raw.code || raw.display || "", occurrence, raw.hospital || "", reportEncounter(raw, patientId)?.reference || ""];
    const key = JSON.stringify(parts);
    if (!groups.has(key)) groups.set(key, { parts, items: [] });
    groups.get(key).items.push(raw);
  }

  const out = [];
  for (const { parts, items } of groups.values()) {
    const [groupKeyCode, occurrence, hospital, encounterRef] = parts;
    const date = items[0]?.date || "";
    const deduped = dedupePanelItems(items);
    const obsResources = [];
    for (const it of deduped) {
      const obs = buildObservation(it, patientId, groupKeyCode);
      if (obs) obsResources.push(obs);
    }
    if (!obsResources.length) continue;

    const orderName = (items.find((it) => it.order_name) || {}).order_name || null;
    const dr = {
      resourceType: "DiagnosticReport",
      id: stableId(patientId, "DR", String(groupKeyCode), occurrence, hospital, ...(encounterRef ? [encounterRef] : [])),
      meta: { ...SRC_META },
      status: "final",
      category: [{ coding: [{ system: "http://terminology.hl7.org/CodeSystem/v2-0074", code: "LAB", display: "Laboratory" }] }],
      code: {
        coding: [{ system: "urn:oid:nhi.order.code", code: String(groupKeyCode) || "UNKNOWN", display: orderName || String(groupKeyCode) }],
        text: orderName || String(groupKeyCode),
      },
      subject: { reference: `Patient/${patientId}` },
      result: obsResources.map((o) => ({ reference: `Observation/${o.id}` })),
    };
    const effective = items.find((it) => it.effective_datetime)?.effective_datetime;
    if (effective) dr.effectiveDateTime = effective;
    else if (date) dr.effectiveDateTime = date + "T00:00:00+08:00";
    if (hospital) dr.performer = [{ display: hospital }];
    const first = items[0];
    const dates = reportDateExtensions(first);
    if (dates.length) dr.extension = dates;
    if (encounterRef) dr.encounter = { reference: encounterRef };
    if (first.issued) dr.issued = first.issued;
    if (first.specimen) dr.specimen = [{ display: first.specimen }];
    if (first.interpreting_physician || first.reporter) dr.resultsInterpreter = [{ display: first.interpreting_physician || first.reporter }];
    const identifiers = [];
    if (first.request_no) identifiers.push({ system: "urn:oid:vgh.report.request", value: String(first.request_no) });
    if (first.work_no) identifiers.push({ system: "urn:oid:vgh.report.work", value: String(first.work_no) });
    if (identifiers.length) dr.identifier = identifiers;

    applyReportOrder(dr, first, patientId);
    out.push(dr, ...obsResources);
  }
  return out;
}

function buildObservation(raw, patientId, panelCode) {
  const display = raw.display || raw.code || "";
  const panel = labPanel(raw);
  const mapped = lookupVghLab(panel, raw.code || display, raw);
  const occurrence = raw.request_no || raw.work_no || reportIdentityDate(raw);
  const encounter = reportEncounter(raw, patientId);
  const obsId = stableId(patientId, "obs", String(panelCode), display, occurrence, ...(encounter ? [encounter.reference] : []));
  const resource = {
    resourceType: "Observation",
    id: obsId,
    meta: { ...SRC_META },
    status: "final",
    category: [{ coding: [{ system: "http://terminology.hl7.org/CodeSystem/observation-category", code: "laboratory", display: "Laboratory" }] }],
    code: { coding: buildCodings(raw.code || "", display, mapped?.loinc || null, mapped?.display), text: mapped?.display || (panel === "Ascites" ? `Ascites ${display}` : display) || "Unknown Lab" },
    subject: { reference: `Patient/${patientId}` },
  };
  if (encounter) resource.encounter = encounter;
  if (raw.effective_datetime) resource.effectiveDateTime = raw.effective_datetime;
  else if (raw.date) resource.effectiveDateTime = raw.date + "T00:00:00+08:00";
  if (raw.hospital) resource.performer = [{ display: raw.hospital }];
  if (raw.specimen) resource.specimen = { display: raw.specimen };
  if (raw.issued) resource.issued = raw.issued;
  const quantity = normalizeLabQuantity(mapped?.loinc, raw.value, raw.unit);
  if (hasValue(raw.value)) Object.assign(resource, valueField(quantity.value, quantity.unit));
  if (raw.reference_range) resource.referenceRange = [{ text: String(normalizeLabRange(raw.reference_range, quantity.factor)) }];
  const interp = mapInterpretation((raw.interpretation || "").toLowerCase());
  if (interp) resource.interpretation = [{ coding: [interp] }];
  applyReportOrder(resource, raw, patientId);
  return resource;
}

function buildCodings(code, display, loinc, loincDisplay) {
  const codings = [];
  if (loinc) codings.push({ system: "http://loinc.org", code: loinc, display: loincDisplay || display });
  codings.push({ system: "urn:oid:his.lab.code", code: code || display, display });
  return codings;
}

function dedupePanelItems(items) {
  const unique = new Map();
  for (const it of items) {
    const key = labResultKey(it);
    if (!unique.has(key)) unique.set(key, it);
  }
  return [...unique.values()];
}

// ── (B) findResd cumulative-matrix path ───────────────────────────────────────
// items: [{panel, date, datetime, abbrev, value, abnormal}]. One DR per
// (panel, datetime) time-point; Observations resolve LOINC/unit from the VGH
// table. `abnormal` is a boolean (from the cell's inline colour) → interpretation
// "A" only (no H/L direction available in the matrix).

export function mapVghCumulative(rawItems, patientId) {
  const items = (rawItems || []).filter((it) => it && typeof it === "object" && !isLabMetadataRow(it) && hasValue(it.value));
  const groups = new Map();
  for (const it of items) {
    const parts = [normalizeVghPanel(it.panel), it.datetime || it.date || "", it.specimen || "", it.hospital || "臺北榮民總醫院"];
    const key = JSON.stringify(parts);
    if (!groups.has(key)) groups.set(key, { parts, cells: [] });
    groups.get(key).cells.push(it);
  }

  const out = [];
  for (const { parts, cells } of groups.values()) {
    const [panel, datetime, specimen, hospital] = parts;
    const isoDT = vghDateToIso(datetime);
    const obsResources = [];
    for (const cell of [...new Map(cells.map(cell => [labResultKey(cell), cell])).values()]) {
      const obs = buildVghObservation(cell, patientId, panel, isoDT);
      if (obs) obsResources.push(obs);
    }
    if (!obsResources.length) continue;

    const dr = {
      resourceType: "DiagnosticReport",
      id: stableId(patientId, "DR", "vgh", panel, datetime, specimen, hospital),
      meta: { ...SRC_META },
      status: "final",
      category: [{ coding: [{ system: "http://terminology.hl7.org/CodeSystem/v2-0074", code: "LAB", display: "Laboratory" }] }],
      code: { coding: [{ system: "urn:oid:vgh.lab.panel", code: panel, display: panel }], text: panel },
      subject: { reference: `Patient/${patientId}` },
      result: obsResources.map((o) => ({ reference: `Observation/${o.id}` })),
      performer: [{ display: hospital }],
    };
    if (isoDT) { dr.effectiveDateTime = isoDT; dr.issued = isoDT; }
    if (specimen) dr.specimen = [{ display: specimen }];
    out.push(dr, ...obsResources);
  }
  return out;
}

function buildVghObservation(cell, patientId, panel, isoDT) {
  const abbrev = (cell.abbrev || "").trim();
  const mapped = lookupVghLab(panel, abbrev); // {loinc, unit, display} | null

  const codings = [];
  if (mapped && mapped.loinc) codings.push({ system: "http://loinc.org", code: mapped.loinc, display: mapped.display || abbrev });
  // Always keep the VGH internal abbreviation as a parallel coding.
  codings.push({ system: "urn:oid:vgh.lab.abbrev", code: abbrev, display: abbrev });

  const resource = {
    resourceType: "Observation",
    id: stableId(patientId, "vghobs", panel, abbrev, cell.datetime || cell.date || "", cell.specimen || "", cell.hospital || "臺北榮民總醫院"),
    meta: { ...SRC_META },
    status: "final",
    category: [{ coding: [{ system: "http://terminology.hl7.org/CodeSystem/observation-category", code: "laboratory", display: "Laboratory" }] }],
    code: { coding: codings, text: (mapped && mapped.display) || (panel === "Ascites" ? `Ascites ${abbrev}` : abbrev) },
    subject: { reference: `Patient/${patientId}` },
    performer: [{ display: cell.hospital || "臺北榮民總醫院" }],
  };
  if (isoDT) resource.effectiveDateTime = isoDT;
  if (cell.specimen) resource.specimen = { display: cell.specimen };
  Object.assign(resource, valueField(cell.value, (mapped && mapped.unit) || ""));
  // Matrix gives no H/L direction — only "abnormal" (red cell). Map to A.
  if (cell.abnormal) resource.interpretation = [{ coding: [mapInterpretation("abnormal")] }];
  return resource;
}

// VGH matrix datetime "20-09-22 22:18" (YY-MM-DD HH:MM, 2-digit year) → ISO.
// All records in this data are 2000+, so prefix "20".
function vghDateToIso(dt) {
  const m = String(dt || "").match(/^(\d{2})-(\d{2})-(\d{2})(?:\s+(\d{2}):(\d{2}))?/);
  if (!m) return "";
  const [, yy, mm, dd, hh, mi] = m;
  const year = 2000 + parseInt(yy, 10);
  const time = hh != null ? `${hh}:${mi}:00` : "00:00:00";
  return `${year}-${mm}-${dd}T${time}+08:00`;
}
