// Procedure mapper — ported from backend/app/mapper/procedure.py.
// Returns null for rows with no indicative content (note/body_site/preop/
// postop/start_time) so lab list-page rows don't become bogus procedures.

import { stableId, SRC_META } from "./helpers.js";

export function mapProcedure(raw, patientId) {
  const note = (raw.note || "").trim();
  const bodySite = (raw.body_site || "").trim();
  const preop = (raw.preop_diagnosis || "").trim();
  const postop = (raw.postop_diagnosis || "").trim();
  const startTime = (raw.start_time || "").trim();
  if (!(note || bodySite || preop || postop || startTime)) return null;

  const display = raw.display || "Unknown Procedure";
  const code = raw.code;

  const resource = {
    resourceType: "Procedure",
    id: stableId(patientId, code || display, raw.date || ""),
    meta: { ...SRC_META },
    status: raw.status || "completed",
    subject: { reference: `Patient/${patientId}` },
    code: {
      coding: [{ system: mapSystem(raw.system || ""), code: code || display, display }],
      text: display,
    },
  };

  const st = raw.start_time, et = raw.end_time;
  if (st || et) {
    const period = {};
    if (st) period.start = st;
    if (et) period.end = et;
    resource.performedPeriod = period;
  } else if (raw.date) {
    resource.performedDateTime = raw.date + "T00:00:00+08:00";
  }

  if (raw.body_site) resource.bodySite = [{ text: raw.body_site }];
  const notes = [];
  if (raw.note) notes.push(raw.note);
  if (raw.operative_note) notes.push(`手術發現暨程序：\n${raw.operative_note}`);
  for (const [label, value] of [
    ["麻醉", raw.anesthesia], ["科別", raw.department], ["病房/來源", raw.ward],
    ["傷口分類", raw.wound_class], ["手術姿勢", raw.position], ["消毒劑", raw.disinfectant],
    ["關閉方式", raw.closure], ["內視鏡", raw.endoscope], ["再手術", raw.reoperation],
  ]) if (value) notes.push(`${label}：${value}`);
  if (notes.length) resource.note = notes.map((text) => ({ text }));

  const performers = [];
  const addPerformer = (role, value) => {
    if (!value) return;
    performers.push({
      function: { coding: [{ system: "urn:oid:vgh.procedure.role", code: role, display: role }], text: role },
      actor: { display: String(value) },
    });
  };
  addPerformer("surgeon", raw.surgeon);
  addPerformer("attending", raw.attending_physician);
  for (const assistant of (raw.assistants || [])) addPerformer("assistant", assistant);
  for (const anesthesiologist of (raw.anesthesiologists || [])) addPerformer("anesthesiologist", anesthesiologist);
  if (performers.length) resource.performer = performers;

  const icd10 = raw.icd10_codes || [];
  if (Array.isArray(icd10)) {
    for (const entry of icd10) {
      if (!entry || typeof entry !== "object") continue;
      const codeVal = (entry.code || "").trim();
      const disp = (entry.display || "").trim();
      if (!codeVal) continue;
      resource.code.coding.push({ system: "http://hl7.org/fhir/sid/icd-10-pcs", code: codeVal, display: disp || codeVal });
    }
  }

  if (preop) resource.reasonCode = [{ text: preop }];
  if (postop) resource.outcome = { text: postop };

  return resource;
}

function mapSystem(hint) {
  const s = typeof hint === "string" ? hint.toLowerCase() : "";
  if (s.includes("snomed")) return "http://snomed.info/sct";
  if (s.includes("icd")) return "http://hl7.org/fhir/sid/icd-10-pcs";
  return "urn:oid:his.procedure.code";
}
