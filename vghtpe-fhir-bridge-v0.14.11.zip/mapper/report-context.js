import { encounterId } from "./encounter-id.js";
import { mapServiceRequest } from "./service-request.js";
import { stableId } from "./helpers.js";

export function reportDateExtensions(raw) {
  return [
    ...(raw.reported_at ? [{url:"https://cloud-wildcatch.invalid/fhir/StructureDefinition/medcloud-source-report-date",valueString:String(raw.reported_at)}] : []),
    ...(raw.source_report_date ? [{url:"https://cloud-wildcatch.invalid/fhir/StructureDefinition/medcloud-source-report-catalog-date",valueDate:String(raw.source_report_date)}] : []),
  ];
}

// Link only a matched outpatient request or an actual ED case. A report
// date alone cannot identify the originating encounter.
export function reportEncounter(raw, patientId) {
  if (raw.outpatient_orders?.length) return { reference: `Encounter/${encounterId(raw.outpatient_orders[0], patientId)}` };
  if (raw.encounter_class !== "EMER" || !raw.case_no || !raw.encounter_ref_date) return null;
  return { reference: `Encounter/${stableId(patientId, raw.encounter_ref_date, "EMER", raw.case_no)}` };
}

export function applyReportOrder(resource, raw, patientId) {
  let sourceOrders = raw.outpatient_orders || [];
  if (resource.resourceType === "Observation" && sourceOrders.length > 1) {
    const normalize = value => String(value || "").normalize("NFKC").replace(/\s+/g, "").toUpperCase();
    sourceOrders = sourceOrders.filter(order => normalize(order.display).split(/[,，]/).filter(Boolean)
      .some(name => name === normalize(raw.display) || name === normalize(raw.code)));
    // Unknown component aliases link to orders only through parent DR membership;
    // never attribute an HDL result to the separate TG order in that panel.
  }
  const orders = sourceOrders.map(order => mapServiceRequest(order, patientId)).filter(Boolean);
  if (!orders.length) return;
  resource.basedOn = orders.map(order => ({ reference: `ServiceRequest/${order.id}` }));
  resource.extension = [...(resource.extension || []), {
    url: "urn:vgh:report:order-match-method", valueCode: raw.order_match_method,
  }];
}
