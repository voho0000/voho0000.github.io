// Minimal synchronous SHA-1 (hex), pure JS, no deps.
//
// Why vendored + synchronous: the FHIR mappers derive stable resource IDs via
// sha1(...).slice(0,32) all over the place, synchronously. SubtleCrypto.digest
// is async and would force every mapper (and its callers) to become async. A
// ~40-line synchronous SHA-1 keeps the mapper code identical in shape to the
// backend's Python (hashlib.sha1) so the two produce the SAME IDs — which is
// what makes "extension local bundle → backend /sync/import" idempotent.
//
// Operates on the UTF-8 bytes of the input string, matching Python's
// hashlib.sha1(s.encode()).

function utf8Bytes(str) {
  return new TextEncoder().encode(str);
}

function sha1Bytes(msg) {
  const ml = msg.length * 8;

  // Pre-processing: append 0x80, pad to 56 mod 64, append 64-bit length.
  const withPad = new Uint8Array((((msg.length + 8) >> 6) + 1) * 64);
  withPad.set(msg);
  withPad[msg.length] = 0x80;
  // 64-bit big-endian bit length in the last 8 bytes.
  const dv = new DataView(withPad.buffer);
  dv.setUint32(withPad.length - 4, ml >>> 0, false);
  dv.setUint32(withPad.length - 8, Math.floor(ml / 0x100000000), false);

  let h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476, h4 = 0xc3d2e1f0;
  const w = new Uint32Array(80);

  for (let off = 0; off < withPad.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4, false);
    for (let i = 16; i < 80; i++) {
      const v = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16];
      w[i] = (v << 1) | (v >>> 31);
    }
    let a = h0, b = h1, c = h2, d = h3, e = h4;
    for (let i = 0; i < 80; i++) {
      let f, k;
      if (i < 20)      { f = (b & c) | (~b & d);          k = 0x5a827999; }
      else if (i < 40) { f = b ^ c ^ d;                   k = 0x6ed9eba1; }
      else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8f1bbcdc; }
      else             { f = b ^ c ^ d;                   k = 0xca62c1d6; }
      const t = (((a << 5) | (a >>> 27)) + f + e + k + w[i]) >>> 0;
      e = d; d = c; c = (b << 30) | (b >>> 2); b = a; a = t;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0;
    h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0;
  }

  const out = new Uint8Array(20);
  const outView = new DataView(out.buffer);
  for (const [i, value] of [h0, h1, h2, h3, h4].entries()) {
    outView.setUint32(i * 4, value, false);
  }
  return out;
}

function hex(bytes) {
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function sha1hex(str) {
  return hex(sha1Bytes(utf8Bytes(str)));
}

// HMAC-SHA1 is used only for stable pseudonymous patient identifiers. SHA-1
// remains here for compatibility with existing deterministic resource ids;
// HMAC prevents a downloaded id from being reversed through a small MRN
// dictionary unless the per-browser secret is also known.
export function hmacSha1hex(key, message) {
  const blockSize = 64;
  let keyBytes = utf8Bytes(String(key));
  if (keyBytes.length > blockSize) keyBytes = sha1Bytes(keyBytes);
  const padded = new Uint8Array(blockSize);
  padded.set(keyBytes);
  const innerPad = new Uint8Array(blockSize);
  const outerPad = new Uint8Array(blockSize);
  for (let i = 0; i < blockSize; i++) {
    innerPad[i] = padded[i] ^ 0x36;
    outerPad[i] = padded[i] ^ 0x5c;
  }
  const messageBytes = utf8Bytes(String(message));
  const innerInput = new Uint8Array(blockSize + messageBytes.length);
  innerInput.set(innerPad);
  innerInput.set(messageBytes, blockSize);
  const innerDigest = sha1Bytes(innerInput);
  const outerInput = new Uint8Array(blockSize + innerDigest.length);
  outerInput.set(outerPad);
  outerInput.set(innerDigest, blockSize);
  return hex(sha1Bytes(outerInput));
}
