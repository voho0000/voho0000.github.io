// Vital-signs mapper — 生命徵象 from qemr findVts. Produces FHIR R4
// Observations in the standard `vital-signs` category with proper LOINC codes.
// Blood pressure follows the FHIR vital-signs profile: ONE Observation
// (85354-9) carrying systolic (8480-6) + diastolic (8462-4) as components.
//
// Input items (from qemr-parser parseVitals), the first row per case + type.
// Optional case_no keeps separate encounters distinct at the same timestamp:
//   BPP  {type,datetime,bp:"120/80",pulse}
//   TMP  {type,datetime,temp}   RSP {type,datetime,rr}
//   OXY  {type,datetime,spo2,o2flow,device}
//   HWS  {type,datetime,height,weight,bsa,bmi}
//   BDS  {type,datetime,glucose}   NYHA {type,datetime,nyha}

import { stableId, SRC_META } from "./helpers.js";

const HOSPITAL = "臺北榮民總醫院";
const VITAL_CATEGORY = [{
  coding: [{ system: "http://terminology.hl7.org/CodeSystem/observation-category", code: "vital-signs", display: "Vital Signs" }],
}];

function num(v, unit) {
  if (typeof v !== "string" && typeof v !== "number") return null;
  const suffixes = {
    "/min": "(?:/min|bpm|次/分)", Cel: "(?:Cel|°\\s*C|℃|C)", "%": "%",
    "L/min": "(?:L/min|LPM)", cm: "(?:cm|公分)", kg: "(?:kg|公斤)",
    "kg/m2": "(?:kg/m2|kg/m²)", m2: "(?:m2|m²)", "mg/dL": "mg/dL",
  };
  const numeric = "[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?";
  const suffix = suffixes[unit];
  const match = String(v).trim().match(new RegExp(`^(${numeric})\\s*${suffix ? `(?:${suffix})?` : ""}$`, "i"));
  if (!match) return null;
  const n = Number(match[1]);
  return Number.isFinite(n) ? n : null;
}

function bloodPressure(value) {
  return String(value || "").match(/^\s*((?:\d+(?:\.\d*)?|\.\d+))\s*\/\s*((?:\d+(?:\.\d*)?|\.\d+))\s*(?:mmHg|mm\[Hg\])?\s*$/i);
}

// Empty cells mean unmeasured. Nonempty cells rejected by the same mapper
// conversion must be reported without dropping other useful values in a row.
export function hasUnmappedVitalValue(item) {
  const fields = {
    BPP: [["pulse", "/min"]], TMP: [["temp", "Cel"]], RSP: [["rr", "/min"]],
    OXY: [["spo2", "%"], ["o2flow", "L/min"]],
    HWS: [["height", "cm"], ["weight", "kg"], ["bmi", "kg/m2"], ["bsa", "m2"]],
    BDS: [["glucose", "mg/dL"]],
  };
  const nonempty = value => value != null && !/^(?:|[-—]|N\/A)$/i.test(String(value).trim());
  if (!Object.hasOwn(fields,item.type) && item.type !== "NYHA") return true;
  return (item.type === "BPP" && nonempty(item.bp) && !bloodPressure(item.bp))
    || (fields[item.type] || []).some(([field,unit]) => nonempty(item[field]) && num(item[field],unit) === null);
}

// One quantitative vital Observation.
function vitalId(patientId, datetime, loinc, caseNo) {
  const parts = [patientId, "vital", loinc, datetime];
  if (caseNo) parts.push(caseNo);
  return stableId(...parts);
}

function vitalObs(patientId, datetime, loinc, display, value, unit, caseNo) {
  const n = num(value, unit);
  if (n === null) return null;
  return {
    resourceType: "Observation",
    id: vitalId(patientId, datetime, loinc, caseNo),
    meta: { ...SRC_META },
    status: "final",
    category: VITAL_CATEGORY,
    code: { coding: [{ system: "http://loinc.org", code: loinc, display }], text: display },
    subject: { reference: `Patient/${patientId}` },
    effectiveDateTime: datetime,
    valueQuantity: { value: n, unit, system: "http://unitsofmeasure.org", code: unit },
    performer: [{ display: HOSPITAL }],
  };
}

export function mapVitalSigns(rawItems, patientId) {
  const out = [];
  for (const it of rawItems || []) {
    if (!it || !it.datetime) continue;
    const dt = it.datetime;
    switch (it.type) {
      case "BPP": {
        const m = bloodPressure(it.bp);
        if (m) {
          const sys = Number(m[1]), dia = Number(m[2]);
          out.push({
            resourceType: "Observation",
            id: vitalId(patientId, dt, "85354-9", it.case_no),
            meta: { ...SRC_META },
            status: "final",
            category: VITAL_CATEGORY,
            code: { coding: [{ system: "http://loinc.org", code: "85354-9", display: "Blood pressure panel" }], text: "血壓" },
            subject: { reference: `Patient/${patientId}` },
            effectiveDateTime: dt,
            performer: [{ display: HOSPITAL }],
            component: [
              { code: { coding: [{ system: "http://loinc.org", code: "8480-6", display: "Systolic blood pressure" }] },
                valueQuantity: { value: sys, unit: "mm[Hg]", system: "http://unitsofmeasure.org", code: "mm[Hg]" } },
              { code: { coding: [{ system: "http://loinc.org", code: "8462-4", display: "Diastolic blood pressure" }] },
                valueQuantity: { value: dia, unit: "mm[Hg]", system: "http://unitsofmeasure.org", code: "mm[Hg]" } },
            ],
          });
        }
        const hr = vitalObs(patientId, dt, "8867-4", "Heart rate", it.pulse, "/min", it.case_no);
        if (hr) out.push(hr);
        break;
      }
      case "TMP": out.push(vitalObs(patientId, dt, "8310-5", "Body temperature", it.temp, "Cel", it.case_no)); break;
      case "RSP": out.push(vitalObs(patientId, dt, "9279-1", "Respiratory rate", it.rr, "/min", it.case_no)); break;
      case "OXY": {
        out.push(vitalObs(patientId, dt, "2708-6", "Oxygen saturation", it.spo2, "%", it.case_no));
        const flow = vitalObs(patientId, dt, "3151-8", "Inhaled oxygen flow rate", it.o2flow, "L/min", it.case_no);
        if (flow) out.push(flow);
        break;
      }
      case "HWS": {
        out.push(vitalObs(patientId, dt, "8302-2", "Body height", it.height, "cm", it.case_no));
        out.push(vitalObs(patientId, dt, "29463-7", "Body weight", it.weight, "kg", it.case_no));
        out.push(vitalObs(patientId, dt, "39156-5", "Body mass index", it.bmi, "kg/m2", it.case_no));
        out.push(vitalObs(patientId, dt, "8277-6", "Body surface area", it.bsa, "m2", it.case_no));
        break;
      }
      case "BDS": out.push(vitalObs(patientId, dt, "2339-0", "Glucose [Mass/volume] in Blood", it.glucose, "mg/dL", it.case_no)); break;
      case "NYHA": {
        const v = (it.nyha || "").trim();
        if (v) out.push({
          resourceType: "Observation",
          id: vitalId(patientId, dt, "88055-3", it.case_no),
          meta: { ...SRC_META },
          status: "final",
          category: VITAL_CATEGORY,
          code: { coding: [{ system: "http://loinc.org", code: "88055-3", display: "NYHA heart failure classification" }], text: "NYHA Fc" },
          subject: { reference: `Patient/${patientId}` },
          effectiveDateTime: dt,
          valueString: v,
          performer: [{ display: HOSPITAL }],
        });
        break;
      }
      default: break;
    }
  }
  return out.filter(Boolean);
}
