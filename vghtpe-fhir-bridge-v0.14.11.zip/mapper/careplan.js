// CarePlan mapper — 癌症治療計畫書 (oncology treatment plan) from qemr findPbc.
// Structured fields from the plan list (no detail fetch; 內容 is an RTF export).
//
// Input dict (from qemr-parser parseCancerPlans):
//   { icd9, mdt, course, version, physician, draft_date, start_date,
//     end_date, finalize_date, first_finalize_date }  (any may be empty)

import { stableId, SRC_META } from "./helpers.js";

export function mapCarePlan(raw, patientId) {
  const startDate = raw.start_date || "";
  const finalizeDate = raw.finalize_date || "";
  const course = raw.course || "";
  // Nothing useful to anchor a plan on → skip.
  if (!startDate && !finalizeDate && !course) return null;

  const anchor = startDate || finalizeDate || raw.draft_date || "";
  const titleParts = [];
  if (course) titleParts.push(`療程 ${course}`);
  if (raw.version) titleParts.push(`v${raw.version}`);
  const title = titleParts.join(" ") || "癌症治療計畫";

  const resource = {
    resourceType: "CarePlan",
    id: stableId(patientId, "careplan", anchor, course || raw.version || ""),
    meta: { ...SRC_META },
    status: "active",
    intent: "plan",
    category: [{
      coding: [{ system: "http://snomed.info/sct", code: "394593009", display: "Medical oncology" }],
      text: "癌症治療計畫",
    }],
    title,
    subject: { reference: `Patient/${patientId}` },
  };

  const period = {};
  if (startDate) period.start = startDate + "T00:00:00+08:00";
  if (raw.end_date) period.end = raw.end_date + "T00:00:00+08:00";
  if (Object.keys(period).length) resource.period = period;

  const created = finalizeDate || raw.draft_date || "";
  if (created) resource.created = created + "T00:00:00+08:00";

  const physician = (raw.physician || "").trim();
  if (physician) resource.author = [{ display: physician }];

  const desc = [
    raw.icd9 ? `ICD9 ${raw.icd9}` : "",
    raw.mdt ? `MDT ${raw.mdt}` : "",
    raw.first_finalize_date ? `初次定版 ${raw.first_finalize_date}` : "",
  ].filter(Boolean).join("；");
  if (desc) resource.description = desc;

  return resource;
}
