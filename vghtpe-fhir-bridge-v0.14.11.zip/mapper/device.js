// Device mapper — 人工植入物 (implants, e.g. PORT-A implantable vascular
// access) from qemr findImplant. One FHIR Device per implant row.
//
// Input dict (from qemr-parser parseImplants):
//   { date, department, name_zh, name_en, spec, quantity, manufacturer,
//     side, body_site, code? }

import { stableId, SRC_META } from "./helpers.js";

export function mapDevice(raw, patientId) {
  const nameZh = (raw.name_zh || "").trim();
  const nameEn = (raw.name_en || "").trim();
  if (!nameZh && !nameEn) return null;

  const deviceName = [];
  if (nameEn) deviceName.push({ name: nameEn, type: "manufacturer-name" });
  if (nameZh) deviceName.push({ name: nameZh, type: "user-friendly-name" });

  const resource = {
    resourceType: "Device",
    id: stableId(patientId, nameEn || nameZh, raw.date || ""),
    meta: { ...SRC_META },
    status: "active",
    patient: { reference: `Patient/${patientId}` },
    type: { text: nameZh || nameEn },
  };

  if (deviceName.length) resource.deviceName = deviceName;
  if (raw.manufacturer) resource.manufacturer = raw.manufacturer;
  if (raw.spec) resource.modelNumber = raw.spec;

  // Device (R4) has no implant-date/body-site fields; keep those human-readable
  // facts (date / 側別 / 部位 / 科別) in a note so nothing is lost.
  const parts = [];
  if (raw.date) parts.push(`植入日期 ${raw.date}`);
  if (raw.side) parts.push(`側別 ${raw.side}`);
  if (raw.body_site) parts.push(`部位 ${raw.body_site}`);
  if (raw.department) parts.push(`科別 ${raw.department}`);
  if (raw.quantity) parts.push(`數量 ${raw.quantity}`);
  if (parts.length) resource.note = [{ text: parts.join("；") }];

  return resource;
}
