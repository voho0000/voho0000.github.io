// Public surface of the extension's backend-independent JS mapper.
// Import this from background.js (a module service worker).

export { buildBundle } from "./build-bundle.js";
export { mapPageType, PER_ITEM_MAPPERS, GROUP_MAPPERS, SUPPORTED_PAGE_TYPES } from "./dispatch.js";
export { stableId, effectiveFhirPatientId, maskId, maskName, deidBirthDate } from "./helpers.js";
export { lookupVghLab } from "./vgh-loinc-tables.js";
export { filterCumulativeDuplicates } from "./lab-results.js";
