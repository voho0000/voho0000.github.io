// page_type → mapper dispatch, mirroring backend/app/api/sync.py so the
// extension's local (backend-independent) path produces byte-identical FHIR.
//
// Two flavours:
//   • PER_ITEM_MAPPERS[page_type](rawItem, patientId) → resource | null
//   • GROUP_MAPPERS[page_type](rawItems, patientId)   → resource[]
// patient_info is special-cased (mapPatient takes {deidentify}).

import { mapPatient } from "./patient.js";
import { mapAllergyIntolerance } from "./allergy.js";
import { mapCondition } from "./condition.js";
import { mapEncounter } from "./encounter.js";
import { mapMedicationRequest } from "./medication.js";
import { mapDiagnosticReport } from "./diagnostic-report.js";
import { mapProcedure } from "./procedure.js";
import { mapDocumentReference } from "./document-reference.js";
import { mapDevice } from "./device.js";
import { mapCarePlan } from "./careplan.js";
import { mapServiceRequest } from "./service-request.js";
import { mapObservationsGrouped, mapVghCumulative } from "./observation.js";
import { mapVitalSigns } from "./vital-signs.js";

export const PER_ITEM_MAPPERS = {
  medications: mapMedicationRequest,
  conditions: mapCondition,
  allergies: mapAllergyIntolerance,
  diagnostic_reports: mapDiagnosticReport,
  procedures: mapProcedure,
  encounters: mapEncounter,
  document_references: mapDocumentReference,
  devices: mapDevice,
  careplans: mapCarePlan,
  service_requests: mapServiceRequest,
};

export const GROUP_MAPPERS = {
  observations: mapObservationsGrouped,      // (A) findRes #RSCONTENT rows
  observations_cumulative: mapVghCumulative, // (B) findResd matrix cells
  vitals: mapVitalSigns,                     // findVts 生命徵象 → vital-signs
};

// Map one page_type's parsed items → FHIR resources. `patientId` is the
// effective FHIR Patient.id (already de-id-adjusted by the caller).
export function mapPageType(pageType, items, patientId, opts = {}) {
  if (pageType === "patient_info") {
    if (!items || !items.length) return [];
    return [mapPatient(items[0], opts)];
  }
  if (GROUP_MAPPERS[pageType]) {
    return GROUP_MAPPERS[pageType](items || [], patientId).filter(Boolean);
  }
  const mapper = PER_ITEM_MAPPERS[pageType];
  if (!mapper) return [];
  return (items || [])
    .filter((it) => it && typeof it === "object")
    .map((it) => mapper(it, patientId))
    .filter(Boolean);
}

export const SUPPORTED_PAGE_TYPES = [
  "patient_info",
  ...Object.keys(GROUP_MAPPERS),
  ...Object.keys(PER_ITEM_MAPPERS),
];
