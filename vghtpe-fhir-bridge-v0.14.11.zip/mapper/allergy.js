// AllergyIntolerance mapper — ported from backend/app/mapper/allergy.py.

import { stableId, SRC_META } from "./helpers.js";

export function mapAllergyIntolerance(raw, patientId) {
  const display = raw.display || "Unknown Allergen";
  const code = raw.code;
  const system = mapSystem(raw.system || "");

  const resource = {
    resourceType: "AllergyIntolerance",
    id: stableId(patientId, code || display, raw.recorded_date || ""),
    meta: { ...SRC_META },
    patient: { reference: `Patient/${patientId}` },
    clinicalStatus: {
      coding: [{ system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", code: "active" }],
    },
    verificationStatus: {
      coding: [{ system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", code: "confirmed" }],
    },
    code: {
      coding: [{ system, code: code || display, display }],
      text: display,
    },
  };

  const category = raw.category || "";
  if (["medication", "food", "environment", "biologic"].includes(category)) resource.category = [category];

  const criticality = raw.criticality || "";
  if (["high", "low", "unable-to-assess"].includes(criticality)) resource.criticality = criticality;

  if (raw.recorded_date) resource.recordedDate = raw.recorded_date + "T00:00:00+08:00";

  const reactionNote = raw.reaction || "";
  if (reactionNote) resource.reaction = [{ description: reactionNote }];

  return resource;
}

function mapSystem(hint) {
  const s = typeof hint === "string" ? hint.toLowerCase() : "";
  if (s.includes("snomed")) return "http://snomed.info/sct";
  if (s.includes("rxnorm")) return "http://www.nlm.nih.gov/research/umls/rxnorm";
  return "urn:oid:his.allergen.code";
}
