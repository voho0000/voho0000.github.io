import { lookupVghLab, normalizeVghPanel } from "./vgh-loinc-tables.js";

export function isLabMetadataLabel(value) {
  const label = String(value || "").replace(/\([^)]*\)|（[^）]*）/g, "").replace(/\s+/g, "");
  return /^(?:[\p{Script=Han}]{0,8}醫師[一二三四五六七八九十〇零\d０-９]*|報告人|醫檢師|技術員|技術師|檢驗師|護理師|開醫囑者)[:：]?$/u.test(label)
    || /^(?:(?:reporting|interpreting|performing|executing|supervising|attending|requesting)?(?:physician|doctor)(?:one|two|\d*)|reporter|technician)[:：]?$/i.test(label);
}

export function isLabMetadataRow(raw) {
  return [raw.display, raw.code, raw.abbrev, raw.value].some(isLabMetadataLabel);
}

export function labPanel(raw) {
  // A known non-blood specimen takes precedence over abbreviations in the
  // order name (a fluid report may contain WBC/RBC too).
  const specimenPanel = normalizeVghPanel(raw.specimen || "");
  if (["Urine", "生化尿液", "Ascites", "CSF"].includes(specimenPanel)) return specimenPanel;
  return normalizeVghPanel(raw.panel || raw.order_name || "");
}

export function normalizeLabQuantity(loinc, value, unit) {
  const numeric = Number(String(value).replace(/,/g, ""));
  const original = { value, unit: unit || "", factor: 1 };
  if (!String(value ?? "").trim() || !Number.isFinite(numeric)) return original;
  const targets = { "6690-2": 1, "777-3": 1, "789-8": 1e6, "26466-3": 1, "26455-6": 1 };
  const target = targets[loinc];
  if (!target) return original;
  const key = String(unit || "").replace(/[µμ]/g, "u").replace(/\s+/g, "").toLowerCase();
  const scales = { "/ul": 1, "cells/ul": 1, "#/ul": 1, "10*3/ul": 1e3, "10^3/ul": 1e3, "k/ul": 1e3, "10*6/ul": 1e6, "10^6/ul": 1e6, "m/ul": 1e6 };
  if (scales[key] == null) return original; // no magnitude-based guessing
  const factor = scales[key] / target;
  return { value: Number((numeric * factor).toPrecision(12)), unit: target === 1e6 ? "10*6/uL" : "/uL", factor };
}

export function normalizeLabRange(text, factor) {
  if (!text || factor === 1) return text;
  // Convert only a plain numeric interval in the source result's units.
  const match = String(text).match(/^\s*([\d.,]+)\s*(~|－|-|–)\s*([\d.,]+)\s*$/);
  if (!match) return text;
  const convert = s => Number((Number(s.replace(/,/g, "")) * factor).toPrecision(12));
  return `${convert(match[1])} ${match[2]} ${convert(match[3])}`;
}

function resultIdentity(raw) {
  const panel = labPanel(raw);
  const name = raw.abbrev || raw.code || raw.display || "";
  const mapped = lookupVghLab(panel, name, raw);
  const specimen = String(raw.specimen || panel).trim().toLowerCase();
  const analyte = mapped?.loinc || String(name).toLowerCase().replace(/[\s.]/g, "");
  return { mapped, key: JSON.stringify([specimen, analyte]) };
}

export function labResultKey(raw) {
  const { mapped, key } = resultIdentity(raw);
  const normalized = normalizeLabQuantity(mapped?.loinc, raw.value, raw.unit || (raw.abbrev ? mapped?.unit : ""));
  const text = String(normalized.value ?? "").trim().toLowerCase().replace(/\s+/g, " ");
  const number = Number(text.replace(/,/g, ""));
  const value = text && Number.isFinite(number) ? String(number) : text;
  const unit = /^(?:n\/a|-)$/i.test(normalized.unit) ? "" : normalized.unit;
  // Identical numbers from different analytes or incompatible units never
  // count as duplicates (e.g. BAND 0 and EOS 0).
  return JSON.stringify([key, value, unit]);
}

export function filterCumulativeDuplicates(cells, detailItems) {
  const detailKeys = new Set();
  for (const raw of detailItems || []) {
    if (!raw || isLabMetadataRow(raw) || raw.value == null) continue;
    const datetime = raw.received_at || raw.effective_datetime || "";
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(datetime)) continue;
    detailKeys.add(JSON.stringify([raw.hospital || "臺北榮民總醫院", Date.parse(datetime), labResultKey(raw)]));
  }
  return (cells || []).filter(cell => {
    const m = String(cell.datetime || "").match(/^(\d{2})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})$/);
    if (!m) return true; // a date alone cannot identify a repeated test
    const iso = `20${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:00+08:00`;
    const key = JSON.stringify([cell.hospital || "臺北榮民總醫院", Date.parse(iso), labResultKey(cell)]);
    return !detailKeys.has(key);
  });
}

export function reconcileLabCaptures(captures) {
  const details = captures.filter(c => c.pageType === "observations").flatMap(c => c.items || []);
  return captures.map(c => c.pageType === "observations_cumulative"
    ? { ...c, items: filterCumulativeDuplicates(c.items, details) } : c);
}
