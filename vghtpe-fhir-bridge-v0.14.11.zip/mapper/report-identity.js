// Keep legacy opaque IDs stable when source date precision is corrected.
// This value is only hashed; it is never emitted as a clinical timestamp.
export function reportIdentityDate(raw) {
  const value = raw.effective_datetime || raw.date || raw.source_report_date || "";
  return value === raw.reported_at && /^\d{4}-\d{2}-\d{2}$/.test(value)
    ? value + "T00:00:00+08:00" : value;
}
