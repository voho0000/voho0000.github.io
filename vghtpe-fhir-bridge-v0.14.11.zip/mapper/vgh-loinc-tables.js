import { NHI_TO_LOINC, LOINC_MAP, PANEL_LOINC_MAP, LOINC_DISPLAY } from "./loinc-tables.js";

// Hospital adapter only: local names, specimen/method routing and legacy
// cumulative-report units. Standard terminology is generated from the same
// shared mapper used by MediCloud (tools/sync-shared-loinc.mjs).
// Referencing NHI terminology does not assert or emit an NHI billing code.
const fromLoinc = (loinc, unit) => {
  if (!loinc || !LOINC_DISPLAY[loinc]) throw new Error(`Missing shared LOINC concept: ${loinc}`);
  return { loinc, unit, display: LOINC_DISPLAY[loinc] };
};
const fromNhi = (code, unit) => fromLoinc(NHI_TO_LOINC[code], unit);
const fromCommonName = (name, unit) => fromLoinc(LOINC_MAP[name], unit);
const fromPanel = (panel, name, unit) => fromLoinc(PANEL_LOINC_MAP[panel]?.[name], unit);
const localOnly = (display, unit = "") => ({ loinc: null, unit, display });

export function normalizeVghPanel(label) {
  const panel = (label || "").replace(/^\(累積\)/, "").trim();
  if (/生化尿液|urine.*(?:chem|biochem)|(?:chem|biochem).*urine/i.test(panel)) return "生化尿液";
  if (/\burine(?:\b|_)|尿液|尿常規|尿沉渣/i.test(panel)) return "Urine";
  if (/ascites|腹水/i.test(panel)) return "Ascites";
  if (/\bCSF(?:\b|_)|腦脊髓/i.test(panel)) return "CSF";
  if (/\bCBC\b|全血球/i.test(panel)) return "CBC";
  const cells = panel.replace(/\*/g, "").split(/[,\s]+/).filter(Boolean);
  if (cells.length && cells.every(cell => /^(?:WBC|RBC|DC|Hb|Hgb|Hct|Plt|MCV|MCH|MCHC|RDW)$/i.test(cell))) return "CBC";
  if (/^(?:T[34]\s*Free|Free\s*T[34]|TSH|hs-TSH|甲狀腺報告)\s*,?$/i.test(panel)) return "甲狀腺報告";
  if (/\bSMAC\b|一般生化|血液生化/i.test(panel)) return "SMAC";
  return panel;
}


// Units here are the hospital's legacy matrix defaults, not a global unit
// conversion policy. Detail reports keep their original units and values.
const urineProtein = fromLoinc("2888-6", "mg/dL");
const urineAlbumin = fromLoinc("1754-1", "mg/L");
const urineCreatinine = fromCommonName("urine creatinine", "mg/dL");
const urineProteinRatio = fromLoinc("2890-2", "mg/g{creat}");
const urineAlbuminRatio = fromPanel("06012C", "uacr", "mg/g{creat}");

export const VGH_PANEL_LAB = {
  CBC: {
    WBC: fromCommonName("wbc", "/uL"),
    RBC: fromCommonName("rbc", "10*6/uL"),
    HGB: fromCommonName("hgb", "g/dL"),
    HCT: fromNhi("08004C", "%"),
    MCV: fromPanel("08011C", "mcv", "fL"),
    MCH: fromCommonName("mch", "pg"),
    MCHC: fromPanel("08011C", "mchc", "g/dL"),
    RDW: fromPanel("08011C", "rdw", "%"),
    PLT: fromCommonName("plt", "/uL"),
    PT: fromPanel("08026C", "prothrombin time", "s"),
    SEG: fromPanel("08011C", "neutrophil", "%"),
    LYM: fromPanel("08011C", "lymphocyte", "%"),
    MONO: fromPanel("08011C", "monocyte", "%"),
    // Global eosinophil means absolute count; CBC differential is a fraction.
    EOS: fromPanel("08011C", "eosinophil", "%"),
    BASO: fromPanel("08011C", "basophil", "%"),
    BAND: fromPanel("08011C", "band", "%"),
  },
  Ascites: {
    WBC: fromLoinc("26466-3", "/uL"),
    RBC: fromLoinc("26455-6", "/uL"),
    Neu: localOnly("Ascites Neu", "%"),
    Lym: localOnly("Ascites Lym", "%"),
    "Mono./Macro.": localOnly("Ascites Mono./Macro.", "%"),
    Eos: localOnly("Ascites Eos", "%"),
    Baso: localOnly("Ascites Baso", "%"),
    "Rivalta-test": localOnly("Ascites Rivalta-test"),
  },
  Glouse: {
    Glucose: fromCommonName("glucose", "mg/dL"),
    // The previous codes describe a glucose load / whole-blood post-meal,
    // not these exact timed serum/plasma measurements. Keep them local-only.
    "Glu,1hrPC": localOnly("Glu,1hrPC", "mg/dL"),
    "Glu,2hrPC": localOnly("Glu,2hrPC", "mg/dL"),
    HbA1c: fromCommonName("hba1c", "%"),
    "C-PEPTIDE": fromLoinc("1986-9", "ng/mL"),
  },
  甲狀腺報告: {
    T3: fromCommonName("total t3", "ng/dL"),
    T4: fromCommonName("total t4", "ug/dL"),
    TSH: fromNhi("09112C", "uIU/mL"),
    "hs-TSH": fromLoinc("11580-8", "uIU/mL"),
    FREET3: fromCommonName("free t3", "pg/mL"),
    FREET4: fromCommonName("free t4", "ng/dL"),
  },
  Urine: {
    COLOR: fromPanel("06012C", "color", ""),
    TRANS: fromPanel("06012C", "appearance", ""),
    PH: fromPanel("06012C", "ph", ""),
    SUGAR: fromPanel("06012C", "sugar", ""),
    PROT: fromLoinc("5804-0", ""),
    KETON: fromPanel("06012C", "ketones", ""),
    BILI: fromPanel("06012C", "bilirubin", ""),
    UROBI: fromPanel("06012C", "urobilinogen", ""),
    GRAVIT: fromPanel("06012C", "specific gravity", ""),
    NITRIT: fromPanel("06012C", "nitrite", ""),
    OCCULT: fromPanel("06012C", "blood", ""),
    WBC: fromPanel("06012C", "wbc", "/HPF"),
    // Common urine RBC route is /volume; this source explicitly reports /HPF.
    RBC: fromLoinc("13945-1", "/HPF"),
    "Prot (spot)": urineProtein,
    "CAlb (spot)": urineAlbumin,
    "Cr (spot)": urineCreatinine,
    "Prot/Cr ratio": urineProteinRatio,
    "Alb/Cr ratio": urineAlbuminRatio,
  },
  生化尿液: {
    "Prot/Cr ratio": urineProteinRatio,
    "Prot (spot)": urineProtein,
    "CREAT (spot)": urineCreatinine,
    "Cr (spot)": urineCreatinine,
    "NA (spot)": fromCommonName("urine sodium", "mmol/L"),
    "K (spot)": fromCommonName("urine potassium", "mmol/L"),
    "CL (spot)": fromCommonName("urine chloride", "mmol/L"),
    "MG (spot)": fromLoinc("19124-7", "mg/dL"),
    "CA (spot)": fromLoinc("17862-4", "mg/dL"),
    "UN (spot)": fromCommonName("urine urea nitrogen", "mg/dL"),
    "UA (spot)": fromLoinc("3086-6", "mg/dL"),
    "24hrs 尿總量": fromLoinc("3167-4", "mL"),
    "Prot (24hrs)": fromLoinc("2889-4", "mg/(24.h)"),
    "ALB/CRE": urineAlbuminRatio,
  },
};

// Local abbreviations reference shared names/codes. Never use these blood
// fallbacks for a urine, ascites or CSF report.
export const VGH_LAB_FALLBACK = {
  TP: fromPanel("09065B", "total protein", "g/dL"),
  ALB: fromNhi("09038C", "g/dL"),
  CA: fromNhi("09011C", "mg/dL"),
  CHOL: fromCommonName("cholesterol", "mg/dL"),
  BUN: fromCommonName("bun", "mg/dL"),
  UA: fromCommonName("uric acid", "mg/dL"),
  CREA: fromCommonName("creatinine", "mg/dL"),
  BILIT: fromNhi("09029C", "mg/dL"),
  DBILI: fromNhi("09030C", "mg/dL"),
  ALKP: fromNhi("09027C", "U/L"),
  LDH: fromNhi("09033C", "U/L"),
  ALT: fromCommonName("alt", "U/L"),
  AST: fromCommonName("ast", "U/L"),
  NA: fromNhi("09021C", "mmol/L"),
  K: fromNhi("09022C", "mmol/L"),
  CL: fromNhi("09023C", "mmol/L"),
  GLU: fromCommonName("glucose", "mg/dL"),
  IP: fromNhi("09012C", "mg/dL"),
  CK: fromCommonName("ck", "U/L"),
  GGT: fromNhi("09031C", "U/L"),
  HDLC: fromCommonName("hdl-c", "mg/dL"),
  LDLC: fromCommonName("ldl-c", "mg/dL"),
  TG: fromCommonName("triglyceride", "mg/dL"),
  CO2: fromCommonName("tco2", "mmol/L"),
  IRON: fromCommonName("iron", "ug/dL"),
  TIBC: fromCommonName("tibc", "ug/dL"),
  CKMB: fromCommonName("ck-mb", "ng/mL"),
  TROP: fromNhi("09099C", "ng/mL"),
  CRP: fromNhi("12015C", "mg/L"),
  "eGFR(M)": fromLoinc("77147-7", "mL/min/{1.73_m2}"),
  AFP: fromNhi("12007C", "ng/mL"),
  CEA: fromNhi("27050C", "ng/mL"),
  PSA: fromNhi("27052C", "ng/mL"),
  CA125: fromNhi("12077C", "U/mL"),
  "CA-125": fromNhi("12077C", "U/mL"),
  CA153: fromNhi("12078C", "U/mL"),
  "CA-153": fromNhi("12078C", "U/mL"),
  CA199: fromNhi("12079C", "U/mL"),
  "CA-199": fromNhi("12079C", "U/mL"),
  Ferritin: fromCommonName("ferritin", "ng/mL"),
  "Anti-HCV": fromNhi("14051C", ""),
  HBSAg: fromNhi("14030C", ""),
  HBsAg: fromNhi("14030C", ""),
};

// Resolve (panelLabel, abbrev) → {loinc, unit, display} or null.
// panelLabel is the raw findResd option label (e.g. "(累積)CBC"); it is
// normalized here. Abbrev match is case-insensitive on a trimmed key.
export function lookupVghLab(panelLabel, abbrev, context = {}) {
  const rawSpecimen = String(context.specimen || "").trim();
  const specimenPanel = normalizeVghPanel(rawSpecimen);
  const knownFluid = ["Urine", "生化尿液", "Ascites", "CSF"].includes(specimenPanel);
  // Explicit, unrecognised specimens must never inherit a blood panel's
  // terminology or count scaling (pleural/synovial/dialysate, for example).
  if (rawSpecimen && !knownFluid && !/^(?:BLOOD|SERUM|PLASMA)(?:$|[_\s-])|^(?:血液|血清|血漿)/i.test(rawSpecimen)) return null;
  const panel = knownFluid ? specimenPanel : normalizeVghPanel(panelLabel);
  let key = (abbrev || "").normalize("NFKC").trim().replace(/\.$/, "");
  const token = key.toUpperCase().replace(/\s+/g, " ");
  const fluid = ["Urine", "生化尿液", "Ascites", "CSF"].includes(panel);
  // A recognized serum/plasma tube is valid for chemistry, but not for
  // whole-blood HbA1c or cell-count concepts. Missing specimens retain the
  // legacy panel-based mapping; explicit incompatible specimens stay local.
  const cellFreeSpecimen = /^(?:SERUM|PLASMA)(?:$|[_\s-])|^(?:血清|血漿)/i.test(rawSpecimen);
  const precise = fromLoinc;
  if (!fluid) {
    if (/^EGFR\s*\(\s*M\s*\)$/.test(token) ||
        (/^EGFR(?:\s*\([^)]*\))?$/.test(token) && /\bMDRD\b/i.test(`${token} ${context.method || ""}`))) {
      return fromLoinc("77147-7", "mL/min/{1.73_m2}");
    }
    if (["LDL-C(實測值)", "LDL-C (實測值)", "LDL-C(DIRECT)", "LDL-C DIRECT"].includes(token)) {
      return precise("18262-6", "mg/dL");
    }
    if (["LDL-C(CALCULATED)", "LDL-C (CALCULATED)", "LDL-C(計算值)"].includes(token)) {
      return precise("13457-7", "mg/dL");
    }
    if (["HIGH SENSITIVE CRP", "HIGH SENSITIVITY CRP", "HS-CRP", "HSCRP"].includes(token)) {
      return precise("30522-7", "mg/L");
    }
    if (token === "PSA" && /\bFREE\b/i.test(panelLabel || "")) return null;
    if (token === "PSA" && /\b(?:EIA|LIA|IMMUNOASSAY)\b/i.test(panelLabel || "")) return fromNhi("12081C", "ng/mL");
    if (["A1C (HBA1C)", "HBA1C", "A1C"].includes(token)) {
      if (cellFreeSpecimen) return null;
      if (/mmol\s*\/\s*mol/i.test(context.unit || "")) return null;
      return fromNhi("09006C", "%");
    }
    if (["FREE T4", "FREET4", "T4 FREE"].includes(token)) {
      if (/(?:p|n|u|µ|μ)mol\s*\//i.test(context.unit || "")) return null;
      return fromNhi("09106C", "ng/dL");
    }
    if (token === "TSH") return fromNhi("09112C", "uIU/mL");
    // CBC alone does not establish automated counting; use the shared method-unspecified ANC.
    if (token === "ANC" && panel === "CBC") return cellFreeSpecimen ? null : fromPanel("08011C", "anc", "/uL");
    if (token === "CHOL/HDLC") return precise("9830-1", "1");
    key = ({ "HDL-C": "HDLC", "LDL-C": "LDLC", CREAT: "CREA", CREATININE: "CREA" })[token] || key;
  }
  if (panel === "Urine" || panel === "生化尿液") {
    key = ({ CLARITY: "TRANS", CREATININE: "Cr (spot)", CREAT: "Cr (spot)", ALBUMIN: "CAlb (spot)" })[token] || key;
    // Preserve microscopy scale: /LPF is not interchangeable with /HPF.
    if (/^(?:\/?(?:HPF|\[HPF\]))$/i.test(String(context.unit || "").trim())) {
      const microscopy = {
        "SQUAMOUS EPI": "11277-1",
        "UROTHELIUM EPI": "30089-7",
        "RTE-RENAL TUBE": "26052-1",
      }[token];
      if (microscopy) return precise(microscopy, "/HPF");
    }
  }
  if (panel === "CBC") key = ({ HB: "HGB", NEU: "SEG", NEUT: "SEG", "RDW-CV": "RDW", 白血球: "WBC", 紅血球: "RBC", 血紅素: "HGB", 血小板: "PLT" })[key.toUpperCase()] || key;
  if (panel === "Ascites" && /^mono\.\/macro$/i.test(key)) key = "Mono./Macro.";
  const panelTable = VGH_PANEL_LAB[panel];
  if (panelTable) {
    const hit = panelTable[key] || _ci(panelTable, key);
    if (hit) {
      // PT is a plasma coagulation assay; all other CBC entries here are
      // whole-blood cells, indices or differential fractions.
      if (cellFreeSpecimen && panel === "CBC" && key.toUpperCase() !== "PT") return null;
      return hit;
    }
  }
  // Never fall through a urine panel to serum/plasma abbreviations (e.g.
  // urine NA/CA/UA must not receive the serum LOINC from the global table).
  if (fluid) return null;
  return VGH_LAB_FALLBACK[key] || _ci(VGH_LAB_FALLBACK, key) || null;
}

function _ci(table, key) {
  const lk = key.toLowerCase();
  for (const k of Object.keys(table)) {
    if (k.toLowerCase() === lk) return table[k];
  }
  return null;
}
