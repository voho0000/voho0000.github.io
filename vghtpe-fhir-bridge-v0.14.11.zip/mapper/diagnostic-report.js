// DiagnosticReport mapper — ported from backend/app/mapper/diagnostic_report.py.
// Returns null for list-page rows without a conclusion.

import { stableId, SRC_META } from "./helpers.js";
import { reportEncounter, applyReportOrder, reportDateExtensions } from "./report-context.js";
import { reportIdentityDate } from "./report-identity.js";

const CATEGORY_MAP = {
  LAB:  ["http://terminology.hl7.org/CodeSystem/v2-0074", "LAB", "Laboratory"],
  RAD:  ["http://terminology.hl7.org/CodeSystem/v2-0074", "RAD", "Radiology"],
  CAR:  ["http://terminology.hl7.org/CodeSystem/v2-0074", "CAR", "Cardiology"],
  PATH: ["http://terminology.hl7.org/CodeSystem/v2-0074", "PAT", "Pathology"],
};

export function mapDiagnosticReport(raw, patientId) {
  const conclusion = (raw.conclusion || "").trim();
  if (!conclusion) return null;
  const encounter = reportEncounter(raw, patientId);

  const display = raw.display || "Unknown Report";
  const code = raw.code;
  const systemHint = raw.system || "";
  const system = typeof systemHint === "string" && systemHint.toUpperCase() === "LOINC"
    ? "http://loinc.org" : "urn:oid:his.report.code";

  // Preserve the previous opaque identity without exporting its inferred time.
  // Older parsers used midnight for a day-only report time, and the catalog
  // day when no clinical date was available.
  const identityDate = reportIdentityDate(raw);
  const sourceIdentity = !raw.request_no && !raw.work_no && !identityDate && raw.report_case_no
    ? [String(raw.report_case_no), String(raw.report_sequence || "")] : [];

  const resource = {
    resourceType: "DiagnosticReport",
    id: stableId(patientId, code || display, raw.request_no || raw.work_no || "", identityDate, ...sourceIdentity, ...(encounter ? [encounter.reference] : [])),
    meta: { ...SRC_META },
    status: raw.status || "final",
    subject: { reference: `Patient/${patientId}` },
    code: {
      coding: [{ system, code: code || display, display }],
      text: display,
    },
    conclusion,
  };
  if (encounter) resource.encounter = encounter;

  const identifiers = [];
  if (raw.request_no) identifiers.push({ system: "urn:oid:vgh.report.request", value: String(raw.request_no) });
  if (raw.work_no) identifiers.push({ system: "urn:oid:vgh.report.work", value: String(raw.work_no) });
  if (identifiers.length) resource.identifier = identifiers;

  const catEntry = CATEGORY_MAP[(raw.category || "").toUpperCase()];
  if (catEntry) {
    resource.category = [{ coding: [{ system: catEntry[0], code: catEntry[1], display: catEntry[2] }] }];
  }

  if (raw.effective_datetime) resource.effectiveDateTime = raw.effective_datetime;
  else if (raw.date) resource.effectiveDateTime = raw.date + "T00:00:00+08:00";
  if (raw.issued) resource.issued = raw.issued;
  // Receipt/effective dates do not establish when a report was published.
  // A catalog date may establish inclusion in a range without an exact instant.
  if (raw.requesting_physician) resource.performer = [{ display: String(raw.requesting_physician) }];
  if (raw.interpreting_physician || raw.reporter) resource.resultsInterpreter = [{ display: String(raw.interpreting_physician || raw.reporter) }];
  if (raw.specimen) resource.specimen = [{ display: String(raw.specimen) }];
  if (raw.received_at) resource.extension = [{
    url: "urn:vgh:report:received-at",
    valueDateTime: String(raw.received_at),
  }];
  const dates = reportDateExtensions(raw);
  if (dates.length) resource.extension = [...(resource.extension || []), ...dates];

  applyReportOrder(resource, raw, patientId);
  return resource;
}
