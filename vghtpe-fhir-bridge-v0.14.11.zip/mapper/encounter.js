// Encounter mapper — ported from backend/app/mapper/encounter.py.

import { SRC_META } from "./helpers.js";
import { conditionId, DIAGNOSIS_CATEGORY_SYSTEM } from "./condition.js";
import { encounterId } from "./encounter-id.js";

const CLASS_MAP = {
  AMB:  ["http://terminology.hl7.org/CodeSystem/v3-ActCode", "AMB",  "ambulatory"],
  IMP:  ["http://terminology.hl7.org/CodeSystem/v3-ActCode", "IMP",  "inpatient encounter"],
  EMER: ["http://terminology.hl7.org/CodeSystem/v3-ActCode", "EMER", "emergency"],
};

export function mapEncounter(raw, patientId) {
  const encClass = (raw.class || "AMB").toUpperCase();
  const classEntry = CLASS_MAP[encClass] || CLASS_MAP.AMB;
  const resource = {
    resourceType: "Encounter",
    id: encounterId(raw, patientId),
    meta: { ...SRC_META },
    status: "finished",
    class: { system: classEntry[0], code: classEntry[1], display: classEntry[2] },
    subject: { reference: `Patient/${patientId}` },
  };

  const typeCode = raw.type_code;
  const typeDisplay = raw.type_display || "";
  if (typeCode || typeDisplay) {
    resource.type = [{
      coding: [{ system: "http://snomed.info/sct", code: typeCode || typeDisplay, display: typeDisplay }],
      text: typeDisplay,
    }];
  }

  const period = {};
  if (raw.start_datetime) period.start = raw.start_datetime;
  else if (raw.date && /^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(raw.visit_time || "")) {
    period.start = `${raw.date}T${raw.visit_time}${raw.visit_time.length === 5 ? ":00" : ""}+08:00`;
  }
  else if (raw.date) period.start = raw.date + "T00:00:00+08:00";
  if (raw.end_date) period.end = raw.end_date + "T00:00:00+08:00";
  if (Object.keys(period).length) resource.period = period;

  const department = raw.department || "";
  const provider = raw.provider || "";
  if (department || provider) {
    if (provider) resource.participant = [{ individual: { display: provider,
      ...(raw.provider_id ? { identifier: { system: "urn:oid:vgh.physician", value: raw.provider_id } } : {}) } }];
    else resource.participant = [];
    if (department) resource.serviceType = { text: department };
  }

  if (raw.reason) resource.reasonCode = [{ text: raw.reason }];

  if (raw.diagnoses?.length) {
    resource.diagnosis = raw.diagnoses.filter((item) => item?.code).map((item) => {
      const diagnosis = { condition: { reference: `Condition/${conditionId(item, patientId)}` } };
      if (item.diagnosis_category) diagnosis.use = {
        coding: [{ system: DIAGNOSIS_CATEGORY_SYSTEM, code: item.diagnosis_category }],
      };
      if (/^\d+$/.test(item.diagnosis_sequence || "")) diagnosis.rank = Number(item.diagnosis_sequence) + 1;
      return diagnosis;
    });
  }

  if (raw.discharge_disposition) {
    resource.hospitalization = { dischargeDisposition: { text: raw.discharge_disposition } };
  }

  const clinicalNote = (raw.clinical_note || "").trim();
  if (clinicalNote) {
    resource.extension = [{
      url: "https://github.com/voho0000/EHR-FHIR-BRIDGE/StructureDefinition/encounter-clinical-note",
      valueString: clinicalNote,
    }];
  }
  if (raw.soap) for (const key of ["s", "o", "a", "p"]) {
    if (!raw.soap[key]) continue;
    (resource.extension ||= []).push({
      url: `https://github.com/voho0000/EHR-FHIR-BRIDGE/StructureDefinition/encounter-soap-${key}`,
      valueString: String(raw.soap[key] || ""),
    });
  }

  return resource;
}
