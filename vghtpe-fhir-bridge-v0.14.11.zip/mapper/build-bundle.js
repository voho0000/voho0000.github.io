// Assemble a FHIR Bundle locally (no backend) from parsed page_type items.
//
// This is what makes "download mode" work without the Python backend: the
// extension parses the qemr DOM, runs these JS mappers, and builds the same
// collection Bundle the backend's /sync/export would have produced. Stable
// IDs mean the result is idempotent with a later backend import.

import { mapPageType } from "./dispatch.js";
import { effectiveFhirPatientId } from "./helpers.js";
import { reconcileLabCaptures } from "./lab-results.js";

// captures: array of { pageType, items }. `histno` is the raw 病歷號 from the
// qemr URL. opts.deidentify toggles the de-identified output.
//
// Returns { bundle, breakdown, patientId }.
export function buildBundle(captures, histno, opts = {}) {
  const deidentify = !!opts.deidentify;
  const patientId = effectiveFhirPatientId(histno, deidentify, opts.deidKey);

  // Dedup by (resourceType, id) — the same resource can be produced by both a
  // list page and a detail page (e.g. an Encounter). Last write wins, matching
  // the backend's upsert semantics.
  const byId = new Map();
  const breakdown = {};

  for (const { pageType, items } of reconcileLabCaptures(captures)) {
    let resources;
    try {
      resources = mapPageType(pageType, items, patientId, {
        deidentify,
        deidKey: opts.deidKey,
      });
    } catch (e) {
      console.warn(`[build-bundle] ${pageType} failed:`, e);
      continue;
    }
    for (const r of resources) {
      if (!r || !r.resourceType || !r.id) continue;
      const key = `${r.resourceType}/${r.id}`;
      byId.set(key, mergeResource(byId.get(key), r));
    }
  }

  if (deidentify) {
    for (const [key, resource] of byId.entries()) {
      const safe = sanitizeDeidentifiedResource(resource);
      if (safe) byId.set(key, safe);
      else byId.delete(key);
    }
  }

  for (const r of byId.values()) {
    breakdown[r.resourceType] = (breakdown[r.resourceType] || 0) + 1;
  }

  const bundle = {
    resourceType: "Bundle",
    type: "collection",
    meta: { source: "ehr-fhir-bridge/extension-local" },
    total: byId.size,
    entry: [...byId.values()].map((resource) => ({ resource })),
  };

  return { bundle, breakdown, patientId };
}

function mergeResource(previous, incoming) {
  if (!previous) return incoming;
  // A list page and its detail page often emit the same resource id. Keep
  // fields learned from both pages rather than replacing the richer list row
  // with a note-only detail row.
  return {
    ...previous,
    ...incoming,
    meta: { ...(previous.meta || {}), ...(incoming.meta || {}) },
  };
}

function sanitizeDeidentifiedResource(resource) {
  // Raw clinical documents and free-text narratives can contain identifiers
  // that cannot be reliably removed with string replacement. Exclude them
  // from the pseudonymized Bundle; structured coded data is retained.
  if (resource.resourceType === "DocumentReference") return null;
  const safe = JSON.parse(JSON.stringify(resource));
  if (safe.resourceType !== "Patient") delete safe.identifier;
  delete safe.note;
  delete safe.conclusion;
  delete safe.presentedForm;
  delete safe.description;
  delete safe.text;
  delete safe.extension;
  delete safe.participant;
  delete safe.performer;
  delete safe.resultsInterpreter;
  delete safe.author;
  delete safe.recorder;
  delete safe.requester;
  // ED chief complaints are free text and can name the patient or relatives.
  if (safe.resourceType === "Encounter") delete safe.reasonCode;
  return safe;
}
