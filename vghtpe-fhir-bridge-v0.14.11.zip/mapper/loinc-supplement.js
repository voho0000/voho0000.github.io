// Standard concepts absent from @voho0000/nhi-clinical-mapper 0.1.4.
// No hospital aliases belong here. Names checked at loinc.org/{code} on
// 2026-10-18. The sync tool rejects overlap with the upstream display map;
// remove a supplement when upstream supplies the concept.
export const LOINC_DISPLAY_SUPPLEMENT = {
  "26466-3": "Leukocytes [#/volume] in Body fluid",
  "26455-6": "Erythrocytes [#/volume] in Body fluid",
  "1986-9": "C peptide [Mass/volume] in Serum or Plasma",
  "11580-8": "Thyrotropin [Units/volume] in Serum or Plasma by Detection limit <= 0.005 mIU/L",
  "5804-0": "Protein [Mass/volume] in Urine by Test strip",
  "13945-1": "Erythrocytes [#/area] in Urine sediment by Microscopy high power field",
  "2890-2": "Protein/Creatinine [Mass Ratio] in Urine",
  "17862-4": "Calcium [Mass/volume] in Urine",
  "3086-6": "Urate [Mass/volume] in Urine",
  "3167-4": "Volume of 24 hour Urine",
  "11277-1": "Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field",
  "30089-7": "Transitional cells [#/area] in Urine sediment by Microscopy high power field",
  "26052-1": "Epithelial cells.renal [#/area] in Urine sediment by Microscopy high power field",
};
