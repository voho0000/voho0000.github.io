// MedicationRequest mapper — ported from backend/app/mapper/medication.py.

import { stableId, SRC_META } from "./helpers.js";
import { encounterId } from "./encounter-id.js";

export function mapMedicationRequest(raw, patientId) {
  const drugName = raw.drug_name || "Unknown medication";
  const genericName = (raw.generic_name || "").trim();
  const brandName = (raw.brand_name || "").trim();
  const start = raw.start_time || (raw.date ? raw.date + "T00:00:00+08:00" : "");
  const sourceStatus = (raw.source_status || "").trim();
  const status = /取消/.test(sourceStatus) ? "cancelled"
    : /完成/.test(sourceStatus) ? "completed"
      : /停止|停用/.test(sourceStatus) ? "stopped" : "active";
  const codings = [];
  if (genericName) codings.push({ system: "urn:oid:vgh.medication.generic", code: genericName, display: genericName });
  if (brandName && brandName !== genericName) codings.push({ system: "urn:oid:vgh.medication.product", code: brandName, display: brandName });
  if (!codings.length) codings.push({ system: "urn:oid:vgh.medication.name", code: drugName, display: drugName });
  const resource = {
    resourceType: "MedicationRequest",
    id: stableId(
      patientId, raw.case_no || "", raw.order_seq || "", genericName || drugName,
      brandName, start, raw.end_time || "", raw.dose || "", raw.unit || "", raw.route || "", raw.frequency || "",
    ),
    meta: { ...SRC_META },
    status,
    intent: "order",
    medicationCodeableConcept: {
      coding: codings,
      text: [genericName, brandName].filter(Boolean).join(" / ") || drugName,
    },
    subject: { reference: `Patient/${patientId}` },
  };
  if (raw.encounter_class && raw.encounter_ref_date) {
    resource.encounter = { reference: `Encounter/${encounterId(raw, patientId)}` };
    // Different doctors can prescribe identical drugs on the same day.
    resource.id = stableId(resource.id, raw.encounter_instance || "");
  }

  if (start) resource.authoredOn = start;
  if (raw.case_no || raw.order_seq) {
    resource.identifier = [{
      system: "urn:oid:vgh.medication.order",
      value: [raw.case_no, raw.order_seq].filter(Boolean).join("-"),
    }];
  }

  const dosage = {};
  const parts = [raw.dose, raw.unit, raw.route, raw.frequency].filter(Boolean).map(String);
  if (parts.length) dosage.text = parts.join(" ");
  if (raw.route) dosage.route = {
    coding: [{ system: "urn:oid:vgh.medication.route", code: String(raw.route), display: String(raw.route) }],
    text: String(raw.route),
  };
  if (raw.frequency) dosage.timing = {
    code: {
      coding: [{ system: "urn:oid:vgh.medication.frequency", code: String(raw.frequency), display: String(raw.frequency) }],
      text: String(raw.frequency),
    },
  };
  const dose = Number(String(raw.dose || "").replace(/,/g, ""));
  if (Number.isFinite(dose) && String(raw.dose || "").trim()) {
    dosage.doseAndRate = [{ doseQuantity: { value: dose, ...(raw.unit ? { unit: String(raw.unit) } : {}) } }];
  }
  if (Object.keys(dosage).length) resource.dosageInstruction = [dosage];

  const dispense = {};
  if (raw.start_time || raw.end_time) {
    dispense.validityPeriod = {};
    if (raw.start_time) dispense.validityPeriod.start = raw.start_time;
    if (raw.end_time) dispense.validityPeriod.end = raw.end_time;
  }
  const total = Number(String(raw.total_quantity || "").replace(/,/g, ""));
  if (Number.isFinite(total) && String(raw.total_quantity || "").trim()) {
    // qemr gives a dose unit but no dispensing unit for the total column.
    // Keep the total value without falsely labelling it as mg/mL/etc.
    dispense.quantity = { value: total };
  }
  if (raw.duration_days) {
    const days = parseInt(raw.duration_days, 10);
    if (!Number.isNaN(days)) {
      dispense.expectedSupplyDuration = { value: days, unit: "days", system: "http://unitsofmeasure.org", code: "d" };
    }
  }
  if (Object.keys(dispense).length) resource.dispenseRequest = dispense;

  if (raw.indication) resource.reasonCode = [{ text: raw.indication }];
  const notes = [];
  if (raw.description) notes.push(String(raw.description));
  if (sourceStatus) notes.push(`原系統狀態：${sourceStatus}`);
  if (raw.self_purchase) notes.push(`自購：${raw.self_purchase}`);
  if (notes.length) resource.note = notes.map((text) => ({ text }));

  return resource;
}
