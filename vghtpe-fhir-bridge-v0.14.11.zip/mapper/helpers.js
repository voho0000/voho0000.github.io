// Cross-mapper helpers for the extension's backend-independent JS mapper path.
// Ported from backend/app/mapper/*.py (the _stable_id / _split_name / _map_*
// helpers, which were duplicated per-file in Python) and from
// NHI-FHIR-BRIDGE/packages/mapper/src/helpers.ts (de-identification).

import { hmacSha1hex, sha1hex } from "./sha1.js";

// Deterministic 32-char hex ID = sha1(patientId|part1|part2|…).slice(0,32).
// IDENTICAL algorithm to the backend Python `_stable_id`, so a locally-built
// Bundle and a backend-built one produce the same IDs (idempotent import).
export function stableId(patientId, ...parts) {
  return sha1hex([patientId, ...parts].join("|")).slice(0, 32);
}

// ── De-identification (opt-in via popup toggle) ───────────────────────────────
// VGH patient key is the 病歷號 histno (not a national ID), so there is no
// derivePatientId-from-national-ID step like NHI. De-id here masks the histno
// used as Patient.id, the name, and the birthDate.

// Half-mask an identifier for display / de-identified IDs. histno is numeric;
// keep first 2 + last 2, star the middle. `char` = "X" for hashing/filenames.
export function maskId(id, char = "*") {
  const s = (id ?? "").trim();
  if (!s) return s;
  if (s.length > 6) return s.slice(0, 2) + char.repeat(s.length - 4) + s.slice(-2);
  return s;
}

// Partially-anonymize a name (Taiwan/CJK convention), matching NHI maskName:
//   2 chars → keep first, 2nd → O (王明 → 王O)
//   3+ chars → keep first + last, middle → O (郭一新 → 郭O新)
// Western names (whitespace): keep first + last token, star the rest.
export function maskName(name) {
  const trimmed = (name ?? "").trim();
  if (!trimmed || trimmed === "Unknown") return trimmed;
  if (/\s/.test(trimmed)) {
    const parts = trimmed.split(/\s+/);
    if (parts.length === 1) return parts[0];
    const first = parts[0], last = parts[parts.length - 1];
    if (parts.length === 2) return `${first} ${last.length <= 1 ? last : last[0] + "***"}`;
    return [first, ...parts.slice(1, -1).map(() => "***"), last].join(" ");
  }
  const chars = Array.from(trimmed);
  if (chars.length <= 1) return trimmed;
  if (chars.length === 2) return `${chars[0]}O`;
  return chars[0] + "O".repeat(chars.length - 2) + chars[chars.length - 1];
}

// Birth date → keep year, normalize to Jan-1 (1962-04-15 → 1962-01-01).
// Full YYYY-01-01 parses in every SMART app while leaking only the year.
export function deidBirthDate(iso) {
  const s = (iso ?? "").trim();
  if (!s) return s;
  const m = /^(\d{4})\b/.exec(s);
  return m ? `${m[1]}-01-01` : s;
}

// The Patient.id to use for a histno under the current de-id mode. When de-id
// is on we hash the half-masked histno so the id can't be reversed to the raw
// 病歷號; when off, the id IS the raw histno (matches the backend Python path,
// which uses histno directly as Patient.id).
export function effectiveFhirPatientId(histno, deidentify, deidKey) {
  const s = String(histno || "").trim();
  if (!deidentify) return s;
  if (!deidKey) throw new Error("去識別化金鑰不存在，請重新啟動擴充功能後再試");
  return hmacSha1hex(deidKey, `patient|${s}`).slice(0, 32);
}

// ── Name splitting (ported from patient.py _split_name) ───────────────────────
export function splitName(fullName) {
  const name = (fullName || "").trim();
  if (!name || name === "Unknown") return { family: "", given: [] };
  if (/\s/.test(name)) {
    const parts = name.split(/\s+/);
    return { family: parts[parts.length - 1], given: parts.slice(0, -1) };
  }
  const chars = Array.from(name);
  return chars.length > 1 ? { family: chars[0], given: [chars.slice(1).join("")] } : { family: name, given: [] };
}

// Base64 of a UTF-8 string (chunked so large discharge-summary HTML doesn't
// blow the String.fromCharCode argument limit). Matches Python
// base64.b64encode(s.encode("utf-8")) so the backend and extension produce the
// same DocumentReference attachment bytes.
export function b64utf8(str) {
  const bytes = new TextEncoder().encode(str || "");
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

export const SRC_META = { versionId: "1", source: "ehr-fhir-bridge/scraper" };
