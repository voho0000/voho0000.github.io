// Condition mapper — ported from backend/app/mapper/condition.py.

import { stableId, SRC_META } from "./helpers.js";
import { encounterId } from "./encounter-id.js";

export const DIAGNOSIS_CATEGORY_SYSTEM = "urn:oid:his.diagnosis.category";

export function conditionId(raw, patientId) {
  const parts = [patientId, raw.code || "", raw.onset_date || raw.recorded_date || ""];
  if (raw.encounter_class) parts.push(raw.encounter_class, raw.case_no || "",
    raw.diagnosis_category || "", raw.diagnosis_sequence || "", raw.effective_date || "");
  if (raw.encounter_class === "AMB" && raw.encounter_instance) parts.push(raw.encounter_instance);
  return stableId(...parts);
}

export function mapCondition(raw, patientId) {
  const resource = {
    resourceType: "Condition",
    id: conditionId(raw, patientId),
    meta: { ...SRC_META },
    subject: { reference: `Patient/${patientId}` },
    clinicalStatus: {
      coding: [{ system: "http://terminology.hl7.org/CodeSystem/condition-clinical", code: raw.clinical_status || "active" }],
    },
    verificationStatus: {
      coding: [{ system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", code: "confirmed" }],
    },
  };

  const display = raw.display || "Unknown Condition";
  const code = raw.code;
  resource.code = {
    coding: [{ system: mapSystem(raw.system || ""), code: code || display, display }],
    text: display,
  };

  if (raw.severity) resource.severity = { text: raw.severity };
  if (raw.onset_date) resource.onsetDateTime = raw.onset_date + "T00:00:00+08:00";
  if (raw.recorded_date) resource.recordedDate = raw.recorded_date;
  if (raw.recorder) resource.recorder = { display: raw.recorder };
  if (raw.encounter_class) {
    // A/D is a source category, not evidence of disease activity or resolution.
    if (!raw.clinical_status) delete resource.clinicalStatus;
    delete resource.verificationStatus;
    resource.category = [{ coding: [{
      system: "http://terminology.hl7.org/CodeSystem/condition-category",
      code: "encounter-diagnosis",
    }] }];
    if (raw.diagnosis_category) resource.category.push({
      coding: [{ system: DIAGNOSIS_CATEGORY_SYSTEM, code: raw.diagnosis_category }],
    });
    if (raw.encounter_ref_date) resource.encounter = {
      reference: `Encounter/${encounterId(raw, patientId)}`,
    };
    const extBase = "https://github.com/voho0000/EHR-FHIR-BRIDGE/StructureDefinition/";
    const extensions = [];
    if (raw.diagnosis_sequence) extensions.push({ url: extBase + "diagnosis-sequence", valueString: raw.diagnosis_sequence });
    if (raw.effective_date) extensions.push({ url: extBase + "diagnosis-effective-date", valueDate: raw.effective_date });
    if (extensions.length) resource.extension = extensions;
  }
  if (raw.verification_status) resource.verificationStatus = {
    coding: [{ system: "http://terminology.hl7.org/CodeSystem/condition-ver-status", code: raw.verification_status }],
  };

  return resource;
}

function mapSystem(hint) {
  const s = typeof hint === "string" ? hint.toLowerCase() : "";
  if (s.includes("snomed")) return "http://snomed.info/sct";
  if (s.includes("icd-10-cm") || s.includes("icd10cm")) return "http://hl7.org/fhir/sid/icd-10-cm";
  if (s.includes("icd-10") || s.includes("icd10")) return "http://hl7.org/fhir/sid/icd-10";
  return "urn:oid:his.condition.code";
}
