// Patient mapper — ported from backend/app/mapper/patient.py, plus opt-in
// de-identification (maskName / deidBirthDate / effectiveFhirPatientId).

import { splitName, deidBirthDate, effectiveFhirPatientId, SRC_META } from "./helpers.js";

export function mapPatient(raw, opts = {}) {
  const deid = !!opts.deidentify;
  const rawHistno = String(raw.identifier ?? raw.id ?? "unknown");
  const patientId = effectiveFhirPatientId(rawHistno, deid, opts.deidKey);

  let nameText = raw.name || "Unknown";
  if (deid) nameText = `DEID-${patientId.slice(0, 8)}`;
  const { family, given } = splitName(nameText);
  const nameEntry = { use: "official", text: nameText };
  if (family) nameEntry.family = family;
  if (given && given.length) nameEntry.given = given;

  const resource = {
    resourceType: "Patient",
    id: patientId,
    meta: { ...SRC_META },
    identifier: [{
      use: "official",
      system: "urn:oid:his.patient.mrn",
      // Under de-id, don't leak the raw 病歷號 in identifier either.
      value: deid ? patientId : rawHistno,
    }],
    name: [nameEntry],
    gender: mapGender(raw.gender),
  };

  const idNo = (raw.id_no || "").trim();
  if (idNo && !deid) {
    resource.identifier.push({
      use: "secondary",
      system: "urn:oid:tw.gov.id-number",
      value: idNo,
    });
  }

  const birthDate = raw.birthDate;
  if (birthDate) resource.birthDate = deid ? deidBirthDate(birthDate) : birthDate;

  // Phone / address dropped entirely under de-id (directly identifying).
  if (!deid) {
    if (raw.phone) resource.telecom = [{ system: "phone", use: "home", value: raw.phone }];
    if (raw.address) resource.address = [{ use: "home", text: raw.address }];
  }

  return resource;
}

function mapGender(gender) {
  const g = typeof gender === "string" ? gender.toLowerCase() : "";
  if (["male", "m", "男", "男性"].includes(g)) return "male";
  if (["female", "f", "女", "女性"].includes(g)) return "female";
  return "unknown";
}
