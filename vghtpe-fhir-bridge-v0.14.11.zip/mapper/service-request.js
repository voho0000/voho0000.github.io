import { stableId, SRC_META } from "./helpers.js";
import { encounterId } from "./encounter-id.js";
import { isOutpatientSupply } from "../outpatient-order.js";

export function mapServiceRequest(raw, patientId) {
  if (!raw.order_code || !raw.display) return null;
  if (isOutpatientSupply(raw)) return null;
  const resource = {
    resourceType: "ServiceRequest",
    id: stableId(patientId, "outpatient-order", raw.encounter_ref_date || raw.date || "",
      raw.encounter_instance || "", raw.order_code, raw.order_sequence || ""),
    meta: { ...SRC_META }, status: "unknown", intent: "order",
    code: { coding: [{ system: "urn:oid:vgh.order.code", code: raw.order_code, display: raw.display }], text: raw.display },
    subject: { reference: `Patient/${patientId}` },
    encounter: { reference: `Encounter/${encounterId(raw, patientId)}` },
  };
  if (raw.request_no) resource.identifier = [{ system: "urn:oid:vgh.report.request", value: raw.request_no }];
  if (raw.date) resource.authoredOn = raw.requested_at || raw.date;
  if (raw.provider) resource.requester = { display: raw.provider };
  if (/^\d+(?:\.\d+)?$/.test(String(raw.quantity || ""))) resource.quantityQuantity = { value: Number(raw.quantity) };
  const details = [["檢體", raw.specimen], ["頻次", raw.frequency], ["是否自購", raw.self_purchase]]
    .filter(([, value]) => value).map(([label, value]) => ({ text: `${label}：${value}` }));
  if (details.length) resource.orderDetail = details;
  return resource;
}
