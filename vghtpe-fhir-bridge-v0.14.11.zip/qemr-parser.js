// VGH qemr DOM parsers.
//
// This file is injected into the qemr tab via chrome.scripting.executeScript
// (files: ["qemr-parser.js"]) so DOMParser + the standard browser DOM are
// available. After injection, the SW calls a follow-up executeScript with
// `func: () => __vghParse(pageType, html)` to drive parsing.
//
// Output dict shapes match what the backend's Python mappers expect (see
// backend/app/mapper/*.py). Keep them aligned when extending.

(function attachParser() {
  const parserVersion = "2026-10-20-report-date-provenance-v9";
  if (window.__vghParse?.parserVersion === parserVersion) return;

  const stripTags = (s) => (s || "").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();

  function parseDoc(html) {
    return new DOMParser().parseFromString(html, "text/html");
  }

  function parseOrderIndex(doc) {
    const table = [...doc.querySelectorAll("table")].find(t =>
      [...(t.rows[0]?.cells || [])].some(c => c.textContent.trim() === "REQNO"));
    if (!table) return { valid: false, items: [] };
    const rows = [...table.rows].slice(1);
    const items = rows.flatMap(row => {
      const c = [...row.cells].map(cell => (cell.textContent || "").trim());
      const href = row.querySelector('a[href*="treqno="]')?.getAttribute("href");
      if (c.length !== 8 || !href) return [];
      const params = new URL(href, "https://qemr.invalid").searchParams;
      if (!c[2] || c[2] !== params.get("treqno")) return [];
      const dt = c[7].match(/開單\s*[:：]\s*(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})/);
      if (!dt) return [];
      return [{ display: c[0].replace(/\(說明\)\s*$/, "").trim(), specimen: c[1],
        request_no: c[2], provider: c[6], date: dt[1], requested_at: `${dt[1]}T${dt[2]}+08:00`,
        case_no: params.get("caseno") || "", sequence: params.get("tseqno") || "" }];
    });
    return { valid: !rows.length || items.length > 0, items, skippedRows: rows.length - items.length };
  }

  // Keep list dates with detail links that otherwise carry only a case number.
  function parseRecordIndex(doc, opts) {
    const action = opts.action;
    const table = doc.querySelector(action === "findRes" ? "#reslist" : "#caselist");
    const root = table || doc;
    const links = [];
    let valid = !!table;
    const values = (params, name) => [...params].filter(([key]) => key.toLowerCase() === name).map(([,value]) => value);
    const value = (params, name) => { const matches = values(params, name); return matches.length === 1 ? matches[0] : ""; };
    const headers = [...(table?.rows?.[0]?.cells || [])].map(cell => (cell.textContent || "").replace(/\s/g, ""));
    const reportColumn = headers.findIndex(text => /報告日期|報告時間|發布日期|發布時間/.test(text));
    const updatedColumn = headers.findIndex(text => /更新日期|更新時間|修改日期|修改時間/.test(text));
    for (const anchor of root.querySelectorAll('a[href]')) {
      const href = (anchor.getAttribute("href") || "").replace(/&amp;/g, "&");
      let params;
      try { params = new URL(href, "https://qemr.invalid").searchParams; } catch { if (href.includes("?")) valid = false; continue; }
      const candidate = ["action", "caseno", "reqno", "ordseq"].some(key => values(params,key).length);
      if (!candidate) continue;
      const bindingKeys = ["action", "histno", "caseno", "reqno", "ordseq", "ordclnm", "treqno", "tseqno", "partno", "dt", "frpdt"];
      if (bindingKeys.some(key => values(params,key).length > 1)) { valid = false; continue; }
      // Cumulative reports are intentionally not part of individual-report capture.
      if (action === "findRes" && value(params,"action") === "findResd") continue;
      if (value(params,"action") !== action || !value(params,"caseno")) { valid = false; continue; }
      const row = anchor.closest("tr");
      const dates = [...(row?.cells || [])].map(cell => toIsoDate((cell.textContent || "").trim())).filter(Boolean);
      links.push({ href, date: dates[0] || toIsoDate(value(params,"dt") || value(params,"frpdt") || ""),
        ...(reportColumn >= 0 ? { report_date: toIsoDate((row?.cells[reportColumn]?.textContent || "").trim()) } : {}),
        ...(updatedColumn >= 0 ? { updated_date: toIsoDate((row?.cells[updatedColumn]?.textContent || "").trim()) } : {}) });
    }
    const years = new Set();
    if (action === "findRes") for (const select of doc.querySelectorAll("select")) {
      for (const option of select.options) {
        let value = (option.value || "").trim();
        let monthValues = [];
        try { monthValues = values(new URL(value, "https://qemr.invalid").searchParams,"tmonth"); } catch {}
        if (monthValues.length > 1) { valid = false; continue; }
        value = monthValues[0] || value;
        const isMonthSelect = select.id?.toLowerCase() === "tmonth" || select.name?.toLowerCase() === "tmonth" || monthValues.length;
        if (isMonthSelect && /^\d{4}$/.test(value)) years.add(Number(value));
      }
    }
    return { links, years: [...years], valid };
  }

  // Pull patient demographics from the qemr navbar, which appears on every
  // page (ul.jd_menu > li:first-child). Real layout (whitespace-collapsed):
  //   "孫翠霞 50205180 55歲(19710410) 女"
  //   name  histno    age(birthYYYYMMDD) gender
  // Histno (from URL) is the canonical ID; navbar gives name + gender + birthDate.
  function parsePatientFromNavbar(doc, histno) {
    const navbar = doc.querySelector("ul.jd_menu > li:first-child");
    const text = navbar ? stripTags(navbar.outerHTML) : "";
    const out = { identifier: histno, id: histno };
    if (!text) return out;

    // Name: first run of CJK chars (2-5). Sits at the start of the navbar.
    const nameMatch = text.match(/([一-鿿]{2,5})/);
    if (nameMatch) out.name = nameMatch[1];

    // Gender: real format is a bare 女 / 男 at the end (no 性 suffix).
    // Match either "女性"/"男性" or an isolated 女/男 surrounded by whitespace/EOL.
    if (/女性|(?:^|\s)女(?:\s|$)/.test(text)) out.gender = "female";
    else if (/男性|(?:^|\s)男(?:\s|$)/.test(text)) out.gender = "male";

    // Birth date: (YYYYMMDD) form, lives next to age 歲.
    const bdMatch = text.match(/\((\d{4})(\d{2})(\d{2})\)/);
    if (bdMatch) out.birthDate = `${bdMatch[1]}-${bdMatch[2]}-${bdMatch[3]}`;

    return out;
  }

  // qemr findEmr homepage allergies live in #p1 under
  // "病人有下列藥物過敏或不良反應記錄" or similar headers. Each item
  // is a free-text drug name; we emit one allergy entry per non-empty line.
  function parseAllergies(doc) {
    const p1 = doc.querySelector("#p1");
    if (!p1) return [];
    const text = p1.textContent || "";
    const m = text.match(/(?:藥物過敏|過敏|不良反應)[^]*?(?=\n\n|$)/);
    if (!m) return [];
    const items = [];
    for (const raw of m[0].split(/[\n,;、，；]+/)) {
      const name = stripTags(raw).replace(/^.*?[:：]/, "").trim();
      // Skip the header line itself and very short tokens
      if (!name || name.length < 2) continue;
      if (/藥物過敏|過敏|不良反應/.test(name)) continue;
      items.push({
        display: name,
        category: "medication",
        criticality: "unable-to-assess",
      });
    }
    return items;
  }

  // findPdiagHistory → #pdigaslist table. Columns typically:
  //   診斷代碼 | 中文/英文名稱 | 起始日期 | 結束日期 | 狀態
  function parseConditions(doc) {
    const tbl = doc.querySelector("#pdigaslist");
    if (!tbl) return [];
    const out = [];
    for (const tr of tbl.querySelectorAll("tr")) {
      const cells = [...tr.querySelectorAll("td")].map((td) => stripTags(td.outerHTML));
      if (cells.length < 2) continue;
      // Skip header rows (no date-like cell present)
      const code = cells[0];
      if (!code || /^診斷|代碼|名稱/.test(code)) continue;
      const display = cells[1] || code;
      const onset = (cells.find((c) => /^\d{4}-\d{2}-\d{2}/.test(c)) || "").slice(0, 10);
      out.push({
        code,
        display,
        system: code.startsWith("ICD") || /^[A-Z]\d/.test(code) ? "ICD-10" : "",
        onset_date: onset || "",
        clinical_status: "active",
      });
    }
    return out;
  }

  // findPdiags exposes an unnamed select with one case number per admission.
  function parseInpatientDiagnosisIndex(doc) {
    const select = doc.querySelector('select[onchange*="dispPiag"]');
    if (!select) return [];
    const out = [], seen = new Set();
    for (const option of select.options) {
      const caseNo = (option.value || "").trim();
      const text = (option.textContent || "").replace(/\s+/g, " ").trim();
      const dates = text.match(/^(\d{8})\s*[~～]\s*(\d{8})(?:\s*\(([^)]+)\))?/);
      if (!caseNo || !dates || seen.has(caseNo)) continue;
      seen.add(caseNo);
      out.push({
        case_no: caseNo,
        admit_date: toIsoDate(dates[1]),
        discharge_date: toIsoDate(dates[2]),
        department: (dates[3] || "").trim(),
        href: `/emr/qemr/qemr.cfm?action=findPdiags&caseno=${encodeURIComponent(caseNo)}`,
      });
    }
    return out;
  }

  // Unlike findPdiagHistory, the first column here is the input date, not ICD.
  // The index has a default diagnosis table; per-case responses use a plain
  // table without an id. Keep both, because their rows can differ.
  function parseInpatientDiagnoses(doc, opts) {
    const meta = opts || {};
    const cases = meta.case_no ? [] : parseInpatientDiagnosisIndex(doc);
    const table = doc.querySelector("#pdigaslist") || doc.querySelector("table");
    if (!table) return [];
    const out = [];
    for (const tr of table.querySelectorAll("tr")) {
      const cells = [...tr.cells].map((cell) => (cell.textContent || "").replace(/\s+/g, " ").trim());
      if (cells.length < 7) continue;
      const recorded = toIsoDate(cells[0]);
      const code = cells[1].toUpperCase();
      if (!recorded || !/^[A-Z]\d[A-Z0-9](?:\.[A-Z0-9]{1,4})?$/.test(code)) continue;
      const effective = toIsoDate(cells[5]);
      // Bind the default table only when its dates identify one admission.
      const candidates = cases.filter((item) => recorded >= item.admit_date
        && recorded <= item.discharge_date
        && (!effective || (effective >= item.admit_date && effective <= item.discharge_date)));
      const encounter = meta.case_no ? meta : (candidates.length === 1 ? candidates[0] : {});
      out.push({
        code,
        display: cells[2] || code,
        system: "ICD-10",
        recorded_date: recorded,
        effective_date: effective,
        diagnosis_category: cells[3],
        diagnosis_sequence: cells[4],
        recorder: cells[6],
        case_no: encounter.case_no || "",
        encounter_ref_date: encounter.admit_date || "",
        encounter_class: "IMP",
      });
    }
    return out;
  }

  // findOpd (no dt=) → #opdlist. Columns:
  //   門診日期 | 門診時間 | 門診醫師 | 科別 | 門診主診斷碼
  // findAdm → #admlist. Similar columns with 出院日期 + 主診斷碼.
  // We accept both #opdlist and #admlist tables and emit one Encounter per row.
  function parseEncountersList(doc) {
    const out = [];
    for (const sel of ["#opdlist", "#admlist"]) {
      const tbl = doc.querySelector(sel);
      if (!tbl) continue;
      const isAdm = sel === "#admlist";
      for (const tr of tbl.querySelectorAll("tr")) {
        const cells = [...tr.querySelectorAll("td")].map((td) => stripTags(td.outerHTML));
        if (cells.length < 2) continue;
        if (!/^\d{4}-?\d{2}-?\d{2}/.test(cells[0])) continue; // skip header
        // Normalize to ISO so admission dates ("20251219") don't yield a
        // malformed period.start AND so the inpatient Encounter's stable id
        // matches the DocumentReference link (stableId(pid, admit_ISO, "IMP")).
        const caseHref = tr.querySelector('a[href*="caseno"]')?.getAttribute("href") || "";
        let caseNo = "";
        try { caseNo = new URL(caseHref, "https://qemr.invalid").searchParams.get("caseno") || ""; } catch {}
        const detailHref = isAdm ? "" : (tr.querySelector('a[href*="action=findOpd"][href*="dt="]')?.getAttribute("href") || "");
        let detailParams;
        try { detailParams = new URL(detailHref, "https://qemr.invalid").searchParams; } catch {}
        const providerId = detailParams?.get("doc") || (cells[2] || "").match(/\bDOC[A-Z0-9]+\b/i)?.[0] || "";
        const departmentCode = detailParams?.get("dept") || "";
        out.push({
          date: toIsoDate(cells[0]),
          end_date: isAdm ? toIsoDate(cells[1] || "") : "",
          visit_time: isAdm ? "" : (cells[1] || ""),
          class: isAdm ? "IMP" : "AMB",
          provider: cells[2] || "",
          department: cells[3] || "",
          reason: cells[4] || "",
          ...(!isAdm && providerId ? { provider_id: providerId,
            department_code: departmentCode, detail_href: detailHref,
            encounter_id: [providerId, departmentCode, cells[1] || ""].join("|") } : {}),
          ...(isAdm && caseNo ? { case_no: caseNo } : {}),
        });
      }
    }
    return out;
  }

  // findOpd&dt=... → #opddetail. SOAP / visit narrative for a single encounter.
  // The legend contains "[YYYY-MM-DD_SOAP]" which gives us the visit date.
  // Strip the per-row table chrome and concatenate text content.
  function parseEncounterDetail(doc, opts = {}) {
    if (doc.querySelector("#opddetail") || [...doc.querySelectorAll("fieldset > legend")]
      .some(legend => /\d{4}-\d{2}-\d{2}_SOAP/.test(legend.textContent || ""))) {
      return parseOutpatientDetail(doc, opts).encounters;
    }
    const root = doc.querySelector("#opddetail") || doc.querySelector("#admdetail") || doc.querySelector("#discase");
    if (!root) return [];
    const legend = root.querySelector("legend");
    const legendText = legend ? stripTags(legend.outerHTML) : "";
    const dateMatch = legendText.match(/(\d{4}-\d{2}-\d{2})/);
    if (!dateMatch) return [];
    const date = dateMatch[1];

    // Concatenate all text content with line breaks preserved roughly.
    const note = root.innerText || root.textContent || "";
    const cleanNote = note.replace(/\s+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();

    const isAdm = !!doc.querySelector("#admdetail");
    return [{
      date,
      class: isAdm ? "IMP" : "AMB",
      clinical_note: cleanNote,
    }];
  }

  function outpatientText(node) {
    if (!node) return "";
    const copy = node.cloneNode(true);
    for (const el of copy.querySelectorAll("script,style,noscript,template,input,button,select,[hidden]")) el.remove();
    for (const br of copy.querySelectorAll("br")) br.replaceWith("\n");
    for (const block of copy.querySelectorAll("p,div,li")) block.append("\n");
    return (copy.textContent || "").replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n")
      .replace(/\n[ \t]+/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function outpatientRowHidden(row) {
    return row.hidden || row.style.display === "none" || row.style.visibility === "hidden";
  }

  function parseOutpatientDetail(doc, opts = {}) {
    const empty = { encounters: [], conditions: [], medications: [], service_requests: [], document_references: [] };
    // findOpd's HTTP response is a fragment with fieldsets directly in body.
    // The live qemr UI supplies #opddetail only when it mounts that fragment.
    const root = doc.querySelector("#opddetail") || doc.body;
    if (!root) return empty;
    const groups = [...root.querySelectorAll("fieldset")];
    const soapGroup = groups.find(group => /\d{4}-\d{2}-\d{2}_SOAP/.test(group.querySelector("legend")?.textContent || ""));
    const date = soapGroup?.querySelector("legend")?.textContent.match(/\d{4}-\d{2}-\d{2}/)?.[0];
    if (!date || (opts.date && date !== opts.date)) return empty;
    const table = soapGroup.querySelector("table");
    if (!table) return empty;
    const soap = { s: "", o: "", a: "", p: "" }, parts = { s: [], o: [], a: [], p: [] };
    let section = null;
    for (const row of table.rows) {
      if (outpatientRowHidden(row)) continue;
      const text = outpatientText(row);
      const heading = text.match(/^([SOAP])\s*[:：]\s*(?:主觀資料|客觀資料|診斷|治療計畫)\s*$/i);
      if (heading) section = heading[1].toLowerCase();
      else if (section && text) parts[section].push(text);
    }
    if (!Object.values(parts).some(lines => lines.length)) return empty;
    for (const key of Object.keys(soap)) soap[key] = parts[key].join("\n");
    const clinicalNote = [["s", "S：主觀資料"], ["o", "O：客觀資料"], ["a", "A：診斷"], ["p", "P：治療計畫"]]
      .map(([key, title]) => `${title}\n${soap[key]}`).join("\n\n");
    const instance = opts.encounter_id || opts.case_no || opts.visit_time || [opts.department, opts.provider].filter(Boolean).join("|");
    const context = { date, encounter_ref_date: date, encounter_class: "AMB", encounter_instance: instance };
    // Codes are parsed only from A, never from O/P's historical narrative.
    const conditions = [];
    const seen = new Set();
    for (const line of soap.a.split(/\n/)) {
      // Preserve CM categories with a letter in position three without accepting A1C lab shorthand.
      const match = line.trim().match(/^((?:[A-Z]\d{2}|C4A|C7[AB]|D3A|M1A|O9A|Z3A)(?:\.[A-Z0-9]{1,4})?)(?:\s+(.+))?$/);
      if (match?.[1] === "B12") continue; // Vitamin B12 shorthand is not a CM category.
      if (!match || seen.has(match[1].toUpperCase())) continue;
      seen.add(match[1].toUpperCase());
      conditions.push({ ...context, code: match[1].toUpperCase(), display: (match[2] || match[1]).trim(),
        system: "ICD-10-CM", recorded_date: date, diagnosis_sequence: String(conditions.length),
        ...(opts.provider ? { recorder: opts.provider } : {}) });
    }
    const rowsFor = title => {
      const group = groups.find(group => (group.querySelector("legend")?.textContent || "").replace(/[\[\]\s]/g, "") === title);
      return [...(group?.querySelector("table")?.rows || [])].slice(1)
        .filter(row => !outpatientRowHidden(row))
        .map(row => [...row.cells].map(outpatientText));
    };
    const medications = rowsFor("用藥記錄").filter(cells => cells.length >= 9 && cells[1]).map(cells => ({
      ...context, drug_name: cells[1], dose: cells[2], unit: cells[3], route: cells[4], duration_days: cells[5],
      frequency: cells[6], start_time: (toIsoDate(cells[7]) || date) + "T00:00:00+08:00", description: cells[8],
    }));
    const serviceRequests = rowsFor("門診醫囑").filter(cells => cells.length >= 7 && cells[1] && cells[2]).map((cells, index) => ({
      ...context, order_code: cells[1], display: cells[2], specimen: cells[3], frequency: cells[4],
      quantity: cells[5], self_purchase: cells[6], order_sequence: String(index), provider: opts.provider || "",
      // The source table records orders, not execution status.
      status: "unknown",
    }));
    const noteHtml = root.cloneNode(true);
    for (const el of noteHtml.querySelectorAll("script,style,noscript,template,input,button,select")) el.remove();
    for (const el of [noteHtml, ...noteHtml.querySelectorAll("*")]) {
      for (const attr of [...el.attributes]) if (/^on/i.test(attr.name) || (/^(?:href|src|action)$/i.test(attr.name) && /^\s*javascript:/i.test(attr.value))) el.removeAttribute(attr.name);
    }
    return {
      encounters: [{ ...opts, date, class: "AMB", soap, clinical_note: clinicalNote, diagnoses: conditions }],
      conditions, medications, service_requests: serviceRequests,
      document_references: [{ ...context, doc_type: "outpatient", html: noteHtml.outerHTML,
        department: opts.department || "", physician: opts.provider || "" }],
    };
  }

  // findErn has one case-number link per ED visit. The summary form posts
  // to ERS/download/pdf; that endpoint rejects GET requests.
  function parseEmergencyList(doc) {
    const table = doc.querySelector("#ernlist");
    if (!table) return [];
    const out = [], seen = new Set();
    for (const row of table.querySelectorAll("tr")) {
      const cells = [...row.cells].map((cell) => (cell.textContent || "").trim());
      const date = toIsoDate(cells[0] || "");
      const link = row.querySelector('a[href*="caseno"]');
      const href = (link?.getAttribute("href") || "").replace(/&amp;/g, "&");
      const caseMatch = href.match(/[?&]caseno=([^&#]+)/);
      if (!date || !/[?&]action=findErn(?:&|$)/.test(href) || !caseMatch) continue;
      let caseNo;
      try { caseNo = decodeURIComponent(caseMatch[1]); } catch (_) { continue; }
      if (!caseNo || seen.has(caseNo)) continue;
      seen.add(caseNo);
      out.push({
        date, class: "EMER", case_no: caseNo, department: cells[1] || "",
        summary_available: !!row.querySelector('form[action*="/ERS/download/pdf"]'),
      });
    }
    return out;
  }

  function emergencyDateTime(text, label) {
    const match = text.match(new RegExp(label + "\\s*[:：]\\s*(\\d{7,8})\\s+(\\d{2}):?(\\d{2})"));
    if (!match) return "";
    const yearLength = match[1].length - 4;
    const year = Number(match[1].slice(0, yearLength)) + (yearLength === 3 ? 1911 : 0);
    const month = match[1].slice(yearLength, yearLength + 2), day = match[1].slice(-2);
    if (Number(month) < 1 || Number(month) > 12 || Number(day) < 1 || Number(day) > 31
      || Number(match[2]) > 23 || Number(match[3]) > 59) return "";
    return `${year}-${month}-${day}T${match[2]}:${match[3]}:00+08:00`;
  }

  // The ED body has no id: use its own fieldset legend, never the surrounding
  // page/navbar. ICD-9 remains in the untouched source HTML only.
  function parseEmergencyDetail(doc, opts) {
    const meta = opts || {};
    const root = [...doc.querySelectorAll("fieldset")].find((fieldset) =>
      /急診[記紀]錄內容/.test(fieldset.querySelector("legend")?.textContent || ""));
    const empty = { encounters: [], conditions: [], document_references: [] };
    if (!root || !meta.case_no || !meta.date) return empty;
    const lines = [...root.querySelectorAll("tr")]
      .map((row) => (row.textContent || "").replace(/\s+/g, " ").trim());
    const fullText = lines.join("\n");
    if (!fullText.trim()) return empty;
    const start = emergencyDateTime(fullText, "掛號日期時間");
    const created = emergencyDateTime(fullText, "建置日期時間");
    const date = start.slice(0, 10) || meta.date;
    // A mismatched detail must never attach another visit's narrative/diagnoses.
    if (date !== meta.date) return empty;
    const diagnoses = [], noteLines = [];
    let icd9 = false, icd10 = false;
    for (const line of lines) {
      if (/^ICD\s*-?\s*9\s*[:：]/i.test(line)) { icd9 = true; icd10 = false; continue; }
      if (/^ICD\s*-?\s*10\s*[:：]/i.test(line)) { icd9 = false; icd10 = true; noteLines.push(line); continue; }
      if (icd9 && (!line || /^\[/.test(line))) continue;
      icd9 = false;
      noteLines.push(line);
      if (!icd10) continue;
      const match = line.match(/^\[\s*([A-Z]\d[A-Z0-9](?:\.[A-Z0-9]{1,4})?)\s*\]\s*(.*)$/i);
      if (!match) { if (line && !/^\[\s*\]/.test(line)) icd10 = false; continue; }
      const code = match[1].toUpperCase();
      if (diagnoses.some((item) => item.code === code)) continue;
      diagnoses.push({
        code, display: match[2] || code, system: "ICD-10",
        recorded_date: created.slice(0, 10) || date,
        case_no: meta.case_no, encounter_class: "EMER", encounter_ref_date: date,
        diagnosis_sequence: String(diagnoses.length), verification_status: "provisional",
      });
    }
    const chiefIndex = lines.findIndex((line) => /主訴\s*\(/.test(line));
    const reason = chiefIndex >= 0 ? (lines[chiefIndex + 1] || "") : "";
    const encounter = {
      date, class: "EMER", case_no: meta.case_no, department: meta.department || "",
      start_datetime: start, clinical_note: noteLines.join("\n").trim(), diagnoses,
      ...(reason ? { reason } : {}),
    };
    return {
      encounters: [encounter], conditions: diagnoses,
      document_references: [{
        doc_type: "emergency", date, datetime: created || start,
        caseno: meta.case_no, encounter_class: "EMER", encounter_ref_date: date,
        department: meta.department || "", html: root.outerHTML,
      }],
    };
  }

  // findUd&caseno=... → #udorder table. Columns:
  //   學名 | 商品名 | 劑量 | 單位 | 途徑 | 頻次 | 開始日 | 結束日 | 狀態 | 總量 | 自購 | 說明
  // The visit's date is on the URL (?dt=YYYY-MM-DD) — caller passes it as `date`.
  function vghDateTime(value) {
    const m = String(value || "").trim().match(/^(\d{4})[-\/]?(\d{2})[-\/]?(\d{2})(?:[- T](\d{2})[.:](\d{2}))?/);
    if (!m) return "";
    const [, y, mo, d, h, mi] = m;
    return h == null ? `${y}-${mo}-${d}` : `${y}-${mo}-${d}T${h}:${mi}:00+08:00`;
  }

  function parseMedicationsDetail(doc, hintedDate) {
    const tbl = doc.querySelector("#udorder");
    if (!tbl) return [];
    const out = [];
    for (const tr of tbl.querySelectorAll("tr")) {
      const tds = [...tr.querySelectorAll("td")];
      const cells = tds.map((td) => stripTags(td.outerHTML));
      if (cells.length < 8) continue;
      if (/^學名|^商品/.test(cells[0])) continue; // header
      const generic = cells[0] || "";
      const brand = cells[1] || "";
      const drugName = brand || generic;
      if (!drugName) continue;
      const start = vghDateTime(cells[6]);
      const end = vghDateTime(cells[7]);
      const detailLink = tds[11]?.querySelector("a[href]");
      const detailHref = detailLink ? (detailLink.getAttribute("href") || "").replace(/&amp;/g, "&") : "";
      const caseNo = (detailHref.match(/[?&]caseno=([^&]+)/) || [])[1] || "";
      const orderSeq = (detailHref.match(/[?&]ordseq=([^&]+)/) || [])[1] || "";
      out.push({
        date: (start || hintedDate || "").slice(0, 10),
        start_time: start,
        end_time: end,
        generic_name: generic,
        brand_name: brand,
        drug_name: drugName,
        dose: cells[2] || "",
        unit: cells[3] || "",
        route: cells[4] || "",
        frequency: cells[5] || "",
        source_status: cells[8] || "",
        total_quantity: cells[9] || "",
        self_purchase: cells[10] || "",
        description: detailHref ? "" : (cells[11] && cells[11] !== "-" ? cells[11] : ""),
        detail_href: detailHref,
        case_no: caseNo,
        order_seq: orderSeq,
      });
    }
    return out;
  }

  // findUd&caseno=...&ordseq=... → free-text administration/dilution note.
  // Keep the full text because important instructions such as diluent,
  // infusion duration and loading dose are not present in #udorder.
  function parseMedicationNoteDetail(doc) {
    const root = doc.querySelector("#uddetail, #udorder, fieldset, table") || doc.body;
    const text = (root?.innerText || root?.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    return { note: text };
  }

  // findPba → "病人基本資料" page. Each row is `<td>label：</td><td>value</td>`
  // and carries 身份證號 + 主治醫師/地址/電話/最近就診日 that
  // the navbar-only patient_info parser doesn't have.
  function parsePatientFromFindPba(doc) {
    const out = {};
    for (const tr of doc.querySelectorAll("tr")) {
      const tds = [...tr.querySelectorAll("td")];
      if (tds.length < 2) continue;
      const label = tds[0].textContent.replace(/\s+/g, "").trim();
      const value = tds[1].textContent.replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
      if (!label || !value) continue;
      if (/病歷號/.test(label)) {
        out.identifier = value;
        out.id = value;
      } else if (/姓.*名|姓名/.test(label)) {
        // "孫翠霞(SUN CUI XIA)" → CJK name + English in paren
        const m = value.match(/^([^(（]+)/);
        out.name = m ? m[1].trim() : value;
      } else if (/生.*日|生日/.test(label)) {
        // "19710410（55歲）" → 1971-04-10
        const m = value.match(/^(\d{8})/);
        if (m) out.birthDate = `${m[1].slice(0,4)}-${m[1].slice(4,6)}-${m[1].slice(6,8)}`;
      } else if (/性.*別/.test(label)) {
        out.gender = value.includes("女") ? "female" : value.includes("男") ? "male" : "unknown";
      } else if (/身份證號|身分證號/.test(label)) {
        out.id_no = value;
      } else if (/地.*址/.test(label)) {
        if (value !== "-") out.address = value;
      } else if (/行動電話/.test(label) || /電.*話[二2]/.test(label)) {
        if (value !== "-" && !out.phone) out.phone = value;
      } else if (/主治醫師/.test(label)) {
        out.attending_physician = value;
      }
    }
    return out;
  }

  // findOpn detail (with dt=) → flat key-value table.
  // Pulls the full operation record. The narrative, team and anaesthesia
  // fields are clinically meaningful and must not be discarded.
  function parseOperationsDetail(doc) {
    const out = {};
    for (const td of doc.querySelectorAll("td")) {
      // Replace nbsp ( ) with space and collapse whitespace so labels
      // and values land on one line regardless of qemr's nbsp-padding.
      const text = td.textContent.replace(/ /g, " ").replace(/\s+/g, " ").trim();
      if (!text) continue;
      let m;
      if ((m = text.match(/^術前診斷：\s*(.+)$/))) {
        out.preop_diagnosis = m[1].trim();
      } else if ((m = text.match(/^術後診斷：\s*(.+)$/))) {
        out.postop_diagnosis = m[1].trim();
      } else if ((m = text.match(/^手術開始日期：\s*(\d{8})\s+(\d{4})\s*$/))) {
        out.start_time = `${m[1].slice(0,4)}-${m[1].slice(4,6)}-${m[1].slice(6,8)}T${m[2].slice(0,2)}:${m[2].slice(2,4)}:00+08:00`;
      } else if ((m = text.match(/^手術結束日期：\s*(\d{8})\s+(\d{4})\s*$/))) {
        out.end_time = `${m[1].slice(0,4)}-${m[1].slice(4,6)}-${m[1].slice(6,8)}T${m[2].slice(0,2)}:${m[2].slice(2,4)}:00+08:00`;
      } else if ((m = text.match(/^ICD10\(代碼\)名稱[^：]+：\s*\[\s*([A-Z0-9]+)\s*\]\s*(.+?)\s*$/))) {
        // Empty ICD slots come through as "[ ]" — m[1] won't match [A-Z0-9]+ so
        // we naturally skip them. Real codes are alphanumeric (e.g. 0UJD8ZZ).
        out.icd10_codes = out.icd10_codes || [];
        out.icd10_codes.push({ code: m[1], display: m[2].trim() });
      } else if ((m = text.match(/^手術發現暨程序：\s*([\s\S]+)$/))) {
        out.operative_note = m[1].trim();
      } else if ((m = text.match(/^(?:主刀|術者|手術醫師)：\s*(.+)$/))) {
        out.surgeon = m[1].trim();
      } else if ((m = text.match(/^主治醫師：\s*(.+)$/))) {
        out.attending_physician = m[1].trim();
      } else if ((m = text.match(/^(?:助手|第一助手|第二助手)：\s*(.+)$/))) {
        out.assistants = out.assistants || [];
        if (m[1].trim() && m[1].trim() !== "-") out.assistants.push(m[1].trim());
      } else if ((m = text.match(/^麻醉醫師：\s*(.+)$/))) {
        out.anesthesiologists = out.anesthesiologists || [];
        if (m[1].trim() && m[1].trim() !== "-") out.anesthesiologists.push(m[1].trim());
      } else if ((m = text.match(/^麻醉(?:方式|方法|種類)?：\s*(.+)$/))) {
        out.anesthesia = m[1].trim();
      } else if ((m = text.match(/^手術科別：\s*(.+)$/))) {
        out.department = m[1].trim();
      } else if ((m = text.match(/^(?:來源|病房)：\s*(.+)$/))) {
        out.ward = m[1].trim();
      } else if ((m = text.match(/^傷口分類：\s*(.+)$/))) {
        out.wound_class = m[1].trim();
      } else if ((m = text.match(/^手術姿勢：\s*(.+)$/))) {
        out.position = m[1].trim();
      } else if ((m = text.match(/^消毒劑：\s*(.+)$/))) {
        out.disinfectant = m[1].trim();
      } else if ((m = text.match(/^關閉方式：\s*(.+)$/))) {
        out.closure = m[1].trim();
      } else if ((m = text.match(/^內視鏡：\s*(.+)$/))) {
        out.endoscope = m[1].trim();
      } else if ((m = text.match(/^再手術：\s*(.+)$/))) {
        out.reoperation = m[1].trim();
      }
    }
    return out;
  }

  // findOpn → #opnlist surgery list. Each <tr> is one operation DATE with
  // potentially multiple procedures concatenated in the second cell:
  //   "1.OBYN    FP005  HYSTEROSCOPY<br>2.OBYN    04015  D&C"
  // We split per <br>, then regex-extract (dept-code, procedure-code, name).
  // 主刀 cell looks like "何積泓               <br>DOC3525H" — name then ID.
  // Each numbered sub-procedure becomes its own FHIR Procedure resource so
  // the SMART app can show them individually rather than as one merged note.
  function parseOperationsList(doc) {
    const tbl = doc.querySelector("#opnlist");
    if (!tbl) return [];
    const out = [];
    for (const tr of tbl.querySelectorAll("tbody tr")) {
      const tds = [...tr.querySelectorAll("td")];
      if (tds.length < 3) continue;

      // td[0]: <a href='...&dt=01140814&...'>20250814</a> — visible text is
      // YYYYMMDD (AD), but the detail-page URL uses dt=01140814 (民國 with
      // century prefix). We capture both: `date` for the FHIR resource and
      // `_dt` for fetching the detail page later.
      const rawDate = stripTags(tds[0].outerHTML);
      if (!/^\d{8}$/.test(rawDate)) continue;
      const date = `${rawDate.slice(0,4)}-${rawDate.slice(4,6)}-${rawDate.slice(6,8)}`;
      const link = tds[0].querySelector("a[title='opndetail']");
      const dtMatch = link ? (link.getAttribute("href") || "").match(/dt=([^&]+)/) : null;
      const dtParam = dtMatch ? dtMatch[1] : "";

      // td[2]: "何積泓<br>DOC3525H" — name + qemr staff ID.
      const surgeonRaw = tds[2].innerHTML
        .replace(/&nbsp;/g, " ")
        .split(/<br\s*\/?>/i)
        .map(s => s.replace(/<[^>]+>/g, "").trim())
        .filter(Boolean);
      const surgeonName = surgeonRaw[0] || "";
      const surgeonId = surgeonRaw[1] || "";

      // td[1]: "1.OBYN    FP005  HYSTEROSCOPY<br>2.OBYN    04015  D&C"
      // Preserve &nbsp; → space, split on <br>, then regex-parse each segment.
      const procHtml = tds[1].innerHTML.replace(/&nbsp;/g, " ");
      const segments = procHtml.split(/<br\s*\/?>/i)
        .map(s => s.replace(/<[^>]+>/g, "").trim())
        .filter(Boolean);
      for (const seg of segments) {
        const m = seg.match(/^\d+\.\s*([A-Z][A-Z0-9_]*)\s+([A-Z0-9]+)\s+(.+)$/);
        if (!m) continue;
        const [, dept, code, name] = m;
        out.push({
          date,
          _dt: dtParam,  // for follow-up detail fetch in background.js
          code: code,
          system: "qemr.procedure",
          display: name.trim(),
          status: "completed",
          department: dept,
          surgeon: surgeonName,
          surgeon_id: surgeonId,
          // Mapper requires note OR body_site. Synthesize a one-line note so
          // each procedure carries dept + surgeon attribution.
          note: `[${dept}] ${name.trim()} — by ${surgeonName}${surgeonId ? ` (${surgeonId})` : ""}`,
        });
      }
    }
    return out;
  }

  // findRes detail URLs (with partno=X) return a fragment whose root is
  // #resdata — NO outer #resdetail wrapper (older qemr / dev-replay captures
  // had it, real prod doesn't). Fall back across both, then to the document
  // root so we never end up with a null `detail`.
  // The fragment may be:
  //   • Numeric lab: #RSCONTENT contains rows of 項目|H/L|結果|前次|單位|參考值
  //   • Narrative (microbiology / radiology / pathology): #RSCONTENT contains
  //     free-text 染色結果 / 培養結果 / impression rows; we emit a single
  //     DiagnosticReport with the full text as `conclusion`.
  function parseObservationsDetail(doc, opts) {
    const detail =
      doc.querySelector("#resdata") ||
      doc.querySelector("#resdetail") ||
      doc.body ||
      doc.documentElement;
    if (!detail) return { observations: [], diagnostic_reports: [] };

    // Pull metadata from every label/value pair in a row. qemr places a
    // second pair at td[3..5] (label/date/time), which the old td[0]/td[1]
    // parser missed entirely.
    const meta = {};
    const setDateTime = (key, parts) => {
      const joined = parts.filter(Boolean).join(" ");
      const m = joined.match(/(\d{4})\/(\d{2})\/(\d{2})(?:\s+(\d{2}):(\d{2}))?/);
      if (!m) return;
      if (key === 'reported_at' && (!m[4] || !m[5])) { meta[key] = `${m[1]}-${m[2]}-${m[3]}`; return; }
      meta[key] = `${m[1]}-${m[2]}-${m[3]}T${m[4] || "00"}:${m[5] || "00"}:00+08:00`;
    };
    for (const tr of detail.querySelectorAll("tr")) {
      const tds = [...tr.cells];
      if (tds.length < 2) continue;
      for (let i = 0; i < tds.length - 1; i++) {
        if (tds[i].querySelector("table, #RSCONTENT")) continue;
        const labelRaw = tds[i].textContent.replace(/\s+/g, " ").trim();
        if (!labelRaw) continue;
        const value = tds[i + 1].textContent.replace(/\s+/g, " ").trim();
        if (/醫囑名稱/.test(labelRaw)) meta.order_name = value;
        else if (/申請序號/.test(labelRaw)) {
          const ids = value.split("/").map((v) => v.trim()).filter(Boolean);
          meta.request_no = ids[0] || "";
          meta.work_no = ids[1] || "";
        } else if (/開立時間/.test(labelRaw)) setDateTime("requested_at", [value, stripTags(tds[i + 2]?.outerHTML || "")]);
        else if (/收件時間|簽收時間/.test(labelRaw)) setDateTime("received_at", [value, stripTags(tds[i + 2]?.outerHTML || "")]);
        else if (/報告時間/.test(labelRaw)) setDateTime("reported_at", [value, stripTags(tds[i + 2]?.outerHTML || "")]);
        else if (/開立醫師|申請醫師|開醫囑者/.test(labelRaw)) meta.requesting_physician = value;
        else if (/報告人|報告醫師/.test(labelRaw)) meta.reporter = value;
        else if (/判讀醫師/.test(labelRaw)) meta.interpreting_physician = value;
        else if (/操作醫師/.test(labelRaw)) meta.operating_physician = value;
        else if (/檢體|specimen/i.test(labelRaw)) meta.specimen = value;
      }
    }
    meta.order_code = (opts && opts.hospital_order_code) || "";
    meta.request_no = meta.request_no || (opts && opts.request_no) || "";
    // The cumulative matrix is indexed by receipt time, not order creation.
    // Orders can be placed several days before the specimen is received.
    const effective = meta.received_at || meta.reported_at || meta.requested_at || "";
    const issued = /T\d{2}:\d{2}/.test(meta.reported_at || '') ? meta.reported_at : '';
    // The catalog publication day is scope evidence, not a clinical event time.
    meta.date = effective.slice(0, 10);

    const rsContent = detail.querySelector("#RSCONTENT");
    const observations = [];
    const cellText = cell => (cell?.textContent || "").replace(/\s+/g, " ").trim();
    // Defense for staff footers embedded in the same table as real results.
    // Match a whole field label; a result comment mentioning a doctor is valid.
    const isStaffLabel = text => {
      const label = text.replace(/\([^)]*\)|（[^）]*）/g, "").replace(/\s+/g, "");
      return /^(?:[\p{Script=Han}]{0,8}醫師[一二三四五六七八九十〇零\d０-９]*|報告人|醫檢師|技術員|技術師|檢驗師|護理師|開醫囑者)[:：]?$/u.test(label)
        || /^(?:(?:reporting|interpreting|performing|executing|supervising|attending|requesting)?(?:physician|doctor)(?:one|two|\d*)|reporter|technician)[:：]?$/i.test(label);
    };
    const tableLayouts = new WeakMap();
    const labLayout = table => {
      if (!table) return null;
      if (tableLayouts.has(table)) return tableLayouts.get(table);
      let layout = null;
      for (const row of table.rows) {
        const headers = [...row.cells].map(cell => cellText(cell).replace(/[：:]/g, "").trim());
        const find = pattern => headers.findIndex(text => pattern.test(text));
        const result = find(/^(?:結果|檢驗結果|Result)$/i);
        const unit = find(/^(?:單位|Unit)$/i);
        const item = find(/^(?:項目|項目名稱|檢驗項目|檢驗名稱|Item|Test)$/i);
        const flag = find(/^(?:H\s*\/\s*L|HL|Flag)$/i);
        const range = find(/^(?:參考值|參考區間|Reference(?: Range)?)$/i);
        if (result >= 0 && unit >= 0 && (item >= 0 || flag >= 0 || range >= 0)) {
          layout = { header: row, width: headers.length, result, unit, item, flag, range };
          break;
        }
      }
      tableLayouts.set(table, layout);
      return layout;
    };
    if (rsContent) {
      for (const tr of rsContent.querySelectorAll("tr")) {
        // Six cells alone cannot identify a result: physician/technician
        // footers also contain three label/value pairs. Accept rows only
        // from a table with a recognizable laboratory column header.
        const layout = labLayout(tr.closest("table"));
        if (!layout || tr === layout.header) continue;
        const tds = [...tr.cells];
        if (tds.length !== layout.width || tds.some(td => td.colSpan > 1 || td.querySelector("table"))) continue;
        const texts = tds.map(cellText);
        const display = layout.item >= 0 ? texts[layout.item] : (meta.order_name || "").replace(/,\s*$/, "");
        if (!display) continue;
        const flag = layout.flag >= 0 ? texts[layout.flag].toLowerCase() : "";
        const value = texts[layout.result];
        if (!value) continue; // require a result value
        if (isStaffLabel(display) || isStaffLabel(value)) continue;
        const unit = texts[layout.unit];
        const ref = layout.range >= 0 ? texts[layout.range] : "";
        const interp = flag === "h" ? "high" : flag === "l" ? "low" : flag === "n" ? "normal" : "";
        observations.push({
          date: meta.date || "",
          order_code: meta.order_code || "",
          order_name: meta.order_name || "",
          code: display,
          display,
          value,
          unit,
          reference_range: ref,
          interpretation: interp,
          effective_datetime: effective,
          requested_at: meta.requested_at || "",
          requesting_physician: meta.requesting_physician || "",
          received_at: meta.received_at || "",
          issued,
          reported_at: meta.reported_at || "",
          specimen: meta.specimen || "",
          reporter: meta.reporter || "",
          interpreting_physician: meta.interpreting_physician || "",
          request_no: meta.request_no || "",
          work_no: meta.work_no || "",
          hospital: "臺北榮民總醫院",
        });
      }
    }

    // Single-test qualitative results (e.g. HCG/COVID) use labelled cells,
    // rather than the multi-analyte result-column layout.
    if (rsContent && observations.length === 0) {
      const scalarLabel = pattern => {
        for (const cell of rsContent.querySelectorAll("td")) {
          if (cell.querySelector?.("table")) continue;
          const match = cellText(cell).match(pattern);
          if (!match) continue;
          if (match[1]) return match[1].trim();
          const next = cell.parentElement?.nextElementSibling;
          const nextText = next?.cells?.length === 1 ? cellText(next.cells[0]) : "";
          // Never use the next field's label as the current field's value.
          return /[:：]/.test(nextText) ? "" : nextText;
        }
        return "";
      };
      const value = scalarLabel(/^結果\s*[:：]\s*(.*)$/);
      if (value) {
        const display = (meta.order_name || "Laboratory result").replace(/,\s*$/, "");
        const flag = scalarLabel(/^H\s*\/\s*L\s*[:：]\s*(.*)$/i).toLowerCase();
        const unit = scalarLabel(/^單位\s*[:：]\s*(.*)$/);
        observations.push({
          ...meta, display, code: display, value,
          unit: /^N\/A$/i.test(unit) ? "" : unit,
          reference_range: scalarLabel(/^參考值\s*[:：]\s*(.*)$/),
          interpretation: flag === "h" ? "high" : flag === "l" ? "low" : flag === "n" ? "normal" : "",
          effective_datetime: effective, issued,
          hospital: "臺北榮民總醫院",
        });
      }
    }

    // Narrative report: if #RSCONTENT didn't yield any result rows but the
    // detail has text content (e.g. CT findings, pathology impression), emit
    // a DiagnosticReport.
    const diagnostic_reports = [];
    const procedures = [];
    let narrativeContent = rsContent;
    if (rsContent?.cloneNode) {
      narrativeContent = rsContent.cloneNode(true);
      for (const row of narrativeContent.querySelectorAll("tr")) {
        const cells = [...row.cells];
        if (!cells.length || cells.some(cell => cell.querySelector("table"))) continue;
        if (isStaffLabel(cellText(cells[0]))) row.remove();
      }
    }
    const text = (narrativeContent?.innerText || narrativeContent?.textContent || "")
      .replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
    const namedVaginalUltrasound = /^(?:trans[- ]?vaginal|vaginal)\s+(?:ultrasound|ultrasonography|sonography)(?:\s+(?:report|examination|exam|study))?$/i.test((meta.order_name || "").trim().replace(/[,，]\s*$/, ""));
    if (observations.length === 0 && text && !/^(?:此查詢範圍無資料|尚未提供|無資料)$/.test(text)) {
      const heading = detail.querySelector("legend, h1, h2, h3, caption")?.textContent || "";
      const header = (heading || detail.textContent || "").slice(0, 1000);
      // For this explicit imaging name, recommendations in the narrative do not
      // identify the report. An explicit pathology/cardiology heading still wins.
      const context = namedVaginalUltrasound ? `${heading} ${meta.order_name}` : `${header} ${meta.order_name || ""} ${text.slice(0, 500)}`;
      const category = /病理|patholog|cytolog|smear|surgical specimen/i.test(context) ? "PATH"
        : /心電圖|心臟超音波|electrocardi|\bECG\b|\bEKG\b|echocardi/i.test(context) ? "CAR"
          : namedVaginalUltrasound
            || /影像診療|放射|radiolog|\bCT\b|\bMRI\b|超音波|X-?ray|sonogram|mammograph|scan|\bCHEST\s+(?:PA|AP)\b/i.test(context) ? "RAD" : "LAB";
      diagnostic_reports.push({
        order_code: meta.order_code || "",
        requested_at: meta.requested_at || "",
        date: meta.date || "",
        effective_datetime: effective,
        received_at: meta.received_at || "",
        issued,
        reported_at: meta.reported_at || "",
        display: meta.order_name || "Diagnostic Report",
        code: meta.order_code || meta.order_name || "report",
        category,
        conclusion: text,
        request_no: meta.request_no || "",
        work_no: meta.work_no || "",
        specimen: meta.specimen || "",
        requesting_physician: meta.requesting_physician || "",
        reporter: meta.reporter || "",
        interpreting_physician: meta.interpreting_physician || "",
      });
    }

    // Procedural reports (drainage, biopsy, endoscopy, paracentesis, ...) come
    // through the same findRes detail URL as labs/imaging. Detect by keyword
    // in 醫囑名稱 or in the narrative; emit a Procedure in addition to the DR
    // so the SMART app can see the procedure list separately. Mapper requires
    // either `note` or `body_site` — we provide both (specimen → body_site).
    const PROC_RX = /手術|引流|切片|抽吸|穿刺|導管|內視鏡|大腸鏡|胃鏡|結紮|切除|drainage|biopsy|aspiration|paracentesis|catheter|endoscop|ercp|lithotripsy|ligation|excision|ablation/i;
    // Recommendations in an explicitly named ultrasound are not procedures.
    if (!namedVaginalUltrasound && (PROC_RX.test(meta.order_name || "") || PROC_RX.test(text.slice(0, 800)))) {
      procedures.push({
        date: meta.date || "",
        display: meta.order_name || "Procedure",
        code: meta.order_code || "procedure",
        note: text,
        body_site: meta.specimen || "",
      });
    }

    for (const item of [...observations, ...diagnostic_reports]) Object.assign(item, {
      report_case_no: opts?.report_case_no || "", report_sequence: opts?.report_sequence || "",
      source_report_date: /^\d{4}-\d{2}-\d{2}$/.test(opts?.source_report_date || "") ? opts.source_report_date : "",
    });
    if (opts?.encounter_class === "EMER" && opts.case_no && opts.encounter_ref_date) {
      for (const item of [...observations, ...diagnostic_reports, ...procedures]) Object.assign(item, {
        case_no: opts.case_no, encounter_class: "EMER", encounter_ref_date: opts.encounter_ref_date,
      });
    }
    return { observations, diagnostic_reports, procedures };
  }

  // findResd query page → the two dropdowns that drive the cumulative-lab
  // matrix. Returns the option lists so the SW can enumerate what to fetch.
  //   resdtmonth <option value> = a FULL URL prefix
  //     ("/emr/qemr/qemr.cfm?action=findResd…&resdtmonth=NN")
  //   resdtype  <option value> = a "&resdtype=DXXX" fragment
  // Actual request = tmonthValue + typeValue + "&histno=" + histno.
  // We DON'T reconstruct the query ourselves — qemr's option values already
  // encode it (verified: the value is 64+ chars incl. the action + a session
  // fragment), so we pass them through verbatim.
  function parseCumulativeIndex(doc) {
    const pick = (sel) => {
      const el = doc.querySelector(sel);
      if (!el) return [];
      return [...el.options].map((o) => ({ v: o.value, t: (o.textContent || "").trim() }));
    };
    return {
      months: pick("#resdtmonth, select[name=resdtmonth]"),
      types: pick("#resdtype, select[name=resdtype]"),
    };
  }

  // findResd result → #resdtable pivot matrix. First row = header
  // (日期 + analyte abbreviations); each following row is one blood-draw
  // timestamp with a value per analyte column. The LAST row is qemr's
  // aggregated "date/value|date/value|…" summary (first cell "-") — skipped.
  //
  // Abnormality is encoded ONLY as inline CSS on the value cell
  // (style="color:red" → abnormal; background-color:FFFF99 → flagged). There
  // is NO H/L column, so we can only emit a boolean `abnormal` (see
  // docs/LOINC-NHI-vs-HIS.md §4). `panel` comes from the caller (the
  // resdtype option label, e.g. "(累積)CBC").
  function parseObservationsCumulative(doc, panelLabel) {
    const tbl = doc.querySelector("#resdtable");
    if (!tbl || tbl.rows.length < 2) return [];
    const headers = [...tbl.rows[0].cells].map((c) => (c.textContent || "").trim());
    const out = [];
    for (let r = 1; r < tbl.rows.length; r++) {
      const row = tbl.rows[r];
      const cells = [...row.cells];
      if (!cells.length) continue;
      const dt = (cells[0].textContent || "").trim();
      // Skip the aggregated summary row and any non-datetime leading cell.
      if (!/^\d{2}-\d{2}-\d{2}/.test(dt)) continue;
      for (let c = 1; c < cells.length; c++) {
        const abbrev = headers[c] || "";
        if (!abbrev || abbrev === "日期" || abbrev === "檢體") continue;
        const cell = cells[c];
        const value = (cell.textContent || "").trim();
        if (!value || ["-", "—"].includes(value)) continue;
        const style = (cell.getAttribute("style") || "").toLowerCase();
        // Yellow is alternating column shading. Only red foreground means
        // abnormal; matching "color" must not match "background-color".
        const abnormal = /(?:^|;)\s*color:\s*(?:red|#ff0000|rgb\(\s*255\s*,\s*0\s*,\s*0\s*\))(?:\s*;|\s*$)/.test(style);
        out.push({
          panel: panelLabel || "",
          datetime: dt,
          abbrev,
          value,
          abnormal,
          specimen: cells[headers.indexOf("檢體")]?.textContent.trim() || "",
          hospital: "臺北榮民總醫院",
        });
      }
    }
    return out;
  }

  // 出院病摘 (#dislist) / 入院病摘 (#admlist) — enumerate the detail links plus
  // per-row metadata. dislist row date cell is two concatenated dates
  // "2025/12/192025/12/30" (住院/離院); admlist is a single YYYYMMDD 住院日期.
  // Detail URLs carry caseno + (admdt|adidate) — we pass the href verbatim
  // (the two summary types use different date param names).
  // Normalize the many qemr date spellings to ISO YYYY-MM-DD:
  //   "2025/12/19", "20251219", "2025-12-19", "2026-05-07 17:36:52" → 2025-12-19
  function toIsoDate(s) {
    const m = (s || "").trim().match(/^(\d{3,4})[/-]?(\d{2})[/-]?(\d{2})(?=$|[^\d])/);
    if (!m) return "";
    let year = Number(m[1]);
    if (m[1].length === 3 || (m[1].startsWith("0") && year < 300)) year += 1911;
    const date = new Date(Date.UTC(year, Number(m[2]) - 1, Number(m[3])));
    return date.getUTCFullYear() === year && date.getUTCMonth() === Number(m[2]) - 1 && date.getUTCDate() === Number(m[3])
      ? `${year}-${m[2]}-${m[3]}` : "";
  }
  function parseSummaryList(doc, docType) {
    const tbl = doc.querySelector(docType === "discharge" ? "#dislist" : "#admlist");
    if (!tbl) return [];
    const out = [];
    for (const tr of tbl.querySelectorAll("tr")) {
      const a = tr.querySelector('a[href*="caseno"]');
      if (!a) continue;
      const cells = [...tr.querySelectorAll("td")].map((td) => td.textContent.trim());
      if (!cells.length) continue;
      const href = (a.getAttribute("href") || "").replace(/&amp;/g, "&");
      if (!href || href.startsWith("javascript")) continue;
      let admit = "", discharge = "";
      const dates = (cells[0] || "").match(/\d{4}[-/]?\d{2}[-/]?\d{2}/g) || [];
      admit = toIsoDate(dates[0] || "");
      discharge = toIsoDate(dates[1] || cells[1] || "");
      out.push({
        href, doc_type: docType,
        admit_date: admit, discharge_date: discharge,
        department: (cells[1] || "").split("/")[0].trim(),
      });
    }
    return out;
  }

  // 出院/入院病摘 detail → verbatim HTML for a DocumentReference. Content lives
  // in a single <fieldset> ("[出院病摘內容]"). We keep the outerHTML faithfully
  // (like NHI's document-reference transport) — no sanitising/truncation. Row
  // metadata (dates/dept) arrives via opts from the list parse; the encounter
  // link uses the ADMIT date so it matches the inpatient Encounter's stable id
  // (_stable_id(pid, admit_date, "IMP")).
  function parseSummaryDetail(doc, opts) {
    const meta = opts || {};
    const fs = doc.querySelector("fieldset") || doc.body || doc.documentElement;
    const html = fs ? fs.outerHTML : "";
    if (!html || html.replace(/<[^>]+>/g, "").trim().length < 40) return [];
    const text = (doc.body ? doc.body.textContent : "") || "";
    let physician = "";
    const pm = text.match(/主治醫師[:：]?\s*([^\s，,、（(）)0-9]{2,10})/);
    if (pm) physician = pm[1].trim();
    const docType = meta.doc_type || "discharge";
    const date = docType === "discharge"
      ? (meta.discharge_date || meta.admit_date || "")
      : (meta.admit_date || "");
    return [{
      doc_type: docType,
      date,
      admit_date: meta.admit_date || "",
      discharge_date: meta.discharge_date || "",
      department: meta.department || "",
      physician,
      encounter_ref_date: meta.admit_date || "",
      html,
    }];
  }

  // findImplant → 人工植入物清單 (#pdigaslist). Columns: 日期 | 科別 |
  // 醫材名稱(中文) | 醫材名稱(英文) | 規格 | 數量 | 廠牌 | 側別 | 部位.
  // One FHIR Device per row (e.g. PORT-A implantable vascular access).
  function parseImplants(doc) {
    const tbl = doc.querySelector("#pdigaslist") ||
      [...doc.querySelectorAll("table")].sort((a, b) => b.rows.length - a.rows.length)[0];
    if (!tbl) return [];
    const out = [];
    for (const tr of tbl.querySelectorAll("tr")) {
      const cells = [...tr.querySelectorAll("td")].map((td) => td.textContent.replace(/\s+/g, " ").trim());
      if (cells.length < 4) continue;
      if (!/^\d{6,8}$/.test(cells[0])) continue; // skip header / non-date rows
      out.push({
        date: toIsoDate(cells[0]),
        department: cells[1] || "",
        name_zh: cells[2] || "",
        name_en: cells[3] || "",
        spec: cells[4] || "",
        quantity: cells[5] || "",
        manufacturer: cells[6] || "",
        side: cells[7] || "",
        body_site: cells[8] || "",
      });
    }
    return out;
  }

  // findVts 生命徵象 query page → the two dropdowns (pbvdt = 就醫紀錄,
  // pbvtype = 量測類型). Same option-value-is-a-URL-fragment scheme as
  // findResd: request = pbvdt.value + pbvtype.value + "&histno=".
  //   pbvtype: HWS 身高體重 / BPP 血壓脈搏 / TMP 體溫 / RSP 呼吸 /
  //            OXY 血氧濃度 / BDS 血糖 / NYHA
  function parseVitalsIndex(doc) {
    const pick = (sel) => {
      const el = doc.querySelector(sel);
      return el ? [...el.options].map((o) => ({ v: o.value, t: (o.textContent || "").trim() })) : [];
    };
    const seenUrls = new Set();
    const dates = pick("#pbvdt, select[name=pbvdt]").filter((option) => {
      let caseNo;
      try { caseNo = [...new URL(option.v.startsWith("&") ? `?${option.v.slice(1)}` : option.v, "https://qemr.invalid").searchParams].find(([key]) => key.toLowerCase() === "caseno")?.[1]; }
      catch { return false; }
      // The aggregate option repeats every encounter's later measurements.
      // Keep distinct case numbers, even when two visits share a date.
      // Deduplicate exact URLs here; case/type deduplication follows URL trust
      // validation in the worker so an invalid first option cannot win.
      // Keep dated but unbound options so the worker can report incomplete
      // coverage instead of silently treating them as an empty vital list.
      if (!caseNo) return /\d{4}[-/]?\d{2}[-/]?\d{2}/.test(option.t);
      if (caseNo.toLowerCase() === "all" || seenUrls.has(option.v)) return false;
      seenUrls.add(option.v);
      return true;
    });
    return {
      dates,
      types: pick("#pbvtype, select[name=pbvtype]"),
    };
  }

  // findVts result table (one encounter + type) → its earliest reading only.
  // Table header starts with 日期時間; columns depend on the type. Datetime is
  // "YYYYMMDD  HH:MM[:SS]". "無…資料!!" placeholder rows are skipped (no date).
  function vitalsDateToIso(s) {
    const m = (s || "").match(/^(\d{4})(\d{2})(\d{2})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (!m) return "";
    const [, y, mo, d, hh, mi, ss] = m;
    const day = new Date(Date.UTC(Number(y), Number(mo) - 1, Number(d)));
    if (day.getUTCFullYear() !== Number(y) || day.getUTCMonth() + 1 !== Number(mo) || day.getUTCDate() !== Number(d)
        || Number(hh) > 23 || Number(mi) > 59 || Number(ss || 0) > 59) return "";
    return `${y}-${mo}-${d}T${hh.padStart(2, "0")}:${mi}:${ss || "00"}+08:00`;
  }
  function parseVitals(doc, type, range, withParseStatus = false) {
    let incomplete = false;
    let knownEmpty = false;
    const emptyReading = text => /^無(?:血壓|脈搏|血壓脈搏|體溫|呼吸|血氧|血氧濃度|血糖|身高體重|身高|體重|生命徵象|NYHA)?(?:量測)?資料[!！。.\s]*$/i.test(text.trim());
    const finish = (items, parseStatus) => withParseStatus ? {items,parseStatus,incomplete} : items;
    // A wrapper table's nested textContent also matches 日期時間, so pick the
    // LARGEST matching table (the actual data grid, ~dozens of rows) not the
    // first (which may be the 1-row wrapper).
    const tbl = [...doc.querySelectorAll("table")]
      .filter((t) => t.rows[0] && /日期時間/.test(t.rows[0].cells[0]?.textContent || ""))
      .sort((a, b) => b.rows.length - a.rows.length)[0];
    if (!tbl) return finish([],emptyReading(doc.body?.textContent || doc.documentElement?.textContent || "") ? "empty" : "invalid");
    let first = null;
    const candidates = [];
    let sourceRows = 0;
    for (let r = 1; r < tbl.rows.length; r++) {
      const cells = [...tbl.rows[r].cells].map((c) => c.textContent.replace(/\s+/g, " ").trim());
      const iso = vitalsDateToIso(cells[0] || "");
      if (!iso) {
        const text=cells.join(" ").trim();
        // Only explicitly empty/header/no-data rows are known omissions.
        if (emptyReading(text)) knownEmpty = true;
        else if (text && !/^日期\s*時間/.test(cells[0] || "")) incomplete = true;
        continue;
      }
      sourceRows++;
      if (range?.start && (iso.slice(0, 10) < range.start || iso.slice(0, 10) > range.end)) continue;
      const item = { type, datetime: iso };
      if (type === "BPP") { item.bp = cells[1] || ""; item.pulse = cells[2] || ""; }
      else if (type === "TMP") { item.temp = cells[1] || ""; }
      else if (type === "RSP") { item.rr = cells[1] || ""; }
      else if (type === "OXY") { item.spo2 = cells[1] || ""; item.o2flow = cells[2] || ""; item.device = cells[3] || ""; }
      else if (type === "HWS") { item.height = cells[1] || ""; item.weight = cells[2] || ""; item.bsa = cells[3] || ""; item.bmi = cells[4] || ""; }
      else if (type === "BDS") { item.glucose = cells[1] || ""; }
      else if (type === "NYHA") { item.nyha = cells[1] || ""; }
      candidates.push(item);
      // Tables may run newest-first. Compare timestamps rather than taking
      // the first displayed row; retain every value on the selected row.
      if (!first || item.datetime < first.datetime) first = item;
    }
    // The worker checks candidates with the actual mapper before selecting
    // its earliest usable row; legacy callers retain the first-row shape.
    return finish(withParseStatus ? candidates : first ? [first] : [], sourceRows ? "parsed" : knownEmpty ? "empty" : "invalid");
  }

  // findChem 化癌治療計畫清單 → one detail link per chemo cycle (anchor text is
  // the cycle date "2025-06-07"; href carries caseno + dt). Returns [{href,date}]
  // for the SW to fetch each regimen detail.
  function parseChemoList(doc) {
    const out = [];
    for (const a of doc.querySelectorAll('a[href*="caseno"]')) {
      const href = (a.getAttribute("href") || "").replace(/&amp;/g, "&");
      if (!href || href.startsWith("javascript")) continue;
      const dt = (href.match(/[?&]dt=([^&]+)/) || [])[1] || "";
      const date = toIsoDate(a.textContent.trim()) || toIsoDate(dt);
      out.push({ href, date });
    }
    return out;
  }

  // findChem detail = a chemotherapy REGIMEN (drug table). Rather than fragile
  // per-drug parsing, keep the regimen text verbatim as the Procedure's note —
  // the key clinical fact (chemo given on date X, this regimen) is preserved.
  // Emits a procedure-shaped item so it reuses the existing procedure mapper.
  function parseChemoDetail(doc, opts) {
    const meta = opts || {};
    const root = doc.querySelector("fieldset") || doc.body || doc.documentElement;
    const text = (root ? (root.innerText || root.textContent) : "").replace(/\n{3,}/g, "\n\n").trim();
    if (!text || text.length < 20) return [];
    return [{
      date: meta.date || "",
      code: "367336001",
      system: "snomed",
      display: "化學治療 (Chemotherapy)",
      status: "completed",
      note: text,
    }];
  }

  // findPbc 癌症治療計畫書清單 → CarePlan items. Columns:
  //   內容 | ICD9 | MDT | 療程別 | 版本別 | 主責醫師 | 計畫書起草日期 |
  //   預計治療開始日 | 預計治療結束日 | 計畫書定版日期 | 計畫書初次定版日
  // Dates are YYYYMMDD. Structured — no detail fetch (內容 is an RTF export).
  function parseCancerPlans(doc) {
    const tbl = [...doc.querySelectorAll("table")]
      .filter((t) => /療程別|ICD9/.test(t.rows[0]?.textContent || ""))
      .sort((a, b) => b.rows.length - a.rows.length)[0];
    if (!tbl) return [];
    const out = [];
    for (let r = 1; r < tbl.rows.length; r++) {
      const c = [...tbl.rows[r].cells].map((x) => x.textContent.replace(/\s+/g, " ").trim());
      if (c.length < 10) continue;
      const item = {
        icd9: c[1] || "", mdt: c[2] || "", course: c[3] || "", version: c[4] || "",
        physician: c[5] || "",
        draft_date: toIsoDate(c[6] || ""), start_date: toIsoDate(c[7] || ""),
        end_date: toIsoDate(c[8] || ""), finalize_date: toIsoDate(c[9] || ""),
        first_finalize_date: toIsoDate(c[10] || ""),
      };
      // Skip fully-empty rows (placeholder/footer).
      if (!item.course && !item.start_date && !item.finalize_date && !item.icd9) continue;
      out.push(item);
    }
    return out;
  }

  // Master dispatcher. pageType matches the backend's page_type strings.
  // For page types that produce items, returns either an array or an
  // object with multiple item arrays (observations_detail case).
  window.__vghParse = function __vghParse(pageType, html, opts) {
    const doc = parseDoc(html);
    const histno = (opts && opts.histno) || "";
    switch (pageType) {
      case "order_index":
        return parseOrderIndex(doc);
      case "record_index":
        return parseRecordIndex(doc, opts || {});
      case "patient_info":
        return [parsePatientFromNavbar(doc, histno)];
      case "patient_info_findpba":
        return [parsePatientFromFindPba(doc)];
      case "allergies":
        return parseAllergies(doc);
      case "conditions":
        return parseConditions(doc);
      case "inpatient_diagnoses_index":
        return parseInpatientDiagnosisIndex(doc);
      case "inpatient_diagnoses":
        return parseInpatientDiagnoses(doc, opts);
      case "encounters_list":
        return parseEncountersList(doc);
      case "encounter_detail":
        return parseEncounterDetail(doc, opts);
      case "outpatient_detail":
        return parseOutpatientDetail(doc, opts);
      case "emergency_list":
        return parseEmergencyList(doc);
      case "emergency_detail":
        return parseEmergencyDetail(doc, opts);
      case "medications_detail":
        return parseMedicationsDetail(doc, opts && opts.date);
      case "medication_note_detail":
        return parseMedicationNoteDetail(doc);
      case "operations_list":
        return parseOperationsList(doc);
      case "operations_detail":
        return parseOperationsDetail(doc);
      case "observations_detail":
        return parseObservationsDetail(doc, opts || {});
      case "observations_cumulative_index":
        return parseCumulativeIndex(doc);
      case "observations_cumulative":
        return parseObservationsCumulative(doc, opts && opts.panel);
      case "summary_list":
        return parseSummaryList(doc, (opts && opts.doc_type) || "discharge");
      case "summary_detail":
        return parseSummaryDetail(doc, opts);
      case "implants":
        return parseImplants(doc);
      case "vitals_index":
        return parseVitalsIndex(doc);
      case "vitals":
        return parseVitals(doc, (opts && opts.type) || "", opts && opts.recordRange, opts && opts.withParseStatus);
      case "chemo_list":
        return parseChemoList(doc);
      case "chemo_detail":
        return parseChemoDetail(doc, opts);
      case "careplans":
        return parseCancerPlans(doc);
      default:
        return [];
    }
  };
  window.__vghParse.parserVersion = parserVersion;
})();
