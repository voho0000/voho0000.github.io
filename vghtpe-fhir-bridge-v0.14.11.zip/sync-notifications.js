const BASE_TITLE = "EHR-FHIR Bridge";

export function hasUnreadSyncCompletion(status) {
  return !!status && !status.running && ["done", "partial"].includes(status.phase)
    && status.completionSeen !== true;
}

export function syncActionPresentation(status) {
  if (status?.running) return { text: "…", color: "#2563eb", title: `${BASE_TITLE}：正在取得資料` };
  if (hasUnreadSyncCompletion(status)) return {
    text: "●", color: "#dc2626",
    title: `${BASE_TITLE}：${status.phase === "partial" ? "部分資料取得完成" : "取得完成"}，開啟查看結果`,
  };
  if (["error", "interrupted"].includes(status?.phase)) return { text: "!", color: "#b91c1c", title: `${BASE_TITLE}：取得未完成，開啟查看原因` };
  return { text: "", color: "#2563eb", title: BASE_TITLE };
}

export function completionMatches(status, { histno, started, completed } = {}) {
  return hasUnreadSyncCompletion(status) && status.histno === histno
    && status.started === started && status.completed === completed;
}

// Badge failures cannot delay capture. Serialize the few visible transitions
// so a late Chrome response for "running" cannot overwrite the completion dot.
export function createSyncActionUpdater(action) {
  let queue = Promise.resolve();
  let previous = "";
  return (status) => {
    const presentation = syncActionPresentation(status);
    const key = JSON.stringify(presentation);
    if (key === previous || !action?.setBadgeText) return queue;
    previous = key;
    queue = queue.then(async () => {
      let timer;
      try {
        await Promise.race([
          Promise.allSettled([
            Promise.resolve().then(() => action.setBadgeBackgroundColor?.({ color: presentation.color })),
            Promise.resolve().then(() => action.setBadgeText({ text: presentation.text })),
            Promise.resolve().then(() => action.setTitle?.({ title: presentation.title })),
          ]),
          new Promise((resolve) => { timer = setTimeout(resolve, 1_000); }),
        ]);
      } finally { clearTimeout(timer); }
    }).catch(() => {});
    return queue;
  };
}
