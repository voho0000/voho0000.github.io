// REQNO is the report occurrence key; SOAP billing codes can be split across
// a single laboratory request. Resolve the bridge through the HIS order index.
import { isOutpatientSupply, outpatientOrderReviewCounts } from "./outpatient-order.js";
const clean = value => String(value || "").normalize("NFKC").replace(/\s+/g, "").toUpperCase();
const doctor = value => clean(value).replace(/\(DOC[A-Z0-9]+\)$/, "");
const tokens = value => clean(value).split(/[,，]/).filter(Boolean);
// HIS uses both blank and '-' for an unspecified specimen. Neither matches a
// specified specimen, and date/doctor/name/uniqueness checks still apply.
const specimen = value => clean(value) === "-" ? "" : clean(value);

export const unlinkedOutpatientOrders = orders => orders.filter(order => !isOutpatientSupply(order) && !order.request_no);

export function outpatientReportIdentity(link) {
  const url = new URL(link.href);
  const ids = ['caseno','reqno','ordseq'].map(key=>url.searchParams.get(key));
  return ids.every(Boolean) ? JSON.stringify([url.origin,url.pathname,...ids]) : url.href;
}

// The rolling and annual catalogs can link to the same report with different
// list filters. Keep every other query parameter and catalog date so versions
// or genuinely different requests are never collapsed.
export function uniqueOutpatientReportLinks(links) {
  return [...new Map(links.map(link => {
    const url = new URL(link.href);
    if (["caseno", "reqno", "ordseq"].every(key => url.searchParams.get(key))) {
      // Compare raw query values: old HIS description bytes may be Big5.
      url.search = url.search.slice(1).split('&').filter(part => !/^(?:tmonth|tdept)=/i.test(part)).sort().join('&');
    }
    return [JSON.stringify([url.href, link.report_date || "", link.updated_date || ""]), link];
  })).values()];
}

export function bindOutpatientRequests(orders, index, warnings = []) {
  const proposals = orders.filter(order => !isOutpatientSupply(order)).map(order => {
    const names = tokens(order.display);
    const matches = index.filter(row => row.request_no && row.date === order.date
      && doctor(row.provider) === doctor(order.provider) && doctor(order.provider)
      && specimen(row.specimen) === specimen(order.specimen)
      && names.length && names.every(name => tokens(row.display).includes(name)));
    return { order, matches };
  });
  for (const { order, matches } of proposals) {
    if (matches.length !== 1) continue;
    const row = matches[0];
    // Two identical SOAP orders cannot both claim a single request component.
    if (proposals.some(p => p.order !== order && p.matches.includes(row)
      && tokens(p.order.display).some(name => tokens(order.display).includes(name)))) continue;
    order.request_no = row.request_no;
    order.requested_at = row.requested_at;
    order.request_case_no = row.case_no;
    order.request_sequence = row.sequence;
  }
  // The report list is filtered by bound request numbers. If binding was
  // ambiguous or impossible, historical report coverage is unknown, even
  // when all fetched pages parsed successfully. This does not prove that a
  // report exists or that the examination has been performed.
  const unbound = unlinkedOutpatientOrders(orders);
  if (unbound.length) {
    const counts = outpatientOrderReviewCounts(unbound);
    const kinds = [["預約醫囑", counts.appointments], ["處置醫囑", counts.procedures], ["其他醫囑", counts.other]]
      .filter(([, count]) => count).map(([label, count]) => `${label} ${count} 筆`).join("、");
    warnings.push(`有 ${unbound.length} 筆門診醫囑未能唯一對應申請序號，無法確認其報告涵蓋範圍；不代表未執行或沒有結果。待核對：${kinds}。以上是醫囑筆數，不是漏抓報告份數；處置不一定產生獨立報告。`);
  }
  return orders;
}

export function matchOutpatientReport(report, orders) {
  const request = clean(report.request_no);
  if (!request) return null;
  const matches = orders.filter(order => clean(order.request_no) === request
    && (!order.request_case_no || order.request_case_no === report.report_case_no)
    && (!order.request_sequence || order.request_sequence === report.report_sequence));
  if (!matches.length) return null;
  if (report.requested_at && matches.some(order => order.date !== report.requested_at.slice(0, 10))) return null;
  const visits = new Set(matches.map(order => JSON.stringify([order.date, order.encounter_instance])));
  if (visits.size !== 1) return null;
  return { orders: matches, method: "his-order-index-request-number" };
}

export function attachOutpatientOrder(report, match) {
  return match ? { ...report, outpatient_orders: match.orders, order_match_method: match.method } : report;
}
