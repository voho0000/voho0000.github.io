// One saved preference and one Taiwan calendar window for every capture path.
export const DEFAULT_RECORD_YEARS = "3";
export function normalizeRecordYears(value) {
  const years = String(value ?? "");
  return ["1", "3", "5", "all"].includes(years) ? years : DEFAULT_RECORD_YEARS;
}

export function createRecordRange(value, now = new Date()) {
  const years = normalizeRecordYears(value);
  const end = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Taipei", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(now);
  if (years === "all") return { years, start: null, end: null };
  const [y, m, d] = end.split("-").map(Number);
  const startYear = y - Number(years);
  const lastDay = new Date(Date.UTC(startYear, m, 0)).getUTCDate();
  const start = `${startYear}-${String(m).padStart(2, "0")}-${String(Math.min(d, lastDay)).padStart(2, "0")}`;
  return { years, start, end };
}

export function recordRangeLabel(value) {
  const years = normalizeRecordYears(value);
  return years === "all" ? "全部歷史" : `近 ${years} 年`;
}

// qemr uses both AD and ROC dates. Reject malformed dates instead of treating
// them as evidence that a row falls outside the selected window.
export function recordDate(value) {
  const match = String(value ?? "").trim().match(/^(\d{3,4})[-/]?(\d{2})[-/]?(\d{2})(?=$|[^\d])/);
  if (!match) return "";
  let year = Number(match[1]);
  if (match[1].length === 3 || (match[1].startsWith("0") && year < 300)) year += 1911;
  const month = Number(match[2]), day = Number(match[3]);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return "";
  return `${year}-${match[2]}-${match[3]}`;
}

function firstDate(...values) {
  return values.map(recordDate).find(Boolean) || "";
}

export function recordInRange(pageType, item, range) {
  if (!range?.start || pageType === "patient_info") return true;
  if (!item || typeof item !== "object") return false;
  let start = "", end = "";
  if (item.encounter_class === "AMB" && item.encounter_ref_date) {
    // Selected-visit snapshots can mention older history/prescription dates.
    start = firstDate(item.encounter_ref_date);
  } else if (pageType === "encounters" || pageType === "admission_index" || pageType === "document_references") {
    start = firstDate(item.admit_date, item.date);
    end = firstDate(item.discharge_date, item.end_date);
    // Open admissions overlap the window. Other single-date records are events.
    if (!end && item.class === "IMP") end = range.end;
  } else if (pageType === "careplans") {
    start = firstDate(item.start_date, item.finalize_date, item.draft_date, item.first_finalize_date);
    end = firstDate(item.end_date);
    if (item.start_date && !end) end = range.end;
  } else if (pageType === "conditions") {
    start = firstDate(item.effective_date, item.onset_date, item.recorded_date, item.date);
  } else {
    start = firstDate(item.datetime, item.effective_datetime, item.start_time, item.date,
      item.received_at, item.recorded_date, item.onset_date);
  }
  // Undated clinical context (e.g. allergies) cannot safely be dated by capture time.
  if (!start && !end) return true;
  return (end || start) >= range.start && (!start || start <= range.end);
}

export function filterRecordItems(pageType, items, range) {
  return Array.isArray(items) ? items.filter(item => recordInRange(pageType, item, range)) : [];
}

export function vitalOptionInRange(option, range, encounterItems = []) {
  let caseNo = "";
  try { caseNo = [...new URL(option.v.startsWith("&") ? `?${option.v.slice(1)}` : option.v, "https://qemr.invalid").searchParams]
    .find(([key]) => key.toLowerCase() === "caseno")?.[1] || ""; } catch {}
  const encounter = encounterItems.find(item => item.case_no === caseNo && item.class === "IMP");
  if (encounter) return recordInRange("encounters", encounter, range);
  const dates = String(option.t || "").match(/\d{4}[-/]?\d{2}[-/]?\d{2}/g) || [];
  return recordInRange("encounters", { date: dates[0], end_date: dates[1] }, range);
}

export function reportQueryYears(range, availableYears = [], encounterItems = [], now = new Date()) {
  const currentYear = Number(new Intl.DateTimeFormat("en", { timeZone: "Asia/Taipei", year: "numeric" }).format(now));
  if (range.years === "1") return [];
  const advertised = availableYears.map(Number).filter(y => Number.isInteger(y) && y >= 1911 && y < currentYear - 1);
  let first = range.start ? Number(range.start.slice(0, 4)) : null;
  if (first == null) {
    const dates = encounterItems.map(it => firstDate(it.date, it.admit_date)).filter(Boolean);
    const oldest = dates.length ? Math.min(...dates.map(date => Number(date.slice(0, 4)))) : currentYear - 1;
    first = Math.min(oldest, ...advertised, currentYear - 1);
  }
  const years = [];
  if (advertised.length) return [...new Set(advertised.filter(year => year >= first))].sort((a, b) => a - b);
  // The 24-month rolling list covers current/previous calendar years; the
  // partially covered third calendar year still needs its annual query.
  for (let year = first; year < currentYear - 1; year++) years.push(year);
  return years;
}
