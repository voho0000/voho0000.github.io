import { normalizeRecordYears } from "./record-range.js";

const FHIR_ID_RE = /^[A-Za-z0-9\-.]{1,64}$/;

export function isSupportedQemrHost(hostname) {
  return typeof hostname === "string" && /(^|\.)vghtpe\.gov\.tw$/i.test(hostname);
}

export function parseQemrPatientPage(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const histnos = url.searchParams.getAll("histno");
    if (
      url.protocol !== "https:" ||
      !isSupportedQemrHost(url.hostname) ||
      !url.pathname.toLowerCase().startsWith("/emr/qemr/") ||
      histnos.length !== 1 ||
      !FHIR_ID_RE.test(histnos[0])
    ) {
      return null;
    }
    return {
      host: url.hostname,
      baseUrl: url.origin,
      histno: histnos[0],
    };
  } catch {
    return null;
  }
}

export function buildOneClickPayload(tabId, page, settings = {}, now = Date.now()) {
  if (!Number.isInteger(tabId) || tabId < 0 || !page?.histno) {
    throw new Error("無法確認目前病人頁面");
  }
  return {
    tabId,
    host: page.host,
    baseUrl: page.baseUrl,
    histno: page.histno,
    mode: "download",
    deidentify: false,
    recordYears: settings.outpatientMode === true ? "1" : normalizeRecordYears(settings.recordYears),
    outpatientMode: settings.outpatientMode === true,
    syncRunId: `one-click-${now}-${page.histno}`,
    includeHtmlZip: false,
  };
}

export function canStopOneClick(sender, histno, context) {
  const page = parseQemrPatientPage(sender?.url || sender?.tab?.url || "");
  return Number.isInteger(sender?.tab?.id)
    && (sender.frameId === undefined || sender.frameId === 0)
    && !!page && page.histno === histno
    && context?.mode === "download" && context.histno === histno
    && context.tabId === sender.tab.id;
}

// The same floating control also observes popup-started download jobs.
// Only the originating patient tab's top frame may stop or read that job.
function matchesSyncPage(sender, histno, context) {
  const page = parseQemrPatientPage(sender?.url || sender?.tab?.url || "");
  return Number.isInteger(sender?.tab?.id)
    && (sender.frameId === undefined || sender.frameId === 0)
    && !!page && page.histno === histno && context?.histno === histno
    && context.tabId === sender.tab.id;
}

export function canControlSyncFromPage(sender, histno, context) {
  return matchesSyncPage(sender, histno, context) && ["download", "html"].includes(context.mode);
}

// A cloud-owned capture is visible on its HIS page, but remains controlled by
// the cloud flow. Observing it must not grant the floating button cancellation.
export function canReadSyncFromPage(sender, histno, context) {
  return matchesSyncPage(sender, histno, context) && ["download", "html", "outpatient-peer"].includes(context.mode);
}


// A query page may observe only a generic preflight status for its own tab.
export function canReadOutpatientPreflight(sender, status) {
  let url; try { url = new URL(sender?.url || sender?.tab?.url || ''); } catch { return false; }
  return Number.isInteger(sender?.tab?.id) && sender.frameId === 0
    && url.protocol === 'https:' && /(^|\.)vghtpe\.gov\.tw$/i.test(url.hostname)
    && url.pathname === '/emr/qemr/qemr.cfm' && url.searchParams.getAll('action').length === 1
    && url.searchParams.get('action') === 'findPatient' && !url.searchParams.has('histno')
    && status?.preflight === true && status.tabId === sender.tab.id;
}
