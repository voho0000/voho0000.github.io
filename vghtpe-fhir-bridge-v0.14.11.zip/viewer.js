// Opening the viewer sends no patient data; the user selects a local file.
export async function openMediPrisma(tabs) {
  return await tabs.create({ url: "https://mediprisma.tw/app/", active: true });
}
