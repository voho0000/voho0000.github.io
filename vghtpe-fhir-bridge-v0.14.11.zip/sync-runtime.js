// Shared sync lifecycle helpers used by both the popup and service worker.
// Kept dependency-free so the same timeout/stale-state rules can be tested in
// Node without a browser or real patient data.

export const PAGE_REQUEST_TIMEOUT_MS = 30_000;
export const BACKEND_REQUEST_TIMEOUT_MS = 120_000;

// Shared by the worker's detail pools, request pacing, and duration estimate.
// Conservative original pacing restored after the faster policy hit HIS limits.
// Server-driven cooldowns can still extend these waits for every worker.
export const QEMR_REQUEST_POLICY = Object.freeze({
  concurrency: 2,
  minStartIntervalMs: 400,
  startJitterMs: 200,
  batchSize: 50,
  batchPauseMs: 10_000,
  batchPauseJitterMs: 5_000,
});

export class RequestTimeoutError extends Error {
  constructor(timeoutMs) {
    super(`請求逾時（${Math.ceil(timeoutMs / 1000)} 秒）`);
    this.name = "RequestTimeoutError";
    this.timeoutMs = timeoutMs;
  }
}

export class SyncAbortError extends Error {
  constructor() {
    super("使用者取消取得");
    this.name = "SyncAbortError";
  }
}

export class HisRequestBlockedError extends Error {
  constructor(status, retryAfterMs = null) {
    const wait = retryAfterMs ? `，請至少等待 ${Math.ceil(retryAfterMs / 1000)} 秒後再試` : "";
    super(`北榮服務暫時拒絕或無法處理請求（HTTP ${status}）${wait}；已停止本次取得，避免持續觸發封鎖`);
    this.name = "HisRequestBlockedError";
    this.status = status;
    this.retryAfterMs = retryAfterMs;
  }
}

export function isSyncAbortError(error) {
  return error?.name === "SyncAbortError";
}

export function isHisRequestBlockedError(error) {
  return error?.name === "HisRequestBlockedError";
}

export function parseRetryAfterMs(value, nowMs = Date.now()) {
  if (!value) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000;
  const at = Date.parse(value);
  return Number.isFinite(at) ? Math.max(0, at - nowMs) : null;
}

export function delayWithSignal(ms, signal) {
  if (ms <= 0) return Promise.resolve();
  if (signal?.aborted) return Promise.reject(new SyncAbortError());
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, ms);
    function done() {
      signal?.removeEventListener("abort", aborted);
      resolve();
    }
    function aborted() {
      clearTimeout(timer);
      signal?.removeEventListener("abort", aborted);
      reject(new SyncAbortError());
    }
    signal?.addEventListener("abort", aborted, { once: true });
  });
}

export function createSyncAbortHandle() {
  const controller = new AbortController();
  return {
    signal: controller.signal,
    get aborted() {
      return controller.signal.aborted;
    },
    abort() {
      if (!controller.signal.aborted) controller.abort();
    },
  };
}

// Serialize starts while allowing already-started requests to overlap. Re-check
// the deadline after every wait: an in-flight request may extend Retry-After.
export function createRequestStartScheduler({
  policy = QEMR_REQUEST_POLICY,
  now = Date.now,
  random = Math.random,
  delay = delayWithSignal,
} = {}) {
  let tail = Promise.resolve();
  let nextStartAt = 0;
  let serverCooldownUntil = 0;
  let starts = 0;
  const scheduler = {
    get starts() { return starts; },
    reset() {
      tail = Promise.resolve();
      nextStartAt = Math.max(0, serverCooldownUntil);
      starts = 0;
    },
    extendCooldown(ms, preserveAcrossReset = false) {
      const deadline = now() + Math.max(0, ms);
      nextStartAt = Math.max(nextStartAt, deadline);
      if (preserveAcrossReset) serverCooldownUntil = Math.max(serverCooldownUntil, deadline);
    },
    async waitForSlot(signal) {
      let release;
      const previous = tail;
      tail = new Promise((resolve) => { release = resolve; });
      try { await awaitWithSignal(previous.catch(() => {}), signal); }
      catch (error) {
        // Keep later waiters behind the original owner, while allowing this
        // cancelled caller to return immediately instead of waiting for it.
        void previous.then(release, release);
        throw error;
      }
      try {
        if (signal?.aborted) throw new SyncAbortError();
        if (starts > 0 && starts % policy.batchSize === 0) {
          scheduler.extendCooldown(policy.batchPauseMs
            + Math.floor(random() * (policy.batchPauseJitterMs + 1)));
        }
        while (nextStartAt > now()) {
          await delay(nextStartAt - now(), signal);
        }
        if (signal?.aborted) throw new SyncAbortError();
        const startedAt = now();
        starts++;
        nextStartAt = startedAt + policy.minStartIntervalMs
          + Math.floor(random() * (policy.startJitterMs + 1));
        return startedAt;
      } finally {
        release();
      }
    },
  };
  return scheduler;
}

export function shouldRecoverOrphanedStatus(status, hasActiveJob) {
  return !!status?.running && !hasActiveJob;
}

// Chrome scripting/navigation promises do not accept an AbortSignal. Stop
// awaiting them promptly while their owner cleans up the created browser tab.
export function awaitWithSignal(promise, signal) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener("abort", aborted);
      if (error) reject(error);
      else resolve(value);
    };
    const aborted = () => finish(new SyncAbortError());
    Promise.resolve(promise).then((value) => finish(null, value), (error) => finish(error));
    if (signal?.aborted) aborted();
    else signal?.addEventListener("abort", aborted, { once: true });
  });
}

// Drain workers before releasing a run's abort controller. Otherwise a late
// worker can continue parsing/posting after cancellation has been acknowledged.
export async function mapWithConcurrency(items, limit, fn) {
  const results = new Array(items.length);
  let next = 0;
  async function worker() {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  }
  const workers = await Promise.allSettled(Array.from({ length: Math.min(limit, items.length) }, worker));
  const failed = workers.find((result) => result.status === "rejected");
  if (failed) throw failed.reason;
  return results;
}

export function shouldFinalizeSync(errors, postedPageTypeCount, aborted) {
  return !aborted && postedPageTypeCount > 0 && (!errors || errors.length === 0);
}

export async function fetchWithTimeout(
  fetchImpl,
  url,
  options = {},
  { timeoutMs = PAGE_REQUEST_TIMEOUT_MS, signal: parentSignal } = {},
) {
  const controller = new AbortController();
  let timedOut = false;
  const abortFromParent = () => controller.abort();

  if (parentSignal?.aborted) abortFromParent();
  else parentSignal?.addEventListener("abort", abortFromParent, { once: true });

  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  try {
    return await fetchImpl(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (parentSignal?.aborted) throw new SyncAbortError();
    if (timedOut) throw new RequestTimeoutError(timeoutMs);
    throw error;
  } finally {
    clearTimeout(timer);
    parentSignal?.removeEventListener("abort", abortFromParent);
  }
}

export async function readResponseBodyWithTimeout(
  response,
  method = "text",
  { timeoutMs = PAGE_REQUEST_TIMEOUT_MS, signal: parentSignal } = {},
) {
  if (!response || typeof response[method] !== "function") {
    throw new TypeError(`Response does not support ${method}()`);
  }
  if (parentSignal?.aborted) throw new SyncAbortError();
  let timer;
  let abortHandler;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      response.body?.cancel?.().catch(() => {});
      reject(new RequestTimeoutError(timeoutMs));
    }, timeoutMs);
    if (parentSignal) {
      abortHandler = () => {
        response.body?.cancel?.().catch(() => {});
        reject(new SyncAbortError());
      };
      parentSignal.addEventListener("abort", abortHandler, { once: true });
    }
  });
  try {
    return await Promise.race([response[method](), timeout]);
  } finally {
    clearTimeout(timer);
    if (abortHandler) parentSignal?.removeEventListener("abort", abortHandler);
  }
}
