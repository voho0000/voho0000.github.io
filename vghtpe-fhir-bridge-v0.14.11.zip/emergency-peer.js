import { outpatientPageStep } from "./outpatient-integration.js";
import { CLOUD_PEER_KEY, pairedCloudId, readPairedCloudId } from "./paired-extension.js";
export const ER_PROTOCOL = "WILDCATCH_EMERGENCY_V2";
async function within(promise, ms = 10_000) {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error("EMERGENCY_TIMEOUT")), ms);
    })]);
  } finally { clearTimeout(timer); }
}
export function parseErPage(value) {
  try {
    const url = new URL(value);
    const match = /^\/ERS\/patientMainPage\/(\d{1,12})\/([A-Za-z0-9]+)\/?$/.exec(url.pathname);
    return url.origin === "https://rkeprd.vghtpe.gov.tw" && match ? { histno: match[1], url: url.href } : null;
  } catch { return null; }
}
export function parseChartPage(value) {
  try {
    const url = new URL(value), histno = url.searchParams.get("histno");
    return url.protocol === "https:" && /(^|\.)vghtpe\.gov\.tw$/.test(url.hostname) &&
      url.pathname.startsWith("/emr/qemr/") && url.searchParams.getAll("histno").length === 1 &&
      /^\d{1,12}$/.test(histno || "") ? { histno, url: url.href } : null;
  } catch { return null; }
}
export function minimalIdentity(value, histno, now = new Date()) {
  if (String(value?.identifier || value?.id || "") !== histno ||
      typeof value.id_no !== "string" || !/^[A-Za-z][A-Za-z0-9][0-9]{8}$/.test(value.id_no) ||
      typeof value.birthDate !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value.birthDate)) return null;
  const date = new Date(value.birthDate + "T00:00:00Z");
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value.birthDate ||
      value.birthDate > `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}` || Number(value.birthDate.slice(0, 4)) < now.getUTCFullYear() - 150 ||
      Number(value.birthDate.slice(0, 4)) < 1912) return null;
  return { nationalId: value.id_no.toUpperCase(), birthDate: value.birthDate };
}

// Runs in the chart's isolated world, using the existing north-side parser.
export async function readEmergencyIdentity(histno) {
  const current = new URL(location.href);
  if (current.searchParams.get("histno") !== histno) return null;
  const header = document.querySelector("ul.jd_menu > li:first-child")?.textContent || "";
  if (!new RegExp("(^|\\D)" + histno + "(\\D|$)").test(header)) return null;
  const audit = document.querySelector("#divNotify02Panel");
  if (audit && audit.getClientRects().length && getComputedStyle(audit).visibility !== "hidden") return null;
  const url = new URL("/emr/qemr/qemr.cfm", current.origin);
  url.searchParams.set("action", "findPba"); url.searchParams.set("histno", histno);
  const response = await fetch(url, { credentials: "include", signal: AbortSignal.timeout(10000), cache: "no-store" });
  if (!response.ok || new URL(response.url).origin !== current.origin) throw new Error("IDENTITY_UNAVAILABLE");
  const html = await response.text();
  if (html.length > 2_000_000 || location.href !== current.href) throw new Error("IDENTITY_UNAVAILABLE");
  const finalAudit = document.querySelector("#divNotify02Panel");
  if (finalAudit && finalAudit.getClientRects().length && getComputedStyle(finalAudit).visibility !== "hidden") return null;
  const patient = window.__vghParse("patient_info_findpba", html)?.[0];
  if (!patient) throw new Error("IDENTITY_UNAVAILABLE");
  return { identifier: patient.identifier, id: patient.id, id_no: patient.id_no, birthDate: patient.birthDate };
}

export function openEmergencyChart(inspectOnly = false) {
  const links = [...document.querySelectorAll("a, span.link.action4")].filter(a => a.textContent.replace(/\s/g, "") === "病歷查詢" && a.getClientRects().length);
  if (links.length !== 1) return false;
  if (inspectOnly) {
    const target = links[0].getAttribute("href") || links[0].getAttribute("id");
    if (!target) return false;
    try { return new URL(target, location.href).href; } catch { return false; }
  }
  links[0].click(); return true;
}

export function installEmergencyPeer({ busy = () => false, sleep = ms => new Promise(resolve => setTimeout(resolve, ms)), now = Date.now } = {}) {
  let job = null;
  const error = code => Object.assign(new Error(code), { code });
  const tell = (current, message, phase = "reading") => chrome.tabs.sendMessage(current.sourceTab, {
    type: "er:status", message, phase, context: current.context, requestId: current.requestId,
  }).catch(() => {});
  async function verify(current) {
    if (job !== current || current.invalid || now() > current.expires) throw error("PATIENT_CONTEXT_CHANGED");
    const [tab, state, peer] = await Promise.all([
      within(chrome.tabs.get(current.sourceTab), 1500),
      within(chrome.tabs.sendMessage(current.sourceTab, { type: "er:context" }), 1500),
      within(readPairedCloudId(), 1500),
    ]);
    if (peer !== current.peer) { stop(current); throw error("PAIRING_CHANGED"); }
    if (tab.url !== current.sourceUrl || state?.href !== current.sourceUrl || state?.context !== current.context) throw error("PATIENT_CONTEXT_CHANGED");

    if (job !== current || current.invalid) throw error("PATIENT_CONTEXT_CHANGED");
    return { ok: true, patientContextId: current.context, windowId: tab.windowId };
  }
  function stop(current) {
    current.invalid = true; clearInterval(current.timer);
    if (job === current) job = null;
  }
  chrome.storage.onChanged?.addListener((changes, area) => {
    if (area !== 'local' || !changes[CLOUD_PEER_KEY] || !job) return;
    const current = job;
    if (pairedCloudId(changes[CLOUD_PEER_KEY].newValue) !== current.peer) {
      stop(current);
      void tell(current, "配對已變更，已停止本次急診流程。", "cancelled");
    }
  });
  // Any navigation invalidates the context even when the clinician goes A -> B -> A.
  chrome.tabs.onUpdated?.addListener((tabId, change) => {
    if (job && (tabId === job.sourceTab || tabId === job.chartTab) && (change.url || change.status === "loading")) {
      if (tabId === job.chartTab) {
        const chart = change.url && parseChartPage(change.url);
        if (!chart || chart.histno === job.histno) { job.stableChart = 0; job.parserReady = false; return; }
      }
      const previous = job;
      stop(previous);
      void tell(previous, "病人頁面已切換或重新載入，已停止本次急診流程；請在目前病人重新啟動。", "cancelled");
    }
  });
  chrome.tabs.onRemoved?.addListener(tabId => {
    if (job && [job.sourceTab, job.chartTab].includes(tabId)) {
      const previous = job; stop(previous);
      void tell(previous, "原病人或病歷分頁已關閉，已停止本次急診流程。", "cancelled");
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message?.type === "er:cancel") {
      const current = job;
      if (current && sender.id === chrome.runtime.id && sender.frameId === 0 && sender.tab?.id === current.sourceTab &&
          message.context === current.context && message.requestId === current.requestId) {
        stop(current); reply({ ok: true });
      } else reply({ ok: false });
      return false;
    }
    if (message?.type !== "er:start") return false;
    void (async () => {
      if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || !sender.tab || !parseErPage(sender.url) || sender.url !== sender.tab.url) return { ok: false, code: "INVALID_SOURCE" };
      if (job || busy()) return { ok: false, code: "ER_BUSY" };
      const peer = await readPairedCloudId();
      if (!/^[a-p]{32}$/.test(peer || "") || peer === chrome.runtime.id) return { ok: false, code: "NOT_PAIRED" };
      // Recheck after asynchronous pairing lookup; another flow may have started.
      if (job || busy()) return { ok: false, code: "ER_BUSY" };
      const current = { sourceTab: sender.tab.id, sourceUrl: sender.url, histno: parseErPage(sender.url).histno,
        context: message.context, requestId: /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(message.requestId || "") ? message.requestId : crypto.randomUUID(), token: crypto.randomUUID(), peer, expires: now() + 8 * 60_000, stableChart: 0, reads: 0 };
      job = current;
      current.timer = setInterval(() => {
        if (now() > current.expires || (current.awaitingCloud && now() - current.lastContact > 30_000)) {
          stop(current); void tell(current, "雲端連線中斷或本次流程已逾時，請重新啟動。", "error");
        }
      }, 1000);
      let created;
      const onCreated = tab => {
        if (tab.openerTabId === current.sourceTab && tab.windowId === sender.tab.windowId) {
          if (created !== undefined) current.ambiguous = true;
          created = tab.id;
        }
      };
      try {
        await verify(current);
        chrome.tabs.onCreated.addListener(onCreated);
        const inspected = await chrome.scripting.executeScript({ target: { tabId: current.sourceTab, frameIds: [0] }, func: openEmergencyChart, args: [true] });
        await verify(current);
        const direct = parseChartPage(inspected[0]?.result);
        if (direct) {
          if (direct.histno !== current.histno) throw error("PATIENT_CONTEXT_CHANGED");
          const tab = await chrome.tabs.create({ url: direct.url, windowId: sender.tab.windowId, openerTabId: current.sourceTab, active: true });
          if (created !== undefined && created !== tab.id) throw error("CHART_UNAVAILABLE");
          created = tab.id;
        } else {
          const opened = await chrome.scripting.executeScript({ target: { tabId: current.sourceTab, frameIds: [0] }, func: openEmergencyChart });
          if (opened[0]?.result !== true) throw error("CHART_LINK_UNAVAILABLE");
        }
        const deadline = Date.now() + 120_000;
        const openDeadline = Date.now() + 10_000;
        let identity;
        while (Date.now() < deadline) {
          await verify(current);
          if (current.ambiguous) throw error("CHART_UNAVAILABLE");
          if (created === undefined && Date.now() > openDeadline) throw error("CHART_UNAVAILABLE");
          if (created !== undefined) {
            const tab = await chrome.tabs.get(created);
            const chart = parseChartPage(tab.url);
            if (chart) {
              if (chart.histno !== current.histno) throw error("PATIENT_CONTEXT_CHANGED");
              current.chartTab = created;
              if (tab.status === "complete") {
                const inspectedChart = await within(chrome.scripting.executeScript({ target: { tabId: created, frameIds: [0] }, func: outpatientPageStep, args: ["inspect", {}] }), 5_000);
                const state = inspectedChart[0]?.result;
                current.stableChart = state?.phase === "chart" && state.histno === current.histno ? current.stableChart + 1 : 0;
                if (current.stableChart < 3) {
                  await tell(current, "請在病歷分頁完成院內登入及調閱理由，確認後會繼續。 ");
                  await sleep(Math.min(8000, 1000 * 2 ** Math.max(0, current.reads - 1))); continue;
                }
                await verify(current);
                if (!current.parserReady) {
                  await chrome.scripting.executeScript({ target: { tabId: created, frameIds: [0] }, files: ["qemr-parser.js"] });
                  current.parserReady = true;
                }
                if (++current.reads > 5) throw error("IDENTITY_UNAVAILABLE");
                const result = await within(chrome.scripting.executeScript({ target: { tabId: created, frameIds: [0] }, func: readEmergencyIdentity, args: [current.histno] }), 15_000);
                if (result[0]?.result != null && !minimalIdentity(result[0].result, current.histno)) throw error("IDENTITY_UNAVAILABLE");
                identity = minimalIdentity(result[0]?.result, current.histno);
                if (identity) break;
                await tell(current, "請在開啟的病歷分頁完成院內登入或調閱理由，完成後會接續急診流程。");
              }
            }
          }
          await sleep(Math.min(8000, 1000 * 2 ** Math.max(0, current.reads - 1)));
        }
        if (!identity) throw error(created === undefined ? "CHART_UNAVAILABLE" : "IDENTITY_UNAVAILABLE");
        await verify(current);
        // Identity is now validated. The extra chart tab is no longer the source.
        current.chartTab = undefined;
        current.awaitingCloud = true; current.lastContact = now();
        current.expires = Number.POSITIVE_INFINITY;
        await tell(current, "正在交給雲端，請稍候", "sending");
        await verify(current);
        if (current.invalid || job !== current) throw error("PATIENT_CONTEXT_CHANGED");
        const result = await within(chrome.runtime.sendMessage(peer, { protocol: ER_PROTOCOL, action: message.preview === true ? "validate" : "launch", mode: "er",
          requestId: current.requestId, patientContextId: current.context, token: current.token,
          issuedAt: Date.now(), ...identity }), 45_000);
        identity = null;
        if (!result?.ok) throw error(result?.code || "CLOUD_UNAVAILABLE");
        if (message.preview === true) {
          if (result.code !== "IDENTITY_VALIDATED" || result.requestId !== current.requestId || result.patientContextId !== current.context) throw error("INVALID_RECEIPT");
          await verify(current); stop(current);
          return { ok: true, preview: true };
        }
        return { ok: true };
      } catch (err) {
        stop(current); return { ok: false, code: err.code || "EMERGENCY_FAILED" };
      } finally { chrome.tabs.onCreated.removeListener(onCreated); }
    })().then(reply, () => reply({ ok: false, code: "EMERGENCY_FAILED" }));
    return true;
  });
  chrome.runtime.onMessageExternal?.addListener((message, sender, reply) => {
    if (message?.protocol !== ER_PROTOCOL) return false;
    void (async () => {
      const current = job;
      const peer = await readPairedCloudId();
      if (!current || job !== current || current.invalid || sender.tab || sender.id !== current.peer || peer !== current.peer ||
          message.requestId !== current.requestId || message.patientContextId !== current.context || message.token !== current.token) return { ok: false, code: "INVALID_CONTEXT" };
      if (message.action === "retained") {
        await tell(current, "結果已保存於雲端；切換原急診病人會清除，請在雲端重試交接。", "retained");
        return { ok: true };
      }
      if (["cancel", "complete", "handoff"].includes(message.action)) {
        if (message.action === "handoff") {
          try { await verify(current); } catch { return { ok: false, code: "PATIENT_CONTEXT_CHANGED" }; }
        }
        stop(current);
        await tell(current, message.action === "handoff" ? "已開始交接醫析，請在醫析確認匯入結果。" : message.action === "complete" ? "本次急診資料已交接醫析。" : "急診流程已停止，請確認目前病人後重新啟動。", ["complete", "handoff"].includes(message.action) ? "done" : "cancelled");
        return { ok: true };
      }
      if (message.action !== "verify") return { ok: false, code: "INVALID_REQUEST" };
      try {
        const state = await verify(current); current.lastContact = now(); return state;
      } catch (err) {
        if (err.code !== "PATIENT_CONTEXT_CHANGED") return { ok: false, code: "VERIFY_UNAVAILABLE" };
        stop(current);
        await tell(current, "原急診病人情境已失效，請重新啟動。", "error");
        return { ok: false, code: "PATIENT_CONTEXT_CHANGED" };
      }
    })().then(reply, () => reply({ ok: false, code: "EMERGENCY_FAILED" }));
    return true;
  });
  return { busy: () => !!job && !job.awaitingCloud };
}
