export const CLOUD_STORE_EXTENSION_ID = "hhfoejpppfbkadcjifgfmfpdhikicmgf";
export const CLOUD_PEER_KEY = "outpatientCloudExtensionId";

function isPeerId(id) {
  return typeof id === "string" && /^[a-p]{32}$/.test(id) && id !== chrome.runtime.id;
}

export function pairedCloudId(stored) {
  // An explicit empty value keeps pairing disabled; only new installs use the default.
  const id = stored === undefined ? CLOUD_STORE_EXTENSION_ID : stored;
  return isPeerId(id) ? id : undefined;
}

export async function readPairedCloudId() {
  return pairedCloudId((await chrome.storage.local.get(CLOUD_PEER_KEY))[CLOUD_PEER_KEY]);
}

export async function savePairedCloudId(value) {
  const id = value.trim();
  if (id && !isPeerId(id)) throw new Error("INVALID_PEER_ID");
  await chrome.storage.local.set({ [CLOUD_PEER_KEY]: id });
  return id;
}
