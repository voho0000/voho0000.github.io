(() => {
  const HOST_ID = "vgh-wildcatch-one-click-launcher";
  const DISPOSE_KEY = "__vghWildcatchLauncherCleanup";
  const currentPatientId = () => {
    try {
      const url = new URL(location.href);
      const histnos = url.searchParams.getAll("histno");
      return /(^|\.)vghtpe\.gov\.tw$/i.test(url.hostname)
        && url.pathname.toLowerCase().startsWith("/emr/qemr/")
        && histnos.length === 1
        && /^[A-Za-z0-9\-.]{1,64}$/.test(histnos[0])
        ? histnos[0] : null;
    } catch { return null; }
  };
  const isPatientPage = () => !!currentPatientId();
  const isSearchPage = () => {
    try { const url = new URL(location.href); return url.protocol === 'https:'
      && /(^|\.)vghtpe\.gov\.tw$/i.test(url.hostname) && url.pathname === '/emr/qemr/qemr.cfm'
      && url.searchParams.getAll('action').length === 1 && url.searchParams.get('action') === 'findPatient'
      && !url.searchParams.has('histno'); } catch { return false; }
  };
  if (typeof window[DISPOSE_KEY] === "function") window[DISPOSE_KEY]();
  document.getElementById(HOST_ID)?.remove();

  const host = document.createElement("div");
  host.id = HOST_ID;
  host.dataset.extensionVersion = chrome.runtime.getManifest?.().version || "";
  const shadow = host.attachShadow({ mode: "closed" });
  const iconUrl = chrome.runtime.getURL("icons/icon48.png");
  shadow.innerHTML = `
    <style>
      :host { all: initial; position: fixed; z-index: 2147483647; right: 16px; top: 52%; transform: translateY(-50%); color-scheme: light; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC",sans-serif; }
      :host([hidden]) { display: none; }
      * { box-sizing: border-box; }
      [hidden] { display:none!important; }
      .launcher { width:62px; min-height:62px; display:flex; align-items:center; gap:8px; overflow:hidden; padding:6px; border:1px solid rgba(30,58,138,.28); border-radius:999px; background:rgba(255,255,255,.97); color:#172554; box-shadow:0 10px 30px rgba(30,58,138,.22),0 2px 8px rgba(30,58,138,.12); transition:width .2s ease,box-shadow .2s ease; }
      .launcher:hover,.launcher:focus-within,.launcher[data-state]:not([data-state="idle"]) { width:min(380px,calc(100vw - 32px)); }
      button { font:inherit; cursor:pointer; }
      .launch-button { min-width:0; flex:1; display:flex; align-items:center; gap:10px; padding:0; border:0; border-radius:999px; background:transparent; color:inherit; }
      button:focus-visible { outline:3px solid rgba(37,99,235,.28); outline-offset:3px; }
      button:disabled { cursor:wait; }
      .mark { position:relative; width:48px; height:48px; flex:0 0 48px; display:grid; place-items:center; border-radius:50%; background:#eff6ff; }
      .mark img { width:46px; height:46px; object-fit:contain; display:block; }
      .completion-dot { position:absolute; z-index:1; top:-1px; right:-1px; width:12px; height:12px; border:2px solid #fff; border-radius:50%; background:#dc2626; box-shadow:0 1px 3px rgba(127,29,29,.2); }
      .copy { min-width:0; padding-right:12px; opacity:0; transform:translateX(6px); transition:opacity .16s ease,transform .16s ease; text-align:left; white-space:nowrap; }
      .launcher:hover .copy,.launcher:focus-within .copy,.launcher[data-state]:not([data-state="idle"]) .copy { opacity:1; transform:none; }
      .label { display:block; overflow:hidden; text-overflow:ellipsis; font-size:14px; line-height:1.35; font-weight:700; }
      .hint { display:block; margin-top:2px; overflow:hidden; text-overflow:ellipsis; color:#64748b; font-size:11px; line-height:1.35; font-weight:500; }
      .launcher[data-state="running"] .mark::after,.launcher[data-state="handoff"] .mark::after,.launcher[data-state="cancelling"] .mark::after { content:""; position:absolute; inset:-2px; border:3px solid rgba(37,99,235,.16); border-top-color:#2563eb; border-radius:50%; animation:spin .85s linear infinite; }
      .launcher[data-state="done"] { border-color:rgba(4,120,87,.38); background:#f0fdf4; color:#065f46; }
      .launcher[data-state="partial"] { border-color:#d97706; background:#fffbeb; color:#92400e; }
      .launcher[data-state="error"] { border-color:rgba(185,28,28,.42); background:#fffafa; color:#991b1b; }
      .launcher[data-state="cancelled"] { border-color:#cbd5e1; background:#f8fafc; color:#475569; }
      .launcher[data-state="running"] .copy,.launcher[data-state="handoff"] .copy,.launcher[data-state="error"] .copy,.launcher[data-state="partial"] .copy { white-space:normal; }
      .launcher[data-state="running"] .hint,.launcher[data-state="handoff"] .hint,.launcher[data-state="error"] .hint,.launcher[data-state="partial"] .hint { white-space:normal; overflow:visible; font-size:12px; }
      .stop-button { display:flex; align-items:center; gap:5px; flex:0 0 auto; min-height:34px; margin-right:7px; padding:7px 10px; border:1px solid #eecbd0; border-radius:8px; background:#fff8f9; color:#b33f50; font-size:12px; font-weight:600; }
      .stop-button:hover:not(:disabled) { background:#ffeef1; border-color:#df9eaa; }
      .stop-button:disabled { cursor:wait; opacity:.65; }
      .stop-button svg { width:10px; height:10px; }
      .live { position:absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0,0,0,0); white-space:nowrap; border:0; }
      @keyframes spin { to { transform:rotate(360deg); } }
      @media (prefers-reduced-motion:reduce) { .launcher,.copy { transition:none; } .mark::after { animation:none!important; } }
      @media (max-width:640px) { :host { right:10px; top:auto; bottom:18px; transform:none; } .launcher:hover,.launcher:focus-within,.launcher[data-state]:not([data-state="idle"]) { width:min(340px,calc(100vw - 20px)); } }
    </style>
    <div class="launcher" data-state="idle" role="group" aria-label="北榮病歷取得工具">
    <button class="launch-button" type="button" aria-label="取得北榮病歷並下載FHIR">
      <span class="mark"><img src="${iconUrl}" alt=""><span class="completion-dot" aria-hidden="true" hidden></span></span>
      <span class="copy"><span class="label">取得病歷並下載 FHIR</span><span class="hint">瀏覽器內轉換 → 本機下載</span></span>
    </button>
    <button class="stop-button" type="button" aria-label="停止取得北榮病歷" hidden><svg viewBox="0 0 12 12" fill="currentColor" aria-hidden="true"><rect x="1" y="1" width="10" height="10" rx="1.5"/></svg><span>停止</span></button>
    </div>
    <span class="live" role="status" aria-live="polite"></span>`;
  document.documentElement.appendChild(host);
  host.hidden = !isPatientPage() && !isSearchPage();

  const launcher = shadow.querySelector(".launcher");
  const button = shadow.querySelector(".launch-button");
  const stopButton = shadow.querySelector(".stop-button");
  const label = shadow.querySelector(".label");
  const hint = shadow.querySelector(".hint");
  const live = shadow.querySelector(".live");
  const completionDot = shadow.querySelector(".completion-dot");
  let busy = false;
  let resumeAvailable = false;
  let resumePending = false;
  let resumeErrorUntil = 0;
  let resumeErrorUrl = '';
  let stopRequested = false;
  let lastPatientId = currentPatientId();
  let lastRefresh = Date.now();
  const render = (state, title, detail, canStart = true, canStop = !canStart) => {
    launcher.dataset.state = state;
    button.disabled = !canStart;
    button.toggleAttribute("aria-busy", ["running", "handoff", "cancelling"].includes(state));
    button.setAttribute("aria-label", title);
    button.title = detail;
    label.textContent = title;
    hint.textContent = detail;
    live.textContent = title;
    busy = !canStart;
    stopButton.hidden = !canStop;
    stopButton.disabled = stopRequested;
    if (!["done", "partial"].includes(state)) completionDot.hidden = true;
  };
  const showSearchHint = () => render('idle', '請先選定病人', '請在查詢結果點選正確病人，再於病歷頁取得資料。', false, false);
  if (isSearchPage()) showSearchHint();
  const applyStatus = (status) => {
    if(status?.mode === 'outpatient-resume' && isPatientPage()) {
      resumeAvailable = true;
      if(!resumePending) render(status.canResume ? 'partial' : 'running', status.canResume ? '繼續抓取' : '正在確認並接續抓取…',status.progress,status.canResume,false);
      return;
    }
    if (isSearchPage()) {
      if (status?.preflight === true && status.mode === 'outpatient-peer') {
        render(status.manualSelectionRequired || status.manualActionRequired ? 'partial' : 'running',
          status.manualSelectionRequired ? '無法自動確認，請手動選病人' : status.manualActionRequired ? '請在 HIS 完成病人確認' : '正在查詢並核對 HIS 病人…',
          status.progress || '請等待查詢完成', false, false);
      } else showSearchHint();
      return;
    }
    const currentHistno = currentPatientId();
    if (!status || !["download", "html", "outpatient-peer"].includes(status.mode) || status.histno !== currentHistno) return;
    const cloudCapture = status.mode === "outpatient-peer";
    lastRefresh = Date.now();
    if (status.running) {
      if (stopRequested) return;
      render(status.phase === "handoff" ? "handoff" : "running",
        cloudCapture ? "正在補入北榮病歷…" : "正在取得北榮病歷…",
        status.progress || "請保持院內病歷分頁開啟", false, !cloudCapture);
      return;
    }
    stopRequested = false;
    const destination = cloudCapture ? "北榮資料已準備完成" : status.mode === "html" ? "原始資料下載已啟動" : status.fhirDownloadStarted ? "FHIR 下載已啟動" : "取得完成，無可下載資源";
    if (cloudCapture) {
      const state = ["done", "partial", "cancelled"].includes(status.phase) ? status.phase : "error";
      const cloudResult = state === "done" ? destination : state === "partial" ? `${destination}（部分資料）`
        : state === "cancelled" ? "已停止補入北榮病歷" : "北榮病歷補入未完成";
      render(state, "取得病歷並下載 FHIR", `${cloudResult}；整合請回雲端查看，按此另存本機 FHIR。`, true, false);
      completionDot.hidden = !["done", "partial"].includes(status.phase) || status.completionSeen === true;
      return;
    }
    if (status.phase === "done") render("done", destination, cloudCapture ? "請回雲端查看後續整合進度" : "取得完成，開啟擴充功能查看結果；點此可重新取得", true);
    else if (status.phase === "partial") render("partial", `${destination}（部分資料）`, status.progress || "部分頁面未取得，可開啟擴充功能查看", true);
    else if (status.phase === "cancelled") render("cancelled", "已停止取得", "點此可重新取得目前病人", true);
    else if (["error", "interrupted"].includes(status.phase)) render("error", "取得未完成，點此重試", status.progress || "請確認登入狀態", true);
    completionDot.hidden = !["done", "partial"].includes(status.phase) || status.completionSeen === true;
  };

  button.addEventListener("click", async () => {
    if (busy || !isPatientPage()) return;
    if (resumeAvailable) {
      resumePending=true;
      render('running','正在確認並接續抓取…','重新核對病人身分',false,false);
      try {
        const reply=await chrome.runtime.sendMessage({type:'resumeOutpatientCapture'});
        if(!reply?.ok) {
          resumeErrorUntil=Date.now()+8000;resumeErrorUrl=location.href;
          const detail=reply?.error==='HIS_CONFIRMATION_REQUIRED' ? '請先完成 HIS 調閱確認，再點繼續抓取。'
            : reply?.error==='RESUME_BUSY' ? '雲端仍在完成前次工作，請稍候再點繼續抓取。'
            : reply?.error==='PATIENT_HIS_MISMATCH' || reply?.error==='PATIENT_CONTEXT_CHANGED' ? '病人資料不符，請確認 HIS 與原雲端病人一致。'
            : '原本的串接已逾時或無法連線，請回雲端重新取得。';
          render('error','繼續抓取尚未啟動',detail,true,false);
        } else {resumeAvailable=false;render('running','已接續抓取北榮資料…','請保持此病歷頁開啟',false,false);}
      } catch {resumeErrorUntil=Date.now()+8000;resumeErrorUrl=location.href;render('error','繼續抓取尚未啟動','請確認雲端抓抓仍已啟用',true,false);}
      finally {resumePending=false;}
      return;
    }
    stopRequested = false;
    render("running", "正在啟動一鍵取得…", "確認目前病人與設定", false);
    try {
      const response = await chrome.runtime.sendMessage({ type: "startOneClick" });
      if (!response?.ok) throw new Error(response?.error || "無法啟動一鍵取得");
    } catch (error) {
      if (stopRequested || error?.name === "SyncAbortError") return;
      if (launcher.dataset.state === "cancelled") return;
      render("error", "一鍵取得未啟動，點此重試", error?.message || "擴充功能沒有回應", true);
    }
  });
  stopButton.addEventListener("click", async () => {
    if (!busy || stopRequested) return;
    stopRequested = true;
    render("cancelling", "正在停止取得…", "中止請求與排隊中的工作", false);
    try {
      const response = await chrome.runtime.sendMessage({
        type: "abortSync", fromLauncher: true, histno: currentPatientId(),
      });
      if (!response?.ok) throw new Error(response?.error || "停止請求未送達");
      if (response.status) applyStatus(response.status);
    } catch (error) {
      stopRequested = false;
      if (!busy) return;
      render("running", "無法停止，請再按一次", error?.message || "擴充功能沒有回應", false);
    }
  });
  const onMessage = (message) => {
    if (message?.type === "syncProgress") applyStatus(message.status);
  };
  chrome.runtime.onMessage.addListener(onMessage);
  const refreshStatus = () => {
    lastRefresh = Date.now();
    if(resumePending || (Date.now()<resumeErrorUntil && location.href===resumeErrorUrl)) return;
    const requestedUrl=location.href;
    chrome.runtime.sendMessage({type:'getOutpatientResumeStatus'}).then(status=>{
      if(location.href!==requestedUrl) return;
      if(status?.mode==='outpatient-resume') {applyStatus(status);return;}
      if(resumeAvailable) {resumeAvailable=false;render('idle','取得病歷並下載 FHIR','瀏覽器內轉換 → 本機下載',true,false);}
      return chrome.runtime.sendMessage({ type: "getSyncStatus", fromLauncher: true, histno: currentPatientId() }).then(applyStatus);
    }).catch(()=>{});
  };
  const onStorageChanged = (changes, area) => {
    if (area === "local" && changes.syncStatus && isPatientPage()) refreshStatus();
  };
  chrome.storage?.onChanged?.addListener(onStorageChanged);
  refreshStatus();
  const pollTimer = setInterval(() => {
    if (!host.isConnected) { dispose(); return; }
    const nextPatientId = currentPatientId();
    host.hidden = !nextPatientId && !isSearchPage();
    if (nextPatientId !== lastPatientId) {
      lastPatientId = nextPatientId;
      stopRequested = false;
      render("idle", "取得病歷並下載 FHIR", "瀏覽器內轉換 → 本機下載", true);
      if (isSearchPage()) showSearchHint();
      if (nextPatientId || isSearchPage()) refreshStatus();
    } else if ((nextPatientId || isSearchPage()) && Date.now() - lastRefresh >= (isSearchPage() || resumeAvailable ? 2_000 : 15_000)) {
      // Recover both the start and the final state if a notification was missed.
      refreshStatus();
    }
  }, 1_000);
  function dispose() {
    clearInterval(pollTimer);
    try { chrome.runtime.onMessage.removeListener?.(onMessage); } catch {}
    try { chrome.storage?.onChanged?.removeListener?.(onStorageChanged); } catch {}
    host.remove();
    if (window[DISPOSE_KEY] === dispose) delete window[DISPOSE_KEY];
  }
  window[DISPOSE_KEY] = dispose;
})();
