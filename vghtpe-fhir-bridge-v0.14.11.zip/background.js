import { bindOutpatientRequests, matchOutpatientReport, attachOutpatientOrder, unlinkedOutpatientOrders, uniqueOutpatientReportLinks, outpatientReportIdentity } from "./outpatient-reports.js";
import { outpatientOrderReviewCounts } from "./outpatient-order.js";
import { installEmergencyPeer } from "./emergency-peer.js";
// Service worker: capture and map locally; output a downloaded FHIR Bundle.
// Explicitly paired extensions may request same-patient FHIR through the peer protocol.

import { buildBundle, mapPageType } from "./mapper/index.js";
import { conditionId } from "./mapper/condition.js";
import { hasUnmappedVitalValue } from "./mapper/vital-signs.js";
import { mergeEmergencyReportUrls, reportEmergencyContext } from "./emergency-reports.js";
import { createRecordRange, filterRecordItems, recordDate, recordInRange, reportQueryYears, vitalOptionInRange } from "./record-range.js";
import { buildOneClickPayload, canStopOneClick, canControlSyncFromPage, canReadSyncFromPage, canReadOutpatientPreflight, parseQemrPatientPage } from "./one-click.js";
import { completionMatches, createSyncActionUpdater } from "./sync-notifications.js";
import { authorizeDownloadAudit, prepareDownloadAudit } from "./download-audit.js";
import { selectOutpatientVisits, outpatientDetailPath } from "./outpatient.js";
import { installOutpatientPeer } from "./outpatient-peer.js";
import { verifyOutpatientIdentity, hasComparableOutpatientIdentity, reportIssuedToday, reportIssuedInRange, outpatientPageStep } from "./outpatient-integration.js";
import {
  HisRequestBlockedError,
  PAGE_REQUEST_TIMEOUT_MS,
  QEMR_REQUEST_POLICY,
  SyncAbortError,
  awaitWithSignal,
  mapWithConcurrency as pMapPool,
  createSyncAbortHandle,
  createRequestStartScheduler,
  delayWithSignal,
  fetchWithTimeout,
  isHisRequestBlockedError,
  isSyncAbortError,
  parseRetryAfterMs,
  readResponseBodyWithTimeout,
  shouldRecoverOrphanedStatus,
} from "./sync-runtime.js";

const STORAGE_KEY = "syncStatus";
const DEID_KEY_STORAGE_KEY = "deidentificationKey";
const updateSyncAction = createSyncActionUpdater(chrome.action);
let statusWrites = Promise.resolve();
let hasPublishedStatus = false;

// In-memory controller for the active sync. Persisted status is intentionally
// separate: Chrome may restart the service worker, so popup recovery must not
// assume `running: true` means this controller still exists.
let currentSyncAbort = null;
let currentHisBlockError = null;
let currentRawCapture = null;
let currentRecordRange = null;
let currentOutpatientMode = false;
let oneClickStartPending = false;

async function getOrCreateDeidentificationKey() {
  const stored = await chrome.storage.local.get(DEID_KEY_STORAGE_KEY);
  if (typeof stored[DEID_KEY_STORAGE_KEY] === "string" && stored[DEID_KEY_STORAGE_KEY].length >= 32) {
    return stored[DEID_KEY_STORAGE_KEY];
  }
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  const key = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  await chrome.storage.local.set({ [DEID_KEY_STORAGE_KEY]: key });
  return key;
}

const QEMR_HOST_RE = /(^|\.)vghtpe\.gov\.tw$|^(localhost|127\.0\.0\.1)$/;
const QEMR_CANONICAL_HOST = "web9.vghtpe.gov.tw";

// Pace starts globally even when detail workers overlap. Short regular
// pauses keep healthy traffic moving; server errors still trigger backoff.
const FETCH_POOL = QEMR_REQUEST_POLICY.concurrency;
// Outpatient details are independent; keep the shared request-start pacing.
const OUTPATIENT_FETCH_POOL = 4;
const QEMR_MAX_RETRIES = 2;
const QEMR_MAX_RETRY_AFTER_MS = 120_000;
const qemrRequestScheduler = createRequestStartScheduler();
let qemrRequestCompleted = 0;
let qemrEstimatedTotalRequests = 0;

function resetQemrRequestSchedule(listRequests = 16) {
  qemrRequestScheduler.reset();
  qemrRequestCompleted = 0;
  // Fixed list/index pages. Detail fan-outs are added as soon as each list is parsed.
  qemrEstimatedTotalRequests = listRequests;
}

function addExpectedQemrRequests(count) {
  qemrEstimatedTotalRequests += Math.max(0, Number(count) || 0);
}

function estimateQemrTotalSeconds(startedAt) {
  const elapsedSeconds = Math.max(0, (Date.now() - Number(startedAt || Date.now())) / 1_000);
  const totalRequests = Math.max(qemrEstimatedTotalRequests, qemrRequestScheduler.starts, 1);
  const remainingRequests = Math.max(0, totalRequests - qemrRequestCompleted);
  // Once enough samples exist, include real network/parser time. Clamp
  // early outliers so one slow login response does not produce a wild ETA.
  const policy = QEMR_REQUEST_POLICY;
  const pacedSecondsPerRequest = (policy.minStartIntervalMs + policy.startJitterMs / 2
    + (policy.batchPauseMs + policy.batchPauseJitterMs / 2) / policy.batchSize) / 1_000;
  const observedSecondsPerRequest = qemrRequestCompleted >= 3
    ? Math.min(5, Math.max(pacedSecondsPerRequest, elapsedSeconds / qemrRequestCompleted))
    : pacedSecondsPerRequest;
  // Observed throughput already includes batch pauses; do not add them twice.
  return Math.max(
    Math.ceil(elapsedSeconds),
    Math.ceil(elapsedSeconds + remainingRequests * observedSecondsPerRequest),
  );
}

function extendQemrCooldown(delayMs) {
  qemrRequestScheduler.extendCooldown(delayMs, true);
}

// Reserve one globally-spaced request start. The mutex is held only until the
// request starts, so up to FETCH_POOL requests may still be in flight.
async function waitForQemrRequestSlot(signal) {
  return qemrRequestScheduler.waitForSlot(signal);
}

const PATHS = {
  patient_homepage: (h) => `/emr/qemr/qemr.cfm?action=findEmr&histno=${h}`,
  // 病人基本資料 — same domain, more structured than the navbar. Carries
  // 身份證號 + address/phone.
  patient_basics:   (h) => `/emr/qemr/qemr.cfm?action=findPba&histno=${h}`,
  conditions:       (h) => `/emr/qemr/qemr.cfm?action=findPdiagHistory&histno=${h}`,
  inpatient_diagnoses: (h) => `/emr/qemr/qemr.cfm?action=findPdiags&histno=${h}`,
  encounters_list:  (h) => `/emr/qemr/qemr.cfm?action=findOpd&histno=${h}`,
  admissions_list:  (h) => `/emr/qemr/qemr.cfm?action=findAdm&histno=${h}`,
  emergency_list: (h) => `/emr/qemr/qemr.cfm?action=findErn&histno=${encodeURIComponent(h)}`,
  emergency_detail: (h, c) => `/emr/qemr/qemr.cfm?action=findErn&histno=${encodeURIComponent(h)}&caseno=${encodeURIComponent(c)}`,
  emergency_summary: (h, c) => `https://rkeprd.vghtpe.gov.tw/ERS/download/pdf?histno=${encodeURIComponent(h)}&caseno=${encodeURIComponent(c)}`,
  // Use supported relative windows; older selected years are queried separately.
  observations_list:(h, range) => `/emr/qemr/qemr.cfm?action=findRes&tdept=ALL&tmonth=${range?.years === "1" ? 12 : 24}&histno=${h}`,
  observations_year:(h, y) => `/emr/qemr/qemr.cfm?action=findRes&tdept=ALL&tmonth=${y}&histno=${encodeURIComponent(h)}`,
  medications_list: (h) => `/emr/qemr/qemr.cfm?action=findUd&histno=${h}`,
  // 手術記錄 — #opnlist has one row per surgery date; multiple procedures
  // per row are concatenated with <br> in the same cell.
  operations_list:  (h) => `/emr/qemr/qemr.cfm?action=findOpn&histno=${h}`,
  // findOpn detail uses dt=YYDDMMDD format (民國 with century prefix, e.g.
  // 01140814 = 民國114年8月14日). We just pass through whatever the list
  // page's <a href> said in dt=... so format quirks don't matter here.
  operations_detail:(h, dt) => `/emr/qemr/qemr.cfm?action=findOpn&histno=${h}&dt=${dt}&tm=1`,
  encounter_detail: (h, dt) => `/emr/qemr/qemr.cfm?action=findOpd&histno=${h}&dt=${dt}`,
};

function setStatus(partial, matches = () => true) {
  const write = statusWrites.then(() => publishStatus(partial, matches));
  statusWrites = write.catch(() => {});
  return write;
}

function refreshCaptureLauncher(tabId) {
  // Reloaded extensions leave old content scripts on already-open HIS pages.
  // Restore the current UI without reloading the chart or delaying capture.
  try {
    void chrome.scripting?.executeScript({
      target: { tabId, frameIds: [0] }, files: ["launcher.js"],
    })?.catch(() => {});
  } catch { /* Indicator failure must not interrupt the capture. */ }
}

async function publishStatus(partial, matches) {
  const prev = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] || {};
  if (!matches(prev)) return null;
  if (currentSyncAbort?.aborted && partial.running !== false) return;
  const next = { ...prev, ...partial, ts: Date.now() };
  if (next.running || !["done", "partial"].includes(next.phase)
      || prev.running || (partial.completed !== undefined && partial.completed !== prev.completed)) {
    next.completionSeen = false;
  }
  if (next.running && next.started) {
    next.estimatedTotalSeconds = estimateQemrTotalSeconds(next.started);
    next.requestProgress = {
      completed: qemrRequestCompleted,
      total: Math.max(qemrEstimatedTotalRequests, qemrRequestScheduler.starts),
    };
  }
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  hasPublishedStatus = true;
  void updateSyncAction(next);
  // Best-effort broadcast; popup may be closed.
  chrome.runtime.sendMessage({ type: "syncProgress", status: next }).catch(() => {});
  if (Number.isInteger(next.tabId)) {
    chrome.tabs.sendMessage(next.tabId, { type: "syncProgress", status: next }).catch(() => {});
  }
  return next;
}

async function assertQemrPatientStillActive(tabId, expectedHistno) {
  const tab = await chrome.tabs.get(tabId);
  const page = parseQemrPatientPage(tab.url || "");
  if (!page || page.histno !== expectedHistno) {
    throw Object.assign(new Error("院內病歷目前病人已切換，已停止本機交付"), { code: "PATIENT_HIS_MISMATCH" });
  }
}



function trustedHisRequestUrl(baseUrl, path, histno, opts) {
  if (typeof path !== "string" || !path.trim()) throw new Error("不可信的 HIS 請求連結");
  const base = new URL(baseUrl);
  const loopback = ["localhost", "127.0.0.1"].includes(base.hostname);
  if (!QEMR_HOST_RE.test(base.hostname) || (base.protocol !== "https:" && !(loopback && base.protocol === "http:"))) throw new Error("不可信的 HIS 請求來源");
  const url = new URL(path, new URL("/emr/qemr/qemr.cfm", base));
  const pdfEndpoint = url.origin === "https://rkeprd.vghtpe.gov.tw" && url.pathname === "/ERS/download/pdf";
  const knownPdf = pdfEndpoint && opts.emergencySummary === true && histno != null && url.searchParams.has("histno");
  if (pdfEndpoint && !knownPdf) throw new Error("不可信的跨系統 HIS 請求");
  const knownExternal = knownPdf;
  if (url.username || url.password || (url.origin !== base.origin && !knownExternal)
      || !["https:", "http:"].includes(url.protocol)) throw new Error("不可信的 HIS 請求連結");
  if (!knownExternal && url.pathname !== "/emr/qemr/qemr.cfm") throw new Error("不可信的 HIS 請求路徑");
  const params = [...url.searchParams.entries()];
  const ids = params.filter(([key]) => key.toLowerCase() === "histno").map(([,value]) => value);
  if (url.pathname.toLowerCase() === "/emr/qemr/qemr.cfm" && ids.length !== 1) {
    throw new Error("HIS 連結缺少唯一可確認的病人識別");
  }
  for (const field of ["action", "histno", "caseno", "reqno", "ordseq", "ordclnm", "treqno", "tseqno", "partno", "dt", "frpdt", "pbvtype"]) {
    const entries=params.filter(([key]) => key.toLowerCase() === field);
    if (entries.length > 1) throw new Error("HIS 連結含重複報告識別欄位");
    if (field !== "ordclnm" && entries.some(([,value]) => /[^\x00-\x7f]/.test(value))) throw new Error("HIS 連結識別欄位無法可靠解碼");
  }
  if (ids.length && (ids.length !== 1 || histno == null || ids[0] !== String(histno))) throw new Error("HIS 請求病人不符");
  // ColdFusion query names are case-insensitive. Canonicalize only the qemr
  // endpoint. Keep raw values byte-for-byte: legacy HIS values can be Big5
  // percent escapes that URLSearchParams cannot losslessly decode as UTF-8.
  if (!knownExternal) {
    url.search = url.search.slice(1).split("&").map(part => {
      const separator=part.indexOf("="), rawKey=separator < 0 ? part : part.slice(0,separator);
      const key=[...new URLSearchParams(`${rawKey}=`).keys()][0] || "";
      return encodeURIComponent(key.toLowerCase()) + (separator < 0 ? "" : part.slice(separator));
    }).join("&");
  }
  return url.href;
}

function trustedReportUrl(baseUrl, path, histno) {
  const url = trustedHisRequestUrl(baseUrl, path, histno, {});
  if (urlParam(url, "action") !== "findRes") throw new Error("報告清單連結不是檢驗報告");
  return url;
}

function hasLossyReportDescription(url) {
  return [...new URL(url, "https://qemr.invalid").searchParams]
    .some(([key,value]) => key.toLowerCase() === "ordclnm" && value.includes("\uFFFD"));
}

function trustedVitalUrl(baseUrl, date, type, histno) {
  const url = trustedHisRequestUrl(baseUrl, date.v + type.v + `&histno=${histno}`, histno, {});
  if (urlParam(url,"action") !== "findVts" || !urlParam(url,"caseno") || !urlParam(url,"pbvtype")) {
    throw new Error("無法確認生命徵象請求連結");
  }
  return url;
}

async function fetchPage(baseUrl, path, opts = {}) {
  // Accepts either a relative path (joined with baseUrl) or an absolute URL
  // (used for the explicitly validated emergency PDF endpoint).
  const url = trustedHisRequestUrl(baseUrl, path, opts.requestState?.histno ?? currentSyncAbort?.context?.histno, opts);
  const requestHost = new URL(url).hostname;
  // Identity preflight precedes the capture controller and owns its stop
  // state. An old/cancelled preflight cannot stop or unlock a newer capture.
  const requestState = opts.requestState;
  const signal = opts.signal || (requestState ? requestState.signal : currentSyncAbort?.signal);
  const stopError = () => requestState ? requestState.error : currentHisBlockError;
  for (let attempt = 0; attempt <= QEMR_MAX_RETRIES; attempt++) {
    if (signal?.aborted) throw new SyncAbortError();
    if (stopError()) throw stopError();
    await waitForQemrRequestSlot(signal);
    if (signal?.aborted) throw new SyncAbortError();
    if (stopError()) throw stopError();
    let res;
    try {
      res = await fetchWithTimeout(fetch, url, {
        credentials: "include",
        redirect: "error",
        ...(opts.method ? { method: opts.method } : {}),
        ...(opts.body ? { body: opts.body, headers: { "Content-Type": "application/x-www-form-urlencoded" } } : {}),
      }, { timeoutMs: PAGE_REQUEST_TIMEOUT_MS, signal });
    } finally {
      qemrRequestCompleted++;
    }
    if (res.ok) {
      if (opts.binary) {
        const buffer = await readResponseBodyWithTimeout(res, "arrayBuffer", {
          timeoutMs: PAGE_REQUEST_TIMEOUT_MS, signal,
        });
        const bytes = new Uint8Array(buffer);
        if (String.fromCharCode(...bytes.subarray(0, 5)) !== "%PDF-") {
          throw new Error("急診摘要回應不是 PDF（可能是登入頁或錯誤頁）");
        }
        if (currentRawCapture && !currentRawCapture.has(url)) {
          currentRawCapture.set(url, { path, bytes, contentType: "application/pdf", method: opts.method || "GET" });
        }
        return bytes;
      }
      const text = await readResponseBodyWithTimeout(res, "text", {
        timeoutMs: PAGE_REQUEST_TIMEOUT_MS,
        signal,
      });
      if (currentRawCapture && !currentRawCapture.has(url)) {
        currentRawCapture.set(url, { path, html: text });
      }
      console.log(`[fetch] ${path.slice(0, 80)} → ${text.length} bytes`);
      return text;
    }

    const retryable = res.status === 429 || res.status === 502
      || res.status === 503 || res.status === 504;
    const retryAfterMs = Math.min(
      parseRetryAfterMs(res.headers.get("Retry-After")) || 0,
      QEMR_MAX_RETRY_AFTER_MS,
    );
    if (retryable && attempt < QEMR_MAX_RETRIES) {
      addExpectedQemrRequests(1);
      const backoffMs = retryAfterMs || (5_000 * (2 ** attempt))
        + Math.floor(Math.random() * 1_000);
      // Cool down the shared scheduler, not only this worker. Otherwise the
      // other pool workers would keep sending while this worker backs off.
      extendQemrCooldown(backoffMs);
      console.warn(`[fetch] HTTP ${res.status}; cooling down ${backoffMs}ms before retry ${attempt + 1}`);
      await delayWithSignal(backoffMs, signal);
      continue;
    }

    // A 403 from the main qemr host commonly means a session/WAF rejection.
    // Abort instead of swallowing it and hammering every remaining detail URL.
    if (retryable || (res.status === 403 && requestHost !== "rkeprd.vghtpe.gov.tw")) {
      if (retryAfterMs) extendQemrCooldown(retryAfterMs);
      const blockedError = new HisRequestBlockedError(res.status, retryAfterMs || null);
      if (requestState) requestState.error = blockedError;
      else currentHisBlockError = blockedError;
      // Availability failures stop further HIS requests, but do not mean
      // the user cancelled or that verified data already captured is invalid.
      // A session/authorization refusal still fails closed.
      if (res.status === 403 && !requestState) currentSyncAbort?.abort();
      throw blockedError;
    }
    throw new Error(`${res.status} ${path.slice(0, 60)}`);
  }
  throw new Error(`request failed: ${path.slice(0, 60)}`);
}

function fetchEmergencySummary(baseUrl, histno, caseNo) {
  return fetchPage(baseUrl, PATHS.emergency_summary(histno, caseNo), {
    binary: true, emergencySummary: true, method: "POST", body: new URLSearchParams({ btn_er: "摘要" }).toString(),
  });
}

// Inject the parser into the qemr tab and call __vghParse(pageType, html).
// The parser script is idempotent — re-injecting is cheap (early-returns).
async function parseInTab(tabId, pageType, html, opts, signal = currentSyncAbort?.signal) {
  await awaitWithSignal(chrome.scripting.executeScript({
    target: { tabId },
    files: ["qemr-parser.js"],
  }), signal);
  const [{ result }] = await awaitWithSignal(chrome.scripting.executeScript({
    target: { tabId },
    func: (pt, h, o) => {
      if (!window.__vghParse) return { __error: "qemr-parser.js failed to attach __vghParse" };
      try {
        return window.__vghParse(pt, h, o);
      } catch (e) {
        return { __error: `parser threw: ${e.message}` };
      }
    },
    args: [pageType, html, opts || {}],
  }), signal);
  if (result && result.__error) throw new Error(result.__error);
  // Log shape so the SW console shows what each parse produced.
  const summary = Array.isArray(result)
    ? `array len=${result.length}`
    : (result && typeof result === "object")
      ? Object.entries(result).map(([k, v]) => `${k}=${Array.isArray(v) ? v.length : typeof v}`).join(", ")
      : String(result);
  console.log(`[parse] ${pageType} → ${summary}`);
  const rangeTypes = {
    conditions: "conditions", inpatient_diagnoses: "conditions", inpatient_diagnoses_index: "admission_index",
    emergency_list: "encounters", medications_detail: "medications", operations_list: "procedures",
    summary_list: "document_references", summary_detail: "document_references",
    implants: "devices", chemo_list: "procedures", chemo_detail: "procedures", careplans: "careplans", vitals: "vitals",
  };
  if (pageType === "vitals" && Array.isArray(result?.items)) return { ...result, items: filterRecordItems("vitals",result.items,currentRecordRange) };
  return rangeTypes[pageType] ? filterRecordItems(rangeTypes[pageType], result, currentRecordRange) : result;
}

async function readReportIndex(tabId, html, baseUrl, histno, signal) {
  const parsed = await parseInTab(tabId, "record_index", html, { action: "findRes" }, signal);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {links:[],years:[],valid:false};
  // Keep validated rows/years even when another member is malformed. The
  // caller reports partial coverage from this flag without losing good rows.
  let valid = parsed.valid === undefined || parsed.valid === true;
  if (!Array.isArray(parsed.links) || (parsed.years !== undefined && !Array.isArray(parsed.years))) valid = false;
  const years = (Array.isArray(parsed.years) ? parsed.years : []).flatMap(year => {
    if (!["string", "number"].includes(typeof year) || !/^[1-9]\d{3}$/.test(String(year))) { valid = false; return []; }
    return [Number(year)];
  });
  const links = (Array.isArray(parsed.links) ? parsed.links : []).flatMap(link => {
    try {
    if (!link || typeof link !== "object" || Array.isArray(link) || typeof link.href !== "string" || !link.href.trim()) throw new Error("報告清單連結格式錯誤");
    const url = new URL(trustedReportUrl(baseUrl, link.href, histno));
    for (const key of ["date", "report_date", "updated_date"]) {
      if (link[key] != null && typeof link[key] !== "string") throw new Error("報告清單日期格式錯誤");
    }
    return [{ ...link, href: url.href }];
    } catch { valid = false; return []; }
  });
  return { links, years, valid };
}

async function readReportDetail(tabId, html, context, patientId, signal) {
  const parsed = await parseInTab(tabId, "observations_detail", html, context, signal);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("報告詳情無法解析");
  let mappedCount = 0;
  for (const type of ["observations", "diagnostic_reports", "procedures"]) {
    const items = parsed[type];
    if (items === undefined) continue;
    if (!Array.isArray(items) || items.some(item => !item || typeof item !== "object" || Array.isArray(item))) {
      throw new Error("報告詳情格式錯誤");
    }
    // Validate this report before adding it to a shared capture. A malformed
    // row or mapper exception must not discard another report's valid rows.
    mappedCount += mapPageType(type, items, patientId).length;
  }
  if (!mappedCount) throw new Error("報告詳情沒有可解析的結果");
  return parsed;
}



// Append a completed sync to the rolling history log (kept in chrome.storage,
// newest first, capped). Powers the popup's "同步紀錄" panel.
async function appendSyncHistory(entry, matches = () => true) {
  const KEY = "syncHistory";
  const prev = (await chrome.storage.local.get(KEY))[KEY] || [];
  if (!matches()) return;
  const next = [entry, ...prev.filter(previous => !entry.runId || previous?.runId !== entry.runId)].slice(0, 20);
  await chrome.storage.local.set({ [KEY]: next });
}

function parseDetailUrls(html, action) {
  // Capture detail-page hrefs (findUd or findRes with caseno=) from list pages.
  const wrapMatch = html.match(/<table[^>]*id="(caselist|reslist)"[\s\S]*?<\/table>/);
  const sub = wrapMatch ? wrapMatch[0] : html;
  const urls = new Set();
  // Match the full action value so findRes cannot also select findResd links.
  const rx = new RegExp(`href="([^"]*action=${action}(?=&)[^"]*caseno=[^"]+)"`, "g");
  for (const m of sub.matchAll(rx)) {
    urls.add(m[1].replace(/&amp;/g, "&"));
  }
  return [...urls];
}

async function captureDetailIndex(tabId, html, action, range, encounterItems = [], warn = () => {}) {
  if (!html) return { links: [], years: [] };
  let index;
  try { index = await parseInTab(tabId, "record_index", html, { action }); }
  catch (error) {
    if (isSyncAbortError(error) || isHisRequestBlockedError(error) || error?.message === "PATIENT_HIS_MISMATCH") throw error;
    warn("無法解析用藥清單，已略過該清單");
    return { links: [], years: [] };
  }
  if (index?.valid === false) warn("無法確認完整用藥清單，已保留可驗證項目");
  if (index && !Array.isArray(index) && !Array.isArray(index.links)) warn("用藥清單格式無法確認，已改用可辨識連結");
  // The fallback also keeps old cached/test parsers working; unknown dates
  // are retained and checked again after parsing the detail page.
  const links = Array.isArray(index?.links) ? index.links : parseDetailUrls(html, action).map(href => ({ href }));
  return {
    links: links.filter(link => {
      if (!link || typeof link.href !== "string" || urlParam(link.href,"action") !== action || (link.date != null && typeof link.date !== "string")) {
        warn("用藥清單含無法解析項目，已略過該筆"); return false;
      }
      // Medication lists can date an inpatient case by admission, while its
      // individual orders are much later. Keep overlapping stays for parsing.
      const admission = action === "findUd" && encounterItems.find(item =>
        item.class === "IMP" && item.case_no && item.case_no === urlParam(link.href, "caseno"));
      if (admission && recordInRange("encounters", admission, range)) return true;
      return recordInRange("observations", { date: link.date || urlParam(link.href, "dt") || urlParam(link.href, "frpdt") }, range);
    }),
    years: Array.isArray(index?.years) ? index.years : [],
  };
}

async function captureReportUrls(tabId, histno, recentHtml, range, encounterItems, fetchYear, baseUrl, warn) {
  const read = async html => {
    if (!html) return { links: [], years: [] };
    try {
      const index = await readReportIndex(tabId, html, baseUrl, histno);
      if (!index.valid) warn("無法確認檢查驗報告清單，已保留可驗證項目");
      return { ...index, links: index.links.filter(link => recordInRange("observations", {
        date: link.date || urlParam(link.href, "dt") || urlParam(link.href, "frpdt"),
      }, range)) };
    } catch (error) {
      if (isSyncAbortError(error) || isHisRequestBlockedError(error)
          || error?.message === "PATIENT_HIS_MISMATCH") throw error;
      warn("無法解析檢查驗報告清單，已略過該清單並保留其他來源");
      return { links: [], years: [] };
    }
  };
  const recent = await read(recentHtml);
  const years = reportQueryYears(range, recent.years, encounterItems);
  addExpectedQemrRequests(years.length);
  const links = [...recent.links];
  for (const year of years) {
    const html = await fetchYear(year, PATHS.observations_year(histno, year));
    const annual = await read(html);
    links.push(...annual.links);
  }
  return mergeEmergencyReportUrls(links.map(link => link.href), [], []);
}

function parseOpnDts(html) {
  // Surgery detail links live in #opnlist rows:
  // href="...action=findOpn&histno=...&dt=01140814&tm=1". Same pass-through
  // philosophy as PATHS.operations_detail — keep whatever dt format the list
  // page used.
  const wrap = html.match(/<table[^>]*id="opnlist"[\s\S]*?<\/table>/);
  const sub = wrap ? wrap[0] : html;
  const dts = new Set();
  for (const m of sub.matchAll(/action=findOpn[^"]*?(?:&amp;|&)dt=([^&"]+)/g)) {
    dts.add(m[1]);
  }
  return [...dts];
}

// ── Minimal ZIP writer (STORE, no compression) ────────────────────────────────
// The SW has no URL.createObjectURL and no zip library; a store-only zip is
// ~60 lines and every extractor can open it.

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function buildZip(files) {
  // files: [{name: string, data: Uint8Array}] → Uint8Array
  const encoder = new TextEncoder();
  const le16 = (v) => [v & 0xff, (v >>> 8) & 0xff];
  const le32 = (v) => [v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff];
  const DOS_DATE = 0x21; // 1980-01-01 — fixed so output is deterministic
  const chunks = [];
  const central = [];
  let offset = 0;
  for (const f of files) {
    const name = encoder.encode(f.name);
    const crc = crc32(f.data);
    // local file header: flags bit 11 = UTF-8 filenames, method 0 = store
    const header = new Uint8Array([
      ...le32(0x04034b50), ...le16(20), ...le16(0x0800), ...le16(0),
      ...le16(0), ...le16(DOS_DATE),
      ...le32(crc), ...le32(f.data.length), ...le32(f.data.length),
      ...le16(name.length), ...le16(0),
    ]);
    chunks.push(header, name, f.data);
    central.push({ name, crc, size: f.data.length, offset });
    offset += header.length + name.length + f.data.length;
  }
  const cdStart = offset;
  for (const e of central) {
    const rec = new Uint8Array([
      ...le32(0x02014b50), ...le16(20), ...le16(20), ...le16(0x0800), ...le16(0),
      ...le16(0), ...le16(DOS_DATE),
      ...le32(e.crc), ...le32(e.size), ...le32(e.size),
      ...le16(e.name.length), ...le16(0), ...le16(0), ...le16(0), ...le16(0),
      ...le32(0), ...le32(e.offset),
    ]);
    chunks.push(rec, e.name);
    offset += rec.length + e.name.length;
  }
  const end = new Uint8Array([
    ...le32(0x06054b50), ...le16(0), ...le16(0),
    ...le16(central.length), ...le16(central.length),
    ...le32(offset - cdStart), ...le32(cdStart), ...le16(0),
  ]);
  chunks.push(end);
  const out = new Uint8Array(offset + end.length);
  let pos = 0;
  for (const c of chunks) { out.set(c, pos); pos += c.length; }
  return out;
}

function u8ToBase64(u8) {
  let s = "";
  const CHUNK = 0x8000; // fromCharCode arg-count limit
  for (let i = 0; i < u8.length; i += CHUNK) {
    s += String.fromCharCode.apply(null, u8.subarray(i, i + CHUNK));
  }
  return btoa(s);
}

// ── One-click raw-HTML capture ────────────────────────────────────────────────
// Fetch every qemr page the sync flow uses (lists + all detail fan-outs) and
// download them as a single ZIP. All output stays local — this exists so
// we can build parser fixtures / debug against real pages offline.

const sanitizeSegment = (s) => String(s).replace(/[^A-Za-z0-9._-]+/g, "_");

function rawCaptureFilename(url, position, extension = "html") {
  const parsed = new URL(url);
  const action = sanitizeSegment(parsed.searchParams.get("action") || "page");
  const detailKeys = ["dt", "caseno", "pbvdate", "pbvtype"];
  const detail = detailKeys
    .map((key) => parsed.searchParams.get(key))
    .filter(Boolean)
    .map(sanitizeSegment)
    .join(".")
    .slice(0, 140);
  const label = parsed.pathname === "/ERS/download/pdf" ? "emergency-summary" : action;
  return `pages/${String(position + 1).padStart(4, "0")}.${label}${detail ? `.${detail}` : ""}.${extension}`;
}

export function urlParam(url, name) {
  try {
    const raw=String(url || "");
    const values = [...new URL(raw.startsWith("&") ? `?${raw.slice(1)}` : raw, "https://qemr.invalid/emr/qemr/qemr.cfm").searchParams]
      .filter(([key]) => key.toLowerCase() === name.toLowerCase()).map(([,value]) => value);
    return values.length === 1 && !values[0].includes("\uFFFD") ? values[0] : "";
  } catch { return ""; }
}

async function downloadRawCaptureZip(rawPages, histno, stamp, { errors = [], signal, onDownloadRequest = () => {} } = {}) {
  if (!rawPages?.size) return null;
  const encoder = new TextEncoder();
  const files = [];
  const manifest = [];
  let position = 0;
  for (const [url, captured] of rawPages) {
    const name = rawCaptureFilename(url, position++, captured.bytes ? "pdf" : "html");
    const data = captured.bytes || encoder.encode(captured.html);
    files.push({ name, data });
    manifest.push({ file: name, url, bytes: data.length,
      ...(captured.contentType ? { contentType: captured.contentType, method: captured.method } : {}),
    });
  }
  files.push({
    name: "capture-manifest.json",
    data: encoder.encode(JSON.stringify({
      tool: "EHR-FHIR Bridge Capture",
      kind: "raw-html-used-for-fhir",
      histno,
      recordRange: currentRecordRange,
      outpatientMode: currentOutpatientMode,
      capturedAt: new Date().toISOString(),
      encoding: "UTF-8 (re-encoded; ignore any Big5 <meta charset> inside the pages)",
      fileCount: manifest.length,
      partial: errors.length > 0,
      errors: [...errors],
      files: manifest,
    }, null, 2)),
  });
  const filename = `ehr-html-${histno}-${stamp}-v${chrome.runtime.getManifest().version}.zip`;
  if (signal?.aborted) throw new SyncAbortError();
  onDownloadRequest(filename);
  const downloadId = await chrome.downloads.download({
    url: `data:application/zip;base64,${u8ToBase64(buildZip(files))}`,
    filename,
    saveAs: false,
  });
  return { filename, downloadId };
}

async function runHtmlCapture({ tabId, host, baseUrl, histno, recordYears, outpatientMode = false }) {
  if (!QEMR_HOST_RE.test(host)) throw new Error(`unsupported host: ${host}`);
  const aborter = createSyncAbortHandle();
  aborter.context = { tabId, histno, mode: "html" };
  currentSyncAbort = aborter;
  refreshCaptureLauncher(tabId);
  currentHisBlockError = null;
  currentRawCapture = null;
  currentOutpatientMode = outpatientMode === true;
  currentRecordRange = createRecordRange(currentOutpatientMode ? "1" : recordYears);
  const range = currentRecordRange;
  resetQemrRequestSchedule(currentOutpatientMode ? 3 : 16);
  const encoder = new TextEncoder();
  const files = [];   // zip entries {name, data}
  const index = [];   // capture-manifest.json listing {file, url, bytes}
  const errors = [];
  const grab = async (label, name, path, opts = {}) => {
    try {
      const html = await fetchPage(baseUrl, path, opts);
      files.push({ name, data: encoder.encode(html) });
      index.push({ file: name, url: trustedHisRequestUrl(baseUrl, path, histno, opts), bytes: html.length });
      return html;
    } catch (e) {
      if (currentHisBlockError) throw currentHisBlockError;
      if (isSyncAbortError(e) || isHisRequestBlockedError(e)) throw e;
      errors.push(`${label}: ${e.message}`);
      console.warn(`htmlCapture "${label}":`, e);
      return null;
    }
  };

  await setStatus({
    running: true, progress: "📄 1/4 抓取清單頁…", phase: "html_capture",
    started: Date.now(), tabId, host, histno, mode: "html",
    totalResources: 0, breakdown: null, errors: [], recordRange: range, outpatientMode: currentOutpatientMode, outpatientVisits: null,
  });

  // ── list pages (same set runSync fetches) ──
  await prepareDownloadAudit({ tabId, baseUrl, histno, signal: aborter.signal,
    onProgress: progress => setStatus({ progress }) });
  await grab("homepage", "patient_homepage.findEmr.html", PATHS.patient_homepage(histno));
  await grab("pba", "patient_basics.findPba.html", PATHS.patient_basics(histno));
  if (currentOutpatientMode) {
    const listHtml = await grab("opd_list", "encounters_list.findOpd.html", PATHS.encounters_list(histno));
    if (listHtml) {
      const rows = await parseInTab(tabId, "encounters_list", listHtml);
      const selected = selectOutpatientVisits(rows, range);
      errors.push(...selected.warnings);
      await setStatus({ outpatientVisits: selected.visits.length });
      addExpectedQemrRequests(selected.visits.length);
      let done = 0;
      await pMapPool(selected.visits, OUTPATIENT_FETCH_POOL, async visit => {
        if (currentSyncAbort?.aborted) throw new SyncAbortError();
        try {
          const path = outpatientDetailPath(visit, histno, baseUrl);
          const name = `encounter_detail/findOpd.${sanitizeSegment(visit.date)}.${sanitizeSegment(visit.provider_id)}.${sanitizeSegment(visit.department_code)}.${sanitizeSegment(visit.visit_time)}.html`;
          const html = await grab(`outpatient ${visit.date}`, name, path);
          if (html) {
            const detail = await parseInTab(tabId, "outpatient_detail", html, visit);
            if (!detail?.encounters?.length) errors.push(`${visit.date} 門診未找到相符的 SOAP 分區`);
          }
        } catch (error) {
          if (isSyncAbortError(error) || isHisRequestBlockedError(error)) throw error;
          errors.push(`${visit.date} 門診：${error.message}`);
        }
        done++;
        await setStatus({ progress: `📄 門診版詳情 ${done}/${selected.visits.length}…`, phase: "html_capture" });
      });
    }
  } else {
    await grab("conditions", "conditions.findPdiagHistory.html", PATHS.conditions(histno));
    const encListHtml = await grab("opd_list", "encounters_list.findOpd.html", PATHS.encounters_list(histno));
    const admListHtml = await grab("adm_list", "admissions_list.findAdm.html", PATHS.admissions_list(histno));
    const erListHtml = await grab("emergency_list", "emergency/00_index.findErn.html", PATHS.emergency_list(histno));
    const opnListHtml = await grab("opn_list", "operations_list.findOpn.html", PATHS.operations_list(histno));
    const obsListHtml = await grab("obs_list", "observations_list.findRes.html", PATHS.observations_list(histno, range));
    const medListHtml = await grab("med_list", "medications_list.findUd.html", PATHS.medications_list(histno));
    const encounterItems = [];
    for (const html of [encListHtml, admListHtml]) if (html) {
      try { encounterItems.push(...await parseInTab(tabId, "encounters_list", html)); }
      catch (e) { errors.push(`encounters_list: ${e.message}`); }
    }

    if (erListHtml) {
      let cases = [];
      try {
        const parsed = await parseInTab(tabId, "emergency_list", erListHtml);
        cases = Array.isArray(parsed) ? parsed : [];
      }
      catch (e) { errors.push(`emergency_list: ${e.message}`); }
      encounterItems.push(...cases);
      addExpectedQemrRequests(cases.length + cases.filter((meta) => meta.summary_available).length);
      await pMapPool(cases, FETCH_POOL, async (meta) => {
        const prefix = `emergency/findErn.caseno-${sanitizeSegment(meta.case_no)}`;
        await grab(`emergency ${meta.case_no}`, `${prefix}.html`, PATHS.emergency_detail(histno, meta.case_no));
        if (!meta.summary_available) return;
        try {
          const bytes = await fetchEmergencySummary(baseUrl, histno, meta.case_no);
          files.push({ name: `${prefix}.summary.pdf`, data: bytes });
          index.push({ file: `${prefix}.summary.pdf`, url: PATHS.emergency_summary(histno, meta.case_no),
            bytes: bytes.length, contentType: "application/pdf", method: "POST" });
        } catch (e) {
          if (currentHisBlockError) throw currentHisBlockError;
          if (isSyncAbortError(e) || isHisRequestBlockedError(e)) throw e;
          errors.push(`emergency summary ${meta.case_no}: ${e.message}`);
        }
      });
    }

    // The default table and per-case responses can contain different rows.
    addExpectedQemrRequests(1);
    const diagnosisIndexHtml = await grab("inpatient_diagnoses", "inpatient_diagnoses/00_index.findPdiags.html", PATHS.inpatient_diagnoses(histno));
    if (diagnosisIndexHtml) {
      let cases = [];
      try { cases = await parseInTab(tabId, "inpatient_diagnoses_index", diagnosisIndexHtml); }
      catch (e) { errors.push(`inpatient_diagnoses_index: ${e.message}`); }
      encounterItems.push(...cases.map(meta => ({ ...meta, class: "IMP", date: meta.admit_date, end_date: meta.discharge_date })));
      addExpectedQemrRequests(cases.length);
      await pMapPool(cases, FETCH_POOL, async (meta) => {
        await grab(`inpatient diagnoses ${meta.case_no}`,
          `inpatient_diagnoses/findPdiags.caseno-${sanitizeSegment(meta.case_no)}.html`, meta.href);
      });
    }

    // ── encounter SOAP details ──
    const allOpdVisits = selectOutpatientVisits(encounterItems, range, false).visits;
    addExpectedQemrRequests(allOpdVisits.length);
    for (let i = 0; i < allOpdVisits.length; i++) {
      const visit = allOpdVisits[i];
      await setStatus({ progress: `📄 2/4 門診詳情 ${i + 1}/${allOpdVisits.length}…`, phase: "html_capture" });
      const path = visit.detail_href && visit.provider_id ? outpatientDetailPath(visit, histno, baseUrl) : PATHS.encounter_detail(histno, visit.date.replaceAll("-", ""));
      await grab(`enc ${visit.date}`, `encounter_detail/findOpd.${sanitizeSegment(visit.date)}.${sanitizeSegment(visit.encounter_id || "")}.html`, path);
    }

    // ── surgery details ──
    let opnDts = [];
    if (opnListHtml) {
      try { opnDts = [...new Set((await parseInTab(tabId, "operations_list", opnListHtml)).map(item => item._dt).filter(Boolean))]; }
      catch (e) { errors.push(`operations_list: ${e.message}`); }
    }
    addExpectedQemrRequests(opnDts.length);
    for (let i = 0; i < opnDts.length; i++) {
      const dt = opnDts[i];
      await setStatus({ progress: `📄 2/4 手術詳情 ${i + 1}/${opnDts.length}…`, phase: "html_capture" });
      await grab(`opn ${dt}`, `operations_detail/findOpn.dt-${sanitizeSegment(dt)}.html`, PATHS.operations_detail(histno, dt));
    }

    // ── medication details ──
    const medUrls = (await captureDetailIndex(tabId, medListHtml, "findUd", range, encounterItems, message => errors.push(message))).links.map(link => link.href);
    addExpectedQemrRequests(medUrls.length);
    for (let i = 0; i < medUrls.length; i++) {
      await setStatus({ progress: `📄 3/4 用藥詳情 ${i + 1}/${medUrls.length}…`, phase: "html_capture" });
      const caseno = urlParam(medUrls[i], "caseno");
      const name = `medications_detail/findUd.${String(i + 1).padStart(3, "0")}${caseno ? `.caseno-${sanitizeSegment(caseno)}` : ""}.html`;
      const medHtml = await grab(`med ${i}`, name, medUrls[i]);
      if (!medHtml) continue;
      let meds = [];
      try { meds = await parseInTab(tabId, "medications_detail", medHtml); }
      catch (e) { errors.push(`med_parse ${i}: ${e.message}`); }
      const noteUrls = [...new Set((meds || []).map((m) => m.detail_href).filter(Boolean))];
      addExpectedQemrRequests(noteUrls.length);
      for (let j = 0; j < noteUrls.length; j++) {
        const caseNo = urlParam(noteUrls[j], "caseno");
        const orderSeq = urlParam(noteUrls[j], "ordseq");
        const noteName = `medications_detail/notes/findUd.caseno-${sanitizeSegment(caseNo)}.ordseq-${sanitizeSegment(orderSeq || j + 1)}.html`;
        await grab(`med note ${i}/${j}`, noteName, noteUrls[j]);
      }
    }

    // ── observation/report details ──
    const obsUrls = await captureReportUrls(tabId, histno, obsListHtml, range, encounterItems, (year, path) =>
      grab(`reports ${year}`, `observations_list/findRes.year-${year}.html`, path), baseUrl, message => errors.push(message));
    addExpectedQemrRequests(obsUrls.length);
    for (let i = 0; i < obsUrls.length; i++) {
      await setStatus({ progress: `📄 4/4 報告詳情 ${i + 1}/${obsUrls.length}…`, phase: "html_capture" });
      const caseno = urlParam(obsUrls[i], "caseno");
      const name = `observations_detail/findRes.${String(i + 1).padStart(3, "0")}${caseno ? `.caseno-${sanitizeSegment(caseno)}` : ""}.html`;
      await grab(`obs ${i}`, name, obsUrls[i]);
    }

    // ── 生命徵象 findVts（就醫紀錄 × 量測類型，不查全部期間）──
    const vtsIndexHtml = await grab("vts_index", "vitals/00_index.findVts.html",
      `/emr/qemr/qemr.cfm?action=findVts&histno=${histno}`);
    if (vtsIndexHtml) {
      let vtsIndex = null;
      try { vtsIndex = await parseInTab(tabId, "vitals_index", vtsIndexHtml); }
      catch (e) { errors.push(`vts_index: ${e.message}`); }
      if (vtsIndex?.dates?.length && vtsIndex?.types?.length) {
        const vtasks = [];
        const seenVitalKeys = new Set();
        for (const date of vtsIndex.dates.filter(option => vitalOptionInRange(option, range, encounterItems))) {
          if (!urlParam(date.v, "caseno")) { errors.push("無法確認生命徵象病歷編號，已略過該筆"); continue; }
          for (const type of vtsIndex.types) {
            try {
              const url=trustedVitalUrl(baseUrl,date,type,histno), key=`${urlParam(url,"caseno")}|${urlParam(url,"pbvtype")}`;
              if (!seenVitalKeys.has(key)) { seenVitalKeys.add(key); vtasks.push({date,type,url}); }
            }
            catch { errors.push("無法確認生命徵象請求連結，已略過該筆"); }
          }
        }
        addExpectedQemrRequests(vtasks.length);
        let vDone = 0;
        await pMapPool(vtasks, FETCH_POOL, async ({ date, type, url }) => {
          const dtag = sanitizeSegment((date.t || "").split(" ")[0]);
          const nm = `vitals/${dtag}.${sanitizeSegment(urlParam(url,"caseno"))}.${sanitizeSegment(type.t)}.html`;
          await grab(`vts ${type.t}`, nm, url, { skipEmpty: true });
          vDone++;
          if (vDone % 10 === 0 || vDone === vtasks.length) {
            await setStatus({ progress: `📄 生命徵象 ${vDone}/${vtasks.length}…`, phase: "html_capture" });
          }
        });
      }
    }

    // ── 化療計畫 findChem (清單 + 每週期 regimen) + 癌症治療計畫書 findPbc ──
    await grab("pbc", "oncology/careplans.findPbc.html", `/emr/qemr/qemr.cfm?action=findPbc&histno=${histno}`);
    const chemListHtml = await grab("chem_list", "oncology/00_chem_list.findChem.html", `/emr/qemr/qemr.cfm?action=findChem&histno=${histno}`);
    if (chemListHtml) {
      let cycles = [];
      try { cycles = await parseInTab(tabId, "chemo_list", chemListHtml); } catch (e) { errors.push(`chem_list: ${e.message}`); }
      for (let i = 0; i < (cycles || []).length; i++) {
        const cyc = cycles[i];
        await setStatus({ progress: `📄 化療計畫 ${i + 1}/${cycles.length}…`, phase: "html_capture" });
        await grab(`chem ${cyc.date}`, `oncology/chem_${String(i + 1).padStart(2, "0")}.${sanitizeSegment(cyc.date)}.html`, cyc.href);
      }
    }

    // ── 出院病摘 + 人工植入物 ──
    await grab("implants", "implants.findImplant.html", `/emr/qemr/qemr.cfm?action=findImplant&histno=${histno}`);
    for (const s of [
      { docType: "discharge", action: "findDis", dir: "discharge_summary" },
    ]) {
      const listHtml = await grab(`${s.docType}_list`, `${s.dir}/00_list.${s.action}.html`,
        `/emr/qemr/qemr.cfm?action=${s.action}&histno=${histno}`);
      if (!listHtml) continue;
      let listItems = [];
      try { listItems = await parseInTab(tabId, "summary_list", listHtml, { doc_type: s.docType }); } catch (e) { errors.push(`${s.docType}_list: ${e.message}`); }
      for (let i = 0; i < (listItems || []).length; i++) {
        const meta = listItems[i];
        await setStatus({ progress: `📄 出院病摘 ${i + 1}/${listItems.length}…`, phase: "html_capture" });
        const nm = `${s.dir}/${String(i + 1).padStart(3, "0")}.${sanitizeSegment(meta.admit_date || "")}.html`;
        await grab(`${s.docType} ${i}`, nm, meta.href);
      }
    }
  }
  if (aborter.signal.aborted) throw new SyncAbortError();
  // Raw ZIP is a complete debugging capture and has no final identity recheck;
  // a service stop conservatively prevents delivery rather than exporting partial PHI.
  if (currentHisBlockError) throw currentHisBlockError;
  if (!index.length) {
    throw new Error(`沒有抓到任何 HTML${errors.length ? `（${errors[0]}）` : ""}`);
  }

  // capture-manifest.json — what was fetched, from where. Note: files are
  // UTF-8 (re-encoded from the browser's decoded text); original pages may
  // declare Big5 in a <meta>, so open them as UTF-8.
  files.push({
    name: "capture-manifest.json",
    data: encoder.encode(JSON.stringify({
      tool: "EHR-FHIR Bridge Capture",
      kind: "raw-html-capture",
      histno, host, baseUrl,
      capturedAt: new Date().toISOString(),
      recordRange: range,
      outpatientMode: currentOutpatientMode,
      encoding: "UTF-8 (re-encoded; ignore any Big5 <meta charset> inside the pages)",
      fileCount: index.length,
      errors,
      files: index,
    }, null, 2)),
  });

  await setStatus({ progress: "📦 打包 ZIP…", phase: "html_capture" });
  const stamp = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  const zipName = `ehr-html-${histno}-${stamp}-v${chrome.runtime.getManifest().version}.zip`;
  const zip = buildZip(files);
  if (aborter.signal.aborted) throw new SyncAbortError();
  if (currentHisBlockError) throw currentHisBlockError;
  await chrome.downloads.download({
    url: `data:application/zip;base64,${u8ToBase64(zip)}`,
    filename: zipName,
    saveAs: false,
  });

  await setStatus({
    running: false,
    progress: `✅ 已下載 ${zipName} — ${index.length} 個 HTML${errors.length ? `（${errors.length} 個頁面失敗）` : ""}`,
    phase: errors.length ? "partial" : "done",
    completed: Date.now(), errors,
  });
  currentSyncAbort = null;
}

// Enumerate individual findVts cases × measurement types, excluding the
// aggregate all-periods option. Retain the earliest row per case + type,
// including all values on that row (e.g. BP + pulse, height + weight).
async function captureVitals(tabId, baseUrl, histno, swallow, setProg, aborter, range, encounterItems, warn) {
  const indexHtml = await swallow("vts_index", () => fetchPage(baseUrl, `/emr/qemr/qemr.cfm?action=findVts&histno=${histno}`));
  if (!indexHtml) return [];
  const index = await swallow("parse_vts_index", () => parseInTab(tabId, "vitals_index", indexHtml));
  if (!index || !index.dates?.length || !index.types?.length) return [];

  const tasks = [];
  const seenVitalKeys = new Set();
  for (const date of index.dates) {
    if (!vitalOptionInRange(date, range, encounterItems)) continue;
    const caseNo = urlParam(date.v, "caseno");
    if (!caseNo) { warn("無法確認生命徵象病歷編號，已略過該筆"); continue; }
    if (caseNo.toLowerCase() === "all") continue;
    for (const type of index.types) {
      try {
        const url=trustedVitalUrl(baseUrl,date,type,histno), key=`${caseNo}|${urlParam(url,"pbvtype")}`;
        if (!seenVitalKeys.has(key)) { seenVitalKeys.add(key); tasks.push({date,type,caseNo,url}); }
      }
      catch { warn("無法確認生命徵象請求連結，已略過該筆"); }
    }
  }
  addExpectedQemrRequests(tasks.length);

  const items = [];
  let done = 0;
  await pMapPool(tasks, FETCH_POOL, async ({ date, type, caseNo, url }) => {
    if (aborter.aborted) return;
    const typeCode = urlParam(url, "pbvtype");
    const html = await swallow(`vts ${type.t}`, () => fetchPage(baseUrl, url));
    done++;
    if (done % 10 === 0 || done === tasks.length) await setProg(`🫀 生命徵象 ${done}/${tasks.length}…`);
    if (!html) return;
    const parsed = await swallow(`parse_vts ${type.t}`, () => parseInTab(tabId, "vitals", html, { type: typeCode, recordRange: range, withParseStatus:true }));
    const rows = Array.isArray(parsed) ? parsed : parsed?.items;
    if (parsed?.incomplete) warn("生命徵象頁含無法解析列，擷取可能不完整");
    else if (Array.isArray(rows) && !rows.length && !["parsed","empty"].includes(parsed?.parseStatus)) warn("生命徵象頁無法解析，未確認為無資料回應");
    if (Array.isArray(rows)) {
      let unusable = false;
      let partialValues = false;
      for (const row of [...rows].sort((a,b) => String(a?.datetime).localeCompare(String(b?.datetime)))) {
        try {
          if (!mapPageType("vitals",[row],histno).length) { if (hasUnmappedVitalValue(row)) unusable = true; continue; }
          if (hasUnmappedVitalValue(row)) partialValues = true;
          items.push({ ...row, case_no: caseNo });
          break; // Later rows are outside the established first-reading contract.
        } catch { unusable = true; }
      }
      if (unusable) warn("生命徵象列沒有可解析量測，已略過該列");
      if (partialValues) warn("生命徵象部分非空量測無法解析，已保留可解析值");
    }
  });

  // Preserve separate same-day visits. Also enforce the first-reading rule
  // if a tab still has an older parser attached that returns multiple rows.
  const firstByCase = new Map();
  for (const it of items) {
    const k = `${it.case_no}|${it.type}`;
    const first = firstByCase.get(k);
    if (!first || it.datetime < first.datetime) firstByCase.set(k, it);
  }
  const uniq = [...firstByCase.values()];
  console.log(`[vts] first vital signs per case/type: ${uniq.length} readings from ${tasks.length} requests`);
  return uniq;
}

export async function runSync({ tabId, host, baseUrl, histno, mode, deidentify, syncRunId, includeHtmlZip, recordYears, outpatientMode = false, expectedIdentity, outpatientOwner, reportCoverageSupported = false, onClinicReady }, aborter = createSyncAbortHandle()) {
  if (!["download", "outpatient-peer"].includes(mode)) throw new Error("不支援的取得模式，請重新開啟擴充功能後使用本機下載。");
  if (!QEMR_HOST_RE.test(host)) throw new Error(`unsupported host: ${host}`);
  if (aborter.aborted) throw new SyncAbortError();
  if (mode === "outpatient-peer") refreshCaptureLauncher(tabId);
  aborter.context = { tabId, histno, mode, ...(outpatientOwner ? { outpatientOwner } : {}) };
  currentSyncAbort = aborter;
  const deid = !!deidentify;
  if (deid && includeHtmlZip) {
    throw new Error("原始 HTML 含可識別病歷資料，不能與去識別化 Bundle 一起下載");
  }
  const deidKey = deid ? await getOrCreateDeidentificationKey() : null;
  // One id for status, cancellation ownership and delivery history.
  const runId = syncRunId || `run-${Date.now()}-${histno}`;
  aborter.context.runId = runId;

  currentHisBlockError = null;
  currentRawCapture = includeHtmlZip ? new Map() : null;
  currentOutpatientMode = outpatientMode === true;
  const independentReports = mode === "outpatient-peer" && currentOutpatientMode && reportCoverageSupported === true;
  currentRecordRange = createRecordRange(currentOutpatientMode ? "1" : recordYears);
  const range = currentRecordRange;
  resetQemrRequestSchedule(currentOutpatientMode ? 3 : 16);
  const checkAbort = () => { if (aborter.aborted) throw new SyncAbortError(); };

  await chrome.storage.local.remove("pendingDownload");
  await setStatus({
    running: true, progress: "啟動 sync…", phase: "init",
    runId, fhirDownloadStarted: false, fhirDownloadId: null, deliveredFile: null, htmlCancelled: false,
    htmlDownloadRequested: false, htmlDownloadStarted: false, htmlDownloadId: null, htmlZipName: null,
    started: Date.now(), totalResources: 0, tabId, host, histno,
    mode, deidentify: deid, errors: [], recordRange: range, outpatientMode: currentOutpatientMode, outpatientVisits: null,
    reportCoverage: null,
  });

  const errors = [];
  const swallow = async (label, fn) => {
    try { return await fn(); }
    catch (e) {
      if (currentHisBlockError?.status === 403) throw currentHisBlockError;
      if (isSyncAbortError(e)) throw e;
      const blocked = currentHisBlockError || e;
      if (isHisRequestBlockedError(blocked)) {
        if (![429, 502, 503, 504].includes(blocked.status)) throw blocked;
        const notice = "北榮服務暫時忙碌或無法處理請求，已停止後續查詢；保留已取得資料，報告涵蓋範圍不完整";
        if (!errors.includes(notice)) errors.push(notice);
        return null;
      }
      errors.push(`${label}: ${e.message}`);
      console.warn(`sync "${label}":`, e);
      return null;
    }
  };
  const setProg = (progress, extra) => setStatus({ progress, ...(extra || {}) });

  // Backend-mode bookkeeping: unique upserted ids per type, and the set of
  // All parsed items are mapped locally after capture.
  let total = 0;
  const captures = [];
  const patientDict = {}; // merged navbar + findPba dicts → one Patient
  const encounterListItems = [];
  let outpatientVisitCount = 0;
  let integrationBundle = null;
  let todayReportCount = 0;
  let capturedReportCount = 0;
  const capturedReportIdentities = new Set();
  const unconfirmedReportOrders = new Set(), confirmedReportOrders = new Set();
  let emergencyCases = [];
  const cap = (pageType, items) => {
    const selected = filterRecordItems(pageType, items, range);
    if (selected.length) captures.push({ pageType, items: selected });
    return selected.length;
  };

  // ── list pages ────────────────────────────────────────────────────────────
  checkAbort();
  await setProg("📥 1/7 病人首頁…", { phase: "list" });
  const homepage = await swallow("homepage", () => fetchPage(baseUrl, PATHS.patient_homepage(histno)));
  if (homepage) {
    const ptItems = await swallow("parse_patient", () => parseInTab(tabId, "patient_info", homepage, { histno }));
    if (ptItems?.[0]) Object.assign(patientDict, ptItems[0]);
    
    const allergyItems = await swallow("parse_allergies", () => parseInTab(tabId, "allergies", homepage));
    cap("allergies", allergyItems);
    
  }

  // findPba — 身份證號 + 主治醫師/地址/phone. Merges into the same
  // Patient (shared stable id = histno).
  const pbaHtml = await swallow("pba", () => fetchPage(baseUrl, PATHS.patient_basics(histno)));
  if (pbaHtml) {
    const pba = await swallow("parse_pba", () => parseInTab(tabId, "patient_info_findpba", pbaHtml));
    if (pba?.[0]) {
      Object.assign(patientDict, pba[0]);
      
    }
  }
  if (expectedIdentity && (patientDict.identifier || patientDict.id) && String(patientDict.identifier || patientDict.id) !== String(histno)) throw new Error("PATIENT_HIS_MISMATCH");
  if (expectedIdentity && currentHisBlockError && [429, 502, 503, 504].includes(currentHisBlockError.status)) throw new Error("HIS_BUSY");
  if (expectedIdentity && !hasComparableOutpatientIdentity(expectedIdentity, patientDict)) throw new Error("HIS_BUSY");
  if (expectedIdentity && !verifyOutpatientIdentity(expectedIdentity, patientDict)) throw new Error("PATIENT_HIS_MISMATCH");
  if (Object.keys(patientDict).length) cap("patient_info", [patientDict]);

  if (currentOutpatientMode) {
    checkAbort();
    await setProg("🩺 門診版：選取每位醫師近一年最新一次門診…", { phase: "outpatient_list" });
    const listHtml = await swallow("opd_list", () => fetchPage(baseUrl, PATHS.encounters_list(histno)));
    if (mode === "outpatient-peer" && listHtml && !/id\s*=\s*["']?opdlist\b/i.test(listHtml)) errors.push("未找到門診清單，可能需要重新登入 HIS");
    const rows = listHtml ? await swallow("parse_encounters", () => parseInTab(tabId, "encounters_list", listHtml)) : [];
    const selected = selectOutpatientVisits(rows, range);
    outpatientVisitCount = selected.visits.length;
    errors.push(...selected.warnings);
    await setStatus({ outpatientVisits: selected.visits.length });
    cap("encounters", selected.visits);
    
    addExpectedQemrRequests(selected.visits.length);
    const outpatientOrders = [];
    let done = 0;
    await pMapPool(selected.visits, OUTPATIENT_FETCH_POOL, async visit => {
      checkAbort();
      const path = await swallow(`outpatient link ${visit.date}`, () => outpatientDetailPath(visit, histno, baseUrl));
      const html = path ? await swallow(`outpatient ${visit.date}`, () => fetchPage(baseUrl, path)) : null;
      const detail = html ? await swallow(`parse_outpatient ${visit.date}`, () => parseInTab(tabId, "outpatient_detail", html, visit)) : null;
      outpatientOrders.push(...(detail?.service_requests || []));
      if (html && !detail?.encounters?.length) errors.push(`${visit.date} 門診未找到相符的 SOAP 分區`);
      for (const pageType of ["conditions", "encounters", "medications", "service_requests", "document_references"]) {
        const items = detail?.[pageType];
        cap(pageType, items);
        
      }
      done++;
      await setProg(`🩺 門診版詳情 ${done}/${selected.visits.length}…`, { phase: "encounter_detail", totalResources: total });
    });
    if (outpatientOrders.length) {
      const orderHtml = await swallow("outpatient_order_index", () => fetchPage(baseUrl,
        `/emr/qemr/qemr.cfm?action=findOrd&histno=${encodeURIComponent(histno)}&tday=720&tdept=ALL`));
      const orderIndex = orderHtml && await swallow("parse_order_index", () => parseInTab(tabId, "order_index", orderHtml));
      if (!orderIndex?.valid) errors.push("無法確認門診醫囑申請序號");
      else if (orderIndex.skippedRows) errors.push(`有 ${orderIndex.skippedRows} 筆醫囑無法解析申請序號，部分對應報告可能未擷取`);
      // The cloud flow independently scans the year's reports. Unconfirmed
      // order edges are a separate notice, not evidence those reports are lost.
      bindOutpatientRequests(outpatientOrders, orderIndex?.items || [], independentReports ? [] : errors);
      for (const order of unlinkedOutpatientOrders(outpatientOrders)) unconfirmedReportOrders.add(order);
      
    }
    if (mode === "outpatient-peer" && typeof onClinicReady === "function") {
      // Freeze a complete visit graph before the slower report scan. Building
      // from a copy keeps report/order linking from mutating an issued snapshot.
      try {
      await assertQemrPatientStillActive(tabId, histno);
      checkAbort();
      const { bundle } = buildBundle(structuredClone(captures), histno, { deidentify: false });
      bundle.meta.tag = [...(bundle.meta.tag || []),
        { system: "urn:oid:vgh.capture.mode", code: "outpatient", display: "近一年每位醫師最新一次門診" },
        { system: "urn:wildcatch:coverage", code: "his-reports-pending", display: "門診資料已取得；檢查驗報告仍在取得中。" }];
      for (const entry of bundle.entry) if (entry.resource.resourceType === "Patient") {
        delete entry.resource.identifier;
        delete entry.resource.telecom;
        delete entry.resource.address;
      }
      await onClinicReady({ bundle, errors: errors.map(() => "HIS_CAPTURE_INCOMPLETE"), outpatientVisitCount, todayReportCount: 0 });
      checkAbort();
      } catch (error) {
        if (isSyncAbortError(error) || isHisRequestBlockedError(error)
          || error?.code === "PATIENT_HIS_MISMATCH" || error?.message === "PATIENT_HIS_MISMATCH") throw error;
        // The final capture has its own delivery guard. Failure to publish an
        // optional early snapshot must not skip the report scan.
      }
    }
    if (mode === "outpatient-peer" || outpatientOrders.some(order => order.request_no)) {
      await setProg(independentReports ? "🧪 取得近一年報告與門診醫囑對應報告…" : "🧪 補抓門診醫囑對應報告與當天報告…", { phase: "obs_detail" });
      // Bound the expanded scan separately so it can return captured visits and
      // reports as partial before the cloud's optional-source deadline.
      const reportController = new AbortController();
      const stopReports = () => reportController.abort(aborter.signal.reason);
      aborter.signal.addEventListener("abort", stopReports, { once: true });
      if (aborter.aborted) stopReports();
      const noteLimit = () => { const notice="近一年報告查詢達時間上限，已保留門診與取得的報告，其餘尚未取得"; if (!errors.includes(notice)) errors.push(notice); };
      const reportTimer = independentReports ? setTimeout(() => { noteLimit(); reportController.abort(); }, 60_000) : null;
      const reportWork = async work => {
        const expired = () => independentReports && reportController.signal.aborted && !aborter.aborted;
        if (expired()) { noteLimit(); return null; }
        try { return await work(); }
        catch (error) { if (expired()) { noteLimit(); return null; } throw error; }
      };
      const reportPage = path => reportWork(() => fetchPage(baseUrl, path, { signal: reportController.signal }));
      try {
      const list = await swallow("today_report_list", () => reportPage(PATHS.observations_list(histno, range)));
      const index = list ? await swallow("today_report_index", () => reportWork(() => readReportIndex(tabId, list, baseUrl, histno, reportController.signal))) : null;
      if (!Array.isArray(index?.links) || index.valid === false) errors.push("無法確認檢查驗報告清單");
      const indexedLinks = [...(index?.links || [])];
      // Year selectors are advertised by HIS. Search their indexes too: a
      // delayed/corrected report must not disappear because its order is old.
      for (const year of [...new Set(index?.years || [])]) {
        if (reportController.signal.aborted) break;
        const annualHtml = await swallow("today_report_year", () => reportPage(PATHS.observations_year(histno, year)));
        const annual = annualHtml && await swallow("today_report_year_parse", () => reportWork(() => readReportIndex(tabId, annualHtml, baseUrl, histno, reportController.signal)));
        if (!Array.isArray(annual?.links) || annual.valid === false) errors.push("無法確認年度報告清單");
        indexedLinks.push(...(annual?.links || []));
      }
      // Unknown report dates must be checked in the detail, never dated by the order.
      const links = uniqueOutpatientReportLinks(indexedLinks.filter(link => (mode === "outpatient-peer" && (!link.report_date || (independentReports
        ? reportIssuedInRange({}, link.report_date, range, link.updated_date) : reportIssuedToday({}, link.report_date, range.end, link.updated_date))))
        || outpatientOrders.some(order => order.request_no && order.request_no === urlParam(link.href, "reqno"))));
      addExpectedQemrRequests(links.length);
      await pMapPool(links, OUTPATIENT_FETCH_POOL, async link => {
        checkAbort();
        const html = await swallow("today_report", () => reportPage(link.href));
        const parsed = html && await swallow("today_report_parse", () => reportWork(() => readReportDetail(tabId, html, {
          hospital_order_code: urlParam(link.href, "ordclnm"), request_no: urlParam(link.href, "reqno"), source_report_date: link.report_date,
          report_case_no: urlParam(link.href, "caseno"), report_sequence: urlParam(link.href, "ordseq"),
        }, histno, reportController.signal)));
        if (!parsed) return;
        const results = [...(parsed.observations || []), ...(parsed.diagnostic_reports || [])];
        if (independentReports) {
          for (const item of results) {
            const match = matchOutpatientReport(item, outpatientOrders);
            if (match) for (const order of match.orders) confirmedReportOrders.add(order);
            else for (const order of outpatientOrders) {
              if (order.request_no && order.request_no === urlParam(link.href, "reqno")) unconfirmedReportOrders.add(order);
            }
          }
        }
        if (!results.length) errors.push("報告詳情無法解析");
        if (mode === "outpatient-peer" && results.some(item => !item.issued && !item.reported_at && !link.report_date && !item.updated_at && !link.updated_date)) errors.push("報告缺少發布或更新日期，僅保留已確認對應醫囑的報告");
        if (!independentReports && outpatientOrders.some(order => order.request_no && order.request_no === urlParam(link.href, "reqno"))
          && results.some(item => !matchOutpatientReport(item, outpatientOrders))) {
          errors.push("報告無法確認對應醫囑，未建立醫囑關聯；非今日報告未匯入");
        }
        let retainedReport = false;
        for (const pageType of ["observations", "diagnostic_reports"]) {
          const items = (parsed[pageType] || []).flatMap(item => {
            const match = matchOutpatientReport(item, outpatientOrders);
            const recent = mode === "outpatient-peer" && (independentReports
              ? reportIssuedInRange(item, link.report_date, range, link.updated_date) : reportIssuedToday(item, link.report_date, range.end, link.updated_date));
            return match || recent ? [attachOutpatientOrder(item, match)] : [];
          });
          // A report released today may concern an older specimen outside the visit window.
          if (items.length) { retainedReport = true; captures.push({ pageType, items }); todayReportCount += items.filter(item => reportIssuedToday(item, link.report_date, range.end, link.updated_date)).length; }
          
        }
        if (independentReports && !retainedReport && outpatientOrders.some(order =>
          order.request_no && order.request_no === urlParam(link.href, "reqno"))) {
          errors.push("報告無法確認對應醫囑或發布範圍，未匯入該報告");
        }
        if (retainedReport) {
          capturedReportIdentities.add(outpatientReportIdentity(link));
          capturedReportCount = capturedReportIdentities.size;
        }
        if (retainedReport && hasLossyReportDescription(link.href) && !errors.includes("報告描述欄位編碼無法確認，已省略描述並保留報告")) errors.push("報告描述欄位編碼無法確認，已省略描述並保留報告");
      });
      } finally {
        if (reportTimer !== null) clearTimeout(reportTimer);
        aborter.signal.removeEventListener("abort", stopReports);
      }
    }
  } else {

    checkAbort();
    await setProg("📥 2/7 診斷清單…", { totalResources: total });
    const condHtml = await swallow("conditions", () => fetchPage(baseUrl, PATHS.conditions(histno)));
    if (condHtml) {
      const items = await swallow("parse_conditions", () => parseInTab(tabId, "conditions", condHtml));
      cap("conditions", items);
      
    }

    checkAbort();
    await setProg("📥 3/7 門診清單…", { totalResources: total });
    const encListHtml = await swallow("opd_list", () => fetchPage(baseUrl, PATHS.encounters_list(histno)));
    if (encListHtml) {
      const items = await swallow("parse_encounters", () => parseInTab(tabId, "encounters_list", encListHtml));
      if (Array.isArray(items)) encounterListItems.push(...items);
      cap("encounters", items);
      
    }

    await setProg("📥 4/7 住院清單…", { totalResources: total });
    const admListHtml = await swallow("adm_list", () => fetchPage(baseUrl, PATHS.admissions_list(histno)));
    if (admListHtml) {
      const items = await swallow("parse_admissions", () => parseInTab(tabId, "encounters_list", admListHtml));
      if (Array.isArray(items)) encounterListItems.push(...items);
      cap("encounters", items);
      
    }

    // ED cases are independent of admissions, including same-day ED visits.
    checkAbort();
    await setProg("🚑 急診紀錄…", { totalResources: total });
    const erListHtml = await swallow("emergency_list", () => fetchPage(baseUrl, PATHS.emergency_list(histno)));
    if (erListHtml) {
      const parsed = await swallow("parse_emergency_list", () => parseInTab(tabId, "emergency_list", erListHtml));
      const cases = Array.isArray(parsed) ? parsed : [];
      emergencyCases = cases;
      const listItems = cases.map(({ summary_available, ...item }) => item);
      cap("encounters", listItems);
      
      addExpectedQemrRequests(cases.length + cases.filter((meta) => meta.summary_available).length);
      let done = 0;
      await pMapPool(cases, FETCH_POOL, async (meta) => {
        if (aborter.aborted) return;
        const html = await swallow(`emergency ${meta.case_no}`,
          () => fetchPage(baseUrl, PATHS.emergency_detail(histno, meta.case_no)));
        const detail = html ? await swallow(`parse_emergency ${meta.case_no}`,
          () => parseInTab(tabId, "emergency_detail", html, meta)) : null;
        if (html && !detail?.encounters?.length) errors.push(`emergency ${meta.case_no}: 未找到相符的急診病歷內容`);
        for (const pageType of ["conditions", "encounters", "document_references"]) {
          const items = detail?.[pageType];
          cap(pageType, items);
          
        }
        if (meta.summary_available) {
          const bytes = await swallow(`emergency summary ${meta.case_no}`, () => fetchEmergencySummary(baseUrl, histno, meta.case_no));
          if (bytes) {
            const items = [{ doc_type: "emergency-summary", date: meta.date, caseno: meta.case_no,
              encounter_class: "EMER", encounter_ref_date: meta.date, department: meta.department,
              pdf_base64: u8ToBase64(bytes) }];
            cap("document_references", items);
            
          }
        }
        done++;
        await setProg(`🚑 急診紀錄 ${done}/${cases.length}…`, { totalResources: total });
      });
    }

    // Full inpatient ICD diagnoses come from findPdiags, not diagnosis history.
    checkAbort();
    await setProg("🏥 住院診斷…", { totalResources: total });
    addExpectedQemrRequests(1);
    const diagnosisIndexHtml = await swallow("inpatient_diagnoses",
      () => fetchPage(baseUrl, PATHS.inpatient_diagnoses(histno)));
    if (diagnosisIndexHtml) {
      const cases = await swallow("parse_inpatient_diagnoses_index",
        () => parseInTab(tabId, "inpatient_diagnoses_index", diagnosisIndexHtml));
      const initial = await swallow("parse_inpatient_diagnoses_default",
        () => parseInTab(tabId, "inpatient_diagnoses", diagnosisIndexHtml));
      const rows = Array.isArray(initial) ? [...initial] : [];
      const admissionCases = Array.isArray(cases) ? cases : [];
      encounterListItems.push(...admissionCases.map(meta => ({ ...meta, class: "IMP", date: meta.admit_date, end_date: meta.discharge_date })));
      addExpectedQemrRequests(admissionCases.length);
      let done = 0;
      await pMapPool(admissionCases, FETCH_POOL, async (meta) => {
        if (aborter.aborted) return;
        const html = await swallow(`inpatient diagnoses ${meta.case_no}`, () => fetchPage(baseUrl, meta.href));
        done++;
        await setProg(`🏥 住院診斷 ${done}/${admissionCases.length}…`, { totalResources: total });
        if (!html) return;
        const items = await swallow(`parse_inpatient_diagnoses ${meta.case_no}`,
          () => parseInTab(tabId, "inpatient_diagnoses", html, meta));
        if (Array.isArray(items)) rows.push(...items);
      });
      const diagnoses = [...new Map(rows.map((item) => [conditionId(item, histno), item])).values()];
      cap("conditions", diagnoses);
      
      const admissions = admissionCases.map((meta) => {
        const items = diagnoses.filter((item) => item.case_no === meta.case_no);
        if (!items.length) return null;
        const existing = encounterListItems.find((item) => item.class === "IMP" && item.date === meta.admit_date);
        return {
          ...existing,
          date: meta.admit_date,
          end_date: meta.discharge_date,
          class: "IMP",
          case_no: meta.case_no,
          department: existing?.department || meta.department,
          diagnoses: items,
        };
      }).filter(Boolean);
      cap("encounters", admissions);
      
    }

    checkAbort();
    await setProg("🔪 5/7 手術記錄…", { totalResources: total });
    const opnListHtml = await swallow("opn_list", () => fetchPage(baseUrl, PATHS.operations_list(histno)));
    if (opnListHtml) {
      const items = await swallow("parse_operations", () => parseInTab(tabId, "operations_list", opnListHtml));
      if (items?.length) {
        // Per surgery date, fetch detail once and enrich every sub-procedure of
        // that date (shared preop/postop/times/ICD-10). Pooled fan-out.
        const uniqueDts = [...new Set(items.map((it) => it._dt).filter(Boolean))];
        addExpectedQemrRequests(uniqueDts.length);
        await pMapPool(uniqueDts, FETCH_POOL, async (dt) => {
          if (aborter.aborted) return;
          const detailHtml = await swallow(`opn_detail ${dt}`, () => fetchPage(baseUrl, PATHS.operations_detail(histno, dt)));
          if (!detailHtml) return;
          const detail = await swallow(`parse_opn_detail ${dt}`, () => parseInTab(tabId, "operations_detail", detailHtml));
          if (!detail) return;
          for (const it of items) {
            if (it._dt !== dt) continue;
            for (const [key, value] of Object.entries(detail)) {
              if (value != null && value !== "" && (!Array.isArray(value) || value.length)) it[key] = value;
            }
          }
        });
        for (const it of items) delete it._dt;
        cap("procedures", items);
        
      }
    }

    await setProg("📥 6/7 檢驗清單…", { totalResources: total });
    const obsListHtml = await swallow("obs_list", () => fetchPage(baseUrl, PATHS.observations_list(histno, range)));
    await setProg("📥 7/7 用藥清單…", { totalResources: total });
    const medListHtml = await swallow("med_list", () => fetchPage(baseUrl, PATHS.medications_list(histno)));

    // ── encounter SOAP details (pooled) ───────────────────────────────────────
    checkAbort();
    const allOpdVisits = selectOutpatientVisits(encounterListItems, range, false).visits;
    addExpectedQemrRequests(allOpdVisits.length);
    let encDone = 0;
    await pMapPool(allOpdVisits, FETCH_POOL, async (visit) => {
      if (aborter.aborted) return;
      const path = await swallow(`enc link ${visit.date}`, () => visit.detail_href && visit.provider_id
        ? outpatientDetailPath(visit, histno, baseUrl) : PATHS.encounter_detail(histno, visit.date.replaceAll("-", "")));
      const enc = path ? await swallow(`enc ${visit.date}`, () => fetchPage(baseUrl, path)) : null;
      encDone++;
      await setProg(`🩺 門診詳情 ${encDone}/${allOpdVisits.length}…`, { phase: "encounter_detail", totalResources: total });
      if (!enc) return;
      const items = await swallow(`parse_enc ${visit.date}`, () => parseInTab(tabId, "encounter_detail", enc, visit));
      const diagnoses = (items || []).flatMap(item => item.diagnoses || []);
      cap("conditions", diagnoses);
      
      cap("encounters", items);
      
    });

    // ── medication detail pages #udorder (pooled) ─────────────────────────────
    checkAbort();
    const medUrls = (await captureDetailIndex(tabId, medListHtml, "findUd", range, encounterListItems, message => errors.push(message))).links.map(link => link.href);
    addExpectedQemrRequests(medUrls.length);
    let medDone = 0;
    await pMapPool(medUrls, FETCH_POOL, async (url) => {
      if (aborter.aborted) return;
      const date = recordDate(urlParam(url, "dt"));
      const html = await swallow(`med ${url.slice(-16)}`, () => fetchPage(baseUrl, url));
      medDone++;
      await setProg(`💊 用藥詳情 ${medDone}/${medUrls.length}…`, { phase: "med_detail", totalResources: total });
      if (!html) return;
      const items = await swallow(`parse_med`, () => parseInTab(tabId, "medications_detail", html, { date }));
      const visitCaseNo = urlParam(url, "caseno");
      for (const item of (items || [])) if (!item.case_no) item.case_no = visitCaseNo;
      const noteItems = (items || []).filter((item) => item.detail_href);
      addExpectedQemrRequests(noteItems.length);
      // Keep note fan-out sequential within each outer medication
      // workers; otherwise nested pools could exceed FETCH_POOL simultaneous fetches.
      for (const item of noteItems) {
        const noteHtml = await swallow(`med note ${item.order_seq || ""}`, () => fetchPage(baseUrl, item.detail_href));
        if (noteHtml) {
          const parsedNote = await swallow(`parse_med_note ${item.order_seq || ""}`,
            () => parseInTab(tabId, "medication_note_detail", noteHtml));
          if (parsedNote?.note) item.description = parsedNote.note;
        }
      }
      for (const item of (items || [])) delete item.detail_href;
      cap("medications", items);
      
    });

    // ── findRes report/observation detail pages #resdata (pooled) ─────────────
    checkAbort();
    const obsUrls = await captureReportUrls(tabId, histno, obsListHtml, range, [...encounterListItems, ...emergencyCases], (year, path) =>
      swallow(`reports ${year}`, () => fetchPage(baseUrl, path)), baseUrl, message => errors.push(message));
    addExpectedQemrRequests(obsUrls.length);
    let obsDone = 0;
    await pMapPool(obsUrls, FETCH_POOL, async (u) => {
      if (aborter.aborted) return;
      const html = await swallow(`obs`, () => fetchPage(baseUrl, u));
      obsDone++;
      await setProg(`🧪 報告詳情 ${obsDone}/${obsUrls.length}…`, { phase: "obs_detail", totalResources: total });
      if (!html) return;
      const parsed = await swallow(`parse_obs`, () => readReportDetail(tabId, html, {
        hospital_order_code: urlParam(u, "ordclnm"),
        request_no: urlParam(u, "reqno"),
        source_report_date: urlParam(u, "frpdt"),
        ...reportEmergencyContext(u, emergencyCases),
      }, histno));
      if (!parsed) return;
      const retainedReport = cap("observations", parsed.observations)
        + cap("diagnostic_reports", parsed.diagnostic_reports) + cap("procedures", parsed.procedures);
      if (retainedReport && hasLossyReportDescription(u) && !errors.includes("報告描述欄位編碼無法確認，已省略描述並保留報告")) errors.push("報告描述欄位編碼無法確認，已省略描述並保留報告");
      
    });

    // ── 出院病摘 → DocumentReference (verbatim HTML, pooled) ──────────────────
    // Only capture findDis summaries as base64 HTML attachments (like NHI).
    // findAdm is fetched above for inpatient Encounters; its notes are skipped.
    for (const summary of [
      { docType: "discharge", action: "findDis", label: "出院病摘" },
    ]) {
      checkAbort();
      const listHtml = await swallow(`${summary.docType}_list`,
        () => fetchPage(baseUrl, `/emr/qemr/qemr.cfm?action=${summary.action}&histno=${histno}`));
      if (!listHtml) continue;
      const listItems = await swallow(`parse_${summary.docType}_list`,
        () => parseInTab(tabId, "summary_list", listHtml, { doc_type: summary.docType }));
      if (!Array.isArray(listItems) || !listItems.length) continue;
      addExpectedQemrRequests(listItems.length);
      const docItems = [];
      let sDone = 0;
      await pMapPool(listItems, FETCH_POOL, async (meta) => {
        if (aborter.aborted) return;
        const detailHtml = await swallow(`${summary.docType}_detail`, () => fetchPage(baseUrl, meta.href));
        sDone++;
        await setProg(`📄 ${summary.label} ${sDone}/${listItems.length}…`, { phase: "summary", totalResources: total });
        if (!detailHtml) return;
        const parsed = await swallow(`parse_${summary.docType}_detail`,
          () => parseInTab(tabId, "summary_detail", detailHtml, meta));
        if (parsed?.[0]?.html) docItems.push(parsed[0]);
      });
      cap("document_references", docItems);
      
    }

    // ── 人工植入物 → Device ────────────────────────────────────────────────────
    checkAbort();
    await setProg("🔧 人工植入物…", { phase: "devices", totalResources: total });
    const implantHtml = await swallow("implants", () => fetchPage(baseUrl, `/emr/qemr/qemr.cfm?action=findImplant&histno=${histno}`));
    if (implantHtml) {
      const items = await swallow("parse_implants", () => parseInTab(tabId, "implants", implantHtml));
      cap("devices", items);
      
    }

    // ── 生命徵象 findVts → vital-signs Observations ───────────────────────────
    checkAbort();
    await setProg("🫀 生命徵象…", { phase: "vitals", totalResources: total });
    const vitalItems = await captureVitals(tabId, baseUrl, histno, swallow, setProg, aborter, range, encounterListItems, message => errors.push(message));
    cap("vitals", vitalItems);
    

    // ── 化癌治療計畫 findChem → 每個化療週期一個 Procedure（regimen 存 note）──
    checkAbort();
    const chemListHtml = await swallow("chem_list", () => fetchPage(baseUrl, `/emr/qemr/qemr.cfm?action=findChem&histno=${histno}`));
    if (chemListHtml) {
      const cycles = await swallow("parse_chem_list", () => parseInTab(tabId, "chemo_list", chemListHtml));
      if (Array.isArray(cycles) && cycles.length) {
        addExpectedQemrRequests(cycles.length);
        const chemItems = [];
        let cDone = 0;
        await pMapPool(cycles, FETCH_POOL, async (cyc) => {
          if (aborter.aborted) return;
          const html = await swallow(`chem ${cyc.date}`, () => fetchPage(baseUrl, cyc.href));
          cDone++;
          await setProg(`💉 化療計畫 ${cDone}/${cycles.length}…`, { phase: "chemo", totalResources: total });
          if (!html) return;
          const items = await swallow(`parse_chem ${cyc.date}`, () => parseInTab(tabId, "chemo_detail", html, { date: cyc.date }));
          if (Array.isArray(items)) chemItems.push(...items);
        });
        cap("procedures", chemItems);
        
      }
    }

    // ── 癌症治療計畫書 findPbc → CarePlan ─────────────────────────────────────
    checkAbort();
    await setProg("🎗 癌症治療計畫…", { phase: "careplans", totalResources: total });
    const pbcHtml = await swallow("pbc", () => fetchPage(baseUrl, `/emr/qemr/qemr.cfm?action=findPbc&histno=${histno}`));
    if (pbcHtml) {
      const plans = await swallow("parse_pbc", () => parseInTab(tabId, "careplans", pbcHtml));
      cap("careplans", plans);
      
    }

  }
  // ── finish ────────────────────────────────────────────────────────────────
  const unlinkedOrders = [...unconfirmedReportOrders].filter(order => !confirmedReportOrders.has(order));
  const unlinkedOrderKinds = outpatientOrderReviewCounts(unlinkedOrders);
  const reportCoverage = independentReports ? { scope: "one-year", capturedReports: capturedReportCount,
    unlinkedOrders: Object.values(unlinkedOrderKinds).reduce((sum, count) => sum + count, 0), unlinkedOrderKinds } : undefined;
  checkAbort();
  if (currentHisBlockError) {
    // No network request is allowed after a service stop. Reuse the current
    // chart's normal final identity/audit check; the header exposes MRN,
    // name and DOB, not the full national identifier read at capture start.
    await assertQemrPatientStillActive(tabId, histno);
    if (!patientDict.name) throw new Error("HIS_BUSY");
    const state = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] },
      func: outpatientPageStep, args: ["inspect", { name: patientDict.name, birthDate: patientDict.birthDate }] });
    checkAbort();
    if (state[0]?.result?.phase !== "chart" || state[0].result.histno !== histno) throw new Error("PATIENT_HIS_MISMATCH");
  }
  const stamp = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  let breakdown = {};
  let uniqueTotal = 0;
  let htmlZipName = null;
  let deliveredFile = null;
  let fhirDownloadId = null;
  let htmlDownloadRequested = false;
  let htmlDownloadId = null;
  const ownsRun = () => currentSyncAbort === aborter;
  const deliveryState = () => ({ fhirDownloadStarted: !!deliveredFile, fhirDownloadId, deliveredFile,
    htmlDownloadRequested,
    htmlDownloadStarted: htmlDownloadId !== null, htmlDownloadId, htmlZipName });

  try {
  {
    // Build locally; explicit peer mode returns only the paired same-patient data.
    const { bundle, breakdown: bd, patientId: bundlePatientId } = buildBundle(captures, histno, {
      deidentify: deid,
      deidKey,
    });
    breakdown = bd;
    if (currentOutpatientMode) bundle.meta.tag = [...(bundle.meta.tag || []), { system: "urn:oid:vgh.capture.mode", code: "outpatient", display: "近一年每位醫師最新一次門診" }];
    if (errors.length) bundle.meta.tag = [...(bundle.meta.tag || []), {
      system: "https://github.com/voho0000/EHR-FHIR-BRIDGE/CodeSystem/capture-completeness", code: "partial", display: "擷取不完整；僅含已取得資料",
    }];
    uniqueTotal = bundle.total;
    if (uniqueTotal > 0) {
      await assertQemrPatientStillActive(tabId, histno);
      checkAbort();
      if (mode === "outpatient-peer") {
        // The coordinator keeps its cloud Patient; no full national ID is transferred.
        for (const entry of bundle.entry) if (entry.resource.resourceType === "Patient") {
          delete entry.resource.identifier;
          delete entry.resource.telecom;
          delete entry.resource.address;
        }
        integrationBundle = bundle;
      } else {
        const json = JSON.stringify(bundle, null, 2);
        const b64 = u8ToBase64(new TextEncoder().encode(json));
        const filePatientId = deid ? bundlePatientId : histno;
        const bundleFile = `ehr-fhir-bridge-${deid ? "deid-" : ""}${filePatientId}-${stamp}-v${chrome.runtime.getManifest().version}.json`;
        const bundleUrl = `data:application/fhir+json;base64,${b64}`;
        // Download immediately. Keeping a base64 Bundle in chrome.storage.local
        // can exceed the extension quota and leaves PHI persisted after export.
        fhirDownloadId = await chrome.downloads.download({ url: bundleUrl, filename: bundleFile, saveAs: false });
        deliveredFile = bundleFile;
        await setStatus({ ...deliveryState(),
          totalResources: uniqueTotal, breakdown }, prev => ownsRun() && prev.runId === runId);
      }
    }
  }

  if (includeHtmlZip) {
    checkAbort();
    await setProg("📦 正在打包同一批原始 HTML…", { phase: "packaging", totalResources: uniqueTotal });
    checkAbort();
    const archive = await downloadRawCaptureZip(currentRawCapture, histno, stamp, {
      errors, signal: aborter.signal, onDownloadRequest: filename => { htmlDownloadRequested = true; htmlZipName = filename; },
    });
    if (archive) { htmlZipName = archive.filename; htmlDownloadId = archive.downloadId; }
    checkAbort();
  }

  
  checkAbort();
  const abortedNote = aborter.aborted ? "（已中止，僅含已抓取部分）" : "";
  await appendSyncHistory({
    ts: Date.now(), histno, mode, runId, deidentify: deid, recordRange: range, outpatientMode: currentOutpatientMode,
    ...deliveryState(),
    total: uniqueTotal, breakdown, errors: errors.length,
    errorDetails: errors.slice(0, 100),
    ...(reportCoverage ? { reportCoverage } : {}),
    aborted: aborter.aborted,
    ...(currentOutpatientMode ? { outpatientVisits: outpatientVisitCount } : {}),
  });
  const destinationNote = mode === "outpatient-peer"
    ? (integrationBundle?.total ? "（配對資料已準備）" : "（沒有可供配對的 FHIR 資源）")
    : deliveredFile ? "（FHIR 下載已啟動）" : "（沒有可下載的 FHIR 資源）";
  checkAbort();
  await setStatus({
    running: false,
    ...deliveryState(),
    progress: currentOutpatientMode
      ? `${errors.length ? "⚠️" : "✅"} 門診版取得完成 — ${outpatientVisitCount ? `${outpatientVisitCount} 次門診` : "近一年沒有符合條件的門診"}，${uniqueTotal} 個 FHIR 資源${destinationNote}${htmlZipName ? " + HTML ZIP" : ""}`
      : includeHtmlZip
      ? `${errors.length ? "⚠️" : "✅"} 一次取得完成 — ${uniqueTotal} 個 FHIR 資源，${deliveredFile ? "FHIR 下載已啟動" : "沒有可下載的 FHIR 資源"}${htmlDownloadId !== null ? " + HTML 封存下載已啟動" : ""}`
      : `✅ Sync 完成 — ${uniqueTotal} 個 FHIR 資源${destinationNote}${abortedNote}`,
    phase: errors.length ? "partial" : "done",
    totalResources: uniqueTotal,
    postedRequests: total,
    breakdown,
    completed: Date.now(), errors,
    ...(reportCoverage ? { reportCoverage } : {}),
  });
  currentSyncAbort = null;
  currentHisBlockError = null;
  currentRawCapture = null;
  return { bundle: integrationBundle, errors: errors.map(() => "HIS_CAPTURE_INCOMPLETE"), outpatientVisitCount, todayReportCount,
    ...(reportCoverage ? { reportCoverage } : {}) };
  } catch (error) {
    if (deliveredFile || htmlDownloadRequested) {
      const cancelled = isSyncAbortError(error);
      const htmlDownloadStarted = htmlDownloadId !== null;
      const delivery = { ...deliveryState(), htmlCancelled: cancelled && includeHtmlZip && !htmlDownloadRequested };
      const progress = !deliveredFile
        ? (htmlDownloadStarted ? (cancelled ? "⏹ HTML 封存下載已啟動，後續處理已取消" : "❌ HTML 封存下載已啟動，後續處理失敗") : "❌ HTML 封存下載失敗")
        : htmlDownloadStarted
        ? (cancelled ? "⏹ FHIR 與 HTML 封存下載已啟動，後續處理已取消" : "❌ FHIR 與 HTML 封存下載已啟動，後續處理失敗")
        : cancelled && !includeHtmlZip ? "⏹ FHIR 下載已啟動，後續處理已取消"
        : !includeHtmlZip ? "❌ FHIR 下載已啟動，後續處理失敗"
        : cancelled && !htmlDownloadRequested ? "⏹ FHIR 下載已啟動，HTML 封存已取消"
        : "❌ FHIR 下載已啟動；HTML 封存下載失敗";
      await appendSyncHistory({ ts: Date.now(), histno, mode, runId, deidentify: deid, recordRange: range,
        outpatientMode: currentOutpatientMode, outpatientVisits: outpatientVisitCount,
        total: uniqueTotal, breakdown, errors: errors.length, errorDetails: errors.slice(0,100),
        aborted: cancelled, deliveryError: !cancelled, ...delivery }, ownsRun);
      await setStatus({ running: false, phase: cancelled ? "cancelled" : "error", completed: Date.now(),
        progress, totalResources: uniqueTotal, breakdown, errors: [...errors], ...delivery }, prev => ownsRun() && prev.runId === runId);
      error.deliveryRecorded = true;
      error.syncOwner = aborter;
    }
    throw error;
  }
}

const outpatientPeer = installOutpatientPeer({
  busy: () => !!currentSyncAbort || oneClickStartPending || emergencyPeer.busy(),
  abort: (tabId, owner) => {
    if (owner && currentSyncAbort?.context?.outpatientOwner === owner && currentSyncAbort.context.tabId === tabId) currentSyncAbort.abort();
  },
  readIdentity: async (tabId, baseUrl, histno, signal) => {
    // Preflight runs before runSync owns a request controller. Keep its stop
    // state local so failure still rejects this job without poisoning a retry
    // or clearing the stop state of a newer capture after cancellation.
    if (currentSyncAbort) throw new Error("HIS_BUSY");
    if (signal?.aborted) throw new SyncAbortError();
    let html;
    try { html = await fetchPage(baseUrl, PATHS.patient_basics(histno), { requestState: { signal, histno } }); }
    catch(error) {
      if (isHisRequestBlockedError(error) && [429, 502, 503, 504].includes(error.status)) throw new Error("HIS_BUSY");
      throw error;
    }
    if (signal?.aborted) throw new SyncAbortError();
    const pba = await parseInTab(tabId, "patient_info_findpba", html);
    if (signal?.aborted) throw new SyncAbortError();
    const page = await chrome.scripting.executeScript({ target: { tabId }, func: () => document.documentElement.outerHTML });
    if (signal?.aborted) throw new SyncAbortError();
    const navbar = await parseInTab(tabId, "patient_info", page[0].result, { histno });
    return { ...navbar?.[0], ...pba?.[0] };
  },
  capture: async payload => {
    try { return await runSync({ ...payload, mode: "outpatient-peer", outpatientMode: true, recordYears: "1", deidentify: false }); }
    catch (error) { await handleDetachedRunFailure(error); throw error; }
  },
});

const emergencyPeer = installEmergencyPeer({ busy: () => !!currentSyncAbort || oneClickStartPending || outpatientPeer.busy() });

async function handleDetachedRunFailure(error) {
  if (error?.deliveryRecorded && currentSyncAbort !== error.syncOwner) return;
  if (error?.deliveryRecorded) {
    // The owned run already published which artifact was delivered.
  } else
  if (isSyncAbortError(error)) {
    await setStatus({
      running: false,
      progress: "⏹ 已取消取得，可以重新開始",
      phase: "cancelled",
      completed: Date.now(),
    });
  } else {
    console.error("capture run failed", error);
    await setStatus({
      running: false,
      progress: `❌ ${error instanceof Error ? error.message : String(error)}`,
      phase: "error",
      completed: Date.now(),
    });
  }
  currentSyncAbort = null;
  currentHisBlockError = null;
  currentRawCapture = null;
}

async function startOneClickFromSender(sender) {
  if (
    oneClickStartPending || outpatientPeer.busy() || emergencyPeer.busy() ||
    currentSyncAbort
  ) {
    throw new Error("已有一個取得工作正在執行");
  }
  if (
    !Number.isInteger(sender.tab?.id) ||
    (sender.frameId !== undefined && sender.frameId !== 0)
  ) {
    throw new Error("請從院內病歷的病人主頁啟動一鍵取得");
  }
  const page = parseQemrPatientPage(sender.url || sender.tab.url || "");
  if (!page) throw new Error("請先在院內系統選擇病人並進入病人頁面");

  oneClickStartPending = true;
  const startAbort = createSyncAbortHandle();
  startAbort.context = { tabId: sender.tab.id, histno: page.histno, mode: "download", runId: `one-click-${crypto.randomUUID()}` };
  currentSyncAbort = startAbort;
  try {
    await setStatus({
      ...startAbort.context, running: true, phase: "init", started: Date.now(),
      progress: "正在準備一鍵取得…", errors: [], breakdown: null,
    });
    const settings = await awaitWithSignal(chrome.storage.sync?.get(["recordYears", "outpatientMode"]) || Promise.resolve({}), startAbort.signal);
    if (startAbort.aborted) throw new SyncAbortError();
    const payload = buildOneClickPayload(sender.tab.id, page, settings);
    payload.syncRunId = startAbort.context.runId;
    void runStandaloneDownload(payload, startAbort).catch(handleDetachedRunFailure);
    return { ok: true, histno: page.histno };
  } catch (error) {
    await handleDetachedRunFailure(error);
    throw error;
  } finally {
    oneClickStartPending = false;
  }
}

async function runStandaloneDownload(payload, aborter = createSyncAbortHandle()) {
  if (payload?.mode !== "download") throw new Error("不支援的取得模式，請重新開啟擴充功能後使用本機下載。");
  refreshCaptureLauncher(payload.tabId);
  const runId = payload.syncRunId || `download-${crypto.randomUUID()}`;
  aborter.context = { tabId: payload.tabId, histno: payload.histno, mode: "download", runId };
  currentSyncAbort = aborter;
  await setStatus({ ...aborter.context, running: true, phase: "audit", started: Date.now(),
    progress: "正在確認病人與醫療需要調閱視窗…", errors: [], breakdown: null });
  await prepareDownloadAudit({ ...payload, signal: aborter.signal,
    onProgress: progress => setStatus({ progress }) });
  if (aborter.aborted) throw new SyncAbortError();
  return runSync({ ...payload, syncRunId: runId }, aborter);
}

async function stopSyncFromMessage(msg, sender) {
  let activeAbort = currentSyncAbort;
  if (msg.oneClick && (!activeAbort || typeof msg.runId !== "string" || msg.runId !== activeAbort.context?.runId)) {
    return { ok: false, error: "目前沒有對應的取得工作" };
  }
  if (msg.oneClick || msg.fromLauncher) {
    const context = activeAbort?.context || (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
    activeAbort = currentSyncAbort;
    const allowed = msg.fromLauncher ? canControlSyncFromPage : canStopOneClick;
    if (!allowed(sender, msg.histno, activeAbort?.context || context)) {
      return { ok: false, error: "目前沒有這個病人頁面的取得工作" };
    }
  }
  if (activeAbort) {
    activeAbort.abort();
    // The run publishes its final state after every worker has stopped.
    return { ok: true, aborting: true };
  }
  await setStatus({
    running: false, progress: "已停止取得，可以重新開始",
    phase: "cancelled", completed: Date.now(),
  });
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return { ok: true, aborting: false, status: data[STORAGE_KEY] };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "authorizeDownloadAudit") {
    sendResponse(authorizeDownloadAudit(msg, sender));
    return false;
  }
  if (["launchBackend", "launchBackendSmartApp"].includes(msg?.type)) {
    sendResponse({ ok: false, error: "此版本僅提供本機下載，已移除後端上傳與啟動功能。" });
    return true;
  }
  if (msg?.type === "startOneClick") {
    startOneClickFromSender(sender).then(
      (result) => sendResponse(result),
      (error) => sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      }),
    );
    return true;
  }
  if (msg?.type === "startSync") {
    if (oneClickStartPending || currentSyncAbort || outpatientPeer.busy() || emergencyPeer.busy()) {
      sendResponse({ ok: false, error: "已有一個取得工作正在執行" });
      return true;
    }
    runStandaloneDownload(msg.payload).then(
      () => { try { sendResponse({ ok: true }); } catch {} },
      async (e) => {
        await handleDetachedRunFailure(e);
        try { sendResponse({ ok: false, error: e.message }); } catch {}
      },
    );
    return true;  // keep channel open
  }
  if (msg?.type === "startHtmlCapture") {
    if (oneClickStartPending || currentSyncAbort || outpatientPeer.busy() || emergencyPeer.busy()) {
      sendResponse({ ok: false, error: "已有一個取得工作正在執行" });
      return true;
    }
    runHtmlCapture(msg.payload).then(
      () => { try { sendResponse({ ok: true }); } catch {} },
      async (e) => {
        await handleDetachedRunFailure(e);
        try { sendResponse({ ok: false, error: e.message }); } catch {}
      },
    );
    return true;  // keep channel open
  }
  if (msg?.type === "abortSync") {
    stopSyncFromMessage(msg, sender).then(sendResponse,
      (error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (msg?.type === 'getOutpatientResumeStatus' || msg?.type === 'resumeOutpatientCapture') {
    const task = msg.type === 'getOutpatientResumeStatus' ? outpatientPeer.resumeStatus(sender) : outpatientPeer.resume(sender);
    task.then(sendResponse, () => sendResponse(null));
    return true;
  }
  if (msg?.type === "getSyncStatus") {
    if (msg.fromLauncher && sender.id === chrome.runtime.id) {
      const preflight = outpatientPeer.statusForTab(sender.tab?.id);
      if (canReadOutpatientPreflight(sender, preflight)) { sendResponse(preflight); return false; }
    }
    chrome.storage.local.get(STORAGE_KEY).then(async (data) => {
      let status = data[STORAGE_KEY] || null;
      // A real job always owns an in-memory abort handle before its first
      // await. If storage says running but this worker has no handle, Chrome
      // restarted the worker and the old job no longer exists — recover now.
      if (shouldRecoverOrphanedStatus(status, !!currentSyncAbort)) {
        await setStatus({
          running: false,
          progress: "⚠️ 上次取得已中斷，可以重新開始",
          phase: "interrupted",
          completed: Date.now(),
        });
        status = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] || null;
      }
      if (msg.fromLauncher && !canReadSyncFromPage(sender, msg.histno, status)) status = null;
      sendResponse(status);
    });
    return true;
  }
  if (msg?.type === "acknowledgeSyncCompletion") {
    setStatus({ completionSeen: true }, (status) => completionMatches(status, msg))
      .then((status) => sendResponse({ ok: !!status, status }), () => sendResponse({ ok: false }));
    return true;
  }
  if (msg?.type === "clearSyncStatus") {
    chrome.storage.local.remove(STORAGE_KEY).then(() => {
      hasPublishedStatus = true;
      void updateSyncAction(null);
      sendResponse({ ok: true });
    });
    return true;
  }
});

// Restore the toolbar indication when Chrome wakes the worker after a restart.
chrome.storage.local.get(STORAGE_KEY).then((data) => {
  if (!hasPublishedStatus) return updateSyncAction(data[STORAGE_KEY]);
}).catch(() => {});

// Keep SW alive during long syncs.
chrome.alarms.create("sw-keepalive", { periodInMinutes: 0.34 });
chrome.alarms.onAlarm.addListener(() => { /* presence is the point */ });

// Best-effort migration belongs to the worker, never the popup startup path.
// Retry on a future worker wake if storage is temporarily unavailable.
for (const [area, keys] of [
  [chrome.storage.local, ["niisApiToken", "syncApiKey"]],
  [chrome.storage.sync, ["niisApiToken", "backendUrl", "syncApiKey", "syncMode"]],
]) {
  area?.remove?.(keys)?.catch(() => {});
}
