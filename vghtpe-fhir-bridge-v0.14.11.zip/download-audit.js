import { parseQemrPatientPage } from "./one-click.js";
import { awaitWithSignal, delayWithSignal, SyncAbortError } from "./sync-runtime.js";

const AUDIT_TIMEOUT_MS = 20_000;
const AUDIT_POLL_MS = 500;
const pendingAudits = new Map();

export function authorizeDownloadAudit(message, sender) {
  const pending = pendingAudits.get(message?.token);
  const page = parseQemrPatientPage(sender?.url || sender?.tab?.url || "");
  const ok = !!pending && !pending.used && pending.active() && Date.now() < pending.expiresAt
    && sender?.tab?.id === pending.tabId && sender.frameId === 0
    && page?.baseUrl === pending.baseUrl && page.histno === pending.histno;
  if (ok) pending.used = true; // The final authorization is the send commit point.
  return { ok };
}

// Runs in the selected tab's isolated world. The snapshot is transient: no
// patient identity or audit completion flag is written to extension storage.
export async function downloadAuditPageStep(action, expected) {
  const visible = element => !!element && element.getClientRects().length > 0
    && getComputedStyle(element).visibility !== "hidden";
  const normalize = value => String(value || "").normalize("NFKC").replace(/\s/g, "");
  const url = new URL(location.href);
  const ids = url.searchParams.getAll("histno");
  if (url.protocol !== "https:" || !/(^|\.)vghtpe\.gov\.tw$/i.test(url.hostname)
    || !url.pathname.toLowerCase().startsWith("/emr/qemr/")
    || url.origin !== expected.baseUrl || ids.length !== 1 || ids[0] !== expected.histno) {
    return { phase: "changed" };
  }
  const header = document.querySelector("ul.jd_menu > li:first-child")?.textContent || "";
  const normalizedHeader = header.replace(/\s+/g, " ").trim();
  const marker = ` ${expected.histno} `;
  const position = normalizedHeader.indexOf(marker);
  const birthday = position > 0 && /^[^()]*\((\d{4})(\d{2})(\d{2})\)/.exec(normalizedHeader.slice(position + marker.length));
  const name = position > 0 ? normalizedHeader.slice(0, position) : "";
  if (!name || !birthday) return { phase: "unavailable" };
  const identity = { name, birthDate: `${birthday[1]}-${birthday[2]}-${birthday[3]}` };
  if (expected.identity && (normalize(identity.name) !== normalize(expected.identity.name)
    || identity.birthDate !== expected.identity.birthDate)) return { phase: "changed" };

  const panel = document.querySelector("#divNotify02Panel");
  if (!visible(panel)) {
    if (action === "complete" && panel) delete panel.__wildcatchMedicalNeedSubmission;
    return { phase: "ready", identity };
  }
  const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Taipei" }).format(new Date());
  const previous = panel.__wildcatchMedicalNeedSubmission;
  const pending = previous?.histno === expected.histno && previous.day === day;
  // HIS may disable/remove its controls while the submitted request runs.
  // Keep waiting for this same patient's gate instead of treating that as a
  // new request or clicking again.
  if (action !== "submit" && (expected.submitted || pending)) return { phase: "pending", identity };
  if (action === "submit" && pending) return { phase: "submitted", identity };
  const radio = panel.querySelector('#form_Pchkau input[name="p_reason"][value="0"]');
  const button = panel.querySelector("#btn_pchkau");
  const reason = () => radio?.labels?.length ? [...radio.labels].map(label => label.textContent).join("")
    : radio?.nextSibling?.textContent;
  if (!visible(radio) || !visible(button) || radio.disabled || button.disabled
    || normalize(reason()) !== "醫療需要" || normalize(button.value || button.textContent) !== "確定送出") {
    return { phase: "unavailable" };
  }
  if (action !== "submit") return { phase: "audit", identity };
  if (Date.now() >= expected.expiresAt) return { phase: "unavailable" };
  let authorization;
  try { authorization = await chrome.runtime.sendMessage({ type: "authorizeDownloadAudit", token: expected.token }); }
  catch { return { phase: "unavailable" }; }
  if (!authorization?.ok || Date.now() >= expected.expiresAt) return { phase: "unavailable" };
  if (document.querySelector("ul.jd_menu > li:first-child")?.textContent !== header
    || location.href !== url.href || !radio.isConnected || !button.isConnected) return { phase: "changed" };
  if (!visible(panel)) return { phase: "ready", identity };
  if (!visible(radio) || !visible(button) || radio.disabled || button.disabled
    || normalize(reason()) !== "醫療需要" || normalize(button.value || button.textContent) !== "確定送出") return { phase: "unavailable" };
  if (!radio.checked) radio.click();
  if (!radio.checked || !radio.isConnected || !button.isConnected || radio.name !== 'p_reason' || radio.value !== '0'
    || document.querySelector("ul.jd_menu > li:first-child")?.textContent !== header
    || location.href !== url.href || !visible(panel) || !visible(radio) || !visible(button) || radio.disabled || button.disabled
    || !panel.contains(radio) || !panel.contains(button) || normalize(button.value || button.textContent) !== '確定送出'
    || normalize(reason()) !== "醫療需要") return { phase: "changed" };
  panel.__wildcatchMedicalNeedSubmission = { histno: expected.histno, day };
  button.click();
  return { phase: "submitted", identity };
}

export async function prepareDownloadAudit({ tabId, baseUrl, histno, signal, onProgress }) {
  const deadline = Date.now() + AUDIT_TIMEOUT_MS;
  const controller = new AbortController();
  const stop = () => controller.abort();
  signal?.addEventListener("abort", stop, { once: true });
  const timer = setTimeout(stop, AUDIT_TIMEOUT_MS);
  const token = crypto.randomUUID();
  pendingAudits.set(token, { tabId, baseUrl, histno, expiresAt: deadline,
    active: () => !signal?.aborted && !controller.signal.aborted, used: false });
  let identity, submitted = false, ready = 0;
  const checkAbort = () => { if (signal?.aborted || controller.signal.aborted) throw new SyncAbortError(); };
  const step = async action => {
    checkAbort();
    let tab;
    try { tab = await awaitWithSignal(chrome.tabs.get(tabId), controller.signal); }
    catch (error) {
      checkAbort();
      throw new Error("HIS 分頁已關閉或無法讀取，已停止調閱與下載。");
    }
    checkAbort();
    const page = parseQemrPatientPage(tab.url);
    if (!page || page.baseUrl !== baseUrl || page.histno !== histno) return { phase: "changed" };
    if (tab.status === "loading") return { phase: "loading" };
    let results;
    try {
      results = await awaitWithSignal(chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] }, func: downloadAuditPageStep,
        args: [action, { baseUrl, histno, identity, expiresAt: deadline, token, submitted }],
      }), controller.signal);
    } catch (error) {
      checkAbort();
      // Navigation can destroy the frame after tabs.get reported complete.
      // Re-check its URL on the next poll; never repeat a submission attempt.
      return { phase: "loading" };
    }
    checkAbort();
    return results?.[0]?.result || { phase: "loading" };
  };
  try {
    while (Date.now() < deadline) {
      const state = await step(ready >= 2 ? "complete" : "inspect");
      if (state.phase === "changed") throw new Error("病人已切換，已停止調閱與下載。");
      if (state.phase === "unavailable") throw new Error("無法確認病人或醫療需要調閱控制項，請在 HIS 確認後重試。");
      if (state.phase !== "loading" && (!["audit", "ready", "pending"].includes(state.phase)
        || !state.identity?.name || !/^\d{4}-\d{2}-\d{2}$/.test(state.identity.birthDate || ""))) {
        throw new Error("無法確認病人或醫療需要調閱控制項，請在 HIS 確認後重試。");
      }
      if (state.identity) identity ??= state.identity;
      if (state.phase === "pending") submitted = true;
      if (state.phase === "ready") {
        if (++ready >= 3) return;
      } else {
        ready = 0;
        if (state.phase === "audit" && !submitted) {
          await onProgress?.("正在送出醫療需要調閱理由…");
          checkAbort();
          submitted = true;
          const result = await step("submit");
          if (result.phase === "changed") throw new Error("病人已切換，已停止調閱與下載。");
          if (!["submitted", "ready", "loading"].includes(result.phase)) throw new Error("醫療需要尚未送出，請在 HIS 確認後重試。");
          await onProgress?.("等待 HIS 完成醫療需要調閱…");
        }
      }
      await delayWithSignal(AUDIT_POLL_MS, controller.signal);
    }
  } catch (error) {
    if (signal?.aborted) throw new SyncAbortError();
    if (!controller.signal.aborted) throw error;
  } finally {
    pendingAudits.delete(token);
    clearTimeout(timer);
    signal?.removeEventListener("abort", stop);
  }
  throw new Error("HIS 調閱視窗尚未關閉，已停止下載；不會重複送出醫療需要。請在 HIS 完成調閱或重新整理頁面後重試。");
}
