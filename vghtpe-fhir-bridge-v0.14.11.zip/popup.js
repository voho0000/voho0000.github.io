// Browser-local capture, download, progress and explicit paired-extension settings.

import { openMediPrisma } from "./viewer.js";
import { hasUnreadSyncCompletion } from "./sync-notifications.js";
import { createRecordRange, normalizeRecordYears, recordRangeLabel } from "./record-range.js";

const QEMR_PATIENT_SEARCH_URL =
  "https://web9.vghtpe.gov.tw/emr/qemr/qemr.cfm?action=findPatient";

const QEMR_HOST_RE = /vghtpe\.gov\.tw$|^(localhost|127\.0\.0\.1)$/;
const CHEVRON = '<svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';

const els = {
  wizardStepper: document.getElementById("wizard-stepper"),
  openSettingsBtn: document.getElementById("open-settings-btn"),
  settingsBackBtn: document.getElementById("settings-back-btn"),
  openQemrBtn: document.getElementById("open-qemr-btn"),
  patientSearchSection: document.getElementById("patient-search-section"),
  patientSearchHint: document.getElementById("patient-search-hint"),
  patientReadySection: document.getElementById("patient-ready-section"),
  patientReadyValue: document.getElementById("patient-ready-value"),
  patientReadyNext: document.getElementById("patient-ready-next"),
  patientId: document.getElementById("patient-id"),
  captureOptions: document.getElementById("capture-options"),
  captureSummary: document.getElementById("capture-summary"),
  syncBtn: document.getElementById("sync-btn"),
  stopBtn: document.getElementById("stop-btn"),
  htmlBtn: document.getElementById("html-btn"),
  launchBtn: document.getElementById("launch-btn"),
  viewerStatus: document.getElementById("viewer-status"),
  backToResultsBtn: document.getElementById("back-to-results-btn"),
  deidToggle: document.getElementById("deid-toggle"),
  recordYears: document.getElementById("record-years"),
  recordRangeHint: document.getElementById("record-range-hint"),
  outpatientToggle: document.getElementById("outpatient-toggle"),
  recordScopeHint: document.getElementById("record-scope-hint"),
  moduleStatusSummary: document.getElementById("module-status-summary"),
  fullModuleList: document.getElementById("full-module-list"),
  outpatientModuleList: document.getElementById("outpatient-module-list"),
  history: document.getElementById("history"),
  status: document.getElementById("status"),
  syncFeedback: document.getElementById("sync-feedback"),
  statusHeading: document.getElementById("status-heading"),
  progressBlock: document.getElementById("progress-block"),
  progressValue: document.getElementById("progress-value"),
  syncProgress: document.getElementById("sync-progress"),
  syncProgressFill: document.getElementById("sync-progress-fill"),
  timing: document.getElementById("timing"),
  syncErrors: document.getElementById("sync-errors"),
  breakdown: document.getElementById("breakdown"),
};

let activeStep = 1;
let savedRecordYears = "3";
let patientDetected = false;
let syncCompleted = false;
let latestSyncStatus = null;

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderSyncErrors(errors) {
  const list = Array.isArray(errors) ? errors.filter(Boolean) : [];
  els.syncErrors.hidden = list.length === 0;
  els.syncErrors.open = false;
  els.syncErrors.querySelector("summary").textContent = `${list.length} 個步驟發生錯誤（展開查看）`;
  els.syncErrors.querySelector("ul").innerHTML = list
    .slice(0, 100)
    .map((error) => `<li>${escapeHtml(error)}</li>`)
    .join("");
}

function isStepDone(step) {
  if (step === 1) return patientDetected;
  if (step === 2) return syncCompleted;
  return false;
}

function refreshWizardUi() {
  for (const item of els.wizardStepper.querySelectorAll("li[data-step]")) {
    const step = Number(item.dataset.step);
    item.setAttribute("aria-selected", String(step === activeStep));
    item.tabIndex = step === activeStep ? 0 : -1;
    if (step === activeStep) item.setAttribute("aria-current", "true");
    else item.removeAttribute("aria-current");
    if (isStepDone(step)) item.dataset.done = "true";
    else delete item.dataset.done;
  }
}

function setActiveStep(step, { scroll = true } = {}) {
  activeStep = Math.max(1, Math.min(3, Number(step) || 1));
  document.body.dataset.activeStep = String(activeStep);
  refreshWizardUi();
  if (scroll && activeStep >= 2) void acknowledgeVisibleCompletion();
  if (scroll) window.scrollTo({ top: 0, behavior: "smooth" });
}

function openSettingsView() {
  document.body.dataset.view = "settings";
  window.scrollTo({ top: 0, behavior: "instant" });
}

function closeSettingsView() {
  delete document.body.dataset.view;
  refreshWizardUi();
  window.scrollTo({ top: 0, behavior: "instant" });
}

function showPatientSearchState(message) {
  patientDetected = false;
  els.patientReadySection.hidden = true;
  els.patientSearchSection.hidden = false;
  if (message) {
    const strong = els.patientSearchHint.querySelector("strong");
    strong.textContent = message.title;
    for (const node of [...els.patientSearchHint.childNodes]) {
      if (node.nodeType === Node.TEXT_NODE) node.remove();
    }
    els.patientSearchHint.append(` ${message.detail}`);
  }
  setActiveStep(1, { scroll: false });
}

function showDetectedPatient(histno) {
  patientDetected = true;
  els.patientId.textContent = histno;
  els.patientReadyValue.textContent = histno;
  els.patientSearchSection.hidden = true;
  els.patientReadySection.hidden = false;
  els.syncBtn.disabled = false;
  els.htmlBtn.disabled = false;
  
  refreshWizardUi();
}

// FHIR resourceType → Chinese label used in the post-sync breakdown panel.
// Listed in the order we want them displayed (clinically: who → what → when).
const RESOURCE_LABELS = [
  ["Patient",            "病人資料"],
  ["AllergyIntolerance", "過敏"],
  ["Condition",          "診斷"],
  ["Encounter",          "就診"],
  ["MedicationRequest",  "處方"],
  ["ServiceRequest",     "門診醫令"],
  ["Observation",        "檢驗"],
  ["DiagnosticReport",   "報告"],
  ["Procedure",          "處置"],
  ["DocumentReference",  "病歷文件"],
  ["Device",             "植入物"],
  ["CarePlan",           "癌症治療計畫"],
];

function renderBreakdown(breakdown) {
  if (!breakdown || typeof breakdown !== "object") {
    els.breakdown.className = "";
    els.breakdown.innerHTML = "";
    return;
  }
  // Always show all categories (zero counts greyed out) — makes "what
  // wasn't captured" obvious.
  const rows = RESOURCE_LABELS.map(([type, label]) => {
    const n = Math.max(0, Number(breakdown[type]) || 0);
    return `<div class="row${n === 0 ? " zero" : ""}"><span class="label">${label}</span><span class="count">${n}</span></div>`;
  }).join("");
  const total = RESOURCE_LABELS.reduce((sum, [type]) => sum + Math.max(0, Number(breakdown[type]) || 0), 0);
  els.breakdown.innerHTML = `<summary><span>本次取得明細</span><span class="summary-count">${total.toLocaleString()} 筆</span>${CHEVRON}</summary><div class="breakdown-grid">${rows}</div>`;
  els.breakdown.className = "has-data";
}

function currentMode() { return "download"; }

function setStatus(text, kind) {
  els.status.textContent = String(text || "").replace(/^[\p{Extended_Pictographic}\uFE0F\s]+/u, "");
  els.status.className = kind || "";
  els.syncFeedback.hidden = !text;
  els.syncFeedback.dataset.kind = kind || "info";
  els.statusHeading.textContent = document.body.dataset.syncRunning === "true"
    ? "正在取得資料"
    : kind === "success" ? "取得完成" : kind === "warning" ? "部分資料未取得"
      : kind === "error" ? "取得遇到問題" : "取得狀態";
}

function setRunningState(running) {
  const wasRunning = document.body.dataset.syncRunning === "true";

  if (!running) els.stopBtn.disabled = false;
  document.body.dataset.syncRunning = String(!!running);
  els.syncBtn.disabled = !!running || !patientDetected;
  els.htmlBtn.disabled = !!running || !patientDetected;
  els.outpatientToggle.disabled = !!running;
  els.recordYears.disabled = !!running || els.outpatientToggle.checked;
  els.stopBtn.hidden = !running;
  refreshCaptureSummary();
}

function refreshCaptureSummary() {
  const mode = latestSyncStatus?.running ? latestSyncStatus.mode || currentMode() : currentMode();
  const label = "本機下載 FHIR";
  const outpatient = latestSyncStatus?.running ? !!latestSyncStatus.outpatientMode : els.outpatientToggle.checked;
  const range = latestSyncStatus?.running ? latestSyncStatus.recordRange || createRecordRange(outpatient ? "1" : els.recordYears.value) : createRecordRange(outpatient ? "1" : els.recordYears.value);
  els.captureSummary.textContent = `${label} · ${outpatient ? "門診版 · " : ""}${recordRangeLabel(range.years)}`;
  els.recordRangeHint.textContent = range.start
    ? `${range.start} 至 ${range.end}（台灣日期，含起訖日）`
    : "取得院內系統提供的全部歷史紀錄。";
  els.recordScopeHint.textContent = outpatient
    ? "每位主治醫師只取得最新一次門診的完整診斷、SOAP、用藥與醫囑；SOAP 內的歷史內容完整保留。"
    : "";
  els.recordScopeHint.hidden = !outpatient;
  els.moduleStatusSummary.textContent = outpatient ? "最新門診・SOAP・診斷・醫囑" : "病歷與 FHIR 資料";
  els.fullModuleList.hidden = outpatient;
  els.outpatientModuleList.hidden = !outpatient;
}

function renderSyncProgress(status) {
  els.progressBlock.hidden = !status?.running;
  const total = Math.max(0, Number(status?.requestProgress?.total) || 0);
  const completed = Math.min(total, Math.max(0, Number(status?.requestProgress?.completed) || 0));
  const percent = total ? Math.round(completed / total * 100) : 0;
  els.syncProgress.dataset.indeterminate = String(!total);
  els.syncProgressFill.style.width = total ? `${percent}%` : "";
  els.progressValue.textContent = total ? `${completed} / ${total}` : "準備中";
  if (total) {
    els.syncProgress.setAttribute("aria-valuenow", String(percent));
    els.syncProgress.setAttribute("aria-valuetext", `已完成 ${completed} / ${total} 個頁面請求`);
  } else {
    els.syncProgress.removeAttribute("aria-valuenow");
    els.syncProgress.setAttribute("aria-valuetext", "準備取得資料");
  }
}

function renderSyncTiming(status, now = Date.now()) {
  if (!status?.started || (!status.running && !["done", "partial"].includes(status.phase))) {
    els.timing.textContent = "";
    els.timing.className = "";
    return;
  }
  const end = status.running ? now : (status.completed || now);
  const elapsed = Math.max(0, Math.floor((end - status.started) / 1_000));
  const requests = status.requestProgress;
  const ratioEstimate = status.running && requests?.completed >= 3 && requests.total > requests.completed
    ? Math.ceil(elapsed * requests.total / requests.completed)
    : 0;
  const estimated = status.running
    ? Math.max(elapsed, Number(status.estimatedTotalSeconds) || 0, ratioEstimate)
    : elapsed;
  els.timing.textContent = status.running
    ? `已用 ${elapsed} 秒 · 預估共 ${estimated} 秒`
    : `總耗時 ${elapsed} 秒`;
  els.timing.className = "active";
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function loadSettings() {
  const synced = await chrome.storage.sync.get(["deidentify", "recordYears", "outpatientMode"]);
  els.deidToggle.checked = !!synced.deidentify;
  savedRecordYears = normalizeRecordYears(synced.recordYears);
  els.outpatientToggle.checked = synced.outpatientMode === true;
  els.recordYears.value = els.outpatientToggle.checked ? "1" : savedRecordYears;
  els.recordYears.disabled = els.outpatientToggle.checked;
  refreshCaptureSummary();
}
els.deidToggle.addEventListener("change", () => {
  chrome.storage.sync.set({ deidentify: els.deidToggle.checked });
});
els.recordYears.addEventListener("change", () => {
  savedRecordYears = els.recordYears.value;
  chrome.storage.sync.set({ recordYears: els.recordYears.value });
  refreshCaptureSummary();
});
els.outpatientToggle.addEventListener("change", () => {
  chrome.storage.sync.set({ outpatientMode: els.outpatientToggle.checked });
  els.recordYears.value = els.outpatientToggle.checked ? "1" : savedRecordYears;
  els.recordYears.disabled = els.outpatientToggle.checked;
  refreshCaptureSummary();
});







async function init() {
  els.version = document.getElementById("version");
  els.version.textContent = `v${chrome.runtime.getManifest().version}`;
  refreshWizardUi();
  await loadSettings();
  const tab = await getActiveTab();
  if (!tab?.url) {
    showPatientSearchState({
      title: "找不到使用中的分頁",
      detail: "請先開啟病人查詢頁。",
    });
    return;
  }

  let url;
  try {
    url = new URL(tab.url);
  } catch {
    showPatientSearchState({
      title: "無法讀取目前頁面",
      detail: "請改由上方按鈕開啟病人查詢頁。",
    });
    return;
  }

  if (!QEMR_HOST_RE.test(url.hostname)) {
    showPatientSearchState({
      title: "目前不是院內病歷頁面",
      detail: "請開啟病人查詢頁並選擇病人。",
    });
    return;
  }

  const histno = url.searchParams.get("histno");
  if (!histno) {
    els.patientId.textContent = "—";
    showPatientSearchState({
      title: "尚未選擇病人",
      detail: "請在院內系統查詢病人，並進入病人頁面。",
    });
    return;
  }

  showDetectedPatient(histno);
  setActiveStep(2, { scroll: false });

  // Re-attach to any sync that's already running in the SW.
  await refreshSyncStatusFromBackground({ acknowledgeCompletion: true });
  await loadHistory();
}

async function refreshSyncStatusFromBackground({ acknowledgeCompletion = false } = {}) {
  const status = await chrome.runtime.sendMessage({ type: "getSyncStatus" }).catch(() => null);
  applySyncStatus(status);
  if (acknowledgeCompletion) await acknowledgeVisibleCompletion();
}

async function acknowledgeVisibleCompletion() {
  const status = latestSyncStatus;
  if (!hasUnreadSyncCompletion(status) || status.histno !== els.patientId.textContent.trim()) return;
  const response = await chrome.runtime.sendMessage({
    type: "acknowledgeSyncCompletion", histno: status.histno,
    started: status.started, completed: status.completed,
  }).catch(() => null);
  if (response?.status) applySyncStatus(response.status);
}

function applySyncStatus(status) {
  if (!status) return;
  // Only adopt the cached status' histno if THIS popup hasn't already pinned
  // a histno from the current tab's URL. Otherwise a previous sync (different
  // patient still in chrome.storage.local) would clobber the current page's
  // patient_id field.
  const currentHistno = els.patientId.textContent.trim();
  const matchesCurrent = currentHistno && currentHistno !== "—" && currentHistno === status.histno;
  if (!matchesCurrent) return;
  latestSyncStatus = status;
  document.body.dataset.completionUnread = String(hasUnreadSyncCompletion(status));
  setRunningState(status.running);
  const failed = status.phase === "error" || status.phase === "interrupted";
  const cancelled = status.phase === "cancelled";
  const partial = status.phase === "partial";
  setStatus(
    status.progress || "(sync 進行中)",
    status.running ? "info" : failed ? "error" : cancelled ? "info" : partial ? "warning" : "success",
  );
  renderSyncTiming(status);
  renderSyncProgress(status);
  renderSyncErrors(status.errors);
  if (!status.running && ["done", "partial"].includes(status.phase)) {
    syncCompleted = !partial;
    refreshWizardUi();
    renderBreakdown(status.breakdown);
    loadHistory();
  } else if (status.running) {
    syncCompleted = false;
    refreshWizardUi();
    // Hide stale breakdown while a new sync is in progress.
    renderBreakdown(null);
  }
}

async function stopSync() {
  els.stopBtn.disabled = true;
  setStatus("⏹ 正在取消取得…", "info");
  const response = await chrome.runtime.sendMessage({ type: "abortSync" }).catch(() => null);
  if (response?.status) applySyncStatus(response.status);
  if (!response) {
    applySyncStatus({ histno: els.patientId.textContent.trim(), running: false, phase: "error", progress: "無法聯絡背景程序，請關閉後重新開啟擴充功能" });
  }
  setTimeout(() => { els.stopBtn.disabled = false; }, 1500);
}

setInterval(() => {
  if (latestSyncStatus?.running) renderSyncTiming(latestSyncStatus);
}, 1_000);

async function loadHistory() {
  const { syncHistory, syncStatus } = await chrome.storage.local.get(["syncHistory", "syncStatus"]);
  const rows = (syncHistory || []).slice(0, 5).map((row) => ({ ...row }));
  // v0.11.5 and earlier stored only the error count in history. Recover the
  // latest run's details from syncStatus when it is still available.
  if (rows[0] && !rows[0].runId && !syncStatus?.runId && !rows[0].errorDetails?.length && Array.isArray(syncStatus?.errors)
      && rows[0].histno === syncStatus.histno) {
    rows[0].errorDetails = syncStatus.errors;
  }
  if (!rows.length) { els.history.innerHTML = ""; return; }
  const fmt = (ts) => {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, "0");
    return `${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };
  const items = rows.map((r) => {
    const tags = [
      r.mode === "backend" ? "歷史後端（已停用）" : r.mode === "mediprisma" ? "歷史 MediPrisma" : r.mode === "outpatient-peer" ? "配對取得" : r.mode === "html" ? "原始資料" : r.mode === "download" ? "下載" : "歷史模式",
      r.deidentify ? "去識別" : null,
      r.recordRange ? recordRangeLabel(r.recordRange.years) : null,
      r.outpatientMode ? "門診版" : null,
      r.aborted ? "中止" : null,
    ].filter(Boolean);
    const errorCount = Number(r.errors) || 0;
    const details = (r.errorDetails || []).filter(Boolean);
    const errorDetails = details.length ? `<details class="history-errors">
      <summary>${errorCount || details.length} 個錯誤明細</summary>
      <ul>${details.slice(0, 100).map((error) => `<li>${escapeHtml(error)}</li>`).join("")}</ul>
    </details>` : "";
    const delivery = [
      r.fhirDownloadStarted ? "FHIR 下載已啟動" : null,
      r.mediprismaImported ? "FHIR 已匯入 MediPrisma" : null,
      r.htmlDownloadStarted ? "HTML 封存下載已啟動"
        : r.deliveryError && r.htmlDownloadRequested ? "HTML 封存下載失敗"
        : r.htmlCancelled ? "HTML 封存已取消" : null,
      r.deliveryError && !r.htmlDownloadRequested ? "交付後續處理失敗" : null,
    ].filter(Boolean);
    const deliveryDetails = delivery.length ? `<div class="history-delivery">${delivery.map(escapeHtml).join(" · ")}${r.deliveredFile ? `<div>請求檔名：${escapeHtml(r.deliveredFile)}</div>` : ""}${r.htmlZipName ? `<div>請求檔名：${escapeHtml(r.htmlZipName)}</div>` : ""}</div>` : "";
    return `<div class="history-entry">
      <div class="history-main"><span class="history-patient">${escapeHtml(r.histno)}</span><span class="history-count">${(Number(r.total) || 0).toLocaleString()} 筆</span></div>
      <div class="history-meta">
        <span class="history-time">${fmt(r.ts)}</span>
        ${tags.length ? `<span class="history-tags">${tags.map(escapeHtml).join(" · ")}</span>` : ""}
        ${errorCount ? `<span class="history-error-tag">${errorCount} 個錯誤</span>` : ""}
        ${r.deliveryError ? '<span class="history-error-tag">交付失敗</span>' : ""}
      </div>${deliveryDetails}${errorDetails}
    </div>`;
  }).join("");
  const wasOpen = !!els.history.querySelector("details")?.open;
  els.history.innerHTML = `<details class="history-card"${wasOpen ? " open" : ""}><summary><span>同步紀錄</span><span class="summary-count">最近 ${rows.length} 次</span>${CHEVRON}</summary><div class="history-list">${items}</div></details>`;
}

// Storage events fire reliably even when popup was closed at broadcast time.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.syncStatus) applySyncStatus(changes.syncStatus.newValue);
  if (changes.syncHistory) void loadHistory();
});
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "syncProgress") applySyncStatus(msg.status);
});

async function syncThisPatient() {
  const tab = await getActiveTab();
  let url;
  try { url = new URL(tab.url); } catch { setStatus("active tab URL invalid", "error"); return; }
  const histno = url.searchParams.get("histno");
  if (!histno) { setStatus("URL 沒有 histno=", "error"); return; }

  const payload = {
    tabId: tab.id,
    host: url.hostname,
    baseUrl: `${url.protocol}//${url.host}`,
    histno,
    mode: currentMode(),
    deidentify: els.deidToggle.checked,
    recordYears: els.recordYears.value,
    outpatientMode: els.outpatientToggle.checked,
    syncRunId: `run-${Date.now()}-${histno}`,
  };

  setActiveStep(2, { scroll: false });
  applySyncStatus({ histno, mode: payload.mode, outpatientMode: payload.outpatientMode, recordRange: createRecordRange(payload.recordYears), running: true, started: Date.now(), phase: "init", progress: "正在準備取得病歷，可關閉視窗繼續執行" });
  chrome.runtime.sendMessage({ type: "startSync", payload }).catch(() => {
    applySyncStatus({ histno, running: false, phase: "error", progress: "無法啟動背景取得，請重新開啟擴充功能後再試" });
  });
}

async function launch() {
  if (els.launchBtn.disabled) return;
  els.launchBtn.disabled = true;
  els.launchBtn.textContent = "正在開啟…";
  setViewerStatus(els.viewerStatus, "正在開啟 MediPrisma…", "info");
  try {
    await openMediPrisma(chrome.tabs);
    setViewerStatus(els.viewerStatus, "MediPrisma 已開啟，可匯入先前下載的 FHIR 檔案。", "success");
  } catch {
    setViewerStatus(els.viewerStatus, "無法開啟 MediPrisma 分頁，請再試一次。", "error");
  } finally {
    els.launchBtn.disabled = false;
    els.launchBtn.textContent = "開啟 MediPrisma";
  }
}

function setViewerStatus(target, text, kind) {
  target.textContent = text;
  target.dataset.kind = kind;
  target.hidden = !text;
}



async function downloadPatientHtml() {
  const tab = await getActiveTab();
  let url;
  try { url = new URL(tab.url); } catch { setStatus("active tab URL invalid", "error"); return; }
  const histno = url.searchParams.get("histno");
  if (!histno) { setStatus("URL 沒有 histno=", "error"); return; }
  if (els.deidToggle.checked) {
    setStatus("❌ 原始 HTML 含病歷識別資料；請關閉去識別化，或改用「下載 Bundle」", "error");
    return;
  }

  const payload = {
    tabId: tab.id,
    host: url.hostname,
    baseUrl: `${url.protocol}//${url.host}`,
    histno,
    mode: "download",
    deidentify: els.deidToggle.checked,
    recordYears: els.recordYears.value,
    outpatientMode: els.outpatientToggle.checked,
    syncRunId: `run-${Date.now()}-${histno}`,
    includeHtmlZip: true,
  };

  applySyncStatus({ histno, mode: payload.mode, outpatientMode: payload.outpatientMode, recordRange: createRecordRange(payload.recordYears), running: true, started: Date.now(), phase: "init", progress: "正在準備 FHIR Bundle 與 HTML ZIP" });
  chrome.runtime.sendMessage({ type: "startSync", payload }).catch(() => {
    applySyncStatus({ histno, running: false, phase: "error", progress: "無法啟動合併下載，請重新開啟擴充功能後再試" });
  });
}

els.syncBtn.addEventListener("click", syncThisPatient);
els.stopBtn.addEventListener("click", stopSync);
els.htmlBtn.addEventListener("click", downloadPatientHtml);
els.launchBtn.addEventListener("click", launch);

els.backToResultsBtn.addEventListener("click", () => setActiveStep(2));
els.openSettingsBtn.addEventListener("click", openSettingsView);
els.settingsBackBtn.addEventListener("click", closeSettingsView);
els.openQemrBtn.addEventListener("click", async () => {
  await chrome.tabs.create({ url: QEMR_PATIENT_SEARCH_URL });
  window.close();
});
els.patientReadyNext.addEventListener("click", () => setActiveStep(2));
for (const item of els.wizardStepper.querySelectorAll("li[data-step]")) {
  const activate = () => setActiveStep(Number(item.dataset.step));
  item.addEventListener("click", activate);
  item.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      activate();
    } else if (["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) {
      event.preventDefault();
      const next = event.key === "Home" ? 1 : event.key === "End" ? 3
        : ((activeStep - 1 + (event.key === "ArrowRight" ? 1 : 2)) % 3) + 1;
      setActiveStep(next);
      els.wizardStepper.querySelector(`li[data-step="${next}"]`).focus();
    }
  });
}
init();
