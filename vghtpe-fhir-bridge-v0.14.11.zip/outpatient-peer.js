import { parseQemrPatientPage } from './one-click.js';
import { OP_PROTOCOL, OP_TTL, OP_CHUNK_SIZE, validOutpatientRequest, outpatientPageStep, verifyOutpatientIdentity, hasComparableOutpatientIdentity } from "./outpatient-integration.js";
import { CLOUD_PEER_KEY, pairedCloudId, readPairedCloudId } from "./paired-extension.js";
import { isSyncAbortError, isHisRequestBlockedError } from "./sync-runtime.js";
export const OP_CONTACT_TTL = 30_000;

export function installOutpatientPeer({ capture, readIdentity, busy, abort }) {
  let job = null;
  let selectionNotice = null;
  let resumeInFlight = false;
  const preflightStatus = current => ({
    mode: 'outpatient-peer', preflight: true, tabId: current.tabId,
    phase: current.phase, running: ['opening', 'searching', 'auditing'].includes(current.phase),
    manualActionRequired: ['selection', 'login', 'audit'].includes(current.phase),
    manualSelectionRequired: current.manualSelectionRequired === true,
    progress: current.manualSelectionRequired
      ? current.resumeSupported ? '本次先使用雲端資料；請手動點選正確病人，選定並完成調閱確認後，點「繼續抓取」。' : '本次先使用雲端資料；請手動點選正確病人，再回雲端重新取得。'
      : ['selection', 'login', 'audit'].includes(current.phase) ? '請在 HIS 完成登入、選定病人或調閱確認；也可回雲端選擇本次只用雲端。'
      : current.phase === 'searching' ? '正在等待 HIS 查詢結果…' : '正在開啟並核對 HIS 病人…',
  });
  const publishPreflight = current => {
    if (!Number.isInteger(current.tabId) || current.captureActive) return;
    const status = preflightStatus(current);
    if (current.manualSelectionRequired) selectionNotice = {
      status, expiresAt: Date.now() + 5 * 60_000,
      requestedIdentity: { ...current.identity }, resumeSupported:current.resumeSupported, ...(current.resumeSupported?{jobId:current.jobId,token:current.token}:{}), knownTabIds: current.knownTabIds || [], peer: current.peer,
    };
    try { Promise.resolve(chrome.tabs.sendMessage?.(current.tabId, { type: 'syncProgress', status }, { frameId: 0 })).catch(() => {}); } catch {}
  };
  const release = current => {
    clearTimeout(current.timer); clearTimeout(current.contactTimer);
    current.preflightAbort.abort();
    const shouldAbort = current.captureActive === true;
    current.captureActive = false;
    current.cancelled = true; current.data = null; current.clinicData = null; current.identity = null; current.actionPermit = null;
    if (job === current) job = null;
    if (shouldAbort) abort(current.tabId, current.owner);
  };
  const expireDisconnected = () => {
    if (job && (Date.now() >= job.expiresAt || Date.now() - job.lastContact >= OP_CONTACT_TTL)) release(job);
  };
  const touch = current => {
    current.lastContact = Date.now();
    clearTimeout(current.contactTimer);
    current.contactTimer = setTimeout(expireDisconnected, OP_CONTACT_TTL);
  };
  chrome.storage.onChanged?.addListener((changes, area) => {
    if (area !== 'local' || !changes[CLOUD_PEER_KEY]) return;
    selectionNotice = null;
    if (!job) return;
    if (pairedCloudId(changes[CLOUD_PEER_KEY].newValue) !== job.peer) release(job);
  });
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const check = current => {
    if (job !== current || current.cancelled || Date.now() > current.expiresAt) throw new Error("OUTPATIENT_CANCELLED");
  };
  const step = async (current, action) => {
    check(current);
    const tab = await chrome.tabs.get(current.tabId);
    check(current);
    if (!/^https:\/\/[^/]*vghtpe\.gov\.tw\/emr\/qemr\//.test(tab.url || "")) return { phase: "login", message: "請登入 HIS 後回到這個病人查詢分頁。" };
    const actionPermit = ["search", "select", "audit"].includes(action)
      ? { token: crypto.randomUUID(), expiresAt: Math.min(current.expiresAt, Date.now() + 5000) } : undefined;
    current.actionPermit = actionPermit ? { ...actionPermit, action, used: false } : null;
    const results = await chrome.scripting.executeScript({ target: { tabId: current.tabId, frameIds: [0] }, func: outpatientPageStep,
      args: [action, {...current.identity, queryId:current.jobId, actionPermit}] });
    check(current);
    return results[0]?.result || { phase: "waiting" };
  };
  chrome.runtime.onMessage?.addListener((message, sender, sendResponse) => {
    if (message?.type !== "authorizeOutpatientPageAction") return false;
    const current = job;
    void (async () => {
      const peer = await readPairedCloudId();
      const permit = current?.actionPermit;
      let page;
      try { page = new URL(sender.url || sender.tab?.url); } catch { return { ok: false }; }
      const ok = !!current && job === current && !current.cancelled && Date.now() < current.expiresAt
        && peer === current.peer && sender.id === chrome.runtime.id && sender.tab?.id === current.tabId && sender.frameId === 0
        && page.protocol === "https:" && /(^|\.)vghtpe\.gov\.tw$/.test(page.hostname) && page.pathname.startsWith("/emr/qemr/")
        && !!permit && !permit.used && permit.token === message.token && permit.action === message.action && Date.now() < permit.expiresAt;
      if (ok) permit.used = true;
      return { ok };
    })().then(sendResponse, () => sendResponse({ ok: false }));
    return true;
  });
  async function run(current) {
    try {
      const partialName = /[*�]/u.test(current.identity.name.normalize("NFKC"));
      const manualIntent = selectionNotice;
      selectionNotice = null;
      const tabs = await chrome.tabs.query({ url: "https://*.vghtpe.gov.tw/emr/qemr/*" });
      check(current);
      // Reuse a selected chart or query page in the existing authenticated origin.
      const charts = tabs.filter(tab => /[?&]histno=\d+/.test(tab.url || ""));
      const selected = charts.filter(tab => tab.active);
      const sameRequest = manualIntent?.peer === current.peer && Math.max(manualIntent.expiresAt,manualIntent.handoffExpiresAt || 0) > Date.now() && ['name', 'sourceId', 'birthDate', 'gender'].every(key =>
        String(manualIntent.requestedIdentity?.[key] || '').normalize('NFKC').trim() === String(current.identity[key] || '').normalize('NFKC').trim());
      const manuallyChosen = sameRequest ? charts.filter(tab => manualIntent.selectedTabId !== undefined ? tab.id === manualIntent.selectedTabId : tab.id === manualIntent.status.tabId || !manualIntent.knownTabIds.includes(tab.id)) : [];
      const manualTab = manuallyChosen.length === 1 ? manuallyChosen[0] : null;
      const previousQuery = sameRequest ? tabs.find(tab => tab.id === manualIntent.status.tabId && new URL(tab.url).searchParams.get('action') === 'findPatient') : null;
      const searchTabs = tabs.filter(tab => new URL(tab.url).searchParams.get('action') === 'findPatient');
      const activeSearch = searchTabs.filter(tab => tab.active);
      const tab = manualTab || previousQuery || (selected.length === 1 ? selected[0] : activeSearch.length === 1 ? activeSearch[0]
        : charts.length === 1 ? charts[0] : searchTabs.length === 1 ? searchTabs[0] : undefined);
      let searchOpened = false;
      const openSearch = async originTab => {
        check(current);
        const origin = originTab?.url ? new URL(originTab.url).origin : "https://web9.vghtpe.gov.tw";
        const created = await chrome.tabs.create({ url: `${origin}/emr/qemr/qemr.cfm?action=findPatient`, active: true,
          ...(originTab?.windowId !== undefined ? {windowId:originTab.windowId} : {}) });
        check(current);
        current.tabId = created.id;
        searchOpened = true;
      };
      current.tabId = tab?.id;
      check(current);
      // Partial names require a new manual choice, not an old open chart.
      if ((partialName && !manualTab && !previousQuery) || current.tabId === undefined) await openSearch(tab || tabs.find(tab => tab.active) || tabs[0]);
      else await chrome.tabs.update(current.tabId, { active: true });
      let audited = false, auditStartedAt = null, stableChart = 0, searchedAt = null, searchAttempted = false, autoSelected = false, openingAt = null, selectionResult = null;
      while (true) {
        check(current);
        if (current.tabId === undefined) {
          if (current.loginRequested) {
            const active = await chrome.tabs.query({ active: true, url: "https://*.vghtpe.gov.tw/emr/qemr/*" });
            if (active.length === 1 && (!partialName || new URL(active[0].url).searchParams.get('action') === 'findPatient')) current.tabId = active[0].id;
          }
        }
        if (current.tabId === undefined) {
          current.phase = "login";
          current.message = "請開啟 HIS 登入並選定目前病人，完成後會自動核對並補抓。";
          await sleep(1000); continue;
        }
        let state;
        if (current.loginRequested) {
          let tab;
          try { tab = await chrome.tabs.get(current.tabId); } catch {
            current.tabId = undefined;
            current.phase = "login";
            current.message = "HIS 分頁已關閉，等待重新開啟並選定目前病人。";
            stableChart = 0; audited = false; auditStartedAt = null;
            await sleep(1000); continue;
          }
          const active = await chrome.tabs.query({ active: true, windowId: tab.windowId, url: "https://*.vghtpe.gov.tw/emr/qemr/*" });
          if (!partialName && active.length === 1 && active[0].id !== current.tabId) {
            current.tabId = active[0].id;
            stableChart = 0; audited = false; auditStartedAt = null;
          }
        }
        try {
          const currentTab = await chrome.tabs.get(current.tabId);
          if (currentTab.status === 'loading') {
            current.phase = 'opening'; current.message = '正在開啟 HIS 病人查詢頁…';
            await sleep(1000); continue;
          }
          state = await step(current, "inspect");
          if (state.phase === 'selection' && state.canSearch) {
            if (searchedAt === null && !searchAttempted) {
              state = await step(current, 'search');
              if (state.phase === 'searching') { searchAttempted = true; searchedAt = Date.now(); }
            } else if (selectionResult) {
              state = selectionResult;
            } else if (!autoSelected) {
              state = await step(current, 'select');
              autoSelected = state.phase === 'opening';
              if (autoSelected) openingAt = Date.now();
              if (state.phase === 'searching' && Date.now()-searchedAt >= 25_000) {
                state = {phase:'searching',message:'HIS 查詢仍在進行，請稍候…'};
              }
              if (state.phase === 'selection') selectionResult = state;
            } else if (Date.now() - openingAt < 15_000) {
              state = {phase:'opening',message:'正在等待 HIS 相符病歷頁開啟…'};
            } else {
              state = {phase:'selection',message:'請在 HIS 確認相符病歷頁，或回雲端選擇本次只用雲端。'};
            }
          }
        } catch {
          try { await chrome.tabs.get(current.tabId); } catch {
            current.tabId = undefined;
            stableChart = 0; audited = false; auditStartedAt = null;
          }
          await sleep(1000); continue;
        }
        if (state.phase === 'retry-query') {
          searchedAt = null; searchAttempted = false; selectionResult = null;
          state = { phase: 'searching', message: state.message };
        }
        current.phase = state.phase;
        if (state.phase === 'waiting-query') current.phase = 'searching';
        current.message = state.message || "正在核對 HIS 病人…";
        if (state.phase === 'selection' && state.queryCompleted === true) {
          current.manualSelectionRequired = true;
          current.knownTabIds = (await chrome.tabs.query({})).map(tab => tab.id);
          check(current);
          current.phase = 'error'; current.error = 'HIS_PATIENT_SELECTION_REQUIRED';
          publishPreflight(current);
          current.identity = null;
          return; // Cloud continues without guessing which row belongs to this patient.
        }
        publishPreflight(current);
        if (state.phase === 'audit' && state.automatic) {
          auditStartedAt ??= Date.now();
          if (Date.now() - auditStartedAt < 20_000) current.phase = 'auditing';
          else current.message = 'HIS 調閱稽核尚未完成，請在院內頁面確認後接續。';
        }
        if (state.phase === "mismatch") {
          // Leave an unrelated open chart intact and search in a new same-origin tab.
          if (searchedAt === null && !autoSelected && !searchOpened) {
            await openSearch(await chrome.tabs.get(current.tabId));
            current.phase = 'opening'; current.message = '正在開啟 HIS 查詢目前病人…';
            stableChart = 0; audited = false; auditStartedAt = null;
            await sleep(1000); continue;
          }
          current.phase = "selection";
          current.message = "HIS 仍是其他病人，請手動點選正確病人後重新取得。";
          if (searchAttempted) {
            current.manualSelectionRequired = true;
            current.knownTabIds = (await chrome.tabs.query({})).map(tab => tab.id);
            check(current);
            current.phase = 'error'; current.error = 'HIS_PATIENT_SELECTION_REQUIRED';
            publishPreflight(current);
            current.identity = null;
            return;
          }
          stableChart = 0; audited = false; auditStartedAt = null;
          await sleep(1000); continue;
        }
        if (state.phase === "audit" && state.automatic && !audited) {
          const outcome = await step(current, "audit");
          audited = outcome.phase === "audit";
        }
        // The audit dialog may mount after the patient header.
        stableChart = state.phase === "chart" ? stableChart + 1 : 0;
        if (stableChart >= 3) {
          current.loginRequested = false;
          current.histno = state.histno;
          const actual = await readIdentity(current.tabId, state.baseUrl, state.histno, current.preflightAbort.signal);
          check(current);
          const actualHistno = String(actual?.identifier || actual?.id || "");
          if (actualHistno && actualHistno !== state.histno) throw new Error("PATIENT_HIS_MISMATCH");
          if (!hasComparableOutpatientIdentity(current.identity, actual)) throw new Error("HIS_BUSY");
          if (!verifyOutpatientIdentity(current.identity, actual)) throw new Error("PATIENT_HIS_MISMATCH");
          current.phase = "capture"; current.message = "已核對病人，正在取得最新門診與當天報告…";
          let result;
          current.captureActive = true;
          try {
            result = await capture({ tabId: current.tabId, host: new URL(state.baseUrl).hostname,
              baseUrl: state.baseUrl, histno: state.histno, expectedIdentity: current.identity, outpatientOwner: current.owner,
              reportCoverageSupported: current.reportCoverageSupported,
              ...(current.progressiveSupported ? { onClinicReady: async result => {
                try {
                  check(current);
                  const chart = await step(current, "inspect");
                  if (chart.phase === "mismatch" || chart.phase === "chart" && chart.histno !== state.histno) throw new Error("PATIENT_HIS_MISMATCH");
                  // Optional delivery must not prevent the final capture when
                  // inspection is temporarily unavailable or an audit remounts.
                  if (chart.phase !== "chart") return;
                  const snapshot = JSON.stringify(result);
                  if (snapshot.length > 50_000_000) return;
                  check(current);
                  current.clinicData = snapshot;
                } catch (error) {
                  if (isSyncAbortError(error) || ["OUTPATIENT_CANCELLED", "PATIENT_HIS_MISMATCH"].includes(error.code || error.message)) throw error;
                  current.clinicData = null;
                }
              } } : {}) });
          } finally { current.captureActive = false; }
          check(current);
          const finalState = await step(current, "inspect");
          if (finalState.phase === "mismatch" || finalState.phase === "chart" && finalState.histno !== state.histno) throw new Error("PATIENT_HIS_MISMATCH");
          if (finalState.phase !== "chart") throw new Error("HIS_BUSY");
          current.data = JSON.stringify(result);
          if (current.data.length > 50_000_000) throw new Error("OUTPATIENT_RESULT_TOO_LARGE");
          current.identity = null;
          current.phase = "complete"; current.message = "北榮補充資料已完成";
          return;
        }
        await sleep(1000);
      }
    } catch (error) {
      current.data = null; current.identity = null; current.phase = "error";
      const code = error.code || error.message;
      current.error = ["PATIENT_HIS_MISMATCH", "HIS_BUSY"].includes(code) ? code
        : isSyncAbortError(error) || code === "OUTPATIENT_CANCELLED" ? "OUTPATIENT_CANCELLED"
        : isHisRequestBlockedError(error) ? "HIS_SESSION_BLOCKED"
        : current.clinicData ? "OUTPATIENT_REPORTS_FAILED" : "OUTPATIENT_CAPTURE_FAILED";
      if (current.error !== "OUTPATIENT_REPORTS_FAILED") current.clinicData = null;
      current.message = current.error === "PATIENT_HIS_MISMATCH" ? "病人資料不符，已停止合併。"
        : current.error === "HIS_BUSY" ? "北榮服務暫時無法完成身份核對，請稍後重試。"
        : "北榮取得未完成，請確認登入與病人頁面後重試。";
    }
  }
  chrome.runtime.onMessageExternal?.addListener((message, sender, sendResponse) => {
    if (message?.protocol !== OP_PROTOCOL) return false;
    void (async () => {
      const peer = await readPairedCloudId();
      if (!peer || sender.id !== peer || sender.tab) return { ok: false, error: "UNTRUSTED_PEER" };
      if (job && job.peer !== peer) release(job);
      expireDisconnected();
      if (message.action === "start") {
        if (!validOutpatientRequest(message)) return { ok: false, error: "INVALID_REQUEST" };
        if (job?.jobId === message.jobId && job.token === message.token) { touch(job); return { ok: true }; }
        if (busy() || (job && !["error", "complete"].includes(job.phase))) return { ok: false, error: "HIS_BUSY" };
        if (job) { clearTimeout(job.timer); clearTimeout(job.contactTimer); job.preflightAbort.abort(); job.data = null; job.clinicData = null; job.identity = null; }
        job = { jobId: message.jobId, token: message.token, peer, owner: `${message.jobId}:${message.token}`,
          resumeSupported:message.resumeVersion === 1, reportCoverageSupported: message.reportCoverageVersion === 1, progressiveSupported: message.progressiveVersion === 1,
          identity: message.identity, expiresAt: Date.now() + OP_TTL, phase: "starting", captureActive: false, preflightAbort: new AbortController() };
        // Store only a tombstone: a worker restart requires a fresh explicit launch.
        const old = await chrome.storage.session.get("outpatientLastJob");
        if (old.outpatientLastJob === message.jobId) { job = null; return { ok: false, error: "JOB_INTERRUPTED" }; }
        await chrome.storage.session.set({ outpatientLastJob: message.jobId });
        const started = job;
        touch(started);
        job.timer = setTimeout(() => {
          if (job !== started) return;
          release(started);
        }, OP_TTL);
        void run(job); return { ok: true };
      }
      if (!job || job.jobId !== message.jobId || job.token !== message.token) return { ok: false, error: "JOB_INTERRUPTED" };
      if (message.action === "open_login") {
        const current = job;
        if (!["starting", "login", "selection", "audit"].includes(current.phase)) return { ok: false, error: "INVALID_REQUEST" };
        touch(current);
        if (current.tabId !== undefined) {
          try {
            await chrome.tabs.update(current.tabId, { active: true });
            await chrome.tabs.get(current.tabId);
          } catch { current.tabId = undefined; }
        }
        if (current.tabId === undefined) {
          const tabs = await chrome.tabs.query({ url: "https://*.vghtpe.gov.tw/emr/qemr/*" });
          const eligible = /[*�]/u.test(current.identity.name.normalize("NFKC"))
            ? tabs.filter(tab => new URL(tab.url).searchParams.get('action') === 'findPatient') : tabs;
          const active = eligible.filter(tab => tab.active);
          const tab = (active.length === 1 ? active[0] : undefined) || (eligible.length === 1 ? eligible[0] : undefined) ||
            await chrome.tabs.create({ url: "https://web9.vghtpe.gov.tw/emr/qemr/qemr.cfm?action=findPatient", active: true });
          check(current);
          current.tabId = tab.id;
          await chrome.tabs.update(tab.id, { active: true });
        }
        check(current);
        const selectedTab = await chrome.tabs.get(current.tabId);
        if (selectedTab.windowId !== undefined) await chrome.windows?.update(selectedTab.windowId, { focused: true });
        current.loginRequested = true;
        return { ok: true };
      }
      if (message.action === "cancel" || message.action === "ack") {
        release(job); return { ok: true };
      }
      if (message.action === "poll") {
        touch(job);
        return { ok: true, phase: job.phase, message: job.message, error: job.error,
          chunks: job.data ? Math.ceil(job.data.length / OP_CHUNK_SIZE) : 0,
          ...(job.clinicData ? { clinic: { version: 1, chunks: Math.ceil(job.clinicData.length / OP_CHUNK_SIZE) } } : {}) };
      }
      if (message.action === "chunk" && message.snapshot === "clinic" && message.version === 1
        && (["capture", "complete"].includes(job.phase) || job.phase === "error" && job.error === "OUTPATIENT_REPORTS_FAILED")
        && job.clinicData && Number.isInteger(message.index)
        && message.index >= 0 && message.index < Math.ceil(job.clinicData.length / OP_CHUNK_SIZE)) {
        touch(job);
        return { ok: true, data: job.clinicData.slice(message.index * OP_CHUNK_SIZE, (message.index + 1) * OP_CHUNK_SIZE) };
      }
      if (message.action === "chunk" && message.snapshot === undefined && job.phase === "complete" && Number.isInteger(message.index) && message.index >= 0 && message.index < Math.ceil(job.data.length / OP_CHUNK_SIZE)) {
        touch(job);
        return { ok: true, data: job.data.slice(message.index * OP_CHUNK_SIZE, (message.index + 1) * OP_CHUNK_SIZE) };
      }
      return { ok: false, error: "INVALID_REQUEST" };
    })().then(sendResponse, () => sendResponse({ ok: false, error: "OUTPATIENT_FAILED" }));
    return true;
  });
  const resumeCandidate = sender => {
    const notice = selectionNotice;
    const page = parseQemrPatientPage(sender?.url || sender?.tab?.url || '');
    if (!notice || !notice.resumeSupported || notice.expiresAt <= Date.now() || sender.id !== chrome.runtime.id || sender.frameId !== 0 || !page ||
      !Number.isInteger(sender.tab?.id) || (sender.tab.id !== notice.status.tabId && notice.knownTabIds.includes(sender.tab.id))) return null;
    return {notice,page};
  };
  const resumeStatus = async sender => {
    const candidate = resumeCandidate(sender);
    if (!candidate || await readPairedCloudId() !== candidate.notice.peer || selectionNotice !== candidate.notice) return null;
    const chart=(await chrome.scripting.executeScript({target:{tabId:sender.tab.id,frameIds:[0]},func:outpatientPageStep,args:['inspect',candidate.notice.requestedIdentity]}).catch(()=>[]))[0]?.result;
    if(!chart || !['chart','audit','selection'].includes(chart.phase) || selectionNotice!==candidate.notice) return null;
    return {mode:'outpatient-resume',canResume:!resumeInFlight && !candidate.notice.accepted,
      progress:'已選定病人後，點「繼續抓取」；系統會重新核對身分並補抓北榮資料。'};
  };
  const resume = async sender => {
    if (resumeInFlight || busy()) return {ok:false,error:'RESUME_BUSY'};
    const candidate = resumeCandidate(sender);
    if (!candidate || candidate.notice.accepted) return {ok:false,error:'RESUME_UNAVAILABLE'};
    resumeInFlight = true;
    const {notice,page} = candidate;
    const controller=new AbortController();
    const deadline=Math.min(notice.expiresAt,Date.now()+15_000);
    let rejectTimeout;
    const timedOut=new Promise((_,reject)=>{rejectTimeout=reject;});
    const timer=setTimeout(()=>{controller.abort();rejectTimeout(new Error('RESUME_TIMEOUT'));},Math.max(0,deadline-Date.now()));
    const assertCurrent = async () => {
      controller.signal.throwIfAborted();
      if (selectionNotice !== notice || notice.expiresAt <= Date.now() || await readPairedCloudId() !== notice.peer || busy()) throw new Error('RESUME_UNAVAILABLE');
      const tab=await chrome.tabs.get(sender.tab.id);
      if(parseQemrPatientPage(tab.url)?.histno !== page.histno || new URL(tab.url).origin !== page.baseUrl) throw new Error('PATIENT_HIS_MISMATCH');
    };
    const inspect = async () => {
      const result=await chrome.scripting.executeScript({target:{tabId:sender.tab.id,frameIds:[0]},func:outpatientPageStep,args:['inspect',notice.requestedIdentity]});
      const state=result[0]?.result;
      if(state?.phase !== 'chart' || state.histno !== page.histno) throw new Error(state?.phase==='audit' || state?.phase==='selection' ? 'HIS_CONFIRMATION_REQUIRED' : 'PATIENT_HIS_MISMATCH');
    };
    try {
      return await Promise.race([(async()=>{
      await assertCurrent(); await inspect();
      const actual=await readIdentity(sender.tab.id,page.baseUrl,page.histno,controller.signal);
      await assertCurrent(); await inspect();
      if(String(actual?.identifier || actual?.id || '') !== page.histno || !hasComparableOutpatientIdentity(notice.requestedIdentity,actual) ||
        !verifyOutpatientIdentity(notice.requestedIdentity,actual)) throw new Error('PATIENT_HIS_MISMATCH');
      notice.selectedTabId=sender.tab.id;
      notice.handoffExpiresAt=deadline+15_000;
      const reply=await chrome.runtime.sendMessage(notice.peer,{protocol:'WILDCATCH_OUTPATIENT_RESUME_V1',action:'resume',jobId:notice.jobId,token:notice.token,deadline});
      controller.signal.throwIfAborted();
      if(reply?.ok && selectionNotice===notice) notice.accepted=true;
      return reply?.ok ? {ok:true} : {ok:false,error:reply?.error || 'RESUME_UNAVAILABLE'};
      })(),timedOut]);
    } catch(error) {return {ok:false,error:error.message || 'RESUME_UNAVAILABLE'};}
    finally {clearTimeout(timer);controller.abort();resumeInFlight=false;}
  };
  return { resumeStatus, resume, statusForTab: tabId => {
    expireDisconnected();
    if (selectionNotice && Math.max(selectionNotice.expiresAt,selectionNotice.handoffExpiresAt || 0) <= Date.now()) selectionNotice = null;
    if (job?.tabId === tabId && !job.captureActive && !['capture', 'complete', 'error'].includes(job.phase)) return preflightStatus(job);
    return selectionNotice?.status.tabId === tabId && Math.max(selectionNotice.expiresAt,selectionNotice.handoffExpiresAt || 0) > Date.now() ? selectionNotice.status : null;
  }, busy: () => { expireDisconnected(); return !!job && !["error", "complete"].includes(job.phase); } };
}
