import { readPairedCloudId, savePairedCloudId } from "./paired-extension.js";

const input = document.getElementById("pairing-peer-id");
const save = document.getElementById("save-pairing");
const status = document.getElementById("pairing-status");
document.getElementById("pairing-own-id").textContent = chrome.runtime.id;

try {
  input.value = await readPairedCloudId() || "";
  save.disabled = false;
} catch {
  status.dataset.kind = "error";
  status.textContent = "無法讀取配對設定，請重新開啟視窗。";
}

save.addEventListener("click", async () => {
  save.disabled = true;
  try {
    const id = await savePairedCloudId(input.value);
    input.value = id;
    input.removeAttribute("aria-invalid");
    status.dataset.kind = "success";
    status.textContent = id ? "配對已儲存。" : "已解除配對。";
  } catch (error) {
    status.dataset.kind = "error";
    if (error.message === "INVALID_PEER_ID") {
      input.setAttribute("aria-invalid", "true");
      status.textContent = "請輸入雲端擴充功能的 32 字元 ID，且不可與本北榮 ID 相同。";
    } else status.textContent = "無法儲存配對，請稍後再試。";
  } finally {
    save.disabled = false;
  }
});
