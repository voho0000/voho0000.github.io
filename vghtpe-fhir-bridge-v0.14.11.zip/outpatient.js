import { recordDate } from "./record-range.js";

// Select before issuing detail requests. Never combine unidentifiable doctors.
export function selectOutpatientVisits(items, range, latestPerDoctor = true) {
  const warnings = [], byVisit = new Map();
  for (const item of items || []) {
    if ((item.class || "AMB") !== "AMB") continue;
    const date = recordDate(item.date);
    if (!date) { warnings.push("門診紀錄缺少有效日期，已略過"); continue; }
    if ((range.start && date < range.start) || (range.end && date > range.end)) continue;
    const doctor = item.provider_id || (item.provider || "").match(/\bDOC[A-Z0-9]+\b/i)?.[0];
    if (latestPerDoctor && !doctor) { warnings.push(`${date} 門診缺少醫師代碼，無法判定每位醫師最新一次`); continue; }
    const key = [date, item.visit_time || "", doctor || item.provider || "", item.department_code || item.department || ""].join("|");
    byVisit.set(key, { ...item, date, ...(doctor ? { provider_id: doctor.toUpperCase() } : {}) });
  }
  const sorted = [...byVisit.values()].sort((a, b) =>
    `${b.date} ${b.visit_time || ""}`.localeCompare(`${a.date} ${a.visit_time || ""}`)
    || (a.provider_id || "").localeCompare(b.provider_id || "")
    || (a.detail_href || "").localeCompare(b.detail_href || ""));
  if (!latestPerDoctor) return { visits: sorted, warnings };
  const byDoctor = new Map();
  for (const item of sorted) {
    const previous = byDoctor.get(item.provider_id);
    if (!previous) byDoctor.set(item.provider_id, item);
    else if (previous.date === item.date && (!previous.visit_time || !item.visit_time || previous.visit_time === item.visit_time)) {
      warnings.push(`${item.date} 同一醫師有無法區分先後的門診，請核對取得結果`);
    }
  }
  return { visits: [...byDoctor.values()], warnings };
}

// Only the listed patient's own qemr detail URL is eligible for capture.
export function outpatientDetailPath(visit, histno, baseUrl) {
  if (!visit.detail_href) throw new Error(`${visit.date} 門診缺少詳情連結`);
  const url = new URL(visit.detail_href, baseUrl);
  if (url.origin !== new URL(baseUrl).origin || url.pathname !== "/emr/qemr/qemr.cfm"
      || url.searchParams.get("action") !== "findOpd"
      || url.searchParams.get("histno") !== histno
      || recordDate(url.searchParams.get("dt")) !== visit.date
      || url.searchParams.get("doc") !== visit.provider_id
      || !url.searchParams.get("dept")
      || (visit.department_code && url.searchParams.get("dept") !== visit.department_code)) {
    throw new Error(`${visit.date} 門診詳情連結與病人、醫師或科別不符`);
  }
  return url.pathname + url.search;
}
