// General-report history supplements and case matching for ED visits.
// qemr's 24-month report list omits older ED cases. Year buckets also cover
// reports finalized after the visit, including across New Year's Eve.

const query = url => new URL(url, "https://qemr.invalid").searchParams;

export function emergencyReportYears(cases, currentYear = new Date().getFullYear()) {
  const years = new Set();
  for (const item of cases || []) {
    if (!item.case_no || !/^\d{4}-\d{2}-\d{2}$/.test(item.date || "")) continue;
    const year = Number(item.date.slice(0, 4));
    // The current and previous calendar years are within the rolling list.
    for (const candidate of [year, year + 1]) {
      if (candidate < currentYear - 1) years.add(candidate);
    }
  }
  return [...years].sort((a, b) => a - b);
}

function reportKey(url) {
  const params = query(url);
  const parts = ["caseno", "reqno", "ordseq", "partno"].map(key => params.get(key) || "");
  return parts[0] && parts.slice(1).some(Boolean) ? JSON.stringify(parts) : url;
}

export function mergeEmergencyReportUrls(recentUrls, historicalUrls, cases) {
  const caseNumbers = new Set((cases || []).map(item => item.case_no).filter(Boolean));
  const selected = [...(recentUrls || []), ...(historicalUrls || []).filter(url => caseNumbers.has(query(url).get("caseno")))];
  // The same report can occur in both the relative and annual query lists.
  return [...new Map(selected.map(url => [reportKey(url), url])).values()];
}

export function reportEmergencyContext(url, cases) {
  const caseNo = query(url).get("caseno") || "";
  const matches = (cases || []).filter(item => item.case_no === caseNo);
  const dates = new Set(matches.map(item => item.date).filter(Boolean));
  if (!caseNo || dates.size !== 1) return {};
  return { case_no: caseNo, encounter_class: "EMER", encounter_ref_date: [...dates][0] };
}
