// Supplies remain in the source document, but do not have diagnostic reports.
export function isOutpatientSupply(order) {
  return /^M/i.test(order?.order_code || "")
    && /\b(?:SYRINGE|NEEDLE|GAUZE|CATHETER)\b/i.test(order?.display || "");
}

// Classify source orders for a review notice, never as proof of execution.
export function outpatientOrderReviewCounts(orders) {
  const counts = { appointments: 0, procedures: 0, other: 0 };
  for (const order of orders) {
    if (isOutpatientSupply(order)) continue;
    // Only a verified local code/name pair is a known treatment here.
    const woundTreatment = String(order.order_code || '').trim() === '00048010'
      && /\bWOUND\s+TREATMENT\b|傷口(?:處理|處置|換藥)/i.test(order.display || '');
    if (woundTreatment) counts.procedures++;
    else if (String(order.frequency || '').trim().toUpperCase() === 'APPOINT') counts.appointments++;
    else counts.other++;
  }
  return counts;
}
