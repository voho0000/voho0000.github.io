"use strict";
(() => {
  // src/winforms-url-automation.ts
  var WINFORMS_SITE_PATTERN = /^[a-z0-9][a-z0-9_-]{0,31}$/i;
  function isValidWinFormsSite(value) {
    return WINFORMS_SITE_PATTERN.test(value);
  }

  // src/mediprisma.ts
  var MEDIPRISMA_APP_PATHS = ["/app", "/app/", "/app-hmc", "/app-hmc/"];
  var MEDIPRISMA_CONTROL_PARAMS = /* @__PURE__ */ new Set(["medcloud2", "site"]);
  function isAllowedMediPrismaAppUrl(raw) {
    try {
      const url = new URL(raw ?? "");
      if (url.origin === "https://mediprisma.tw" && MEDIPRISMA_APP_PATHS.includes(url.pathname) && !url.username && !url.password && url.hash === "") {
        const keys = [];
        url.searchParams.forEach((_value, key) => keys.push(key));
        if (keys.some((key) => !MEDIPRISMA_CONTROL_PARAMS.has(key))) return false;
        if (keys.length === 0) return true;
        const modes = url.searchParams.getAll("medcloud2");
        const sites = url.searchParams.getAll("site");
        return modes.length <= 1 && (modes.length === 0 || modes[0] === "auto") && sites.length <= 1 && (sites.length === 0 || isValidWinFormsSite(sites[0] ?? "")) && modes.length + sites.length > 0;
      }
      return false;
    } catch {
      return false;
    }
  }

  // src/mediprisma-viewer-protocol.ts
  var OPEN_NHI_VIEWER = "medcloud:open-nhi-viewer";
  var MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST = "MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST";
  var MEDIPRISMA_NHI_VIEWER_OPEN_RESULT = "MEDIPRISMA_NHI_VIEWER_OPEN_RESULT";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function safePart(value, maxLength) {
    return typeof value === "string" && value.length <= maxLength && !/[\u0000-\u001f\u007f@]/u.test(value);
  }
  function isNhiImagingViewerRequestDescriptor(value) {
    if (!isRecord(value)) return false;
    return value.version === 1 && (value.procId === "IMUE0030" || value.procId === "IMUE0130") && safePart(value.iplCaseSeqNo, 256) && value.iplCaseSeqNo.length > 0 && safePart(value.readPos, 128) && (value.ordMark === "" || value.ordMark === "Y") && safePart(value.fileType, 128) && safePart(value.fileQty, 32) && safePart(value.feeYm, 64);
  }
  function isRequestId(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{8,128}$/u.test(value);
  }
  function isPatientContextHash(value) {
    return typeof value === "string" && /^[a-f0-9]{64}$/iu.test(value);
  }
  function isMediPrismaViewerPageRequest(value) {
    return isRecord(value) && value.source === "mediprisma" && value.type === MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST && value.version === 1 && isRequestId(value.requestId) && isPatientContextHash(value.patientContextHash) && isNhiImagingViewerRequestDescriptor(value.descriptor);
  }
  function viewerPageResult(requestId, response) {
    return {
      source: "medcloud2-extension",
      type: MEDIPRISMA_NHI_VIEWER_OPEN_RESULT,
      version: 1,
      requestId,
      ok: response.ok,
      ...!response.ok ? { code: response.code } : {}
    };
  }

  // src/mediprisma-viewer-bridge.ts
  function allowedMediPrismaViewerOrigin(rawUrl) {
    if (isAllowedMediPrismaAppUrl(rawUrl)) return "https://mediprisma.tw";
    return void 0;
  }
  function invalidRequestId(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    const candidate = value;
    return candidate.source === "mediprisma" && candidate.type === "MEDIPRISMA_NHI_VIEWER_OPEN_REQUEST" && candidate.version === 1 && typeof candidate.requestId === "string" && /^[A-Za-z0-9_-]{8,128}$/u.test(candidate.requestId) ? candidate.requestId : void 0;
  }
  function runtimeResponse(value) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      const response = value;
      if (response.ok === true) return { ok: true };
      if (response.ok === false && [
        "INVALID_REQUEST",
        "REQUEST_IN_PROGRESS",
        "MEDCLOUD_TAB_NOT_FOUND",
        "PATIENT_MISMATCH",
        "SESSION_EXPIRED",
        "VIEWER_UNAVAILABLE",
        "OPEN_FAILED"
      ].includes(String(response.code))) {
        return { ok: false, code: response.code };
      }
    }
    return { ok: false, code: "OPEN_FAILED" };
  }
  function startMediPrismaViewerBridge(runtime) {
    const initialOrigin = allowedMediPrismaViewerOrigin(runtime.currentUrl());
    if (!initialOrigin) return null;
    const inFlight = /* @__PURE__ */ new Set();
    let stopped = false;
    const removeMessageListener = runtime.addMessageListener((event) => {
      if (stopped || event.origin !== initialOrigin || event.source !== runtime.pageWindow || allowedMediPrismaViewerOrigin(runtime.currentUrl()) !== initialOrigin) {
        return;
      }
      if (!isMediPrismaViewerPageRequest(event.data)) {
        const requestId = invalidRequestId(event.data);
        if (requestId) {
          runtime.postMessage(
            viewerPageResult(requestId, { ok: false, code: "INVALID_REQUEST" }),
            initialOrigin
          );
        }
        return;
      }
      const request = event.data;
      if (inFlight.has(request.requestId)) return;
      inFlight.add(request.requestId);
      void runtime.sendRuntimeMessage({
        type: OPEN_NHI_VIEWER,
        requestId: request.requestId,
        patientContextHash: request.patientContextHash,
        descriptor: request.descriptor
      }).then((response) => {
        if (stopped || allowedMediPrismaViewerOrigin(runtime.currentUrl()) !== initialOrigin) return;
        runtime.postMessage(
          viewerPageResult(request.requestId, runtimeResponse(response)),
          initialOrigin
        );
      }).catch(() => {
        if (stopped || allowedMediPrismaViewerOrigin(runtime.currentUrl()) !== initialOrigin) return;
        runtime.postMessage(
          viewerPageResult(request.requestId, { ok: false, code: "OPEN_FAILED" }),
          initialOrigin
        );
      }).finally(() => {
        inFlight.delete(request.requestId);
      });
    });
    return {
      stop: () => {
        if (stopped) return;
        stopped = true;
        inFlight.clear();
        removeMessageListener();
      }
    };
  }
  function startDefaultMediPrismaViewerBridge() {
    return startMediPrismaViewerBridge({
      currentUrl: () => location.href,
      pageWindow: window,
      postMessage: (message, targetOrigin) => window.postMessage(message, targetOrigin),
      addMessageListener: (listener) => {
        const wrapped = (event) => listener(event);
        window.addEventListener("message", wrapped);
        return () => window.removeEventListener("message", wrapped);
      },
      sendRuntimeMessage: (message) => chrome.runtime.sendMessage(message)
    });
  }

  // src/mediprisma-raw-protocol.ts
  var READ_RAW_CAPTURE = "medcloud:read-raw-capture";
  var RAW_CAPTURE_CHUNK = "medcloud:raw-capture-chunk";
  var RAW_CAPTURE_REQUEST = "MEDIPRISMA_RAW_CAPTURE_REQUEST";
  var RAW_CAPTURE_RESULT = "MEDIPRISMA_RAW_CAPTURE_RESULT";
  var RAW_CHUNK_CHARACTERS = 64 * 1024;
  var RAW_READ_TIMEOUT_MS = 6e4;
  var record = (value) => !!value && typeof value === "object" && !Array.isArray(value);
  var isRawRequestId = (value) => typeof value === "string" && /^[A-Za-z0-9_-]{8,128}$/.test(value);
  var isBundleId = (value) => typeof value === "string" && /^[A-Za-z0-9.-]{1,64}$/.test(value);
  function isRawCapturePageRequest(value) {
    return record(value) && value.source === "mediprisma" && value.type === RAW_CAPTURE_REQUEST && value.version === 1 && isRawRequestId(value.requestId) && isBundleId(value.bundleId);
  }
  function isRawCaptureChunk(value) {
    return record(value) && value.type === RAW_CAPTURE_CHUNK && isRawRequestId(value.requestId) && isBundleId(value.bundleId) && Number.isSafeInteger(value.offset) && Number(value.offset) >= 0 && typeof value.text === "string" && value.text.length > 0 && value.text.length <= RAW_CHUNK_CHARACTERS && typeof value.expiresAt === "number" && Number.isFinite(value.expiresAt);
  }

  // src/mediprisma-raw-bridge.ts
  var ORIGIN = "https://mediprisma.tw";
  function startRawCaptureBridge(runtime) {
    if (!isAllowedMediPrismaAppUrl(runtime.currentUrl())) return null;
    let stopped = false;
    let active;
    const discard = () => {
      if (active) {
        clearTimeout(active.timer);
        active.chunks.length = 0;
      }
      active = void 0;
    };
    const postError = (requestId, code) => runtime.post({
      source: "medcloud2-extension",
      type: RAW_CAPTURE_RESULT,
      version: 1,
      requestId,
      ok: false,
      code
    }, ORIGIN);
    const removeChunk = runtime.addChunkListener((message) => {
      if (stopped || !active || !isRawCaptureChunk(message) || message.requestId !== active.requestId || message.bundleId !== active.bundleId || runtime.currentUrl() !== active.url || message.offset !== active.length || Date.now() >= message.expiresAt || active.expiresAt !== void 0 && active.expiresAt !== message.expiresAt) return false;
      active.expiresAt = message.expiresAt;
      active.chunks.push(message.text);
      active.length += message.text.length;
      return true;
    });
    const removePage = runtime.addPageListener((event) => {
      if (stopped || event.source !== runtime.pageWindow || event.origin !== ORIGIN || !isAllowedMediPrismaAppUrl(runtime.currentUrl()) || !isRawCapturePageRequest(event.data)) return;
      const request = event.data;
      if (active) {
        postError(request.requestId, "REQUEST_IN_PROGRESS");
        return;
      }
      const url = runtime.currentUrl();
      const pending = active = {
        requestId: request.requestId,
        bundleId: request.bundleId,
        url,
        chunks: [],
        length: 0,
        expiresAt: void 0,
        timer: setTimeout(() => {
          if (active !== pending) return;
          discard();
          if (!stopped && runtime.currentUrl() === url) postError(request.requestId, "READ_FAILED");
        }, RAW_READ_TIMEOUT_MS + 1e3)
      };
      void runtime.request({ type: READ_RAW_CAPTURE, requestId: request.requestId, bundleId: request.bundleId }).then((response) => {
        if (stopped || active !== pending || runtime.currentUrl() !== url) return;
        const base = { source: "medcloud2-extension", type: RAW_CAPTURE_RESULT, version: 1, requestId: request.requestId };
        if (!response.ok) {
          runtime.post({ ...base, ...response }, ORIGIN);
          return;
        }
        if (response.metadata.bundleId !== request.bundleId || response.metadata.totalCharacters !== pending.length || response.metadata.expiresAt !== pending.expiresAt || Date.now() >= response.metadata.expiresAt) {
          postError(request.requestId, "READ_FAILED");
          return;
        }
        runtime.post({ ...base, ...response, json: pending.chunks.join("") }, ORIGIN);
      }).catch(() => {
        if (!stopped && active === pending && runtime.currentUrl() === url) postError(request.requestId, "READ_FAILED");
      }).finally(() => {
        if (active === pending) discard();
      });
    });
    return { stop: () => {
      stopped = true;
      discard();
      removePage();
      removeChunk();
    } };
  }
  function startDefaultRawCaptureBridge() {
    startRawCaptureBridge({
      currentUrl: () => location.href,
      pageWindow: window,
      addPageListener: (listener) => {
        const wrapped = (event) => listener(event);
        window.addEventListener("message", wrapped);
        return () => window.removeEventListener("message", wrapped);
      },
      addChunkListener: (listener) => {
        const wrapped = (message, sender, respond) => {
          if (sender.id !== chrome.runtime.id || sender.tab || !isRawCaptureChunk(message)) return false;
          respond({ ok: listener(message) });
          return false;
        };
        chrome.runtime.onMessage.addListener(wrapped);
        return () => chrome.runtime.onMessage.removeListener(wrapped);
      },
      request: (message) => chrome.runtime.sendMessage(message),
      post: (message, origin) => window.postMessage(message, origin)
    });
  }

  // src/mediprisma-viewer-launcher.ts
  startDefaultMediPrismaViewerBridge();
  startDefaultRawCaptureBridge();
})();
