"use strict";
(() => {
  // src/outpatient-coverage.ts
  var TRANSPORT_DIAGNOSTICS = ["CHUNK_METADATA", "CHUNK_DATA", "JSON_PARSE", "RESULT_SHAPE"];
  var GRAPH_DIAGNOSTICS = ["INVALID_PATIENT_GRAPH", "INVALID_HIS_RESOURCE", "DUPLICATE_HIS_RESOURCE", "UNRESOLVED_HIS_REFERENCE"];
  var diagnosticCodes = /* @__PURE__ */ new Set([
    ...TRANSPORT_DIAGNOSTICS,
    ...GRAPH_DIAGNOSTICS,
    "non-finite-number",
    "null-element",
    "empty-string",
    "empty-array",
    "empty-object",
    "bundle-shape",
    "patient-isolation",
    "resource-identity",
    "duplicate-resource-identity",
    "duplicate-full-url",
    "full-url-identity",
    "full-url",
    "invalid-reference",
    "broken-reference",
    "provenance-coverage"
  ]);

  // src/winforms-url-automation.ts
  var WINFORMS_PATIENT_WAIT_TIMEOUT_MS = 3e4;
  var WINFORMS_SITE_PATTERN = /^[a-z0-9][a-z0-9_-]{0,31}$/i;
  function shouldAutoLaunchFromWinForms(search) {
    const params = new URLSearchParams(search);
    const modes = params.getAll("medcloud2");
    if (modes.length !== 1 || modes[0] !== "auto") return false;
    const sites = params.getAll("site");
    if (sites.length > 1 || sites.length === 1 && !isValidWinFormsSite(sites[0]?.trim() ?? "")) {
      return false;
    }
    const types = params.getAll("type");
    if (types.length === 1) return ["icc", "er"].includes(types[0]?.toLowerCase() ?? "");
    if (types.length > 0) return false;
    return sites.length === 1;
  }
  function isValidWinFormsSite(value) {
    return WINFORMS_SITE_PATTERN.test(value);
  }
  function isEmergencyWinFormsLaunch(search) {
    return shouldAutoLaunchFromWinForms(search) && new URLSearchParams(search).get("type")?.toLowerCase() === "er";
  }
  function clickEmergencyMediCloudLogin(search, pageDocument = document) {
    if (!isEmergencyWinFormsLaunch(search) || pageDocument.location?.origin !== "https://medcloud2.nhi.gov.tw" || !pageDocument.location.pathname.startsWith("/imu/")) return Promise.resolve(false);
    return new Promise((resolve) => {
      const tryClick = () => {
        const controls = Array.from(pageDocument.querySelectorAll("a.login-btn, button.login-btn")).filter((control) => control.textContent?.replace(/\s+/g, "").trim() === "\u56E0\u61C9\u5929\u707D\u53CA\u7DCA\u6025\u91AB\u7642\u67E5\u8A62\u4F5C\u696D2.0" && control.getClientRects().length > 0 && !control.hasAttribute("disabled") && control.getAttribute("aria-disabled") !== "true");
        if (controls.length !== 1) return false;
        finish(true);
        controls[0].click();
        return true;
      };
      const observer = new MutationObserver(() => {
        tryClick();
      });
      const timer = setTimeout(() => finish(false), 1e4);
      const finish = (clicked) => {
        clearTimeout(timer);
        observer.disconnect();
        resolve(clicked);
      };
      observer.observe(pageDocument, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["class", "style", "hidden", "disabled", "aria-disabled"]
      });
      tryClick();
    });
  }

  // ../packages/medcloud-adapter/src/constants.ts
  var IMUE0060_SOURCE_MODULE = "IMUE0060";
  var IMUE0060_DATASET_SCOPE = "/imu/api/imue0060/imue0060s02/get-data";
  var IMUE0008_SOURCE_MODULE = "IMUE0008";
  var IMUE0008_DATASET_SCOPE = "/imu/api/imue0008/imue0008s02/get-data";
  var IMUE0130_SOURCE_MODULE = "IMUE0130";
  var IMUE0130_DATASET_SCOPE = "/imu/api/imue0130/imue0130s02/get-data";
  var IMUE0030_SOURCE_MODULE = "IMUE0030";
  var IMUE0030_DATASET_SCOPE = "/imu/api/imue0030/imue0030s02/get-data";
  var IMUE0010_SOURCE_MODULE = "IMUE0010";
  var IMUE0010_DATASET_SCOPE = "/imu/api/imue0010/imue0010s02/get-data";
  var IMUE0120_SOURCE_MODULE = "IMUE0120";
  var IMUE0120_DATASET_SCOPE = "/imu/api/imue0120/imue0120s01/pres-med-day";
  var IMUE0140_SOURCE_MODULE = "IMUE0140";
  var IMUE0140_DATASET_SCOPE = "/imu/api/imue0140/imue0140s01/hpa-data";
  var IMUE0070_SOURCE_MODULE = "IMUE0070";
  var IMUE0070_DATASET_SCOPE = "/imu/api/imue0070/imue0070s02/get-data";
  var IMUE0080_SOURCE_MODULE = "IMUE0080";
  var IMUE0080_DATASET_SCOPE = "/imu/api/imue0080/imue0080s02/get-data";
  var IMUE0150_SOURCE_MODULE = "IMUE0150";
  var IMUE0150_DATASET_SCOPE = "/imu/api/imue0150/imue0150s01/hpa-data";
  var IMUE0040_SOURCE_MODULE = "IMUE0040";
  var IMUE0040_DATASET_SCOPE = "/imu/api/imue0040/imue0040s02/get-data";
  var IMUE0020_SOURCE_MODULE = "IMUE0020";
  var IMUE0020_DATASET_SCOPE = "/imu/api/imue0020/imue0020s02/get-data";
  var IMUE0200_SOURCE_MODULE = "IMUE0200";
  var IMUE0200_DATASET_SCOPE = "/imu/api/imue0200/imue0200s02/get-data";
  var MEDCLOUD_CLINICAL_MODULES = [
    { sourceModule: IMUE0060_SOURCE_MODULE, datasetScope: IMUE0060_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C" },
    { sourceModule: IMUE0008_SOURCE_MODULE, datasetScope: IMUE0008_DATASET_SCOPE, label: "\u897F\u91AB\u7528\u85E5" },
    { sourceModule: IMUE0130_SOURCE_MODULE, datasetScope: IMUE0130_DATASET_SCOPE, label: "\u6587\u5B57\u5831\u544A" },
    { sourceModule: IMUE0030_SOURCE_MODULE, datasetScope: IMUE0030_DATASET_SCOPE, label: "\u7259\u79D1\u8655\u7F6E" },
    { sourceModule: IMUE0010_SOURCE_MODULE, datasetScope: IMUE0010_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D00\u9304" },
    { sourceModule: IMUE0070_SOURCE_MODULE, datasetScope: IMUE0070_DATASET_SCOPE, label: "\u4F4F\u9662\u53CA\u51FA\u9662\u75C5\u6B77\u6458\u8981" },
    { sourceModule: IMUE0080_SOURCE_MODULE, datasetScope: IMUE0080_DATASET_SCOPE, label: "\u5FA9\u5065\u91AB\u7642\u7D00\u9304" },
    { sourceModule: IMUE0120_SOURCE_MODULE, datasetScope: IMUE0120_DATASET_SCOPE, label: "\u9580\u8A3A\u85E5\u54C1\u9918\u85E5\u65E5\u6578" },
    { sourceModule: IMUE0140_SOURCE_MODULE, datasetScope: IMUE0140_DATASET_SCOPE, label: "\u6210\u4EBA\u9810\u9632\u4FDD\u5065" },
    { sourceModule: IMUE0150_SOURCE_MODULE, datasetScope: IMUE0150_DATASET_SCOPE, label: "\u764C\u75C7\u7BE9\u6AA2\u7D50\u679C" },
    { sourceModule: IMUE0040_SOURCE_MODULE, datasetScope: IMUE0040_DATASET_SCOPE, label: "\u904E\u654F\u7D00\u9304" },
    { sourceModule: IMUE0020_SOURCE_MODULE, datasetScope: IMUE0020_DATASET_SCOPE, label: "\u624B\u8853\u7D00\u9304" },
    { sourceModule: IMUE0200_SOURCE_MODULE, datasetScope: IMUE0200_DATASET_SCOPE, label: "\u7279\u6750\u7D00\u9304" }
  ];

  // src/module-stage-status.ts
  var MODULE_IDS = new Set(MEDCLOUD_CLINICAL_MODULES.map((module) => module.sourceModule));

  // src/background-job.ts
  var START_ONE_CLICK_FLOW = "medcloud:start-one-click-flow";
  var GET_ONE_CLICK_FLOW_STATE = "medcloud:get-one-click-flow-state";
  var OPEN_POPUP_WINDOW = "medcloud:open-popup-window";
  var ONE_CLICK_FLOW_STATE_CHANGED = "medcloud:one-click-flow-state-changed";
  var OUTPATIENT_ACTION = "medcloud:outpatient-action";
  var BACKGROUND_RESULT_TTL_MS = 60 * 60 * 1e3;
  var BACKGROUND_JOB_RECOVERY_WINDOW_MS = 10 * 60 * 1e3;
  var BACKGROUND_JOB_TIMEOUT_MS = 4 * 60 * 1e3;
  var OUTPATIENT_JOB_TIMEOUT_MS = 15 * 60 * 1e3;

  // src/async-timeout.ts
  var AsyncTimeoutError = class extends Error {
    constructor() {
      super("ASYNC_OPERATION_TIMED_OUT");
      this.name = "AsyncTimeoutError";
    }
  };
  function withTimeout(operation, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timeoutId = globalThis.setTimeout(() => {
        reject(new AsyncTimeoutError());
      }, timeoutMs);
      void Promise.resolve(operation).then(
        (value) => {
          globalThis.clearTimeout(timeoutId);
          resolve(value);
        },
        (error) => {
          globalThis.clearTimeout(timeoutId);
          reject(error);
        }
      );
    });
  }

  // src/launcher-drag.ts
  function enableLauncherDrag(host, button) {
    const margin = 8;
    let gesture;
    let suppressClick = false;
    let position;
    const place = (right, top) => {
      const rect = host.getBoundingClientRect();
      position = {
        right: Math.max(margin, Math.min(right, Math.max(margin, window.innerWidth - rect.width - margin))),
        top: Math.max(margin, Math.min(top, Math.max(margin, window.innerHeight - rect.height - margin)))
      };
      host.style.right = `${position.right}px`;
      host.style.top = `${position.top}px`;
      host.style.bottom = "auto";
      host.style.transform = "none";
    };
    button.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || event.isPrimary === false) return;
      suppressClick = false;
      const rect = host.getBoundingClientRect();
      gesture = {
        id: event.pointerId,
        x: event.clientX,
        y: event.clientY,
        right: window.innerWidth - rect.right,
        top: rect.top,
        moved: false
      };
      try {
        button.setPointerCapture(event.pointerId);
      } catch {
      }
    });
    button.addEventListener("pointermove", (event) => {
      if (!gesture || gesture.id !== event.pointerId) return;
      const dx = event.clientX - gesture.x, dy = event.clientY - gesture.y;
      if (!gesture.moved && Math.hypot(dx, dy) < 6) return;
      gesture.moved = true;
      suppressClick = true;
      host.setAttribute("data-dragging", "");
      place(gesture.right - dx, gesture.top + dy);
      event.preventDefault();
    });
    const end = (event) => {
      if (!gesture || gesture.id !== event.pointerId) return;
      if (gesture.moved) event.preventDefault();
      gesture = void 0;
      host.removeAttribute("data-dragging");
      try {
        button.releasePointerCapture(event.pointerId);
      } catch {
      }
    };
    button.addEventListener("pointerup", end);
    button.addEventListener("pointercancel", end);
    button.addEventListener("lostpointercapture", end);
    button.addEventListener("click", (event) => {
      if (!suppressClick || event.detail === 0) return;
      suppressClick = false;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
    window.addEventListener("resize", () => {
      if (position && host.isConnected) place(position.right, position.top);
    });
  }

  // src/launcher.ts
  var HOST_ID = "cloud-wildcatch-one-click-launcher";
  var START_RESPONSE_TIMEOUT_MS = WINFORMS_PATIENT_WAIT_TIMEOUT_MS + 5e3;
  var STATE_RESPONSE_TIMEOUT_MS = 3e3;
  var WAITING_COMPACT_DELAY_MS = 2200;
  var FALLBACK_STATE_POLL_MS = 15e3;
  var CARD_SWITCH_RECHECK_DELAYS_MS = [400, 1200, 3e3];
  var VALID_PHASES = /* @__PURE__ */ new Set([
    "idle",
    "paused",
    "ready",
    "running",
    "opening",
    "error",
    "done"
  ]);
  function isLiveMediCloudPage() {
    return location.origin === "https://medcloud2.nhi.gov.tw" && location.pathname.startsWith("/imu/");
  }
  function isOneClickFlowState(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return VALID_PHASES.has(String(record.phase)) && typeof record.label === "string" && record.label.length <= 80 && typeof record.detail === "string" && record.detail.length <= 500 && typeof record.canStart === "boolean" && (record.hasWarnings === void 0 || typeof record.hasWarnings === "boolean") && (record.diagnosticCode === void 0 || typeof record.diagnosticCode === "string" && /^[A-Z][A-Z0-9_]{2,63}$/.test(record.diagnosticCode));
  }
  function idleState() {
    return {
      phase: "idle",
      label: "\u53D6\u5F97\u75C5\u6B77\u4E26\u9001\u5230 MediPrisma",
      detail: "\u53D6\u5F97\u76EE\u524D\u75C5\u4EBA\u7684\u8EAB\u5206\u8207\u81E8\u5E8A\u53C3\u8003\u8CC7\u6599\uFF0C\u5728\u672C\u6A5F\u8F49\u6210 FHIR \u4E26\u4EA4\u7D66 MediPrisma \u672C\u6A5F\u532F\u5165\uFF1B\u5F71\u50CF Viewer URL \u53EA\u7528\u65BC\u7ACB\u5373\u958B\u555F\uFF0C\u4E0D\u5BEB\u5165 FHIR \u6216\u4EA4\u7D66 MediPrisma\u3002",
      canStart: true
    };
  }
  function launcherLogo() {
    return `
    <svg viewBox="0 0 512 512" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="cwc-fire" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#f15a24"/>
          <stop offset="100%" stop-color="#ef4136"/>
        </linearGradient>
        <linearGradient id="cwc-core" x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stop-color="#fbb040" stop-opacity=".8"/>
          <stop offset="100%" stop-color="#ffd400" stop-opacity=".6"/>
        </linearGradient>
      </defs>
      <path d="M89 412c-39 0-64-30-60-67 4-36 32-64 68-66-7-61 27-134 82-167 26-15 53-8 71 16 20-61 79-96 142-85 62 11 105 66 98 133-2 21-7 40-16 56 47 19 53 56 34 83-9 13-22 22-38 25 7 38-22 72-62 72H89"
        fill="#eaf6ff" stroke="#0072bc" stroke-width="30" stroke-linecap="round" stroke-linejoin="round"/>
      <g transform="translate(36 80.5) scale(.8)">
        <path d="M180 220v160" stroke="#009b4d" stroke-width="45" stroke-linecap="round"/>
        <circle cx="180" cy="160" r="35" fill="#009b4d"/>
      </g>
      <g transform="translate(66.4 76) scale(.8)">
        <path d="M332 380s98-40 98-140c0-100-50-160-90-200 0 0 20 60 0 120S256 40 256 40s44 110 24 200 52 140 52 140Z" fill="url(#cwc-fire)"/>
        <path d="M310 340s60-30 60-100c0-60-30-100-50-130 0 0 10 40 0 80s-50-70-50-70 20 60 10 120 30 100 30 100Z" fill="url(#cwc-core)"/>
      </g>
      <path d="M180 280h120" stroke="#009b4d" stroke-width="35" stroke-linecap="round" opacity=".8"/>
      <rect x="160" y="400" width="192" height="15" rx="7" fill="#0072bc"/>
    </svg>
  `;
  }
  function mountLauncher() {
    if (!isLiveMediCloudPage() || document.getElementById(HOST_ID)) return;
    const host = document.createElement("div");
    host.id = HOST_ID;
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
    <style>
      :host {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        right: max(16px, env(safe-area-inset-right));
        top: 52%;
        transform: translateY(-50%);
        color-scheme: light;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans TC", sans-serif;
      }
      :host([hidden]) { display: none; }
      *, *::before, *::after { box-sizing: border-box; }
      button {
        width: 62px;
        min-height: 62px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 10px;
        overflow: hidden;
        padding: 6px;
        border: 1px solid rgba(0, 114, 188, .28);
        border-radius: 999px;
        background: rgba(255, 255, 255, .97);
        color: #0f3057;
        box-shadow: 0 10px 30px rgba(15, 48, 87, .22), 0 2px 8px rgba(15, 48, 87, .12);
        cursor: pointer;
        touch-action: none;
        user-select: none;
        transition: width .2s ease, box-shadow .2s ease, border-color .2s ease, transform .2s ease;
        -webkit-font-smoothing: antialiased;
      }
      button:hover,
      button:focus-visible,
      button:is(
        [data-state="checking"],
        [data-state="waiting"],
        [data-state="paused"],
        [data-state="ready"],
        [data-state="running"],
        [data-state="opening"],
        [data-state="error"],
        [data-warning="true"]
      ) {
        width: min(286px, calc(100vw - 32px));
        border-color: rgba(0, 114, 188, .58);
        box-shadow: 0 14px 34px rgba(15, 48, 87, .27), 0 3px 9px rgba(15, 48, 87, .14);
      }
      button:hover { transform: translateX(-2px); }
      :host([data-dragging]) button { cursor: grabbing; transform: none; transition: none; }
      button:focus-visible {
        outline: 3px solid rgba(37, 99, 235, .28);
        outline-offset: 3px;
      }
      button:disabled {
        cursor: wait;
        opacity: 1;
      }
      .mark {
        position: relative;
        width: 48px;
        height: 48px;
        flex: 0 0 48px;
        display: grid;
        place-items: center;
        border-radius: 50%;
        background: #f7fcff;
      }
      .mark svg { width: 44px; height: 44px; display: block; }
      .copy {
        min-width: 0;
        padding-right: 12px;
        opacity: 0;
        transform: translateX(6px);
        transition: opacity .16s ease, transform .16s ease;
        text-align: left;
        white-space: nowrap;
      }
      button:hover .copy,
      button:focus-visible .copy,
      button:is(
        [data-state="checking"],
        [data-state="waiting"],
        [data-state="paused"],
        [data-state="ready"],
        [data-state="running"],
        [data-state="opening"],
        [data-state="error"],
        [data-warning="true"]
      ) .copy {
        opacity: 1;
        transform: translateX(0);
      }
      .label {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 14px;
        line-height: 1.35;
        font-weight: 700;
        letter-spacing: .01em;
      }
      .hint {
        display: block;
        margin-top: 2px;
        overflow: hidden;
        text-overflow: ellipsis;
        color: #60758b;
        font-size: 11px;
        line-height: 1.35;
        font-weight: 500;
      }
      button[data-state="running"] .mark::after,
      button[data-state="opening"] .mark::after,
      button[data-state="checking"] .mark::after,
      button[data-state="waiting"] .mark::after {
        content: "";
        position: absolute;
        inset: -2px;
        border: 3px solid rgba(0, 114, 188, .16);
        border-top-color: #0072bc;
        border-radius: 50%;
        animation: cwc-spin .85s linear infinite;
      }
      button[data-state="waiting"] .mark::after {
        border-color: rgba(0, 114, 188, .14);
        border-top-color: #0072bc;
        border-right-color: rgba(0, 114, 188, .52);
        animation-duration: 1.45s;
      }
      button[data-state="waiting"][data-wait-compact="true"] {
        width: 62px;
      }
      button[data-state="waiting"][data-wait-compact="true"] .copy {
        opacity: 0;
        transform: translateX(6px);
      }
      button[data-state="waiting"][data-wait-compact="true"]:hover,
      button[data-state="waiting"][data-wait-compact="true"]:focus-visible {
        width: min(286px, calc(100vw - 32px));
      }
      button[data-state="waiting"][data-wait-compact="true"]:hover .copy,
      button[data-state="waiting"][data-wait-compact="true"]:focus-visible .copy {
        opacity: 1;
        transform: translateX(0);
      }
      button[data-warning="true"] {
        width: min(430px, calc(100vw - 32px));
        min-height: 92px;
        border-color: #d97706;
        background: #fffbeb;
        color: #92400e;
      }
      button[data-state="error"] {
        width: min(430px, calc(100vw - 32px));
        min-height: 92px;
        border-color: rgba(185, 28, 28, .42);
        background: #fffafa;
        color: #991b1b;
      }
      button[data-state="error"] .copy,
      button[data-warning="true"] .copy,
      button[data-state="running"] .copy {
        padding-top: 4px;
        padding-bottom: 4px;
        white-space: normal;
      }
      button[data-state="error"] .hint,
      button[data-warning="true"] .hint,
      button[data-state="running"] .hint {
        display: block;
        overflow: visible;
        white-space: normal;
        font-size: 12px;
      }
      .diagnostic {
        display: block;
        width: fit-content;
        margin-top: 5px;
        padding: 2px 6px;
        border: 1px solid rgba(185, 28, 28, .22);
        border-radius: 4px;
        background: rgba(185, 28, 28, .06);
        color: #7f1d1d;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        /* The code a clinician is asked to report must not be the smallest
           text on a clinic monitor. */
        font-size: 12px;
        line-height: 1.35;
        letter-spacing: .02em;
      }
      .diagnostic[hidden] { display: none; }
      button[data-state="done"]:not([data-warning="true"]) {
        border-color: rgba(4, 120, 87, .38);
        background: #f4fff9;
        color: #065f46;
      }
      button[data-state="ready"] {
        border-color: rgba(217, 119, 6, .42);
        background: #fffbeb;
        color: #92400e;
      }
      button[data-state="paused"] {
        width: min(340px, calc(100vw - 32px));
        border-color: rgba(217, 119, 6, .48);
        background: #fffbeb;
        color: #92400e;
      }
      button[data-state="paused"] .mark::after {
        content: "";
        position: absolute;
        inset: -2px;
        border: 3px solid rgba(217, 119, 6, .52);
        border-radius: 50%;
      }
      @keyframes cwc-spin { to { transform: rotate(360deg); } }
      @media (prefers-reduced-motion: reduce) {
        button, .copy { transition: none; }
        button[data-state] .mark::after { animation: none; }
        button[data-state="waiting"][data-wait-compact="true"] {
          width: min(286px, calc(100vw - 32px));
        }
        button[data-state="waiting"][data-wait-compact="true"] .copy {
          opacity: 1;
          transform: none;
        }
      }
      @media (max-width: 640px) {
        :host { right: 10px; top: auto; bottom: 18px; transform: none; }
        button:hover,
        button:focus-visible,
        button:is(
          [data-state="checking"],
          [data-state="waiting"],
          [data-state="paused"],
          [data-state="ready"],
          [data-state="running"],
          [data-state="opening"],
          [data-state="error"]
        ) {
          width: min(260px, calc(100vw - 20px));
        }
        button[data-state="waiting"][data-wait-compact="true"]:hover,
        button[data-state="waiting"][data-wait-compact="true"]:focus-visible {
          width: min(260px, calc(100vw - 20px));
        }
        button[data-state="error"] {
          width: min(340px, calc(100vw - 20px));
        }
      }
      .actions {
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 8px;
      }
      @media (max-width: 600px) {
        .actions { top: auto; bottom: calc(100% + 8px); }
      }
      button.details {
        position: relative;
        width: max-content;
        min-height: 0;
        display: block;
        padding: 7px 14px;
        border-radius: 999px;
        border: 1px solid rgba(180, 83, 9, .45);
        background: rgba(255, 251, 235, .98);
        color: #7c2d12;
        font-size: 13px;
        font-weight: 600;
        line-height: 1.3;
        white-space: nowrap;
        box-shadow: 0 6px 18px rgba(124, 45, 18, .18);
        transition: background .2s ease, border-color .2s ease;
      }
      button.details[hidden] { display: none; }
      button.details:hover,
      button.details:focus-visible {
        width: max-content;
        background: #fff;
        border-color: rgba(180, 83, 9, .75);
        transform: none;
      }
    </style>
    <button type="button" data-state="idle" aria-label="\u53D6\u5F97\u75C5\u6B77\u4E26\u9001\u5230 MediPrisma">
      <span class="mark">${launcherLogo()}</span>
      <span class="copy">
        <span class="label">\u53D6\u5F97\u75C5\u6B77\u4E26\u9001\u5230 MediPrisma</span>
        <span class="hint">\u672C\u6A5F\u8F49\u6210 FHIR \u2192 MediPrisma</span>
        <span class="diagnostic" hidden></span>
      </span>
    </button>
    <div class="actions">
    <button type="button" class="details warning-details" hidden>\u958B\u555F\u96F2\u6293\u5C0F\u8996\u7A97\u67E5\u770B\u660E\u7D30</button>
    <button type="button" class="details his-login" hidden>\u958B\u555F HIS \u767B\u5165</button>
    <button type="button" class="details cloud-only" hidden>\u672C\u6B21\u53EA\u7528\u96F2\u7AEF</button>
    </div>
    <span class="live" role="status" aria-live="polite" style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0"></span>
  `;
    document.documentElement.appendChild(host);
    const button = shadow.querySelector("button");
    const label = shadow.querySelector(".label");
    const hint = shadow.querySelector(".hint");
    const diagnostic = shadow.querySelector(".diagnostic");
    const live = shadow.querySelector(".live");
    const details = shadow.querySelector(".warning-details");
    const loginButton = shadow.querySelector(".his-login");
    const cloudOnlyButton = shadow.querySelector(".cloud-only");
    if (!button || !label || !hint || !diagnostic || !live || !details || !loginButton || !cloudOnlyButton) {
      host.remove();
      return;
    }
    enableLauncherDrag(host, button);
    details.addEventListener("click", () => {
      void chrome.runtime.sendMessage({ type: OPEN_POPUP_WINDOW }).then((response) => {
        if (response?.ok) return;
        live.textContent = "\u7121\u6CD5\u81EA\u52D5\u958B\u555F\uFF0C\u8ACB\u9EDE\u700F\u89BD\u5668\u5DE5\u5177\u5217\u7684\u96F2\u6293\u5716\u793A";
        details.textContent = "\u8ACB\u9EDE\u5DE5\u5177\u5217\u7684\u96F2\u6293\u5716\u793A\u958B\u555F\u5C0F\u8996\u7A97";
      }).catch(() => {
        live.textContent = "\u7121\u6CD5\u81EA\u52D5\u958B\u555F\uFF0C\u8ACB\u9EDE\u700F\u89BD\u5668\u5DE5\u5177\u5217\u7684\u96F2\u6293\u5716\u793A";
        details.textContent = "\u8ACB\u9EDE\u5DE5\u5177\u5217\u7684\u96F2\u6293\u5716\u793A\u958B\u555F\u5C0F\u8996\u7A97";
      });
    });
    let state = idleState();
    const hospitalAction = async (action) => {
      if (!state.outpatientNeedsLogin || !state.runId) return;
      loginButton.disabled = cloudOnlyButton.disabled = true;
      try {
        const reply = await chrome.runtime.sendMessage({ type: OUTPATIENT_ACTION, runId: state.runId, action });
        if (!reply?.ok) live.textContent = "\u5DE5\u4F5C\u72C0\u614B\u5DF2\u8B8A\u66F4\uFF0C\u8ACB\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u5F8C\u518D\u8A66\u3002";
      } catch {
        live.textContent = "\u7121\u6CD5\u9023\u63A5\u5317\u69AE\u64F4\u5145\u529F\u80FD\uFF0C\u8ACB\u78BA\u8A8D\u76EE\u524D\u5DE5\u4F5C\u3002";
      } finally {
        loginButton.disabled = cloudOnlyButton.disabled = false;
        await refresh();
      }
    };
    loginButton.addEventListener("click", () => {
      void hospitalAction("open_login");
    });
    cloudOnlyButton.addEventListener("click", () => {
      void hospitalAction("cloud_only");
    });
    let requestInFlight = false;
    let runtimeUnavailable = false;
    let waitingCompactTimer;
    const clearWaitingCompactTimer = () => {
      if (waitingCompactTimer !== void 0) window.clearTimeout(waitingCompactTimer);
      waitingCompactTimer = void 0;
      button.removeAttribute("data-wait-compact");
    };
    const render = (next) => {
      clearWaitingCompactTimer();
      details.hidden = typeof next === "string" || next.hasWarnings !== true;
      loginButton.hidden = cloudOnlyButton.hidden = typeof next === "string" || next.outpatientNeedsLogin !== true;
      if (next === "waiting") {
        delete button.dataset.warning;
        button.dataset.state = "waiting";
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.setAttribute("aria-label", "\u7B49\u5F85\u96F2\u7AEF\u75C5\u6B77\u5C31\u7DD2\uFF0C\u5C1A\u672A\u958B\u59CB\u53D6\u5F97\u8CC7\u6599");
        button.title = "\u7B49\u5F85\u96F2\u7AEF\u75C5\u6B77\u5C31\u7DD2\uFF1B\u5C1A\u672A\u958B\u59CB\u53D6\u5F97\u8CC7\u6599\u3002";
        label.textContent = "\u7B49\u5F85\u96F2\u7AEF\u75C5\u6B77\u5C31\u7DD2\u2026";
        hint.textContent = "\u5C1A\u672A\u958B\u59CB\u53D6\u5F97\u8CC7\u6599";
        diagnostic.hidden = true;
        diagnostic.textContent = "";
        live.textContent = "\u7B49\u5F85\u96F2\u7AEF\u75C5\u6B77\u5C31\u7DD2\uFF0C\u5C1A\u672A\u958B\u59CB\u53D6\u5F97\u8CC7\u6599";
        waitingCompactTimer = window.setTimeout(() => {
          if (button.dataset.state === "waiting") {
            button.dataset.waitCompact = "true";
          }
        }, WAITING_COMPACT_DELAY_MS);
        return;
      }
      if (next === "checking") {
        delete button.dataset.warning;
        button.dataset.state = "checking";
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.setAttribute("aria-label", "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA");
        button.title = "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u2026";
        label.textContent = "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u2026";
        hint.textContent = "\u5373\u5C07\u958B\u59CB\u4E00\u9375\u8655\u7406";
        diagnostic.hidden = true;
        diagnostic.textContent = "";
        live.textContent = "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA";
        return;
      }
      state = next;
      button.dataset.state = next.phase;
      button.dataset.warning = String(next.hasWarnings === true);
      button.disabled = !next.canStart;
      button.toggleAttribute(
        "aria-busy",
        next.phase === "running" || next.phase === "opening"
      );
      button.setAttribute("aria-label", next.label);
      button.title = next.detail;
      label.textContent = next.label;
      hint.textContent = next.phase === "idle" ? "\u672C\u6A5F\u8F49\u6210 FHIR \u2192 MediPrisma" : next.detail;
      diagnostic.hidden = !next.diagnosticCode;
      diagnostic.textContent = next.diagnosticCode ? `\u932F\u8AA4\u4EE3\u78BC ${next.diagnosticCode}` : "";
      live.textContent = next.label;
    };
    const applyResponse = (response) => {
      if (isOneClickFlowState(response?.state)) {
        runtimeUnavailable = false;
        render(response.state);
        return;
      }
      runtimeUnavailable = true;
      render({
        phase: "error",
        label: "\u96F2\u6293\u9023\u7DDA\u4E2D\u65B7\uFF0C\u9EDE\u6B64\u91CD\u65B0\u8F09\u5165",
        detail: "\u64F4\u5145\u529F\u80FD\u6C92\u6709\u56DE\u61C9\uFF0C\u53EF\u80FD\u662F\u66F4\u65B0\u6216\u9023\u7DDA\u903E\u6642\u3002\u8ACB\u91CD\u65B0\u8F09\u5165\u96F2\u7AEF\u75C5\u6B77\u5F8C\u91CD\u8A66\u3002",
        canStart: true
      });
    };
    const sendOneClickMessage = (type, timeoutMs, waitForPatient) => withTimeout(
      chrome.runtime.sendMessage({
        type,
        ...type === START_ONE_CLICK_FLOW ? { waitForPatient: waitForPatient === true } : {}
      }),
      timeoutMs
    );
    const startFlow = async (fromWinFormsAutoLaunch = false) => {
      if (!state.canStart || requestInFlight) return;
      if (runtimeUnavailable) {
        requestInFlight = true;
        render("checking");
        label.textContent = "\u6B63\u5728\u91CD\u65B0\u8F09\u5165\u9801\u9762\u2026";
        hint.textContent = "\u5373\u5C07\u9023\u63A5\u65B0\u7248\u64F4\u5145\u529F\u80FD";
        location.reload();
        return;
      }
      requestInFlight = true;
      render(fromWinFormsAutoLaunch ? "waiting" : "checking");
      try {
        const response = await sendOneClickMessage(
          START_ONE_CLICK_FLOW,
          START_RESPONSE_TIMEOUT_MS,
          fromWinFormsAutoLaunch
        );
        applyResponse(response);
      } catch {
        requestInFlight = false;
        await refresh();
      } finally {
        requestInFlight = false;
      }
    };
    const refresh = async () => {
      if (!isLiveMediCloudPage()) {
        host.hidden = true;
        return;
      }
      host.hidden = false;
      if (requestInFlight) return;
      try {
        const response = await sendOneClickMessage(
          GET_ONE_CLICK_FLOW_STATE,
          STATE_RESPONSE_TIMEOUT_MS
        );
        if (state.phase === "error" && state.diagnosticCode?.startsWith("PATIENT_") && isOneClickFlowState(response?.state) && response.state.phase !== "error") return;
        applyResponse(response);
      } catch {
        applyResponse(void 0);
      }
    };
    button.addEventListener("click", () => {
      void startFlow();
    });
    document.addEventListener("click", (event) => {
      if (!host.isConnected) return;
      const target = event.target instanceof Element ? event.target.closest("a,button") : null;
      const labelText = String(target?.textContent ?? "").replace(/\s+/g, "").trim();
      if (!labelText.includes("\u8ACB\u63DB\u5361\u518D\u6309\u6211")) return;
      for (const delayMs of CARD_SWITCH_RECHECK_DELAYS_MS) {
        window.setTimeout(() => void refresh(), delayMs);
      }
    }, true);
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || typeof message !== "object" || Array.isArray(message)) return;
      const candidate = message;
      if (candidate.type === ONE_CLICK_FLOW_STATE_CHANGED && isOneClickFlowState(candidate.state)) {
        if (state.phase === "error" && state.diagnosticCode?.startsWith("PATIENT_") && candidate.state.phase !== "error" && !requestInFlight) return;
        applyResponse({ state: candidate.state });
      }
    });
    window.setInterval(() => {
      if (state.phase === "running" || state.phase === "opening" || state.phase === "ready" || state.phase === "error" || state.phase === "done") {
        void refresh();
      }
    }, FALLBACK_STATE_POLL_MS);
    const autoLaunch = shouldAutoLaunchFromWinForms(location.search);
    if (autoLaunch) {
      void startFlow(true);
      if (isEmergencyWinFormsLaunch(location.search)) void clickEmergencyMediCloudLogin(location.search);
    } else void refresh();
  }
  mountLauncher();
})();
