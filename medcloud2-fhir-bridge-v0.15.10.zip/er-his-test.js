"use strict";
(() => {
  // src/er-his.ts
  var ER_HIS_LAUNCH = "CLOUD_WILDCATCH_ER_HIS_LAUNCH_V1";
  var ER_HIS_TEST_LAUNCH = "CLOUD_WILDCATCH_ER_HIS_TEST_LAUNCH_V1";
  function parseErHisPatient(message, now = /* @__PURE__ */ new Date()) {
    if (!message || typeof message !== "object" || Array.isArray(message)) return null;
    const value = message;
    if (value.type !== ER_HIS_LAUNCH || value.mode !== "er" || typeof value.issuedAt !== "number" || !Number.isSafeInteger(value.issuedAt) || value.issuedAt > now.getTime() + 5e3 || now.getTime() - value.issuedAt > 3e4 || typeof value.requestId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value.requestId) || typeof value.nationalId !== "string" || !/^[A-Za-z][A-Za-z0-9][0-9]{8}$/.test(value.nationalId) || typeof value.birthRoc !== "string" || !/^\d{7}$/.test(value.birthRoc)) return null;
    const roc = Number(value.birthRoc.slice(0, 3)), year = roc + 1911;
    const month = Number(value.birthRoc.slice(3, 5)), day = Number(value.birthRoc.slice(5));
    const date = new Date(Date.UTC(year, month - 1, day));
    const today = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
    if (roc < 1 || date.getUTCFullYear() !== year || date.getUTCMonth() + 1 !== month || date.getUTCDate() !== day || date.getTime() > today || now.getFullYear() - year > 150) return null;
    return {
      nationalId: value.nationalId.toUpperCase(),
      birthRoc: value.birthRoc,
      birthDate: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    };
  }

  // src/async-timeout.ts
  var AsyncTimeoutError = class extends Error {
    constructor() {
      super("ASYNC_OPERATION_TIMED_OUT");
      this.name = "AsyncTimeoutError";
    }
  };
  function withTimeout(operation, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timeoutId = globalThis.setTimeout(() => {
        reject(new AsyncTimeoutError());
      }, timeoutMs);
      void Promise.resolve(operation).then(
        (value) => {
          globalThis.clearTimeout(timeoutId);
          resolve(value);
        },
        (error) => {
          globalThis.clearTimeout(timeoutId);
          reject(error);
        }
      );
    });
  }

  // src/er-his-test.ts
  var button = document.getElementById("start");
  var status = document.getElementById("status");
  async function launch() {
    if (button.disabled) return;
    button.disabled = true;
    try {
      const nationalId = window.prompt("\u8ACB\u8F38\u5165\u672C\u6B21\u6388\u6B0A\u67E5\u8A62\u7684\u75C5\u4EBA\u8EAB\u5206\u8B49\u5B57\u865F\uFF1A");
      if (nationalId === null) {
        status.textContent = "\u5DF2\u53D6\u6D88\uFF0C\u672A\u555F\u52D5\u67E5\u8A62\u3002";
        return;
      }
      const birthRoc = window.prompt("\u8ACB\u8F38\u5165\u75C5\u4EBA\u51FA\u751F\u5E74\u6708\u65E5\uFF08\u6C11\u570B\u4E03\u78BC\uFF0C\u4F8B\uFF1A0800101\uFF09\uFF1A");
      if (birthRoc === null) {
        status.textContent = "\u5DF2\u53D6\u6D88\uFF0C\u672A\u555F\u52D5\u67E5\u8A62\u3002";
        return;
      }
      const payload = {
        type: ER_HIS_LAUNCH,
        mode: "er",
        requestId: crypto.randomUUID(),
        issuedAt: Date.now(),
        nationalId: nationalId.trim().toUpperCase(),
        birthRoc: birthRoc.trim()
      };
      if (!parseErHisPatient(payload)) {
        status.textContent = "\u8B49\u865F\u6216\u751F\u65E5\u683C\u5F0F\u4E0D\u6B63\u78BA\uFF0C\u8ACB\u91CD\u65B0\u8F38\u5165\uFF1B\u751F\u65E5\u9808\u70BA\u6C11\u570B\u4E03\u78BC\u6709\u6548\u65E5\u671F\u3002";
        return;
      }
      status.textContent = "\u6B63\u5728\u555F\u52D5\u6025\u8A3A\u67E5\u8A62\u2026";
      const response = await withTimeout(chrome.runtime.sendMessage({ type: ER_HIS_TEST_LAUNCH, payload }), 15e3);
      if (response?.ok) status.textContent = "\u5DF2\u958B\u555F\u6025\u8A3A\u96F2\u7AEF\u75C5\u6B77\u3002\u5B8C\u6210\u5B98\u65B9\u8B80\u5361\u767B\u5165\u5F8C\uFF0C\u96F2\u6293\u6703\u9810\u586B\u3001\u67E5\u8A62\u4E26\u6838\u5C0D\u75C5\u4EBA\u5F8C\u53D6\u5F97\u8CC7\u6599\u3002";
      else status.textContent = response?.code === "LAUNCH_BUSY" ? "\u53E6\u4E00\u500B\u6025\u8A3A\u67E5\u8A62\u6B63\u5728\u555F\u52D5\uFF0C\u8ACB\u7A0D\u5019\u3002" : "\u672A\u555F\u52D5\u6210\u529F\uFF0C\u8ACB\u78BA\u8A8D\u65B0\u7248\u96F2\u6293\u5DF2\u8F09\u5165\u3002";
    } catch {
      status.textContent = "\u96F2\u6293\u56DE\u61C9\u903E\u6642\u6216\u5DF2\u91CD\u65B0\u8F09\u5165\uFF0C\u8ACB\u6AA2\u67E5\u662F\u5426\u5DF2\u958B\u555F\u67E5\u8A62\u9801\u518D\u91CD\u8A66\u3002";
    } finally {
      button.disabled = false;
    }
  }
  button.addEventListener("click", () => {
    void launch();
  });
  void launch();
})();
