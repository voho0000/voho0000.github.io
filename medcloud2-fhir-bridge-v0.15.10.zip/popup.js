"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // (disabled):crypto
  var require_crypto2 = __commonJS({
    "(disabled):crypto"() {
    }
  });

  // (disabled):buffer
  var require_buffer2 = __commonJS({
    "(disabled):buffer"() {
    }
  });

  // ../node_modules/js-sha1/src/sha1.js
  var require_sha12 = __commonJS({
    "../node_modules/js-sha1/src/sha1.js"(exports, module) {
      (function() {
        "use strict";
        var INPUT_ERROR = "input is invalid type";
        var FINALIZE_ERROR = "finalize already called";
        var WINDOW = typeof window === "object";
        var root = WINDOW ? window : {};
        if (root.JS_SHA1_NO_WINDOW) {
          WINDOW = false;
        }
        var WEB_WORKER = !WINDOW && typeof self === "object";
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
        if (NODE_JS) {
          root = global;
        } else if (WEB_WORKER) {
          root = self;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var ARRAY_BUFFER = !root.JS_SHA1_NO_ARRAY_BUFFER && typeof ArrayBuffer !== "undefined";
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var isArray = Array.isArray;
        if (root.JS_SHA1_NO_NODE_JS || !isArray) {
          isArray = function(obj) {
            return Object.prototype.toString.call(obj) === "[object Array]";
          };
        }
        var isView = ArrayBuffer.isView;
        if (ARRAY_BUFFER && (root.JS_SHA1_NO_ARRAY_BUFFER_IS_VIEW || !isView)) {
          isView = function(obj) {
            return typeof obj === "object" && obj.buffer && obj.buffer.constructor === ArrayBuffer;
          };
        }
        var formatMessage = function(message2) {
          var type = typeof message2;
          if (type === "string") {
            return [message2, true];
          }
          if (type !== "object" || message2 === null) {
            throw new Error(INPUT_ERROR);
          }
          if (ARRAY_BUFFER && message2.constructor === ArrayBuffer) {
            return [new Uint8Array(message2), false];
          }
          if (!isArray(message2) && !isView(message2)) {
            throw new Error(INPUT_ERROR);
          }
          return [message2, false];
        };
        var createOutputMethod = function(outputType) {
          return function(message2) {
            return new Sha1(true).update(message2)[outputType]();
          };
        };
        var createMethod = function() {
          var method = createOutputMethod("hex");
          if (NODE_JS) {
            method = nodeWrap(method);
          }
          method.create = function() {
            return new Sha1();
          };
          method.update = function(message2) {
            return method.create().update(message2);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createOutputMethod(type);
          }
          return method;
        };
        var nodeWrap = function(method) {
          var crypto2 = require_crypto2();
          var Buffer2 = require_buffer2().Buffer;
          var bufferFrom;
          if (Buffer2.from && !root.JS_SHA1_NO_BUFFER_FROM) {
            bufferFrom = Buffer2.from;
          } else {
            bufferFrom = function(message2) {
              return new Buffer2(message2);
            };
          }
          var nodeMethod = function(message2) {
            if (typeof message2 === "string") {
              return crypto2.createHash("sha1").update(message2, "utf8").digest("hex");
            } else {
              if (message2 === null || message2 === void 0) {
                throw new Error(INPUT_ERROR);
              } else if (message2.constructor === ArrayBuffer) {
                message2 = new Uint8Array(message2);
              }
            }
            if (isArray(message2) || isView(message2) || message2.constructor === Buffer2) {
              return crypto2.createHash("sha1").update(bufferFrom(message2)).digest("hex");
            } else {
              return method(message2);
            }
          };
          return nodeMethod;
        };
        var createHmacOutputMethod = function(outputType) {
          return function(key, message2) {
            return new HmacSha1(key, true).update(message2)[outputType]();
          };
        };
        var createHmacMethod = function() {
          var method = createHmacOutputMethod("hex");
          method.create = function(key) {
            return new HmacSha1(key);
          };
          method.update = function(key, message2) {
            return method.create(key).update(message2);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createHmacOutputMethod(type);
          }
          return method;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message2) {
          if (this.finalized) {
            throw new Error(FINALIZE_ERROR);
          }
          var result = formatMessage(message2);
          message2 = result[0];
          var isString = result[1];
          var code, index = 0, i, length = message2.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              this.block = blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (isString) {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message2.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >>> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >>> 2] |= (192 | code >>> 6) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >>> 2] |= (224 | code >>> 12) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message2.charCodeAt(++index) & 1023);
                  blocks2[i >>> 2] |= (240 | code >>> 18) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >>> 2] |= message2[index] << SHIFT[i++ & 3];
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >>> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >>> 28 & 15] + HEX_CHARS[h0 >>> 24 & 15] + HEX_CHARS[h0 >>> 20 & 15] + HEX_CHARS[h0 >>> 16 & 15] + HEX_CHARS[h0 >>> 12 & 15] + HEX_CHARS[h0 >>> 8 & 15] + HEX_CHARS[h0 >>> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >>> 28 & 15] + HEX_CHARS[h1 >>> 24 & 15] + HEX_CHARS[h1 >>> 20 & 15] + HEX_CHARS[h1 >>> 16 & 15] + HEX_CHARS[h1 >>> 12 & 15] + HEX_CHARS[h1 >>> 8 & 15] + HEX_CHARS[h1 >>> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >>> 28 & 15] + HEX_CHARS[h2 >>> 24 & 15] + HEX_CHARS[h2 >>> 20 & 15] + HEX_CHARS[h2 >>> 16 & 15] + HEX_CHARS[h2 >>> 12 & 15] + HEX_CHARS[h2 >>> 8 & 15] + HEX_CHARS[h2 >>> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >>> 28 & 15] + HEX_CHARS[h3 >>> 24 & 15] + HEX_CHARS[h3 >>> 20 & 15] + HEX_CHARS[h3 >>> 16 & 15] + HEX_CHARS[h3 >>> 12 & 15] + HEX_CHARS[h3 >>> 8 & 15] + HEX_CHARS[h3 >>> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >>> 28 & 15] + HEX_CHARS[h4 >>> 24 & 15] + HEX_CHARS[h4 >>> 20 & 15] + HEX_CHARS[h4 >>> 16 & 15] + HEX_CHARS[h4 >>> 12 & 15] + HEX_CHARS[h4 >>> 8 & 15] + HEX_CHARS[h4 >>> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >>> 24 & 255,
            h0 >>> 16 & 255,
            h0 >>> 8 & 255,
            h0 & 255,
            h1 >>> 24 & 255,
            h1 >>> 16 & 255,
            h1 >>> 8 & 255,
            h1 & 255,
            h2 >>> 24 & 255,
            h2 >>> 16 & 255,
            h2 >>> 8 & 255,
            h2 & 255,
            h3 >>> 24 & 255,
            h3 >>> 16 & 255,
            h3 >>> 8 & 255,
            h3 & 255,
            h4 >>> 24 & 255,
            h4 >>> 16 & 255,
            h4 >>> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        function HmacSha1(key, sharedMemory) {
          var i, result = formatMessage(key);
          key = result[0];
          if (result[1]) {
            var bytes = [], length = key.length, index = 0, code;
            for (i = 0; i < length; ++i) {
              code = key.charCodeAt(i);
              if (code < 128) {
                bytes[index++] = code;
              } else if (code < 2048) {
                bytes[index++] = 192 | code >>> 6;
                bytes[index++] = 128 | code & 63;
              } else if (code < 55296 || code >= 57344) {
                bytes[index++] = 224 | code >>> 12;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              } else {
                code = 65536 + ((code & 1023) << 10 | key.charCodeAt(++i) & 1023);
                bytes[index++] = 240 | code >>> 18;
                bytes[index++] = 128 | code >>> 12 & 63;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              }
            }
            key = bytes;
          }
          if (key.length > 64) {
            key = new Sha1(true).update(key).array();
          }
          var oKeyPad = [], iKeyPad = [];
          for (i = 0; i < 64; ++i) {
            var b = key[i] || 0;
            oKeyPad[i] = 92 ^ b;
            iKeyPad[i] = 54 ^ b;
          }
          Sha1.call(this, sharedMemory);
          this.update(iKeyPad);
          this.oKeyPad = oKeyPad;
          this.inner = true;
          this.sharedMemory = sharedMemory;
        }
        HmacSha1.prototype = new Sha1();
        HmacSha1.prototype.finalize = function() {
          Sha1.prototype.finalize.call(this);
          if (this.inner) {
            this.inner = false;
            var innerHash = this.array();
            Sha1.call(this, this.sharedMemory);
            this.update(this.oKeyPad);
            this.update(innerHash);
            Sha1.prototype.finalize.call(this);
          }
        };
        var exports2 = createMethod();
        exports2.sha1 = exports2;
        exports2.sha1.hmac = createHmacMethod();
        if (COMMON_JS) {
          module.exports = exports2;
        } else {
          root.sha1 = exports2;
          if (AMD) {
            define(function() {
              return exports2;
            });
          }
        }
      })();
    }
  });

  // src/privacy-preferences.ts
  var MASK_NAME_PREFERENCE_KEY = "cloud-wildcatch:maskNameEnabled";
  async function saveMaskNamePreference(enabled) {
    if (typeof enabled !== "boolean") throw new TypeError("Privacy preference must be boolean");
    await chrome.storage.local.set({ [MASK_NAME_PREFERENCE_KEY]: enabled });
  }
  async function readMaskNamePreference() {
    const stored = await chrome.storage.local.get(MASK_NAME_PREFERENCE_KEY);
    return stored[MASK_NAME_PREFERENCE_KEY] !== false;
  }
  async function migratePopupMaskNamePreference() {
    const stored = await chrome.storage.local.get(MASK_NAME_PREFERENCE_KEY);
    const value = stored[MASK_NAME_PREFERENCE_KEY];
    if (value !== void 0) return value !== false;
    const legacy = localStorage.getItem(MASK_NAME_PREFERENCE_KEY);
    const enabled = legacy === null || legacy === "false" ? false : true;
    await saveMaskNamePreference(enabled);
    return enabled;
  }
  async function loadPopupMaskNamePreference() {
    try {
      return await migratePopupMaskNamePreference();
    } catch {
      return true;
    }
  }

  // src/outpatient-preferences.ts
  var OUTPATIENT_PEER_KEY = "outpatientHisExtensionId";
  var NORTH_STORE_EXTENSION_ID = "eempjoojendpjgpkhljnplchhdkllkgo";
  var OUTPATIENT_ENABLED_KEY = "outpatientIntegrationEnabled";
  var SITE_TTL = 30 * 6e4;
  async function readOutpatientEnabled() {
    const stored = await chrome.storage.local.get([OUTPATIENT_ENABLED_KEY, OUTPATIENT_PEER_KEY]);
    if (typeof stored[OUTPATIENT_ENABLED_KEY] === "boolean") return stored[OUTPATIENT_ENABLED_KEY];
    return false;
  }
  async function saveOutpatientSettings(enabled, peerId) {
    if (typeof enabled !== "boolean") throw new Error("INVALID_OUTPATIENT_PREFERENCE");
    const id = peerId.trim();
    if ((enabled || id) && (!/^[a-p]{32}$/.test(id) || id === chrome.runtime.id)) throw new Error("INVALID_PEER_ID");
    await chrome.storage.local.set({ [OUTPATIENT_ENABLED_KEY]: enabled, [OUTPATIENT_PEER_KEY]: id });
  }
  function configuredPeerId(stored) {
    const id = stored === void 0 ? NORTH_STORE_EXTENSION_ID : stored;
    return typeof id === "string" && /^[a-p]{32}$/.test(id) && id !== chrome.runtime.id ? id : void 0;
  }
  async function readOutpatientPeerId() {
    return configuredPeerId((await chrome.storage.local.get(OUTPATIENT_PEER_KEY))[OUTPATIENT_PEER_KEY]);
  }

  // src/outpatient-coverage.ts
  var OUTPATIENT_INCOMPLETE_NOTICE = "\u5317\u69AE\u90E8\u5206\u8CC7\u6599\u672A\u53D6\u5F97\uFF0C\u7F3A\u6F0F\u4E0D\u4EE3\u8868\u6C92\u6709\u7D00\u9304\uFF1B\u8ACB\u6838\u5C0D HIS\u3002";
  var validCount = (value) => Number.isSafeInteger(value) && Number(value) >= 0 && Number(value) <= 1e5;
  function isOutpatientReportCoverage(value) {
    if (!value || typeof value !== "object") return false;
    const record = value;
    if (record.scope !== "one-year" || !validCount(record.capturedReports) || !validCount(record.unlinkedOrders)) return false;
    if (record.unlinkedOrderKinds === void 0) return true;
    if (!record.unlinkedOrderKinds || typeof record.unlinkedOrderKinds !== "object" || Array.isArray(record.unlinkedOrderKinds)) return false;
    const kinds = record.unlinkedOrderKinds;
    return validCount(kinds.appointments) && validCount(kinds.procedures) && validCount(kinds.other) && kinds.appointments + kinds.procedures + kinds.other === record.unlinkedOrders;
  }
  function outpatientReportNotice(value) {
    if (!isOutpatientReportCoverage(value) || value.unlinkedOrders === 0) return "";
    const kinds = value.unlinkedOrderKinds;
    const review = kinds ? [
      kinds.appointments ? `\u9810\u7D04\u91AB\u56D1 ${kinds.appointments} \u7B46\uFF08APPOINT\uFF0C\u672A\u78BA\u8A8D\u57F7\u884C\u6216\u672C\u6B21\u5831\u544A\u5C0D\u61C9\uFF09` : "",
      kinds.procedures ? `\u8655\u7F6E\u91AB\u56D1 ${kinds.procedures} \u7B46\uFF08\u672A\u78BA\u8A8D\u57F7\u884C\uFF0C\u4E0D\u4E00\u5B9A\u7522\u751F\u7368\u7ACB\u5831\u544A\uFF09` : "",
      kinds.other ? `\u5176\u4ED6\u91AB\u56D1 ${kinds.other} \u7B46\uFF08\u672A\u78BA\u8A8D\u5831\u544A\u5C0D\u61C9\uFF09` : ""
    ].filter(Boolean).join("\u3001") : `${value.unlinkedOrders} \u7B46\u91AB\u56D1\u672A\u78BA\u8A8D\u5831\u544A\u5C0D\u61C9`;
    return `\u5317\u69AE\u5831\u544A\u6E05\u55AE\u5167\u8FD1\u4E00\u5E74\u8CC7\u6599\u5DF2\u4FDD\u7559 ${value.capturedReports} \u4EFD\u3002\u53E6\u6709\u5F85\u6838\u5C0D\uFF1A${review}\u3002\u4EE5\u4E0A\u662F\u91AB\u56D1\u7B46\u6578\uFF0C\u4E0D\u662F\u6F0F\u6293\u5831\u544A\u4EFD\u6578\uFF1B\u5DF2\u4FDD\u7559\u539F\u59CB\u91AB\u56D1\u8207\u5831\u544A\u65E5\u671F\uFF0C\u672A\u5C07\u820A\u5831\u544A\u914D\u6210\u9019\u6B21\u91AB\u56D1\u7D50\u679C\u3002`;
  }
  function outpatientFallbackNotice(reason) {
    switch (reason) {
      case "HIS_PATIENT_SELECTION_REQUIRED":
        return "\u5317\u69AE\u67E5\u8A62\u7121\u6CD5\u552F\u4E00\u78BA\u8A8D\u75C5\u4EBA\uFF0C\u672C\u6B21\u5148\u4F7F\u7528\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u5728 HIS \u624B\u52D5\u9EDE\u9078\u6B63\u78BA\u75C5\u4EBA\u5F8C\u56DE\u96F2\u7AEF\u91CD\u65B0\u53D6\u5F97\u3002";
      case "CLOUD_WORKER_RESTARTED":
        return "\u96F2\u6293\u80CC\u666F\u5DE5\u4F5C\u91CD\u65B0\u555F\u52D5\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF0C\u672A\u6574\u5408\u5317\u69AE\u9662\u5167\u8CC7\u6599\uFF1B\u7F3A\u6F0F\u4E0D\u4EE3\u8868\u6C92\u6709\u9662\u5167\u7D00\u9304\u3002\u5982\u9700\u6574\u5408\u5317\u69AE\u8CC7\u6599\uFF0C\u8ACB\u91CD\u65B0\u53D6\u5F97\u3002";
      case "HIS_PATIENT_PROBE_UNAVAILABLE":
        return "\u66AB\u6642\u7121\u6CD5\u78BA\u8A8D\u96F2\u7AEF\u76EE\u524D\u75C5\u4EBA\uFF0C\u672A\u6574\u5408\u9662\u5167\u8CC7\u6599\uFF1B\u8ACB\u5F85\u9801\u9762\u8F09\u5165\u5B8C\u6210\u5F8C\u91CD\u8A66\u3002";
      case "HIS_INVALID_REQUEST":
        return "\u5317\u69AE\u7121\u6CD5\u9A57\u8B49\u672C\u6B21\u75C5\u4EBA\u8ACB\u6C42\uFF0C\u672A\u6574\u5408\u9662\u5167\u8CC7\u6599\uFF1B\u8ACB\u78BA\u8A8D\u59D3\u540D\u8207\u6838\u5C0D\u8B49\u865F\u8CC7\u6599\u5B8C\u6574\u3002";
      case "HIS_PAIRING_CHANGED":
        return "\u9580\u8A3A\u6574\u5408\u8A2D\u5B9A\u6216\u914D\u5C0D\u5DF2\u8B8A\u66F4\uFF0C\u672C\u6B21\u672A\u6574\u5408\u9662\u5167\u8CC7\u6599\u3002";
      case "HIS_MASKING_UNSUPPORTED":
        return "\u672C\u6B21\u555F\u7528\u53BB\u8B58\u5225\u5316\uFF0C\u50C5\u4F7F\u7528\u96F2\u7AEF\u8CC7\u6599\uFF1B\u9662\u5167\u539F\u6587\u5C1A\u4E0D\u652F\u63F4\u76F8\u540C\u906E\u7F69\uFF0C\u672A\u64F7\u53D6\u6216\u6574\u5408\u9662\u5167\u8CC7\u6599\u3002";
      case "PATIENT_HIS_MISMATCH":
        return "HIS \u9078\u5B9A\u75C5\u4EBA\u8207\u96F2\u7AEF\u4E0D\u4E00\u81F4\uFF0C\u672A\u6574\u5408\u9662\u5167\u8CC7\u6599\uFF0C\u8ACB\u78BA\u8A8D HIS \u75C5\u4EBA\u3002";
      case "INVALID_HIS_RESULT":
        return "\u5317\u69AE\u8CC7\u6599\u50B3\u8F38\u6216\u9A57\u8B49\u672A\u901A\u904E\uFF0C\u672A\u6574\u5408\u9662\u5167\u8CC7\u6599\uFF0C\u8ACB\u91CD\u65B0\u64F7\u53D6\u6216\u6AA2\u67E5\u5317\u69AE\u64F4\u5145\u529F\u80FD\u3002";
      case "HIS_LOGIN_REQUIRED":
        return "\u5317\u69AE\u4ECD\u5728\u7B49\u5F85\u767B\u5165\u6216\u9078\u5B9A\u76F8\u540C\u75C5\u4EBA\uFF0C\u6216\u5B8C\u6210\u8ABF\u95B1\u7406\u7531\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u5728 HIS \u5B8C\u6210\u4E0A\u8FF0\u6B65\u9A5F\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "HIS_TIMEOUT":
        return "\u5317\u69AE\u9662\u5167\u8CC7\u6599\u64F7\u53D6\u903E\u6642\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u78BA\u8A8D HIS \u75C5\u6B77\u9801\u5DF2\u5C31\u7DD2\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "HIS_BUSY":
        return "\u5317\u69AE\u64F4\u5145\u529F\u80FD\u6B63\u5728\u57F7\u884C\u5176\u4ED6\u5DE5\u4F5C\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u5F85\u8A72\u5DE5\u4F5C\u5B8C\u6210\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "JOB_INTERRUPTED":
        return "\u5317\u69AE\u80CC\u666F\u5DE5\u4F5C\u5DF2\u4E2D\u65B7\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u78BA\u8A8D\u5317\u69AE\u64F4\u5145\u529F\u80FD\u4ECD\u555F\u7528\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "OUTPATIENT_FAILED":
        return "\u5317\u69AE\u4E32\u63A5\u8981\u6C42\u672A\u5B8C\u6210\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u7A0D\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "OUTPATIENT_CAPTURE_FAILED":
        return "\u5317\u69AE\u9662\u5167\u8CC7\u6599\u64F7\u53D6\u5931\u6557\uFF0C\u672C\u6B21\u5148\u9001\u51FA\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u78BA\u8A8D HIS \u75C5\u6B77\u9801\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "OUTPATIENT_REPORTS_FAILED":
        return "\u5317\u69AE\u6AA2\u67E5\u9A57\u5831\u544A\u672A\u5B8C\u6574\u53D6\u5F97\uFF0C\u8ACB\u6838\u5C0D HIS\uFF1B\u7F3A\u6F0F\u4E0D\u4EE3\u8868\u6C92\u6709\u5831\u544A\u3002";
      case "OUTPATIENT_CANCELLED":
        return "\u5317\u69AE\u53D6\u5F97\u5DF2\u53D6\u6D88\uFF0C\u672C\u6B21\u50C5\u4F7F\u7528\u96F2\u7AEF\u8CC7\u6599\u3002";
      case "HIS_SESSION_BLOCKED":
        return "\u5317\u69AE\u670D\u52D9\u62D2\u7D55\u672C\u6B21\u8ACB\u6C42\uFF0C\u5DF2\u505C\u6B62\u9662\u5167\u64F7\u53D6\uFF1B\u8ACB\u78BA\u8A8D HIS \u767B\u5165\u8207\u670D\u52D9\u72C0\u614B\u5F8C\u91CD\u65B0\u53D6\u5F97\u3002";
      case "OUTPATIENT_SKIPPED":
        return "\u672C\u6B21\u5DF2\u9078\u64C7\u50C5\u4F7F\u7528\u96F2\u7AEF\u8CC7\u6599\uFF0C\u672A\u6574\u5408\u5317\u69AE\u9662\u5167\u8CC7\u6599\u3002";
      default:
        return "\u5317\u69AE\u6574\u5408\u76EE\u524D\u7121\u6CD5\u4F7F\u7528\uFF0C\u672C\u6B21\u50C5\u4F7F\u7528\u96F2\u7AEF\u8CC7\u6599\uFF1B\u8ACB\u6AA2\u67E5\u64F4\u5145\u529F\u80FD\u914D\u5C0D\u8A2D\u5B9A\u8207\u75C5\u4EBA\u8B58\u5225\u8CC7\u6599\u3002";
    }
  }
  function appendDistinctNotices(message2, ...notices) {
    let result = message2;
    for (const notice of notices) {
      const normalized = (text) => text.replace(/\s+/g, "").replace(/[。；]+$/, "");
      if (notice && !normalized(result).includes(normalized(notice))) result += ` ${notice}`;
    }
    return result.trim();
  }
  function hospitalResultNotice(status) {
    return appendDistinctNotices(
      status.outpatientSkipped ? outpatientFallbackNotice(status.outpatientFallbackReason) : status.outpatientIncomplete ? OUTPATIENT_INCOMPLETE_NOTICE : "",
      status.progressiveInterrupted ? "\u5148\u524D\u91AB\u6790\u5206\u9801\u7684\u88DC\u8F09\u5DF2\u4E2D\u65B7\uFF1B\u96F2\u7AEF\u7D50\u679C\u5DF2\u53E6\u884C\u4FDD\u5B58\uFF0C\u8ACB\u6838\u5C0D\u5F8C\u624B\u52D5\u958B\u555F\uFF0C\u672A\u81EA\u52D5\u5EFA\u7ACB\u7B2C\u4E8C\u500B\u5206\u9801\u3002" : "",
      outpatientDiagnosticNotice(status.outpatientDiagnostic),
      status.outpatientSkipped ? "" : outpatientReportNotice(status.outpatientReportCoverage)
    );
  }
  var TRANSPORT_DIAGNOSTICS = ["CHUNK_METADATA", "CHUNK_DATA", "JSON_PARSE", "RESULT_SHAPE"];
  var GRAPH_DIAGNOSTICS = ["INVALID_PATIENT_GRAPH", "INVALID_HIS_RESOURCE", "DUPLICATE_HIS_RESOURCE", "UNRESOLVED_HIS_REFERENCE"];
  var diagnosticCodes = /* @__PURE__ */ new Set([
    ...TRANSPORT_DIAGNOSTICS,
    ...GRAPH_DIAGNOSTICS,
    "non-finite-number",
    "null-element",
    "empty-string",
    "empty-array",
    "empty-object",
    "bundle-shape",
    "patient-isolation",
    "resource-identity",
    "duplicate-resource-identity",
    "duplicate-full-url",
    "full-url-identity",
    "full-url",
    "invalid-reference",
    "broken-reference",
    "provenance-coverage"
  ]);
  function outpatientDiagnosticNotice(value) {
    if (typeof value !== "string" || value.length > 1024) return "";
    const codes = [...new Set(value.split(",").map((code) => code.trim()))];
    if (!codes.length || codes.some((code) => !diagnosticCodes.has(code))) return "";
    return `\uFF08\u932F\u8AA4\u4EE3\u78BC\uFF1A${codes.slice(0, 6).join(", ")}\uFF09`;
  }

  // src/winforms-url-automation.ts
  var WINFORMS_SITE_PATTERN = /^[a-z0-9][a-z0-9_-]{0,31}$/i;
  function isValidWinFormsSite(value) {
    return WINFORMS_SITE_PATTERN.test(value);
  }

  // src/mediprisma.ts
  var MEDIPRISMA_APP_URL = "https://mediprisma.tw/app/";
  var MEDIPRISMA_ORIGIN_PATTERNS = [
    "https://mediprisma.tw/app",
    "https://mediprisma.tw/app/*",
    "https://mediprisma.tw/app-hmc",
    "https://mediprisma.tw/app-hmc/*"
  ];
  var MEDIPRISMA_APP_PATHS = ["/app", "/app/", "/app-hmc", "/app-hmc/"];
  var MEDIPRISMA_CONTROL_PARAMS = /* @__PURE__ */ new Set(["medcloud2", "site"]);
  function isAllowedMediPrismaAppUrl(raw) {
    try {
      const url = new URL(raw ?? "");
      if (url.origin === "https://mediprisma.tw" && MEDIPRISMA_APP_PATHS.includes(url.pathname) && !url.username && !url.password && url.hash === "") {
        const keys = [];
        url.searchParams.forEach((_value, key) => keys.push(key));
        if (keys.some((key) => !MEDIPRISMA_CONTROL_PARAMS.has(key))) return false;
        if (keys.length === 0) return true;
        const modes = url.searchParams.getAll("medcloud2");
        const sites = url.searchParams.getAll("site");
        return modes.length <= 1 && (modes.length === 0 || modes[0] === "auto") && sites.length <= 1 && (sites.length === 0 || isValidWinFormsSite(sites[0] ?? "")) && modes.length + sites.length > 0;
      }
      return false;
    } catch {
      return false;
    }
  }

  // ../packages/medcloud-adapter/src/constants.ts
  var MEDCLOUD_ADAPTER_VERSION = "0.15.10";
  var IMUE0060_SOURCE_MODULE = "IMUE0060";
  var IMUE0060_DATASET_SCOPE = "/imu/api/imue0060/imue0060s02/get-data";
  var IMUE0008_SOURCE_MODULE = "IMUE0008";
  var IMUE0008_DATASET_SCOPE = "/imu/api/imue0008/imue0008s02/get-data";
  var IMUE0130_SOURCE_MODULE = "IMUE0130";
  var IMUE0130_DATASET_SCOPE = "/imu/api/imue0130/imue0130s02/get-data";
  var IMUE0030_SOURCE_MODULE = "IMUE0030";
  var IMUE0030_DATASET_SCOPE = "/imu/api/imue0030/imue0030s02/get-data";
  var IMUE0010_SOURCE_MODULE = "IMUE0010";
  var IMUE0010_DATASET_SCOPE = "/imu/api/imue0010/imue0010s02/get-data";
  var IMUE0120_SOURCE_MODULE = "IMUE0120";
  var IMUE0120_DATASET_SCOPE = "/imu/api/imue0120/imue0120s01/pres-med-day";
  var IMUE0140_SOURCE_MODULE = "IMUE0140";
  var IMUE0140_DATASET_SCOPE = "/imu/api/imue0140/imue0140s01/hpa-data";
  var IMUE0070_SOURCE_MODULE = "IMUE0070";
  var IMUE0070_DATASET_SCOPE = "/imu/api/imue0070/imue0070s02/get-data";
  var IMUE0080_SOURCE_MODULE = "IMUE0080";
  var IMUE0080_DATASET_SCOPE = "/imu/api/imue0080/imue0080s02/get-data";
  var IMUE0150_SOURCE_MODULE = "IMUE0150";
  var IMUE0150_DATASET_SCOPE = "/imu/api/imue0150/imue0150s01/hpa-data";
  var IMUE0040_SOURCE_MODULE = "IMUE0040";
  var IMUE0040_DATASET_SCOPE = "/imu/api/imue0040/imue0040s02/get-data";
  var IMUE0020_SOURCE_MODULE = "IMUE0020";
  var IMUE0020_DATASET_SCOPE = "/imu/api/imue0020/imue0020s02/get-data";
  var IMUE0200_SOURCE_MODULE = "IMUE0200";
  var IMUE0200_DATASET_SCOPE = "/imu/api/imue0200/imue0200s02/get-data";
  var MEDCLOUD_CLINICAL_MODULES = [
    { sourceModule: IMUE0060_SOURCE_MODULE, datasetScope: IMUE0060_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C" },
    { sourceModule: IMUE0008_SOURCE_MODULE, datasetScope: IMUE0008_DATASET_SCOPE, label: "\u897F\u91AB\u7528\u85E5" },
    { sourceModule: IMUE0130_SOURCE_MODULE, datasetScope: IMUE0130_DATASET_SCOPE, label: "\u6587\u5B57\u5831\u544A" },
    { sourceModule: IMUE0030_SOURCE_MODULE, datasetScope: IMUE0030_DATASET_SCOPE, label: "\u7259\u79D1\u8655\u7F6E" },
    { sourceModule: IMUE0010_SOURCE_MODULE, datasetScope: IMUE0010_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D00\u9304" },
    { sourceModule: IMUE0070_SOURCE_MODULE, datasetScope: IMUE0070_DATASET_SCOPE, label: "\u4F4F\u9662\u53CA\u51FA\u9662\u75C5\u6B77\u6458\u8981" },
    { sourceModule: IMUE0080_SOURCE_MODULE, datasetScope: IMUE0080_DATASET_SCOPE, label: "\u5FA9\u5065\u91AB\u7642\u7D00\u9304" },
    { sourceModule: IMUE0120_SOURCE_MODULE, datasetScope: IMUE0120_DATASET_SCOPE, label: "\u9580\u8A3A\u85E5\u54C1\u9918\u85E5\u65E5\u6578" },
    { sourceModule: IMUE0140_SOURCE_MODULE, datasetScope: IMUE0140_DATASET_SCOPE, label: "\u6210\u4EBA\u9810\u9632\u4FDD\u5065" },
    { sourceModule: IMUE0150_SOURCE_MODULE, datasetScope: IMUE0150_DATASET_SCOPE, label: "\u764C\u75C7\u7BE9\u6AA2\u7D50\u679C" },
    { sourceModule: IMUE0040_SOURCE_MODULE, datasetScope: IMUE0040_DATASET_SCOPE, label: "\u904E\u654F\u7D00\u9304" },
    { sourceModule: IMUE0020_SOURCE_MODULE, datasetScope: IMUE0020_DATASET_SCOPE, label: "\u624B\u8853\u7D00\u9304" },
    { sourceModule: IMUE0200_SOURCE_MODULE, datasetScope: IMUE0200_DATASET_SCOPE, label: "\u7279\u6750\u7D00\u9304" }
  ];
  var MEDCLOUD_CAPTURE_MODULES = MEDCLOUD_CLINICAL_MODULES;

  // src/module-stage-status.ts
  var MODULE_IDS = new Set(MEDCLOUD_CLINICAL_MODULES.map((module) => module.sourceModule));
  function isModuleAcquisitionStatuses(value) {
    return Array.isArray(value) && value.length <= MODULE_IDS.size && new Set(value.map((item) => item?.sourceModule)).size === value.length && value.every((item) => item && typeof item === "object" && MODULE_IDS.has(item.sourceModule) && Number.isInteger(item.httpStatus) && item.httpStatus >= 0 && item.httpStatus <= 599 && typeof item.bodyReceived === "boolean" && Object.keys(item).every((key) => ["sourceModule", "httpStatus", "bodyReceived"].includes(key)));
  }
  function summarizeCapturedEndpoints(endpoints) {
    return MEDCLOUD_CLINICAL_MODULES.flatMap((module) => {
      const response = endpoints[module.datasetScope];
      if (!response) return [];
      return [{
        sourceModule: module.sourceModule,
        httpStatus: Number.isInteger(response.status) && response.status >= 0 && response.status <= 599 ? response.status : 0,
        bodyReceived: typeof response.body === "string" ? response.body.length > 0 : response.body != null
      }];
    });
  }
  function presentModuleStages(context = {}) {
    const modules = MEDCLOUD_CLINICAL_MODULES.filter(({ sourceModule }) => MEDCLOUD_CAPTURE_MODULES.some((module) => module.sourceModule === sourceModule) || context.moduleAcquisition?.some((module) => module.sourceModule === sourceModule) || context.summary?.moduleStatuses.some((module) => module.sourceModule === sourceModule));
    const rows = modules.map(({ sourceModule, label }) => {
      const captured = context.moduleAcquisition?.find((module) => module.sourceModule === sourceModule);
      const converted = context.summary?.moduleStatuses.find((module) => module.sourceModule === sourceModule);
      const running = context.phase === "running";
      const invalidated = context.errorCode === "PATIENT_CONTEXT_CHANGED";
      let acquisition;
      if (invalidated) acquisition = { text: "\u5DF2\u4F5C\u5EE2", tone: "" };
      else if (captured) {
        const ok = captured.httpStatus >= 200 && captured.httpStatus < 300;
        acquisition = {
          text: ok ? captured.bodyReceived ? "\u53D6\u5F97\u6210\u529F" : "\u7A7A\u56DE\u61C9" : [401, 403].includes(captured.httpStatus) ? "\u6388\u6B0A\u5931\u6557" : "\u53D6\u5F97\u5931\u6557",
          tone: ok ? captured.bodyReceived ? "complete" : "partial" : "failed",
          detail: captured.httpStatus ? `HTTP ${captured.httpStatus}\uFF1B${captured.bodyReceived ? "\u5DF2\u6536\u5230\u56DE\u61C9\u672C\u6587" : "\u672A\u6536\u5230\u56DE\u61C9\u672C\u6587"}` : "\u672A\u53D6\u5F97 HTTP \u56DE\u61C9"
        };
      } else if (converted && ["complete", "empty", "partial"].includes(converted.completeness)) {
        acquisition = { text: "\u53D6\u5F97\u6210\u529F", tone: "complete", detail: "\u4F9D\u8F49\u63DB\u7D50\u679C\u78BA\u8A8D\uFF1B\u820A\u7248\u672A\u8A18\u9304 HTTP \u72C0\u614B" };
      } else acquisition = { text: running && (!context.stage || context.stage === "capture") ? "\u53D6\u5F97\u4E2D" : context.phase ? "\u672A\u78BA\u8A8D" : "\u5F85\u53D6\u5F97", tone: running && (!context.stage || context.stage === "capture") ? "running" : "" };
      let conversion;
      if (invalidated) conversion = { text: "\u5DF2\u4F5C\u5EE2", tone: "" };
      else if (context.rawOnly) conversion = { text: "\u672A\u57F7\u884C", tone: "", detail: "\u9019\u6B21\u53EA\u4E0B\u8F09\u539F\u59CB\u8CC7\u6599\uFF0C\u672A\u57F7\u884C FHIR \u8F49\u63DB" };
      else if (converted) {
        conversion = converted.completeness === "complete" ? { text: (converted.warningCount ?? 0) > 0 ? "\u6210\u529F\u30FB\u6709\u63D0\u9192" : "\u8F49\u63DB\u6210\u529F", tone: "complete" } : converted.completeness === "empty" ? { text: "\u7121\u8CC7\u6599", tone: "complete", detail: "\u5DF2\u89E3\u6790\u56DE\u61C9\uFF0C\u4F86\u6E90\u6C92\u6709\u53EF\u8F49\u63DB\u7684\u7D00\u9304" } : converted.completeness === "partial" ? { text: "\u90E8\u5206\u6210\u529F", tone: "partial" } : acquisition.tone === "failed" ? { text: "\u672A\u57F7\u884C", tone: "", detail: "\u539F\u59CB\u8CC7\u6599\u53D6\u5F97\u5931\u6557" } : { text: "\u8F49\u63DB\u5931\u6557", tone: "failed" };
      } else if (acquisition.tone === "failed") conversion = { text: "\u672A\u57F7\u884C", tone: "" };
      else if (context.errorCode === "ALL_MODULES_FAILED" && captured) conversion = { text: "\u8F49\u63DB\u5931\u6557", tone: "failed" };
      else if (context.phase === "error") conversion = { text: "\u672A\u5B8C\u6210", tone: "partial", detail: "\u4F5C\u696D\u4E2D\u6B62\uFF0C\u6C92\u6709\u53EF\u78BA\u8A8D\u7684\u6A21\u7D44\u8F49\u63DB\u7D50\u679C\uFF1B\u4E0D\u4EE3\u8868\u539F\u59CB\u53D6\u5F97\u5931\u6557" };
      else conversion = {
        text: running && context.stage === "transform" ? "\u8F49\u63DB\u4E2D" : "\u5F85\u8F49\u63DB",
        tone: running && context.stage === "transform" ? "running" : ""
      };
      return { sourceModule, label, acquisition, conversion };
    });
    const acquired = rows.filter((row) => row.acquisition.text === "\u53D6\u5F97\u6210\u529F").length;
    const captureFailed = rows.filter((row) => row.acquisition.tone === "failed").length;
    const complete = rows.filter((row) => ["\u8F49\u63DB\u6210\u529F", "\u6210\u529F\u30FB\u6709\u63D0\u9192"].includes(row.conversion.text)).length;
    const empty = rows.filter((row) => row.conversion.text === "\u7121\u8CC7\u6599").length;
    const partial = rows.filter((row) => row.conversion.text === "\u90E8\u5206\u6210\u529F").length;
    const failed = rows.filter((row) => row.conversion.text === "\u8F49\u63DB\u5931\u6557").length;
    const acquisitionSummary = context.errorCode === "PATIENT_CONTEXT_CHANGED" ? "\u539F\u59CB\u8CC7\u6599\uFF1A\u5DF2\u4F5C\u5EE2" : context.phase === "error" && !context.summary && !context.moduleAcquisition?.length ? "\u539F\u59CB\u8CC7\u6599\uFF1A\u72C0\u614B\u672A\u78BA\u8A8D" : !context.phase && !context.summary && !context.moduleAcquisition ? `\u539F\u59CB\u8CC7\u6599\uFF1A${rows.length} \u9805\u5F85\u53D6\u5F97` : `\u539F\u59CB\u8CC7\u6599\uFF1A${acquired}/${rows.length} \u9805\u5DF2\u53D6\u5F97${captureFailed ? `\uFF0C${captureFailed} \u9805\u5931\u6557` : ""}`;
    const conversionCounts = [
      complete ? `${complete} \u6210\u529F` : "",
      empty ? `${empty} \u7121\u8CC7\u6599` : "",
      partial ? `${partial} \u90E8\u5206\u6210\u529F` : "",
      failed ? `${failed} \u5931\u6557` : ""
    ].filter(Boolean);
    const conversionSummary = `FHIR \u8F49\u63DB\uFF1A${context.errorCode === "PATIENT_CONTEXT_CHANGED" ? "\u5DF2\u4F5C\u5EE2" : context.rawOnly ? "\u672A\u57F7\u884C" : conversionCounts.length ? conversionCounts.join("\u3001") : context.phase === "error" ? "\u672A\u5B8C\u6210" : context.stage === "transform" ? "\u8F49\u63DB\u4E2D" : "\u5F85\u8F49\u63DB"}`;
    return { rows, acquisitionSummary, conversionSummary };
  }

  // src/mapping-progress.ts
  function isMappingProgress(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const progress = value;
    return Object.keys(progress).length === 3 && Number.isInteger(progress.attempts) && Number(progress.attempts) >= 0 && Number(progress.attempts) <= 28 && [progress.totalBuildMs, progress.maxBuildMs].every((ms) => typeof ms === "number" && Number.isFinite(ms) && ms >= 0) && Number(progress.maxBuildMs) <= Number(progress.totalBuildMs);
  }

  // src/background-job.ts
  var BACKGROUND_JOB_STATUS_KEY = "cloud-wildcatch:medcloud-job-status-v1";
  var BACKGROUND_JOB_REQUEST_KEY = "cloud-wildcatch:medcloud-job-request-v1";
  var BACKGROUND_RESULT_ENCRYPTION_KEY = "cloud-wildcatch:result-encryption-key-v1";
  var START_BACKGROUND_JOB = "medcloud:start-background-job";
  var MARK_BACKGROUND_JOB_DOWNLOADED = "medcloud:mark-background-job-downloaded";
  var CLEAR_BACKGROUND_JOB = "medcloud:clear-background-job";
  var ARM_MEDIPRISMA_HANDOFF = "medcloud:arm-mediprisma-handoff";
  var DISARM_MEDIPRISMA_HANDOFF = "medcloud:disarm-mediprisma-handoff";
  var OPEN_PENDING_BUNDLE_IN_MEDIPRISMA = "medcloud:open-pending-bundle-in-mediprisma";
  var OUTPATIENT_ACTION = "medcloud:outpatient-action";
  var BACKGROUND_RESULT_TTL_MS = 60 * 60 * 1e3;
  var PRIVACY_OUTPUT_VERSION = 6;
  var PRIVACY_STALE_MESSAGE = "\u53BB\u8B58\u5225\u5316\u8A2D\u5B9A\u6216\u8F38\u51FA\u7248\u672C\u5DF2\u8B8A\u66F4\uFF0C\u8ACB\u6309\u300C\u91CD\u65B0\u53D6\u5F97\u300D\u5F8C\u518D\u4E0B\u8F09\u6216\u67E5\u770B\u3002";
  function isPrivacyOutputCurrent(status, enabled) {
    return Boolean(status && (status.maskNameEnabled ?? true) === enabled && status.privacyOutputVersion === PRIVACY_OUTPUT_VERSION);
  }
  var BACKGROUND_JOB_RECOVERY_WINDOW_MS = 10 * 60 * 1e3;
  var BACKGROUND_JOB_TIMEOUT_MS = 4 * 60 * 1e3;
  var OUTPATIENT_JOB_TIMEOUT_MS = 15 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isBackgroundJobStatus(value) {
    if (!isRecord(value)) return false;
    return value.schemaVersion === 1 && typeof value.runId === "string" && ["running", "complete", "error", "downloaded", "handed-off"].includes(String(value.phase)) && typeof value.patientContextHash === "string" && typeof value.startedAt === "number" && typeof value.updatedAt === "number" && (value.completedAt === void 0 || typeof value.completedAt === "number" && Number.isFinite(value.completedAt)) && typeof value.message === "string" && typeof value.hasResult === "boolean" && ["outpatientNeedsLogin", "outpatientIncomplete", "outpatientSkipped"].every((key) => value[key] === void 0 || typeof value[key] === "boolean") && ["outpatientMessage", "outpatientFallbackReason", "outpatientDiagnostic"].every((key) => value[key] === void 0 || typeof value[key] === "string") && (value.outpatientReportCoverage === void 0 || isOutpatientReportCoverage(value.outpatientReportCoverage)) && (value.outpatientPeerId === void 0 || typeof value.outpatientPeerId === "string" && /^[a-p]{32}$/.test(value.outpatientPeerId)) && (value.mediprismaAppUrl === void 0 || typeof value.mediprismaAppUrl === "string" && isAllowedMediPrismaAppUrl(value.mediprismaAppUrl)) && (value.stage === void 0 || ["capture", "transform", "protect", "store"].includes(String(value.stage))) && (value.stageStartedAt === void 0 || typeof value.stageStartedAt === "number" && Number.isFinite(value.stageStartedAt)) && typeof value.includeImagingViewerLinks === "boolean" && (value.tabId === void 0 || Number.isInteger(value.tabId) && Number(value.tabId) > 0) && (value.deliveryMode === void 0 || ["manual", "mediprisma"].includes(String(value.deliveryMode))) && (value.downloadedAt === void 0 || typeof value.downloadedAt === "number" && Number.isFinite(value.downloadedAt)) && (value.handedOffAt === void 0 || typeof value.handedOffAt === "number" && Number.isFinite(value.handedOffAt)) && (value.resultBytes === void 0 || Number.isInteger(value.resultBytes) && Number(value.resultBytes) >= 0) && (value.moduleAcquisition === void 0 || isModuleAcquisitionStatuses(value.moduleAcquisition)) && (value.mappingProgress === void 0 || isMappingProgress(value.mappingProgress)) && (value.moduleProgress === void 0 || isRecord(value.moduleProgress) && Number.isInteger(value.moduleProgress.completed) && Number(value.moduleProgress.completed) >= 0 && Number.isInteger(value.moduleProgress.total) && Number(value.moduleProgress.total) >= 0 && Number(value.moduleProgress.completed) <= Number(value.moduleProgress.total));
  }
  function isBackgroundJobResult(value) {
    if (!isRecord(value)) return false;
    const hasCommonFields = typeof value.runId === "string" && typeof value.patientContextHash === "string" && typeof value.generatedAt === "number" && typeof value.expiresAt === "number" && typeof value.filename === "string";
    if (!hasCommonFields) return false;
    if (value.schemaVersion === 5) return value.rawCapture === void 0 && isEncodedRawCapture(value);
    if (value.schemaVersion === 1) return "bundle" in value;
    const hasValidUncompressedSize = Number.isInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) >= 0;
    if (value.schemaVersion === 2) {
      return value.encoding === "gzip-base64" && typeof value.data === "string" && value.data.length > 0 && hasValidUncompressedSize;
    }
    if (value.schemaVersion === 3) return value.schemaVersion === 3 && value.encoding === "gzip" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && hasValidUncompressedSize;
    return value.schemaVersion === 4 && value.encoding === "gzip+aes-gcm" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && value.iv instanceof ArrayBuffer && value.iv.byteLength === 12 && hasValidUncompressedSize && (value.bundleId === void 0 || typeof value.bundleId === "string" && /^[A-Za-z0-9.-]{1,64}$/.test(value.bundleId)) && (value.rawCapture === void 0 || isEncodedRawCapture(value.rawCapture));
  }
  function isEncodedRawCapture(value) {
    if (!isRecord(value)) return false;
    return value.encoding === "gzip+aes-gcm" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && value.iv instanceof ArrayBuffer && value.iv.byteLength === 12 && Number.isInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) >= 0 && typeof value.filename === "string" && value.filename.length > 0;
  }
  function runningJobStatus(request, startedAt = Date.now(), recovered = false) {
    return {
      schemaVersion: 1,
      runId: request.runId,
      phase: "running",
      patientContextHash: request.expectedPatientContextHash,
      startedAt,
      updatedAt: Date.now(),
      message: recovered ? "\u6B63\u5728\u7E7C\u7E8C\u53D6\u5F97\u96F2\u7AEF\u75C5\u6B77\u8CC7\u6599\u2026" : runningJobElapsedMessage(startedAt, startedAt),
      hasResult: false,
      stage: "capture",
      stageStartedAt: startedAt,
      tabId: request.tabId,
      deliveryMode: request.deliveryMode ?? "manual",
      mediprismaAppUrl: request.mediprismaAppUrl,
      outpatientPeerId: request.outpatientPeerId,
      outpatientFallbackReason: request.outpatientFallbackReason,
      progressiveInterrupted: request.progressiveInterrupted,
      emergencySourceId: request.emergencySourceId,
      includeImagingViewerLinks: request.includeImagingViewerLinks,
      maskNameEnabled: request.maskNameEnabled,
      privacyOutputVersion: PRIVACY_OUTPUT_VERSION
    };
  }
  function backgroundJobStageLabel(stage) {
    if (stage === "transform") return "\u6B63\u5728\u6574\u7406\u5065\u5EB7\u7D00\u9304";
    if (stage === "protect") return "\u6B63\u5728\u58D3\u7E2E\u8207\u4FDD\u8B77";
    if (stage === "store") return "\u6B63\u5728\u5B89\u5168\u4FDD\u5B58";
    return "\u6B63\u5728\u53D6\u5F97\u96F2\u7AEF\u8CC7\u6599";
  }
  function runningJobStagePresentation(status, now = Date.now()) {
    const stage = status.stage ?? (status.moduleProgress && status.moduleProgress.total > 0 && status.moduleProgress.completed >= status.moduleProgress.total ? "transform" : "capture");
    const stageStartedAt = Number.isFinite(status.stageStartedAt) ? Number(status.stageStartedAt) : status.startedAt;
    const stageElapsedMs = Math.max(0, now - stageStartedAt);
    const seconds = Math.floor(stageElapsedMs / 1e3);
    const duration = seconds < 60 ? `${seconds} \u79D2` : seconds % 60 > 0 ? `${Math.floor(seconds / 60)} \u5206 ${seconds % 60} \u79D2` : `${Math.floor(seconds / 60)} \u5206\u9418`;
    const slowAfterMs = {
      capture: 9e4,
      transform: 3e4,
      protect: 2e4,
      store: 15e3
    };
    const slow = stageElapsedMs >= slowAfterMs[stage];
    const progress = stage === "capture" && status.moduleProgress?.total ? ` \xB7 ${Math.min(
      Math.max(0, status.moduleProgress.completed),
      status.moduleProgress.total
    )}/${status.moduleProgress.total} \u9805` : stage === "transform" && (status.mappingProgress?.attempts ?? 0) > 1 ? ` \xB7 \u6B63\u5728\u9694\u96E2\u8F49\u63DB\u554F\u984C\uFF08\u5DF2\u7D44\u88DD ${status.mappingProgress.attempts} \u6B21\uFF09` : "";
    return {
      title: backgroundJobStageLabel(stage),
      detail: `\u76EE\u524D\u968E\u6BB5 ${duration}${progress}${slow ? " \xB7 \u8655\u7406\u6642\u9593\u8F03\u9577" : ""}\u3002\u53EF\u95DC\u9589\u96F2\u6293\u5C0F\u8996\u7A97\uFF1B\u8ACB\u4FDD\u6301\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\u958B\u555F\uFF0C\u5B8C\u6210\u524D\u4E0D\u8981\u63DB\u5361\u3002`,
      slow
    };
  }
  function runningJobElapsedMessage(startedAt, now = Date.now(), moduleProgress) {
    const elapsedSeconds = Number.isFinite(startedAt) && Number.isFinite(now) ? Math.max(0, Math.floor((now - startedAt) / 1e3)) : 0;
    const progress = moduleProgress && Number.isInteger(moduleProgress.total) && moduleProgress.total > 0 && Number.isInteger(moduleProgress.completed) ? `\uFF08${Math.min(Math.max(0, moduleProgress.completed), moduleProgress.total)}/${moduleProgress.total} \u9805\uFF09` : "";
    return `\u6B63\u5728\u53D6\u5F97\u8CC7\u6599 ${elapsedSeconds} \u79D2${progress}\u3002\u53EF\u95DC\u9589\u96F2\u6293\u5C0F\u8996\u7A97\uFF1B\u8ACB\u4FDD\u6301\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\u958B\u555F\uFF0C\u5B8C\u6210\u524D\u4E0D\u8981\u63DB\u5361\u3002`;
  }
  function hasAvailableBackgroundResult(status) {
    return status.hasResult && ["complete", "downloaded", "handed-off"].includes(status.phase);
  }

  // src/background-result-storage.ts
  var RESULT_DATABASE_NAME = "cloud-wildcatch-background-results-v1";
  var RESULT_DATABASE_VERSION = 1;
  var RESULT_STORE_NAME = "results";
  var CURRENT_RESULT_KEY = "current";
  var SESSION_RESULT_PREFIX = "cloud-wildcatch:encrypted-result-fallback:";
  var STORAGE_TIMEOUT_MS = 5e3;
  var FALLBACK_MAX_BYTES = 3 * 1024 * 1024;
  var encryptionKeyForRun = (runId) => `${BACKGROUND_RESULT_ENCRYPTION_KEY}:${runId}`;
  var databasePromise = null;
  function base64ToBytes(value) {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }
  async function readEncryptionKey(runId) {
    const key = encryptionKeyForRun(runId);
    const stored = await chrome.storage.session.get(key);
    if (stored[key] !== void 0) return stored[key];
    const legacy = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
    return legacy[BACKGROUND_RESULT_ENCRYPTION_KEY];
  }
  async function decodeBackgroundPayload(payload, runId) {
    const keyRecord = await readEncryptionKey(runId);
    if (!isSessionEncryptionKey(keyRecord) || keyRecord.runId !== runId) {
      throw new Error("\u9019\u6B21\u66AB\u5B58\u8CC7\u6599\u7684\u89E3\u5BC6\u91D1\u9470\u5DF2\u5931\u6548");
    }
    const rawKey = base64ToBytes(keyRecord.rawKey);
    const rawKeyBuffer = new ArrayBuffer(rawKey.byteLength);
    new Uint8Array(rawKeyBuffer).set(rawKey);
    const encryptionKey = await crypto.subtle.importKey(
      "raw",
      rawKeyBuffer,
      { name: "AES-GCM" },
      false,
      ["decrypt"]
    );
    const compressedBuffer = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(payload.iv) },
      encryptionKey,
      payload.data
    );
    const json = await new Response(
      new Blob([compressedBuffer]).stream().pipeThrough(new DecompressionStream("gzip"))
    ).text();
    if (new TextEncoder().encode(json).byteLength !== payload.uncompressedBytes) {
      throw new Error("\u66AB\u5B58\u8CC7\u6599\u5927\u5C0F\u4E0D\u7B26");
    }
    return json;
  }
  async function decodeBackgroundBundle(result) {
    if (result.schemaVersion === 5) throw new Error("\u9019\u6B21\u53EA\u6709\u539F\u59CB\u56DE\u61C9\uFF0C\u672A\u7522\u751F FHIR \u5065\u5EB7\u7D00\u9304");
    if (result.schemaVersion === 1) return JSON.stringify(result.bundle);
    let compressedBuffer;
    if (result.schemaVersion === 2) {
      const compressed = base64ToBytes(result.data);
      compressedBuffer = new ArrayBuffer(compressed.byteLength);
      new Uint8Array(compressedBuffer).set(compressed);
    } else if (result.schemaVersion === 3) {
      compressedBuffer = result.data;
    } else {
      const keyRecord = await readEncryptionKey(result.runId);
      if (!isSessionEncryptionKey(keyRecord) || keyRecord.runId !== result.runId) {
        throw new Error("\u9019\u6B21\u5065\u5EB7\u7D00\u9304\u7684\u66AB\u5B58\u89E3\u5BC6\u91D1\u9470\u5DF2\u5931\u6548");
      }
      const rawKey = base64ToBytes(keyRecord.rawKey);
      const rawKeyBuffer = new ArrayBuffer(rawKey.byteLength);
      new Uint8Array(rawKeyBuffer).set(rawKey);
      const encryptionKey = await crypto.subtle.importKey(
        "raw",
        rawKeyBuffer,
        { name: "AES-GCM" },
        false,
        ["decrypt"]
      );
      compressedBuffer = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: new Uint8Array(result.iv) },
        encryptionKey,
        result.data
      );
    }
    const json = await new Response(
      new Blob([compressedBuffer]).stream().pipeThrough(new DecompressionStream("gzip"))
    ).text();
    const actualBytes = new TextEncoder().encode(json).byteLength;
    if (actualBytes !== result.uncompressedBytes) {
      throw new Error("\u66AB\u5B58\u5065\u5EB7\u7D00\u9304\u5927\u5C0F\u4E0D\u7B26");
    }
    if (result.schemaVersion !== 4) JSON.parse(json);
    return json;
  }
  function openResultDatabase() {
    if (databasePromise) return databasePromise;
    const opening = new Promise((resolve, reject) => {
      let settled = false;
      const fail = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(error);
      };
      const timer = setTimeout(() => fail(new Error("\u75C5\u6B77\u66AB\u5B58\u958B\u555F\u903E\u6642")), STORAGE_TIMEOUT_MS);
      let request;
      try {
        request = indexedDB.open(RESULT_DATABASE_NAME, RESULT_DATABASE_VERSION);
      } catch (error) {
        fail(error instanceof Error ? error : new Error("\u7121\u6CD5\u958B\u555F\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593"));
        return;
      }
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(RESULT_STORE_NAME)) {
          database.createObjectStore(RESULT_STORE_NAME, { keyPath: "key" });
        }
      };
      request.onsuccess = () => {
        if (settled) {
          request.result.close();
          return;
        }
        settled = true;
        clearTimeout(timer);
        const database = request.result;
        database.onversionchange = () => {
          database.close();
          databasePromise = null;
        };
        resolve(database);
      };
      request.onerror = () => fail(request.error ?? new Error("\u7121\u6CD5\u958B\u555F\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593"));
      request.onblocked = () => fail(new Error("\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593\u6B63\u5728\u66F4\u65B0\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66"));
    }).catch((error) => {
      databasePromise = null;
      throw error;
    });
    databasePromise = opening;
    return opening;
  }
  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u64CD\u4F5C\u5931\u6557"));
    });
  }
  function transactionComplete(transaction, signal) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
        if (error) reject(error);
        else resolve();
      };
      const abort = () => {
        try {
          transaction.abort();
        } catch {
        }
        finish(signal?.reason ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u903E\u6642"));
      };
      const timer = setTimeout(abort, STORAGE_TIMEOUT_MS);
      transaction.oncomplete = () => finish();
      transaction.onerror = () => finish(transaction.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u5931\u6557"));
      transaction.onabort = () => finish(transaction.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u5DF2\u4E2D\u6B62"));
      signal?.addEventListener("abort", abort, { once: true });
      if (signal?.aborted) abort();
    });
  }
  async function sessionFallback(runId) {
    if (!runId) {
      const state = await chrome.storage.session.get("cloud-wildcatch:medcloud-job-status-v1");
      runId = state["cloud-wildcatch:medcloud-job-status-v1"]?.runId;
    }
    if (!runId) return null;
    const key = SESSION_RESULT_PREFIX + runId;
    const value = (await chrome.storage.session.get(key))[key];
    if (!value || ![4, 5].includes(value.schemaVersion) || typeof value.data !== "string" || typeof value.iv !== "string") return null;
    try {
      const decode = (payload) => ({
        ...payload,
        data: base64ToBytes(payload.data).buffer,
        iv: base64ToBytes(payload.iv).buffer
      });
      const result = { ...decode(value), ...value.rawCapture ? { rawCapture: decode(value.rawCapture) } : {} };
      return isBackgroundJobResult(result) && result.runId === runId ? result : null;
    } catch {
      return null;
    }
  }
  async function readBackgroundResult(runId) {
    const fallback = await sessionFallback(runId);
    if (fallback) return fallback;
    const database = await openResultDatabase();
    const transaction = database.transaction(RESULT_STORE_NAME, "readonly");
    const [record] = await Promise.all([
      requestResult(transaction.objectStore(RESULT_STORE_NAME).get(CURRENT_RESULT_KEY)),
      transactionComplete(transaction)
    ]);
    if (!record || !isStoredResultRecord(record)) return null;
    if (runId && record.result.runId !== runId) return null;
    return record.result;
  }
  async function clearBackgroundResults(runId) {
    if (runId) {
      await chrome.storage.session.remove(encryptionKeyForRun(runId));
      await chrome.storage.session.remove(SESSION_RESULT_PREFIX + runId);
      const legacy = (await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY))[BACKGROUND_RESULT_ENCRYPTION_KEY];
      if (!isSessionEncryptionKey(legacy) || legacy.runId === runId) await chrome.storage.session.remove(BACKGROUND_RESULT_ENCRYPTION_KEY);
    } else {
      const stored = await chrome.storage.session.get(null);
      for (const key of Object.keys(stored).filter((key2) => key2 === BACKGROUND_RESULT_ENCRYPTION_KEY || key2.startsWith(BACKGROUND_RESULT_ENCRYPTION_KEY + ":") || key2.startsWith(SESSION_RESULT_PREFIX))) {
        await chrome.storage.session.remove(key);
      }
    }
    try {
      const database = await openResultDatabase();
      const transaction = database.transaction(RESULT_STORE_NAME, "readwrite");
      const completed = transactionComplete(transaction);
      const store = transaction.objectStore(RESULT_STORE_NAME);
      if (runId) {
        const lookup = store.get(CURRENT_RESULT_KEY);
        lookup.onsuccess = () => {
          const record = lookup.result;
          if (!record || !isStoredResultRecord(record) || record.result.runId === runId) store.delete(CURRENT_RESULT_KEY);
        };
      } else {
        store.clear();
      }
      await completed;
    } catch {
    }
  }
  function isStoredResultRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    if (record.key !== CURRENT_RESULT_KEY) return false;
    return isBackgroundJobResult(record.result);
  }
  function isSessionEncryptionKey(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return record.schemaVersion === 1 && typeof record.runId === "string" && typeof record.rawKey === "string" && record.rawKey.length > 0;
  }

  // ../node_modules/@voho0000/nhi-clinical-mapper/dist/index.js
  var __create2 = Object.create;
  var __defProp2 = Object.defineProperty;
  var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames2 = Object.getOwnPropertyNames;
  var __getProtoOf2 = Object.getPrototypeOf;
  var __hasOwnProp2 = Object.prototype.hasOwnProperty;
  var __commonJS2 = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export2 = (target, all) => {
    for (var name in all)
      __defProp2(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps2 = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames2(from))
        if (!__hasOwnProp2.call(to, key) && key !== except)
          __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM2 = (mod, isNodeMode, target) => (target = mod != null ? __create2(__getProtoOf2(mod)) : {}, __copyProps2(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp2(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var require_crypto = __commonJS2({
    "(disabled):crypto"() {
    }
  });
  var require_buffer = __commonJS2({
    "(disabled):buffer"() {
    }
  });
  var require_sha1 = __commonJS2({
    "node_modules/js-sha1/src/sha1.js"(exports, module) {
      (function() {
        "use strict";
        var INPUT_ERROR = "input is invalid type";
        var FINALIZE_ERROR = "finalize already called";
        var WINDOW = typeof window === "object";
        var root = WINDOW ? window : {};
        if (root.JS_SHA1_NO_WINDOW) {
          WINDOW = false;
        }
        var WEB_WORKER = !WINDOW && typeof self === "object";
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && false;
        if (NODE_JS) {
          root = global;
        } else if (WEB_WORKER) {
          root = self;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var ARRAY_BUFFER = !root.JS_SHA1_NO_ARRAY_BUFFER && typeof ArrayBuffer !== "undefined";
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var isArray = Array.isArray;
        if (root.JS_SHA1_NO_NODE_JS || !isArray) {
          isArray = function(obj) {
            return Object.prototype.toString.call(obj) === "[object Array]";
          };
        }
        var isView = ArrayBuffer.isView;
        if (ARRAY_BUFFER && (root.JS_SHA1_NO_ARRAY_BUFFER_IS_VIEW || !isView)) {
          isView = function(obj) {
            return typeof obj === "object" && obj.buffer && obj.buffer.constructor === ArrayBuffer;
          };
        }
        var formatMessage = function(message2) {
          var type = typeof message2;
          if (type === "string") {
            return [message2, true];
          }
          if (type !== "object" || message2 === null) {
            throw new Error(INPUT_ERROR);
          }
          if (ARRAY_BUFFER && message2.constructor === ArrayBuffer) {
            return [new Uint8Array(message2), false];
          }
          if (!isArray(message2) && !isView(message2)) {
            throw new Error(INPUT_ERROR);
          }
          return [message2, false];
        };
        var createOutputMethod = function(outputType) {
          return function(message2) {
            return new Sha1(true).update(message2)[outputType]();
          };
        };
        var createMethod = function() {
          var method = createOutputMethod("hex");
          if (NODE_JS) {
            method = nodeWrap(method);
          }
          method.create = function() {
            return new Sha1();
          };
          method.update = function(message2) {
            return method.create().update(message2);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createOutputMethod(type);
          }
          return method;
        };
        var nodeWrap = function(method) {
          var crypto2 = require_crypto();
          var Buffer2 = require_buffer().Buffer;
          var bufferFrom;
          if (Buffer2.from && !root.JS_SHA1_NO_BUFFER_FROM) {
            bufferFrom = Buffer2.from;
          } else {
            bufferFrom = function(message2) {
              return new Buffer2(message2);
            };
          }
          var nodeMethod = function(message2) {
            if (typeof message2 === "string") {
              return crypto2.createHash("sha1").update(message2, "utf8").digest("hex");
            } else {
              if (message2 === null || message2 === void 0) {
                throw new Error(INPUT_ERROR);
              } else if (message2.constructor === ArrayBuffer) {
                message2 = new Uint8Array(message2);
              }
            }
            if (isArray(message2) || isView(message2) || message2.constructor === Buffer2) {
              return crypto2.createHash("sha1").update(bufferFrom(message2)).digest("hex");
            } else {
              return method(message2);
            }
          };
          return nodeMethod;
        };
        var createHmacOutputMethod = function(outputType) {
          return function(key, message2) {
            return new HmacSha1(key, true).update(message2)[outputType]();
          };
        };
        var createHmacMethod = function() {
          var method = createHmacOutputMethod("hex");
          method.create = function(key) {
            return new HmacSha1(key);
          };
          method.update = function(key, message2) {
            return method.create(key).update(message2);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createHmacOutputMethod(type);
          }
          return method;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message2) {
          if (this.finalized) {
            throw new Error(FINALIZE_ERROR);
          }
          var result = formatMessage(message2);
          message2 = result[0];
          var isString = result[1];
          var code, index = 0, i, length = message2.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              this.block = blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (isString) {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message2.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >>> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >>> 2] |= (192 | code >>> 6) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >>> 2] |= (224 | code >>> 12) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message2.charCodeAt(++index) & 1023);
                  blocks2[i >>> 2] |= (240 | code >>> 18) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >>> 2] |= message2[index] << SHIFT[i++ & 3];
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >>> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >>> 28 & 15] + HEX_CHARS[h0 >>> 24 & 15] + HEX_CHARS[h0 >>> 20 & 15] + HEX_CHARS[h0 >>> 16 & 15] + HEX_CHARS[h0 >>> 12 & 15] + HEX_CHARS[h0 >>> 8 & 15] + HEX_CHARS[h0 >>> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >>> 28 & 15] + HEX_CHARS[h1 >>> 24 & 15] + HEX_CHARS[h1 >>> 20 & 15] + HEX_CHARS[h1 >>> 16 & 15] + HEX_CHARS[h1 >>> 12 & 15] + HEX_CHARS[h1 >>> 8 & 15] + HEX_CHARS[h1 >>> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >>> 28 & 15] + HEX_CHARS[h2 >>> 24 & 15] + HEX_CHARS[h2 >>> 20 & 15] + HEX_CHARS[h2 >>> 16 & 15] + HEX_CHARS[h2 >>> 12 & 15] + HEX_CHARS[h2 >>> 8 & 15] + HEX_CHARS[h2 >>> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >>> 28 & 15] + HEX_CHARS[h3 >>> 24 & 15] + HEX_CHARS[h3 >>> 20 & 15] + HEX_CHARS[h3 >>> 16 & 15] + HEX_CHARS[h3 >>> 12 & 15] + HEX_CHARS[h3 >>> 8 & 15] + HEX_CHARS[h3 >>> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >>> 28 & 15] + HEX_CHARS[h4 >>> 24 & 15] + HEX_CHARS[h4 >>> 20 & 15] + HEX_CHARS[h4 >>> 16 & 15] + HEX_CHARS[h4 >>> 12 & 15] + HEX_CHARS[h4 >>> 8 & 15] + HEX_CHARS[h4 >>> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >>> 24 & 255,
            h0 >>> 16 & 255,
            h0 >>> 8 & 255,
            h0 & 255,
            h1 >>> 24 & 255,
            h1 >>> 16 & 255,
            h1 >>> 8 & 255,
            h1 & 255,
            h2 >>> 24 & 255,
            h2 >>> 16 & 255,
            h2 >>> 8 & 255,
            h2 & 255,
            h3 >>> 24 & 255,
            h3 >>> 16 & 255,
            h3 >>> 8 & 255,
            h3 & 255,
            h4 >>> 24 & 255,
            h4 >>> 16 & 255,
            h4 >>> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        function HmacSha1(key, sharedMemory) {
          var i, result = formatMessage(key);
          key = result[0];
          if (result[1]) {
            var bytes = [], length = key.length, index = 0, code;
            for (i = 0; i < length; ++i) {
              code = key.charCodeAt(i);
              if (code < 128) {
                bytes[index++] = code;
              } else if (code < 2048) {
                bytes[index++] = 192 | code >>> 6;
                bytes[index++] = 128 | code & 63;
              } else if (code < 55296 || code >= 57344) {
                bytes[index++] = 224 | code >>> 12;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              } else {
                code = 65536 + ((code & 1023) << 10 | key.charCodeAt(++i) & 1023);
                bytes[index++] = 240 | code >>> 18;
                bytes[index++] = 128 | code >>> 12 & 63;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              }
            }
            key = bytes;
          }
          if (key.length > 64) {
            key = new Sha1(true).update(key).array();
          }
          var oKeyPad = [], iKeyPad = [];
          for (i = 0; i < 64; ++i) {
            var b = key[i] || 0;
            oKeyPad[i] = 92 ^ b;
            iKeyPad[i] = 54 ^ b;
          }
          Sha1.call(this, sharedMemory);
          this.update(iKeyPad);
          this.oKeyPad = oKeyPad;
          this.inner = true;
          this.sharedMemory = sharedMemory;
        }
        HmacSha1.prototype = new Sha1();
        HmacSha1.prototype.finalize = function() {
          Sha1.prototype.finalize.call(this);
          if (this.inner) {
            this.inner = false;
            var innerHash = this.array();
            Sha1.call(this, this.sharedMemory);
            this.update(this.oKeyPad);
            this.update(innerHash);
            Sha1.prototype.finalize.call(this);
          }
        };
        var exports2 = createMethod();
        exports2.sha1 = exports2;
        exports2.sha1.hmac = createHmacMethod();
        if (COMMON_JS) {
          module.exports = exports2;
        } else {
          root.sha1 = exports2;
          if (AMD) {
            define(function() {
              return exports2;
            });
          }
        }
      })();
    }
  });
  var import_js_sha1 = __toESM2(require_sha1(), 1);
  var TAIWAN_CITY_COUNTY = "(?:\u57FA\u9686\u5E02|\u81FA\u5317\u5E02|\u53F0\u5317\u5E02|\u65B0\u5317\u5E02|\u6843\u5712\u5E02|\u81FA\u4E2D\u5E02|\u53F0\u4E2D\u5E02|\u81FA\u5357\u5E02|\u53F0\u5357\u5E02|\u9AD8\u96C4\u5E02|\u65B0\u7AF9\u5E02|\u5609\u7FA9\u5E02|\u65B0\u7AF9\u7E23|\u82D7\u6817\u7E23|\u5F70\u5316\u7E23|\u5357\u6295\u7E23|\u96F2\u6797\u7E23|\u5609\u7FA9\u7E23|\u5C4F\u6771\u7E23|\u5B9C\u862D\u7E23|\u82B1\u84EE\u7E23|\u81FA\u6771\u7E23|\u53F0\u6771\u7E23|\u6F8E\u6E56\u7E23|\u91D1\u9580\u7E23|\u9023\u6C5F\u7E23)";
  var DETAILED_TAIWAN_ADDRESS_RE = new RegExp(
    `${TAIWAN_CITY_COUNTY}[^\\s<\uFF0C\u3002\uFF1B;\u3001,()\uFF08\uFF09]{0,90}(?:\u5927\u9053|\u8DEF|\u8857|\u5DF7|\u5F04|\u865F|\u91CC|\u6751|\u9130)[^\\s<\uFF0C\u3002\uFF1B;\u3001,()\uFF08\uFF09]{0,90}`,
    "g"
  );
  var PHONE_LABEL_PATTERN = "(?:\u806F\u7D61\u96FB\u8A71|\u9023\u7D61\u96FB\u8A71|\u884C\u52D5\u96FB\u8A71(?:\u865F\u78BC)?|\u624B\u6A5F(?:\u865F\u78BC)?|\u96FB\u8A71(?:\u865F\u78BC)?|\\b(?:phone\\s*(?:number|no\\.?|#)?|telephone\\s*(?:number|no\\.?|#)?|mobile(?:\\s+phone)?\\s*(?:number|no\\.?|#)?)(?![A-Za-z]))";
  var PHONE_VALUE_PATTERN = "[+\uFF0B]?[ \\t\\u3000]*(?:[\uFF08(][ \\t\\u3000]*)?[0-9\uFF10-\uFF19](?:[0-9\uFF10-\uFF19 \\t\\u3000().\uFF08\uFF09\uFF0E\\-\uFF0D\u2013\u2014/\uFF0F]{0,40}[0-9\uFF10-\uFF19])?(?:[ \\t\\u3000]*(?:#|\uFF03|\u5206\u6A5F|ext\\.?)[ \\t\\u3000]*[0-9\uFF10-\uFF19]{1,8})?";
  var PHONE_INLINE_LAYOUT_PATTERN = "(?:[ \\t\\u3000]|&nbsp;|&#160;|&#x0*a0;|<\\/?(?:b|strong|span|font|em|i)\\b[^>]*>)*";
  var PHONE_LABEL_SEPARATOR_PATTERN = "(?:\\s*[:\uFF1A]\\s*|[ \\t\\u3000]+)?";
  var LABELED_PHONE_VALUE_RE = new RegExp(
    `(${PHONE_LABEL_PATTERN}${PHONE_LABEL_SEPARATOR_PATTERN}${PHONE_INLINE_LAYOUT_PATTERN}(?:<\\/td>\\s*<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN})?)(${PHONE_VALUE_PATTERN})`,
    "gi"
  );
  var BARE_PHONE_CELL_VALUE_RE = new RegExp(
    `(<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN}${PHONE_LABEL_PATTERN}${PHONE_INLINE_LAYOUT_PATTERN}<\\/td>\\s*<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN})(${PHONE_VALUE_PATTERN})`,
    "gi"
  );
  var LABELED_ADDRESS_VALUE_RE = new RegExp(
    `((?:\u6236\u7C4D\u5730\u5740|\u901A\u8A0A\u5730\u5740|\u806F\u7D61\u5730\u5740|\u73FE\u4F4F\u5730\u5740|\u4F4F\u5740|\u5730\u5740)\\s*[:\uFF1A]\\s*(?:<\\/b>\\s*)?(?:<\\/td>\\s*<td[^>]*>\\s*(?:<b>\\s*<\\/b>\\s*)?)?)([^<\\n\\r]+?)(?=<|\\n|\\r|\\s*(?:[-_=]{8,}|(?:SNOMED|DX|GROSS(?:\\s+(?:D|FINDING))?|MICRO(?:SCOPIC\\s+FINDING|\\s+D)?|PATHOLOGICAL\\s+DIAGNOSIS|DIAGNOSIS|\u81E8\u5E8A\u8A3A\u65B7|\u75C5\u7406\u8A3A\u65B7|\u6253\u5B57\u54E1|\u75C5\u7406\u91AB\u5E2B|\u5C1A\u6709\u5831\u544A|\u75C5\u89E3\u5C08\u91AB\u5B57|\u5165\u9662\u79D1\u5225|\u51FA\u9662\u79D1\u5225|\u4F4F\u9662\u5929\u6578|ISS\u5206\u6578|\u91AB\u7642\u6A5F\u69CB\u540D\u7A31|\u91AB\u7642\u6A5F\u69CB\u4EE3\u78BC|${PHONE_LABEL_PATTERN})\\s*[:\uFF1A])|$)`,
    "gi"
  );
  var systems_exports = {};
  __export2(systems_exports, {
    ADULT_PREVENTIVE_EVENT_IDENTIFIER: () => ADULT_PREVENTIVE_EVENT_IDENTIFIER,
    ADULT_PREVENTIVE_RESULT: () => ADULT_PREVENTIVE_RESULT,
    ADULT_PREVENTIVE_SECTION: () => ADULT_PREVENTIVE_SECTION,
    CANCER_SCREENING_CODE: () => CANCER_SCREENING_CODE,
    CANCER_SCREENING_RESULT: () => CANCER_SCREENING_RESULT,
    DEDUP_PROVENANCE: () => DEDUP_PROVENANCE,
    ENCOUNTER_CHANNEL_SYSTEM: () => ENCOUNTER_CHANNEL_SYSTEM,
    ENCOUNTER_KIND_SYSTEM: () => ENCOUNTER_KIND_SYSTEM,
    HIS_LOCAL_ALLERGEN_CODE: () => HIS_LOCAL_ALLERGEN_CODE,
    HIS_LOCAL_CONDITION_CODE: () => HIS_LOCAL_CONDITION_CODE,
    HIS_LOCAL_LAB_CODE: () => HIS_LOCAL_LAB_CODE,
    HIS_LOCAL_MEDICATION_CODE: () => HIS_LOCAL_MEDICATION_CODE,
    HIS_LOCAL_PATIENT_MRN: () => HIS_LOCAL_PATIENT_MRN,
    HIS_LOCAL_PROCEDURE_CODE: () => HIS_LOCAL_PROCEDURE_CODE,
    HIS_LOCAL_REPORT_CODE: () => HIS_LOCAL_REPORT_CODE,
    ICD_10_CM: () => ICD_10_CM,
    ICD_10_PCS: () => ICD_10_PCS,
    LOINC: () => LOINC,
    MEDICATION_SEMANTIC_GROUP: () => MEDICATION_SEMANTIC_GROUP,
    MEDICATION_SOURCE_LOCATOR: () => MEDICATION_SOURCE_LOCATOR,
    NHI_CARE_PLAN_PROGRAM: () => NHI_CARE_PLAN_PROGRAM,
    NHI_DRUG_CODE: () => NHI_DRUG_CODE,
    NHI_MEDICAL_ORDER_CODE: () => NHI_MEDICAL_ORDER_CODE,
    NHI_SOURCE: () => NHI_SOURCE,
    NHI_SOURCE_ENDPOINT_IDENTIFIER: () => NHI_SOURCE_ENDPOINT_IDENTIFIER,
    NHI_SOURCE_ORDER_CODE: () => NHI_SOURCE_ORDER_CODE,
    OBSERVATION_VALUE: () => OBSERVATION_VALUE,
    PROCEDURE_CLASSIFICATION_SYSTEM: () => PROCEDURE_CLASSIFICATION_SYSTEM,
    PROCEDURE_EVENT: () => PROCEDURE_EVENT,
    PROCEDURE_EVENT_IDENTIFIER: () => PROCEDURE_EVENT_IDENTIFIER,
    PROCEDURE_TRANSFORM_ACTIVITY: () => PROCEDURE_TRANSFORM_ACTIVITY,
    SNOMED_CT: () => SNOMED_CT,
    TW_NATIONAL_ID: () => TW_NATIONAL_ID
  });
  var NHI_MEDICAL_ORDER_CODE = "https://twcore.mohw.gov.tw/CodeSystem/nhi-medical-order-code";
  var NHI_DRUG_CODE = "https://twcore.mohw.gov.tw/CodeSystem/nhi-drug-code";
  var TW_NATIONAL_ID = "https://twcore.mohw.gov.tw/IdentifierSystem/national-id";
  var HIS_LOCAL_LAB_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-lab";
  var HIS_LOCAL_MEDICATION_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-medication";
  var HIS_LOCAL_REPORT_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-report";
  var HIS_LOCAL_CONDITION_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-condition";
  var HIS_LOCAL_PROCEDURE_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-procedure";
  var HIS_LOCAL_ALLERGEN_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-allergen";
  var HIS_LOCAL_PATIENT_MRN = "https://nhi-fhir-bridge.local/IdentifierSystem/his-mrn";
  var MEDICATION_SOURCE_LOCATOR = "https://nhi-fhir-bridge.github.io/IdentifierSystem/medication-source-locator";
  var MEDICATION_SEMANTIC_GROUP = "https://nhi-fhir-bridge.github.io/IdentifierSystem/medication-semantic-group";
  var ENCOUNTER_KIND_SYSTEM = "https://nhi-fhir-bridge.github.io/CodeSystem/encounter-kind";
  var ENCOUNTER_CHANNEL_SYSTEM = "https://nhi-fhir-bridge.github.io/CodeSystem/encounter-channel";
  var PROCEDURE_CLASSIFICATION_SYSTEM = "https://nhi-fhir-bridge.github.io/CodeSystem/procedure-classification";
  var NHI_CARE_PLAN_PROGRAM = "https://nhi-fhir-bridge.github.io/CodeSystem/nhi-care-plan-program";
  var CANCER_SCREENING_CODE = "https://nhi-fhir-bridge.github.io/CodeSystem/cancer-screening";
  var CANCER_SCREENING_RESULT = "https://nhi-fhir-bridge.github.io/CodeSystem/cancer-screening-result";
  var ADULT_PREVENTIVE_SECTION = "https://nhi-fhir-bridge.github.io/CodeSystem/adult-preventive-section";
  var ADULT_PREVENTIVE_RESULT = "https://nhi-fhir-bridge.github.io/CodeSystem/adult-preventive-result";
  var ADULT_PREVENTIVE_EVENT_IDENTIFIER = "https://nhi-fhir-bridge.github.io/IdentifierSystem/adult-preventive-event";
  var OBSERVATION_VALUE = "https://nhi-fhir-bridge.github.io/CodeSystem/observation-value";
  var NHI_SOURCE_ORDER_CODE = "http://nhi-fhir-bridge/nhi-source-order-code";
  var NHI_SOURCE = "http://nhi-fhir-bridge/nhi-source";
  var PROCEDURE_EVENT = "http://nhi-fhir-bridge/procedure-event";
  var PROCEDURE_EVENT_IDENTIFIER = "https://nhi-fhir-bridge.github.io/IdentifierSystem/procedure-event";
  var NHI_SOURCE_ENDPOINT_IDENTIFIER = "https://nhi-fhir-bridge.github.io/IdentifierSystem/nhi-source-endpoint";
  var PROCEDURE_TRANSFORM_ACTIVITY = "https://nhi-fhir-bridge.github.io/CodeSystem/procedure-transform-activity";
  var DEDUP_PROVENANCE = "http://nhi-fhir-bridge/dedup-provenance";
  var LOINC = "http://loinc.org";
  var SNOMED_CT = "http://snomed.info/sct";
  var ICD_10_CM = "http://hl7.org/fhir/sid/icd-10-cm";
  var ICD_10_PCS = "http://www.cms.gov/Medicare/Coding/ICD10";
  var CELL_ALIASES = {
    NEUTROPHIL: {
      common: [
        "neutrophilic segment",
        "neutrophil",
        "neutrophils",
        "segmented",
        "segment",
        "segments",
        "seg",
        "seg.",
        "neut",
        "neut.",
        "neut. seg",
        "neut seg",
        "\u55DC\u4E2D\u6027\u767D\u8840\u7403",
        "\u55DC\u4E2D\u6027\u7403",
        "\u4E2D\u6027\u7403",
        "\u591A\u6838\u7403",
        "\u591A\u5F62\u6838\u7403",
        "neutrophilic segment(\u55DC\u4E2D\u6027\u767D\u8840\u7403)",
        "neutrophil(\u55DC\u4E2D\u6027\u767D\u8840\u7403)",
        "neutrophils(\u55DC\u4E2D\u6027\u767D\u8840\u7403)",
        "segment(\u55DC\u4E2D\u6027\u767D\u8840\u7403)"
      ],
      scoped: { "16003C": ["neu", "neu-pleural", "sediment-neu"] }
    },
    LYMPHOCYTE: {
      common: [
        "lymphocyte",
        "lymphocytes",
        "lymph cell",
        "lymph",
        "lymph.",
        "lym",
        "lym.",
        "\u6DCB\u5DF4\u767D\u8840\u7403",
        "\u6DCB\u5DF4\u7403",
        "\u6DCB\u5DF4\u7D30\u80DE",
        "\u6DCB\u5DF4",
        "lymphocytes(\u6DCB\u5DF4\u767D\u8840\u7403)",
        "lymphocyte(\u6DCB\u5DF4\u767D\u8840\u7403)"
      ],
      scoped: { "16008C": ["lymohocyte"] }
      // known LIS typo (missing 'p'), real 北榮 P20105
    },
    MONOCYTE: {
      common: [
        "monocyte",
        "monocytes",
        "mono",
        "mono.",
        "\u55AE\u6838\u767D\u8840\u7403",
        "\u55AE\u6838\u7403",
        "monocytes(\u55AE\u6838\u767D\u8840\u7403)",
        "monocyte(\u55AE\u6838\u767D\u8840\u7403)"
      ]
    },
    EOSINOPHIL: {
      common: [
        "eosinophil",
        "eosinophils",
        "eos",
        "eos.",
        "\u55DC\u9178\u6027\u767D\u8840\u7403",
        "\u55DC\u9178",
        "\u55DC\u4F0A\u7D05\u6027\u767D\u8840\u7403",
        "\u55DC\u4F0A\u7D05",
        "eosinophils(\u55DC\u9178\u6027\u767D\u8840\u7403)",
        "eosinophil(\u55DC\u9178\u6027\u767D\u8840\u7403)"
      ],
      scoped: { "16003C": ["eosin", "sediment-eosin"] }
    },
    BASOPHIL: {
      common: [
        "basophil",
        "basophils",
        "baso",
        "baso.",
        "\u55DC\u9E7C\u6027\u767D\u8840\u7403",
        "\u55DC\u9E7C",
        "basophils(\u55DC\u9E7C\u6027\u767D\u8840\u7403)",
        "basophil(\u55DC\u9E7C\u6027\u767D\u8840\u7403)"
      ]
    },
    // Macrophage & histiocyte — in serous-fluid differentials LOINC MERGES
    // monocytes+macrophages into one code (e.g. Pleural 35021-5), so a fluid panel
    // routes BOTH the MONOCYTE and MACROPHAGE tokens to that same code.
    MACROPHAGE: {
      common: ["macrophage", "macrophages", "\u5DE8\u566C\u7D30\u80DE", "histiocyte", "\u7D44\u7E54\u7403"],
      scoped: { "16003C": ["m&h", "sediment-m&h", "m & h"] }
    },
    // Reactive / variant / atypical lymphocyte — distinct from plain lymphocyte
    // (own LOINC, e.g. Pleural 33370-8 Variant lymphocytes/Leukocytes).
    REACTIVE_LYMPHOCYTE: {
      common: [
        "reactive lymphocyte",
        "reactive lymphocytes",
        "variant lymphocyte",
        "variant lymphocytes",
        "atypical lymphocyte",
        "atypical lymphocytes",
        // 台大癌醫 CBC differential shorthand. Separator-insensitive matching
        // also covers Aty.Lym.(STAT), Aty-Lym and Aty_Lym from this one alias.
        // Keep it on the central analyte token so Blood/Pleural contexts choose
        // their own System-specific LOINC without duplicating private regexes.
        "aty lym",
        "atyp lym",
        "atypical lympho",
        "\u53CD\u61C9\u6027\u6DCB\u5DF4\u7403",
        "\u7570\u578B\u6DCB\u5DF4\u7403",
        "\u975E\u5178\u578B\u6DCB\u5DF4\u7403"
      ],
      scoped: { "16003C": ["react lympho", "react. lympho"] }
    },
    // ── Cell counts (cross-specimen: Blood / Synovial / Pleural / … each own LOINC) ──
    LEUKOCYTE_COUNT: {
      common: ["leukocyte count", "\u767D\u8840\u7403\u8A08\u6578"],
      scoped: { "16003C": ["wbc", "wbc-pleural", "leukocyte", "leukocytes", "\u767D\u8840\u7403"] }
    },
    ERYTHROCYTE_COUNT: {
      common: ["erythrocyte count", "\u7D05\u8840\u7403\u8A08\u6578"],
      scoped: {
        "16003C": ["rbc", "rbc count", "rbc-pleural", "erythrocyte", "erythrocytes", "\u7D05\u8840\u7403"]
      }
    },
    // Total nucleated cells — serous fluids (pleural/ascites/pericardial) report
    // TNC instead of a WBC count (NHI/lab convention).
    NUCLEATED_CELL_COUNT: {
      common: [
        "nucleated cell count",
        "total nucleated cell count",
        "total nuclear cell count",
        "total nuclear cell c",
        "tnc",
        "\u6709\u6838\u7D30\u80DE\u8A08\u6578"
      ]
    },
    // ── Physical characteristics (cross-specimen: Urine / Synovial / Pleural …) ──
    COLOR: { common: ["color", "colour", "\u8272", "\u984F\u8272"] },
    APPEARANCE: { common: ["appearance", "\u5916\u89C0", "turbidity", "\u6FC1\u5EA6", "clarity"] },
    PH: { common: ["ph", "\u9178\u9E7C\u5EA6", "\u9178\u9E7C\u503C"] },
    SPECIFIC_GRAVITY: {
      common: ["specific gravity", "sp.gravity", "sp gravity", "sp.gr", "\u6BD4\u91CD"]
    }
  };
  function buildRoutes(tokenToLoinc, opts = {}) {
    const out = {};
    for (const [token, loinc] of Object.entries(tokenToLoinc)) {
      const entry = CELL_ALIASES[token];
      if (!entry) throw new Error(`buildRoutes: unknown analyte token "${token}"`);
      if (opts.validLoinc && !opts.validLoinc(loinc)) {
        throw new Error(`buildRoutes: LOINC "${loinc}" for ${token} is not in LOINC_DISPLAY`);
      }
      const variants = [...entry.common, ...opts.scope ? entry.scoped?.[opts.scope] ?? [] : []];
      for (const v of variants) {
        const key = v.toLowerCase();
        if (key in out && out[key] !== loinc) {
          throw new Error(`buildRoutes: alias "${key}" maps to both ${out[key]} and ${loinc}`);
        }
        out[key] = loinc;
      }
    }
    return out;
  }
  var CANONICAL_PAGE_TYPE_ORDER = [
    "encounters",
    "observations",
    "medications",
    "conditions",
    "allergies",
    "diagnostic_reports",
    "procedures",
    "immunizations",
    "care_plans",
    "cancer_screening",
    "document_references"
  ];
  var NHI_REPORT_CATEGORY_GROUPS = {
    // NHI report category 3: pathology reports.
    CP: ["15001C", "15017C"],
    SP: ["25003C", "25004C", "25006B", "25024C", "25025C"],
    PAT: ["25012B", "30103B", "30105B"],
    CG: ["12195B", "25007B", "25021B", "30109B", "30110B", "30111B"],
    GE: [
      "30101B",
      "30102B",
      "30104B",
      "30106B",
      "30107B",
      "30108B",
      "30301B",
      "30302B",
      "30303B",
      "30304B",
      "30305B",
      "30306B",
      "30307B"
    ],
    // v2-0074 has no dedicated endoscopy service. OTH is an active standard
    // category; the original NHI code continues to identify the report type.
    OTH: ["28002C", "28016C", "28017C", "28023C"],
    // NHI report category 2: imaging/check reports with an unambiguous
    // diagnostic-service section in HL7 v2-0074.
    EN: ["17008B", "20001C", "20019B", "20023B"],
    EC: ["18001C", "18015B", "18019C"],
    VUS: ["18008C", "18010C", "18041B", "20013C", "20026B"],
    CTH: ["18020B", "18022B", "33076B", "33077B"],
    NMS: ["26025B", "26029B", "26072B"],
    PF: ["17003C", "17004C", "17006C", "17019C"],
    CUS: ["18005C", "18006C", "18007C", "18033B"],
    CT: ["33070B", "33071B", "33072B"],
    NMR: ["33084B", "33085B"],
    OUS: ["19010C"],
    RUS: [
      "19001C",
      "19002B",
      "19003C",
      "19005C",
      "19009C",
      "19012C",
      "19014C",
      "19015C",
      "19016C",
      "19017C",
      "19018C",
      "21008C",
      "23504C"
    ],
    // Ultrasound-guided intervention remains radiology as requested; the two
    // vascular interventions are likewise issued by an imaging service.
    RAD: ["19007C", "33074B", "33075B"],
    RX: [
      "32001C",
      "32002C",
      "32006C",
      "32007C",
      "32008C",
      "32009C",
      "32010C",
      "32011C",
      "32012C",
      "32013C",
      "32014C",
      "32015C",
      "32016C",
      "32017C",
      "32018C",
      "32022C",
      "32023C",
      "33005B",
      "33012B"
    ]
  };
  var NHI_REPORT_CATEGORY_BY_CODE = Object.freeze(
    Object.fromEntries(
      Object.entries(NHI_REPORT_CATEGORY_GROUPS).flatMap(
        ([category, codes]) => codes.map((code) => [code, category])
      )
    )
  );
  var DELAYED_NHI_REPORT_CODES = new Set(
    Object.keys(NHI_REPORT_CATEGORY_BY_CODE)
  );
  var NHI_REPORT_LOINC_BY_CODE = Object.freeze({
    "18001C": { code: "11524-6", display: "EKG study" },
    "18005C": { code: "59281-6", display: "US Heart Transthoracic" },
    "18007C": { code: "80859-2", display: "US.doppler Heart" },
    // 18020B 心導管－一側 / "Cardiac cath- one side" and 18022B 冠狀動脈攝影 /
    // "Coronary angiography" (TW Core medical-service-payment CodeSystem). Both
    // are catheter-laboratory studies of the heart: 18022B is the only NHI item
    // named 冠狀動脈攝影 and it sits inside the 18020B-18043B catheterization
    // block, while catheter-free coronary CT is claimed under the generic CT
    // items 33070B-33072B, which stay unmapped. 18745-0 is
    // "Cardiac catheterization study:Find:Pt:Heart:Doc:Cardiac catheterization"
    // (active) — System, Scale and Method are all supplied by the order code, and
    // laterality (一側/二側) is not a LOINC axis. https://loinc.org/18745-0
    "18020B": { code: "18745-0", display: "Cardiac catheterization study" },
    "18022B": { code: "18745-0", display: "Cardiac catheterization study" },
    // 33076B 經皮冠狀動脈擴張術－一條血管 and 33077B －二條血管 (TW Core).
    // 76642-8 is "Percutaneous coronary intervention study:Find:Pt:Heart:Doc:
    // Cardiac catheterization" (active); its LOINC term description defines PCI
    // as coronary angioplasty performed via cardiac catheterization, which is
    // literally what the NHI item names say. It is preferred over the generic
    // 18745-0 because the order code names the intervention, and the treated
    // vessel count is not a LOINC axis. https://loinc.org/76642-8
    "33076B": { code: "76642-8", display: "Percutaneous coronary intervention study" },
    "33077B": { code: "76642-8", display: "Percutaneous coronary intervention study" },
    // 26025B 壓力與重分佈心肌斷層灌注掃描 / "Stress & redistribution myocardial
    // perfusion study with SPECT" (TW Core), whose NHI note states it contains
    // 26024B 靜態心肌斷層灌注掃描 / "Resting myocardial perfusion study with
    // SPECT". Stress, rest and the SPECT method are therefore all named by the
    // order code. 39724-0 is "Multisection perfusion^at rest+W stress+W
    // radionuclide IV:Find:Pt:Chest>Heart:Doc:NM.SPECT" (active); its generic
    // radionuclide challenge matches an order code that names no tracer.
    // https://loinc.org/39724-0
    "26025B": {
      code: "39724-0",
      display: "SPECT Heart perfusion at rest and W stress and W radionuclide IV"
    },
    // 26029B 全身骨骼掃描 / "Whole body bone scan" (TW Core). 39818-0 is
    // "Views^W radionuclide IV:Find:Pt:Whole body>Bone:Doc:NM" (active): planar
    // NM, whole body, bone — every axis is named by the order code, and the
    // radiopharmaceutical stays generic because NHI claims it separately
    // (26076B 全身骨骼掃描-Tc-99m). https://loinc.org/39818-0
    "26029B": { code: "39818-0", display: "NM Whole body Bone Views" },
    // 26072B 正子造影-全身 (TW Core; the regional study is the separate item
    // 26073B). 44139-4 is "Multisection^W radionuclide IV:Find:Pt:Whole
    // body:Doc:PT" (active): PET method and whole-body region, both named by the
    // order code, with a generic radionuclide challenge because the order code
    // names no tracer. https://loinc.org/44139-4
    "26072B": { code: "44139-4", display: "PT Whole body" },
    "32001C": { code: "30745-4", display: "XR Chest Views" },
    "32002C": { code: "30745-4", display: "XR Chest Views" }
  });
  var NHI_REPORT_CODES_WITH_EXACT_LOINC = new Set(
    Object.keys(NHI_REPORT_LOINC_BY_CODE)
  );
  var import_js_sha12 = __toESM2(require_sha1(), 1);
  var CBC_COMPONENT_KEYS = {
    // Hemoglobin — variant CJK 血色素 / 血紅蛋白 added v0.11.4 audit
    // (Taiwan medical texts use all three interchangeably).
    hemoglobin: "718-7",
    \u8840\u7D05\u7D20: "718-7",
    \u8840\u8272\u7D20: "718-7",
    \u8840\u7D05\u86CB\u767D: "718-7",
    hgb: "718-7",
    hb: "718-7",
    "hb.": "718-7",
    // Hematocrit (HCT) — Taiwan LIS shortens to "Ht" / "H.t.". The
    // ".ascii" period-separated forms (e.g. "M.C.V.") added v0.11.4 —
    // they bypass \bMCV\b matching because intra-word periods break
    // the word boundary. Key WITHOUT trailing period covers both
    // "M.C.V" and "M.C.V." inputs (trailing period creates a \b on
    // the closing letter, key's regex `\bm\.c\.v\b` matches the "M.C.V"
    // prefix of "M.C.V." just fine).
    hematocrit: "4544-3",
    \u8840\u7403\u5BB9\u7A4D\u6BD4: "4544-3",
    // v0.11.11 (SMART app dev bug 2 + 5 2026-05-29): variants observed
    // in user's v0.11.9 bundle. "血球容積比值測定" was previously
    // matching the global LOINC_MAP fallback to a panel LOINC; "血球比容值"
    // is a sibling phrasing.
    \u8840\u7403\u5BB9\u7A4D\u6BD4\u503C: "4544-3",
    \u8840\u7403\u5BB9\u7A4D\u6BD4\u503C\u6E2C\u5B9A: "4544-3",
    \u8840\u7403\u6BD4\u5BB9\u503C: "4544-3",
    \u8840\u7403\u6BD4\u5BB9\u503C\u6E2C\u5B9A: "4544-3",
    \u8840\u7403\u6BD4\u5BB9: "4544-3",
    \u8840\u6BD4\u5BB9: "4544-3",
    \u7D05\u8840\u7403\u5BB9\u7A4D: "4544-3",
    // alt phrasing — RBC volume = hematocrit
    hct: "4544-3",
    ht: "4544-3",
    "h.t.": "4544-3",
    "h.t": "4544-3",
    "%ht": "4544-3",
    // RBC — period-separated abbrev added
    \u7D05\u8840\u7403: "789-8",
    rbc: "789-8",
    "r.b.c": "789-8",
    // WBC — period-separated abbrev added
    \u767D\u8840\u7403: "6690-2",
    wbc: "6690-2",
    "w.b.c": "6690-2",
    // Platelet — include the plural "Platelets" (v1.2.9). Some 林口長庚 CBC
    // rows ship the full word "Platelets"; the both-side `\b…\b` matcher won't
    // let the singular key match the plural, so the row degraded to the
    // (stripped) CBC panel default → no LOINC → the PLT column went blank in
    // the cumulative-report pivot even though the value was in the bundle.
    // Mirrors the sing/plural pairs already in CBC_DIFF_KEYS (neutrophils …).
    platelet: "777-3",
    platelets: "777-3",
    "platelet count": "777-3",
    \u8840\u5C0F\u677F: "777-3",
    plt: "777-3",
    // MPV is a volume measurement, not a platelet count. The mapper retains
    // this LOINC only when the source unit proves fL.
    mpv: "28542-9",
    "mean platelet volume": "28542-9",
    \u5E73\u5747\u8840\u5C0F\u677F\u5BB9\u7A4D: "28542-9",
    // Reticulocyte (v1.2.9) — % form: 4679-7 "Reticulocytes/Erythrocytes in
    // Blood" (Property NFr, System Bld, methodless; WebFetch-verified
    // loinc.org 2026-07-06). Sing + plural + short "Retic" so a reticulocyte
    // row billed under a general CBC code resolves instead of falling to the
    // stripped CBC panel default. (Bare "retic" only matches standalone via
    // `\bretic\b`, so it never fires inside diuretic/natriuretic.)
    reticulocyte: "4679-7",
    reticulocytes: "4679-7",
    retic: "4679-7",
    "retic.": "4679-7",
    \u7DB2\u72C0\u7D05\u8840\u7403: "4679-7",
    \u7DB2\u7E54\u7D05\u8840\u7403: "4679-7",
    // CBC indices — period-separated abbrev forms added v0.11.4.
    // Order matters: longer "m.c.h.c" must register before "m.c.h"
    // is even considered (_findLongestMatch picks longest match
    // regardless of insertion order, so insertion order here is for
    // readability only).
    "m.c.v": "787-2",
    "m.c.h.c": "786-4",
    "m.c.h": "785-6",
    // ── v0.12.1 (SMART app dev bug 5'/6'/7' 2026-05-29): explicit
    // "EN(中文)" parenthetical variants from the 2024-01-22 hospital's
    // CBC display format. Same rationale as the CBC_DIFF_KEYS additions
    // above: guarantee longest-match wins over panel-default fallback.
    "mcv(\u5E73\u5747\u7D05\u8840\u7403\u5BB9\u7A4D)": "787-2",
    "mch(\u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20)": "785-6",
    "mchc(\u5E73\u5747\u7D05\u8840\u7403\u6FC3\u5EA6)": "786-4",
    "mchc(\u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20\u6FC3\u5EA6)": "786-4",
    "rdw(\u7D05\u8840\u7403\u5206\u5E03\u5BEC\u5EA6)": "788-0",
    "rdw(\u5E73\u5747\u7D05\u8840\u7403\u5BEC\u5EA6)": "788-0",
    // observed variant in user's bundle
    "rdw(\u7D05\u8840\u7403\u5206\u4F48\u5BEC\u5EA6)": "788-0",
    "wbc(\u767D\u8840\u7403\u8A08\u6578)": "6690-2",
    "rbc(\u7D05\u8840\u7403\u8A08\u6578)": "789-8",
    "hb(\u8840\u7D05\u7D20)": "718-7",
    "hb(\u8840\u8272\u7D20)": "718-7",
    "hgb(\u8840\u7D05\u7D20)": "718-7",
    "hgb(\u8840\u8272\u7D20)": "718-7",
    "hct(\u8840\u7403\u5BB9\u7A4D\u6BD4)": "4544-3",
    "ht(\u8840\u7403\u5BB9\u7A4D\u6BD4)": "4544-3",
    "platelet(\u8840\u5C0F\u677F)": "777-3",
    "platelets(\u8840\u5C0F\u677F)": "777-3",
    "plt(\u8840\u5C0F\u677F)": "777-3",
    // ── v0.11.11 (SMART app dev bug 5 2026-05-29): variants observed
    // in user's v0.11.9 bundle that previously fell through to global
    // LOINC_MAP "紅血球" → 789-8 (RBC count) — 5 distinct CBC indices
    // all wrongly tagged as RBC count (48 records).
    //
    // 紅血球分**佈**變異數 (LIS variant of 紅血球分**布**寬度) → RDW.
    //   LOINC 788-0 already verified v0.11.4.
    // 紅血球**平均**容積 (word order variant of **平均**紅血球容積) → MCV.
    //   LOINC 787-2 already verified.
    // 紅血球色素 → MCH (mean corpuscular hemoglobin).
    //   LOINC 785-6 already verified.
    // 紅血球色素濃度 → MCHC. LOINC 786-4 already verified.
    // Add 變異 + 體積 cross variants for robustness against future LIS
    // quirks; longest-match semantics keep RBC ("紅血球") from winning
    // over the longer compound keys.
    \u7D05\u8840\u7403\u5206\u4F48\u8B8A\u7570\u6578: "788-0",
    \u7D05\u8840\u7403\u5206\u5E03\u8B8A\u7570\u6578: "788-0",
    // 布 variant
    \u7D05\u8840\u7403\u5206\u5E03\u8B8A\u7570: "788-0",
    \u7D05\u8840\u7403\u5206\u4F48\u8B8A\u7570: "788-0",
    \u7D05\u8840\u7403\u9AD4\u7A4D\u5206\u4F48: "788-0",
    \u7D05\u8840\u7403\u9AD4\u7A4D\u5206\u5E03: "788-0",
    \u7D05\u8840\u7403\u5E73\u5747\u5BB9\u7A4D: "787-2",
    \u7D05\u8840\u7403\u5E73\u5747\u9AD4\u7A4D: "787-2",
    \u7D05\u8840\u7403\u8272\u7D20\u6FC3\u5EA6: "786-4",
    // MCHC (must precede 紅血球色素 for longest-match clarity)
    \u7D05\u8840\u7403\u8272\u7D20: "785-6",
    // MCH
    \u7D05\u8840\u7403\u5E73\u5747\u8840\u8272\u7D20\u6FC3\u5EA6: "786-4",
    \u7D05\u8840\u7403\u5E73\u5747\u8840\u8272\u7D20: "785-6"
  };
  var CBC_DIFF_KEYS = {
    // Cell differential (neut/lym/mono/eos/baso, incl. Taiwan CJK synonyms, bare
    // abbreviations, and "EN(中文)" parenthetical forms). Variants live ONCE in
    // CELL_ALIASES (analyte-aliases.ts); buildRoutes reproduces the prior hand-
    // written blood table byte-for-byte (pinned by loinc-alias-matrix.test.ts +
    // the registry-equivalence test). Same tokens route to Synovial-fluid LOINCs
    // under 16008C via buildRoutes there — no more per-specimen re-listing/drift.
    ...buildRoutes({
      NEUTROPHIL: "770-8",
      // Neutrophils/100 leukocytes
      LYMPHOCYTE: "736-9",
      // Lymphocytes/100 leukocytes
      // Method is absent from the NHI row, so use the method-unspecified blood
      // term rather than guessing manual-only 735-1. LOINC explicitly treats
      // variant, atypical and reactive lymphocytes as the same component.
      // Verified: https://loinc.org/13046-8 and https://loinc.org/735-1
      REACTIVE_LYMPHOCYTE: "13046-8",
      MONOCYTE: "5905-5",
      // Monocytes/100 leukocytes
      EOSINOPHIL: "713-8",
      // Eosinophils/100 leukocytes
      BASOPHIL: "706-2"
      // Basophils/100 leukocytes
    }),
    // ANC is an absolute count. The mapper retains this LOINC only when the
    // source unit proves count per volume, never for a percentage row.
    anc: "26499-4",
    "absolute neutrophil count": "26499-4",
    \u55DC\u4E2D\u6027\u7403\u7D55\u5C0D\u503C: "26499-4",
    \u4E2D\u6027\u7403\u7D55\u5C0D\u503C: "26499-4",
    // Nucleated erythrocytes are reported per 100 leukocytes and are NOT the
    // ordinary RBC count. These longer aliases must live in the CBC-scoped table
    // so they win before the shorter CBC_COMPONENT_KEYS "rbc" / "紅血球"
    // aliases. Do not infer Normobl. here: that LIS abbreviation has no explicit
    // ratio/unit evidence in the captured rows and deliberately remains code-only.
    "nucleated rbc": "19048-8",
    "nucleated erythrocyte": "19048-8",
    "nucleated erythrocytes": "19048-8",
    nrbc: "19048-8",
    "n.r.b.c": "19048-8",
    \u6709\u6838\u7D05\u8840\u7403: "19048-8",
    \u6709\u6838\u7D05\u7D30\u80DE: "19048-8",
    // ── Maturation-stage neutrophils (v0.11.11) ────────────────────
    // SMART app dev bug 2 + 6 2026-05-29: Metamyelocyte ("後骨髓球") and
    // Band ("帶狀嗜中性白血球") rows were falling to the panel LOINC
    // 57021-8 (CBC W Diff panel) or 770-8 (Segment neutrophils). Both
    // are immature neutrophil maturation stages distinct from total /
    // segmented neutrophils; each has its own LOINC verified at
    // loinc.org 2026-05-29:
    //   740-1  Metamyelocytes/Leukocytes in Blood by Manual count (NFr)
    //   764-1  Band form neutrophils/Leukocytes in Blood by Manual count (NFr)
    // Adding to CBC_DIFF_KEYS so they're available under every CBC
    // sibling code (08002C/08003C/08004C/08006C/08011C/08013C).
    metamyelocyte: "740-1",
    metamyelocytes: "740-1",
    "meta-myelocyte": "740-1",
    "meta myelocyte": "740-1",
    meta: "740-1",
    // abbrev "Meta" / "Meta(STAT)" — `\bmeta\b` never matches the
    // full "metamyelocyte" (no word boundary), so this only catches the standalone
    // abbreviation; the "(STAT)" suffix is collapsed to a separate token.
    \u5F8C\u9AA8\u9AD3\u7403: "740-1",
    band: "764-1",
    bands: "764-1",
    "band form": "764-1",
    "band cell": "764-1",
    \u5E36\u72C0\u55DC\u4E2D\u6027\u767D\u8840\u7403: "764-1",
    \u5E36\u72C0: "764-1",
    \u687F\u72C0\u6838: "764-1",
    // alt name 桿狀核細胞
    // ── Earlier maturation stages (v1.3.3, H12113 audit 2026-07-08) ──────
    // 中國北港醫's manual diff (08013C) reports the full left-shift series as
    // abbreviations (Myelo. / Promyl. / Blast) that matched no key → panel-default
    // → suppressed → no-LOINC. Each is a distinct blood maturation stage with its
    // own NFr%/Manual LOINC, WebFetch-verified loinc.org 2026-07-08:
    //   749-2  Myelocytes/Leukocytes in Blood by Manual count (NFr)
    //   783-1  Promyelocytes/Leukocytes in Blood by Manual count (NFr)
    //   709-6  Blasts/Leukocytes in Blood by Manual count (NFr)
    // Abbrev keys are separator-collapse safe (Myelo.(STAT) → "myelo stat"); the
    // `\bmyelo\b` guard never matches "metamyelocyte"/"myelocyte" (no word
    // boundary), so it only catches the standalone abbreviation. 骨髓球 (myelocyte)
    // added too, but longest-match keeps 後骨髓球 → 740-1 (4 chars > 3).
    // NOT mapped from the bare aliases below because their Property comes from
    // the source unit. resolveQualifiedCbcRareCellLoinc() maps PlasmaCell % to
    // method-neutral 13047-6 and absolute counts to 30458-4; Normobl. maps to
    // 33990-3 only with a proven leukocyte denominator. Placeholder units and
    // PS workflow narrative remain code-only.
    myelocyte: "749-2",
    myelocytes: "749-2",
    myelo: "749-2",
    "myelo.": "749-2",
    \u9AA8\u9AD3\u7403: "749-2",
    promyelocyte: "783-1",
    promyelocytes: "783-1",
    promyel: "783-1",
    "promyel.": "783-1",
    promyl: "783-1",
    // 北港醫 abbreviates "Promyl." (no e)
    "promyl.": "783-1",
    \u524D\u9AA8\u9AD3\u7403: "783-1",
    blast: "709-6",
    blasts: "709-6",
    \u82BD\u7D30\u80DE: "709-6",
    \u6BCD\u7D30\u80DE: "709-6"
  };
  var URINE_BIOCHEM_KEYS = {
    // Microalbumin variants (specimen + analyte)
    "micro-albumin": "14957-5",
    // Microalbumin Mass/vol Urine
    microalbumin: "14957-5",
    microalb: "14957-5",
    // 長庚嘉義 "MicroALB(U)"; (U) is folded as a separator
    "micro albumin": "14957-5",
    "u-malb": "14957-5",
    "malb(u)": "14957-5",
    "malb.": "14957-5",
    malb: "14957-5",
    \u5FAE\u5C0F\u767D\u86CB\u767D: "14957-5",
    \u5FAE\u767D\u86CB\u767D: "14957-5",
    // 官方 12111C 中文名（免疫比濁法版是「微白蛋白（免疫比濁法）」）
    \u5FAE\u91CF\u767D\u86CB\u767D: "14957-5",
    // 通用寫法（"尿微量白蛋白" 亦含此子字串）
    \u5C3F\u5FAE\u91CF\u767D\u86CB\u767D: "14957-5",
    \u5C3F\u767D\u86CB\u767D: "14957-5",
    // UACR (Microalbumin/Creatinine ratio Urine)
    uacr: "14959-1",
    "u-acr": "14959-1",
    acr: "14959-1",
    // bare "ACR" (P10109 audit 2026-07-08) — safe: URINE_BIOCHEM_KEYS
    // is consulted ONLY under 09016C/12111C (urine-creatinine codes), so "acr" can't
    // hijack a non-urine row.
    "alb/cre": "14959-1",
    "albumin/creatinine": "14959-1",
    // Urine creatinine variants
    "urine creatinine": "2161-8",
    "creatinine urine": "2161-8",
    "creatinine(u)": "2161-8",
    "u-cre": "2161-8",
    "u-crea": "2161-8",
    \u5C3F\u6DB2\u808C\u9178\u9150: "2161-8",
    \u5C3F\u808C\u9178\u9150: "2161-8",
    creatinine: "2161-8",
    // bare — within 09016C/12111C scope, default to urine
    crea: "2161-8",
    \u808C\u9178\u9150: "2161-8"
  };
  var STOOL_ROUTINE_ANALYTE_KEYS = {
    color: "9397-1",
    // Color of Stool (Nom)
    colour: "9397-1",
    \u984F\u8272: "9397-1",
    form: "11029-6",
    // Consistency of Stool (Nom); real value "Formed"
    consistency: "11029-6",
    \u786C\u5EA6: "11029-6",
    \u6027\u72C0: "11029-6",
    appearance: "29636-8",
    // Appearance of Stool (Nom)
    \u5916\u89C0: "29636-8",
    mucus: "42524-9",
    // Mucus [Presence] in Stool by Light microscopy
    mucous: "42524-9",
    \u7C98\u6DB2: "42524-9",
    \u9ECF\u6DB2: "42524-9",
    "o.b.(chem)": "2335-8",
    // real LIS spelling; punctuation is separator-folded
    "ob chem": "2335-8",
    "occult blood": "2335-8",
    \u6F5B\u8840: "2335-8",
    "ova(dir)": "10704-5",
    // Ova and parasites identified in Stool by LM
    "ova direct": "10704-5",
    ova: "10704-5",
    parasite: "10704-5",
    \u87F2\u5375: "10704-5",
    \u5BC4\u751F\u87F2: "10704-5",
    pus: "13655-6",
    // pus cells = stool leukocytes; real result is Ord Negative
    wbc: "13655-6",
    leukocyte: "13655-6",
    leukocytes: "13655-6",
    \u767D\u8840\u7403: "13655-6",
    rbc: "33668-5",
    erythrocyte: "33668-5",
    erythrocytes: "33668-5",
    \u7D05\u8840\u7403: "33668-5"
  };
  var URINALYSIS_ANALYTE_KEYS = {
    // Order matters: longer/more-specific keys before generic ones
    // (matches _LOINC_MAP iteration semantics — first hit wins).
    "specific gravity": "5811-5",
    // Specific gravity Urine
    "sp.gravity": "5811-5",
    "sp gravity": "5811-5",
    \u6BD4\u91CD: "5811-5",
    "micro-albumin": "14957-5",
    // Microalbumin Mass/vol Urine
    microalbumin: "14957-5",
    "malb(u)": "14957-5",
    malb: "14957-5",
    \u5FAE\u5C0F\u767D\u86CB\u767D: "14957-5",
    // v0.12.1 (caught during v0.11.7 test re-run after LOINC_SHORT_TEXT
    // for 20454-5 was added — both 微白蛋白 displays were silently
    // routing to bare "蛋白" → 20454-5 (urine protein) instead of
    // their correct microalbumin/UACR LOINCs). Longer specific keys
    // ensure correct routing via _findLongestMatch.
    \u5FAE\u767D\u86CB\u767D: "14957-5",
    "\u5FAE\u767D\u86CB\u767D(\u5C3F)": "14957-5",
    "\u5FAE\u767D\u86CB\u767D(\u5C3F)(\u534A\u5B9A\u91CF)": "14957-5",
    "\u5FAE\u767D\u86CB\u767D(\u5C3F\u6DB2)": "14957-5",
    \u5C3F\u5FAE\u91CF\u767D\u86CB\u767D: "14957-5",
    \u5C3F\u767D\u86CB\u767D: "14957-5",
    "u-malb": "14957-5",
    uacr: "14959-1",
    // Microalbumin/Creatinine ratio Urine
    "\u5FAE\u767D\u86CB\u767D/\u808C\u9150\u9178\u6BD4\u503C": "14959-1",
    "\u5FAE\u767D\u86CB\u767D/\u808C\u9150\u9178\u6BD4\u503C(\u534A\u5B9A\u91CF)": "14959-1",
    \u808C\u9150\u9178\u6BD4\u503C: "14959-1",
    \u808C\u9178\u9150\u6BD4\u503C: "14959-1",
    "alb/cre": "14959-1",
    "albumin/creatinine": "14959-1",
    "u-acr": "14959-1",
    "urine glucose": "5792-7",
    sugar: "5792-7",
    // NHI '尿糖' / 'Sugar' under 06013C
    \u5C3F\u7CD6: "5792-7",
    \u7CD6: "5792-7",
    // panel-scoped bare Chinese alias (real 06012C row)
    urobilinogen: "5818-0",
    // Urobilinogen Urine Ql
    \u5C3F\u81BD\u7D20\u539F: "5818-0",
    \u5C3F\u81BD\u5143: "5818-0",
    // Taiwan LIS shorthand; unit fix may select 19161-9
    bilirubin: "5770-3",
    // Bilirubin Urine Ql
    \u5C3F\u81BD\u7D05\u7D20: "5770-3",
    // v0.13.1 (LOINC-based dedup migration audit 2026-05-30): bare
    // "膽紅素" was missing — only the 尿- prefixed form was registered.
    // PANEL_LOINC_MAP is code-scoped to 06013C urinalysis context, so
    // adding the bare term here doesn't cross-pollute serum 膽紅素 (which
    // routes via 09029C → NHI_TO_LOINC = 1975-2).
    // WebFetch loinc.org/5770-3 verified 2026-06-02: Long Common Name
    // "Bilirubin.total [Presence] in Urine by Test strip" — Component
    // Bilirubin / Property PrThr / System Urine / Scale Ord / Method
    // Test strip → correct urine-dipstick context for 06013C. ✅
    \u81BD\u7D05\u7D20: "5770-3",
    nitrite: "5802-4",
    // Nitrite Urine
    \u4E9E\u785D\u9178: "5802-4",
    ketones: "5797-6",
    // Ketones Urine
    ketone: "5797-6",
    \u916E\u9AD4: "5797-6",
    protein: "20454-5",
    // Protein Mass/vol Urine
    \u5C3F\u86CB\u767D: "20454-5",
    \u86CB\u767D: "20454-5",
    leukocyte: "5799-2",
    // Leukocytes Urine
    leu: "5799-2",
    \u767D\u8840\u7403\u916F\u9176: "5799-2",
    // v0.11.11 (SMART app dev bug 7 2026-05-29): variant character 脢
    // (not 酶) observed under 06013C in user's v0.11.9 bundle. Without
    // this entry path-B missed and fell to global LOINC_MAP "白血球" →
    // 6690-2 (blood WBC count) — wrong specimen + wrong analyte (4
    // records affected).
    \u767D\u8840\u7403\u916F\u8122: "5799-2",
    \u767D\u8840\u7403\u8102\u9176: "5799-2",
    // also seen — 脂 vs 酯
    \u767D\u8840\u7403\u8102\u8122: "5799-2",
    \u767D\u8840\u7403\u916F\u985E: "5799-2",
    // observed in some HIS as descriptive name
    "\u767D\u8840\u7403\u916F\uE002": "5799-2",
    // hospital private-use glyph for the final 脂/酶 character
    blood: "5794-3",
    // Hemoglobin Urine Ql
    \u6F5B\u8840: "5794-3",
    \u8272: "5778-6",
    // Color of Urine (CJK substring)
    color: "5778-6",
    turbidity: "5767-9",
    // Appearance of Urine
    appearance: "5767-9",
    clarity: "5767-9",
    \u5916\u89C0: "5767-9",
    // v0.13.1 (app dev urinalysis A/B audit 2026-06-02): NHI B-channel
    // ships "濁度" where A-channel ships "Turbidity". Without this key
    // 濁度 fell to path-C panel default 24356-8 (Urinalysis complete
    // panel) → diverged from Turbidity's 5767-9 → looked like a dup pair
    // AND carried the wrong LOINC. WebFetch loinc.org/5767-9 verified
    // 2026-06-02: Long Common Name "Appearance of Urine" — System Urine,
    // Property Aper, Scale Nom. Taiwan urinalysis 濁度/Turbidity is the
    // standard urine appearance/clarity test. ✅
    \u6FC1\u5EA6: "5767-9",
    ph: "5803-2",
    // pH of Urine (urine-specific, NOT
    // the arterial 11558-4 that the
    // global map points to)
    \u9178\u9E7C\u5EA6: "5803-2",
    // v0.13.1 (same audit): B-channel "酸鹼值" vs A-channel "pH". Note
    // 酸鹼值 (值) ≠ 酸鹼度 (度) — only the latter was registered, so 酸鹼值
    // fell to panel default 24356-8. Code-scoped to 06013C so no clash
    // with 09041B ABG's "酸鹼值" → 11558-4 (arterial pH). WebFetch
    // loinc.org/5803-2 verified 2026-06-02: "pH of Urine by Test strip"
    // — Component pH, System Urine. ✅
    \u9178\u9E7C\u503C: "5803-2",
    glucose: "5792-7",
    // Last in this block so 'urine
    // ── v0.11.4 audit — Taiwan dipstick abbrev variants ──
    // Without these the abbreviated displays ("Bili" / "KET" / "OB" /
    // "NIT" / "UBG" / "URO" / "SG" / "Colour" / "WBC esterase") fell
    // to path-C and got LOINC 24356-8 (Urinalysis panel). Some also
    // shadowed by global LOINC_MAP keys (e.g. "WBC esterase" matched
    // global "wbc" → 6690-2 BLOOD WBC, wrong specimen).
    "u-bili": "5770-3",
    bili: "5770-3",
    ket: "5797-6",
    ob: "5794-3",
    "ob.": "5794-3",
    "occult blood": "5794-3",
    nit: "5802-4",
    ubg: "5818-0",
    uro: "5818-0",
    sg: "5811-5",
    "s.g": "5811-5",
    colour: "5778-6",
    // UK spelling
    "wbc esterase": "5799-2",
    // blocks global "wbc" → 6690-2 shadow
    // v0.12.2 (SMART app dev v0.12.1 audit 2026-05-29): hospital
    // 長庚嘉義 ships urine creatinine rows under NHI 06013C (尿生化
    // panel) — NOT under 09015C as the v0.12.1 fix targeted. Without
    // explicit urine variants here, "肌酸酐(尿液)(半定量)" routed via
    // LOINC_MAP global "肌酸酐" → 2160-0 serum LOINC under 06013C
    // billing (4 rows affected in user's v0.12.1 bundle). Mirror the
    // same urine creatinine variants from PANEL_LOINC_MAP["09015C"]
    // — longest-match guarantees urine LOINC 2161-8 wins over generic.
    "\u808C\u9178\u9150(\u5C3F\u6DB2)(\u534A\u5B9A\u91CF)": "2161-8",
    "\u808C\u9178\u9150(\u5C3F\u6DB2)": "2161-8",
    "\u808C\u9178\u9150(\u5C3F)": "2161-8",
    "\u808C\u9178\u9150(u)": "2161-8",
    // ASCII keys ending in ")" fail \b regex boundary at end of match
    // (same \b-non-word-char-no-boundary issue documented in v0.11.13
    // APTT ratio fix). Use opening-paren-only form so \b at end fires
    // on the word char preceding ")" — "creatinine(u" matches inside
    // "creatinine(u)" with \b after "u".
    "creatinine(u": "2161-8",
    "creatinine(urine": "2161-8",
    // v0.13.1 (app dev urinalysis A/B audit 2026-06-02): A-channel ships
    // the abbreviation "CREA(U)(半定量)" — "creatinine(u" did NOT match
    // (no "creatinine" substring in "crea(u)"), so it fell to global
    // LOINC_MAP "crea" → 2160-0 SERUM creatinine while the B-channel
    // "肌酸酐(尿液)" correctly got urine 2161-8. Add the abbreviated
    // opening-paren form. Same verified LOINC 2161-8 "Creatinine
    // [Mass/volume] in Urine" — WebFetch loinc.org/2161-8 confirmed
    // 2026-06-02 (System Urine). ✅
    "crea(u": "2161-8",
    "crea(urine": "2161-8",
    "u-creatinine": "2161-8",
    "urine creatinine": "2161-8",
    "creatinine, urine": "2161-8",
    // ── Sediment microscopy sub-analytes (v0.18.2, 2026-06-09) ──
    // 06012C 尿液一般檢查 also ships URINE SEDIMENT MICROSCOPY items the
    // dipstick-only 06013C bundles never carried. Each LOINC WebFetch-
    // verified at loinc.org 2026-06-09 (rule #5):
    //   5787-7  Epithelial cells [#/area] Urine sed Microscopy HPF (Qn)
    //   5821-4  Leukocytes [#/area] Urine sed Microscopy HPF (Qn)
    //   5808-1  Erythrocytes [#/volume] Urine sed Microscopy HPF (Qn)
    //   25145-4 Bacteria [Presence] Urine sed Light microscopy (Ord)
    //   5783-6  Unidentified crystals [Presence] Urine sed (Ord)
    // Count-form keys (白血球計數/紅血球計數) outrank the dipstick
    // leukocyte-esterase key (白血球酯脢→5799-2) by longest-match.
    //
    // v1.0.11 (2026-06-29, real P10109 06012C bundle): some HIS ship the
    // sediment items as BARE ENGLISH "WBC" / "RBC" / "Epith Cell" (value e.g.
    // "0-2" /HPF). The earlier "deliberately NO bare wbc/rbc" stance backfired:
    // with no panel key they fell through to the BLOOD CBC LOINCs in the global
    // map (6690-2 / 789-8) — the very wrong-specimen it tried to avoid (and
    // after the v1.0.10 blood-LOINC veto they degraded to uncoded). Adding them
    // HERE (Path B1, resolves BEFORE the global map) is what actually prevents
    // the blood fall-through. Shadow-safety: the dipstick keys are DISTINCT
    // strings (leukocyte / leu / 白血球酯酶 / "wbc esterase" / blood / 潛血 / ob)
    // and "wbc esterase" (11) beats bare "wbc" (3) via longest-match — so the
    // dipstick esterase / occult-blood rows still route correctly; only a row
    // whose display IS bare "WBC"/"RBC" (the microscopy count) lands on the
    // sediment LOINC. Re-verified 5821-4 / 5808-1 / 5787-7 on loinc.org
    // 2026-06-29 (all Qn, Urine sed, Microscopy.light.HPF). CI: bundle-quality
    // "CI v1.0.11 — urine sediment 英文 WBC/RBC/Epith".
    \u4E0A\u76AE\u7D30\u80DE: "5787-7",
    "epi cell": "5787-7",
    "epith cell": "5787-7",
    // "Epith Cell" — the trailing "th" breaks epi/epithelial
    "ep.cell": "5787-7",
    // real urine-sediment abbreviation
    epith: "5787-7",
    epithelial: "5787-7",
    \u767D\u8840\u7403\u8A08\u6578: "5821-4",
    \u7D05\u8840\u7403\u8A08\u6578: "5808-1",
    wbc: "5821-4",
    // bare English sediment WBC count (esterase = "wbc esterase"/leukocyte/leu, longer/distinct → still wins)
    rbc: "5808-1",
    // bare English sediment RBC count (occult blood = blood/潛血/ob, distinct → unaffected)
    \u7D30\u83CC: "25145-4",
    bacteria: "25145-4",
    \u7D50\u6676: "5783-6",
    crystal: "5783-6",
    crystals: "5783-6",
    crystal1: "5783-6",
    // hospital compact suffix without a separator
    "crystal 1": "5783-6",
    cast: "24124-0",
    // generic qualitative Cast / Cast(1)
    // 尿膽素元 — real-world 元/原 spelling variant of urobilinogen (the
    // dipstick key above is 尿膽素原). English "Urobilinogen" already routes
    // it; cover the CJK-only 元 form too.
    \u5C3F\u81BD\u7D20\u5143: "5818-0",
    \u81BD\u7D20\u5143: "5818-0",
    // 黏液/Mucus → 8247-9 (2026-06-13, SMART app dev report + WebFetch).
    // CORRECTION: the prior comment claimed "no clean generic urine-mucus
    // LOINC" and left 黏液 unmapped → it fell to the Step-C panel default
    // 24356-8, which is the "Urinalysis complete PANEL" code, NOT a mucus
    // analyte. The app dev correctly flagged that as a panel-on-analyte
    // mis-tag. loinc.org/8247-9 (rule #5, WebFetch-verified): Component
    // "Mucus", Property "PrThr", System "Urine sed", Scale "Ord", Method
    // "Microscopy.light" — a single-observation urine-sediment mucus code
    // matching the qualitative (Negative/Present) result NHI ships. ✅
    \u9ECF\u6DB2: "8247-9",
    mucus: "8247-9"
  };
  var URINE_SEDIMENT_MEMBER_LOINCS = /* @__PURE__ */ new Set([
    "5787-7",
    // epithelial cells
    "5821-4",
    // leukocytes
    "5808-1",
    // erythrocytes
    "25145-4",
    // bacteria
    "5783-6",
    // crystals
    "24124-0",
    // casts
    "8247-9"
    // mucus
  ]);
  var URINE_SEDIMENT_ANALYTE_KEYS = Object.fromEntries(
    Object.entries(URINALYSIS_ANALYTE_KEYS).filter(
      ([, loinc]) => URINE_SEDIMENT_MEMBER_LOINCS.has(loinc)
    )
  );
  var PANEL_LOINC_MAP = {
    // ── Urinalysis: 06012C + 06013C share ONE analyte table ──────
    // v0.18.2 (2026-06-09): both urinalysis panel codes route display-first
    // through URINALYSIS_ANALYTE_KEYS. 06012C was previously NOT registered
    // as a panel and short-circuited (NHI_TO_LOINC Step A) to 5778-6 "Color
    // of Urine", collapsing all 18 sub-analytes. See rule #10.
    "06009C": URINE_SEDIMENT_ANALYTE_KEYS,
    "06012C": URINALYSIS_ANALYTE_KEYS,
    "06013C": URINALYSIS_ANALYTE_KEYS,
    // 09040C (全蛋白) is specimen-agnostic, so it must never receive a
    // code-wide urine default. This exact LIS spelling carries positive urine
    // evidence in the suffix: 長庚「T-Protein(U)」. Separator folding makes the
    // single key cover T-Protein(U), T Protein (U), and fullwidth punctuation;
    // the trailing U is required, so a bare/serum T-Protein cannot be poached.
    "09040C": {
      "t-protein(u": "2888-6",
      "t protein urine": "2888-6"
    },
    // 13007C is a broad microbiology billing container, not a single culture.
    // Keep only the legacy aerobic aliases here. The evidence-qualified resolver
    // handles explicit anaerobic/fungal/urine/organism rows before this table and
    // leaves composite susceptibility/microscopy rows local-code-only.
    "13007C": {
      "aerobic culture": "634-6",
      \u55DC\u6C27\u57F9\u990A: "634-6"
    },
    // ── ABG panel (09041B) ───────────────────────────────
    // 09041B has DISPLAY_FIRST_CODES but no PANEL_LOINC_MAP entry until
    // v0.11.4 — relied on global LOINC_MAP for routing, which works for
    // the canonical abbreviations (pH/pCO2/pO2/HCO3/TCO2/SaO2) but
    // missed period-separated forms (P.CO2 / T.CO2 / p.H.) + Chinese
    // descriptive names (酸鹼值 / 二氧化碳分壓 / 氧分壓 / 血氧飽和度).
    // Panel-scoped table now covers Taiwan LIS variants. Global entries
    // kept for backward compat (Mode A bundles older than v0.11.4 may
    // still rely on global path).
    // 2026-07-06 (v1.2.10 — REVERTED the 2026-07-03 arterial mapping):
    // 09041B 的健保目錄名稱實際是「血液氣體分析」(Blood gas analysis) — 實際 NHI
    // 資料帶的 order_name 亦為「血液氣體分析」，**未指定動脈或靜脈**。先前 2026-07-03
    // 誤以為是「動脈血液氣體分析」而改用動脈專屬 LOINC，屬 over-claim（實測案例：
    // SAT 值 37.3%、參考範圍 70-75% 明顯是靜脈血氧區間 → 動脈 LOINC 與靜脈範圍
    // 自相矛盾）。忠實搬運：來源沒說動/靜脈，就用**泛用「in Blood」LOINC**，檢體標
    // 泛用「Blood」(見 SPECIMEN_SPECIFIC_CODE["09041B"])，交給臨床判讀。**不由參考
    // 範圍反推靜脈**(間接、脆弱、非每筆都有範圍 → 也是猜)。全部 loinc.org 查證
    // 2026-07-06：
    //   pH   2744-1(Arterial) → 11558-4「pH of Blood」
    //   pCO2 2019-8(Arterial) → 11557-6「Carbon dioxide [PPres] in Blood」
    //   pO2  2703-7(Arterial) → 11556-8「Oxygen [PPres] in Blood」
    //   HCO3 1960-4(Arterial) → 1959-6「Bicarbonate [Moles/vol] in Blood」
    //   SaO2 2708-6(Arterial) → 20564-1「Oxygen saturation in Blood」(method-less;
    //        不用 2713-6「Calculated from pO2」— NHI 未給 assay 方向，選 calculated
    //        會捏造來源沒有的方法)
    // 這些也正是全域 LOINC_MAP 的泛用值 → 面板與全域一致。
    // SBE temporarily uses ordinary base excess only to remain identifiable; the
    // final mapper drops that borrowed code unless venous evidence selects
    // 19237-7. SBC uses its true vessel-neutral plasma term 69964-5 and promotes
    // to 19232-8 with venous evidence. ABE/HCO3 retain their generic Blood terms.
    "09041B": {
      // pH → generic 11558-4
      ph: "11558-4",
      "p.h.": "11558-4",
      "p.h": "11558-4",
      \u9178\u9E7C\u503C: "11558-4",
      // pCO2 / pO2 → generic in Blood
      pco2: "11557-6",
      "pco 2": "11557-6",
      // observed LIS spacing variant
      "p.co2": "11557-6",
      \u4E8C\u6C27\u5316\u78B3\u5206\u58D3: "11557-6",
      po2: "11556-8",
      "po 2": "11556-8",
      // observed LIS spacing variant
      \u6C27\u5206\u58D3: "11556-8",
      // HCO3 → generic 1959-6 (distinct from total CO2)
      hco3: "1959-6",
      chco3: "1959-6",
      // calculated bicarbonate shorthand
      "hco3-": "1959-6",
      bicarbonate: "1959-6",
      sbc: "69964-5",
      // Standard bicarbonate in plasma; not ordinary HCO3
      chco3st: "69964-5",
      \u78B3\u9178\u6C2B\u6839: "1959-6",
      \u91CD\u78B3\u9178: "1959-6",
      // 09041B is a whole-blood gas order. Use the specimen-correct generic
      // Blood total-CO2 term; a proven venous group is promoted to 2027-1.
      // Keep global codeless `tco2` on 2028-9 because without the NHI context it
      // may genuinely be the serum/plasma chemistry analyte.
      tco2: "20565-8",
      "t.co2": "20565-8",
      "total co2": "20565-8",
      "total carbon dioxide": "20565-8",
      // SaO2 → generic 20564-1「Oxygen saturation in Blood」(method-less; measured
      // or pulse-ox, NOT the calculated 2713-6). NHI ships bare "SAT" / "O2SAT".
      sao2: "20564-1",
      so2: "20564-1",
      // SO2 / SO2% LIS shorthand
      sat: "20564-1",
      o2sat: "20564-1",
      saturat: "20564-1",
      "o2 saturation": "20564-1",
      "o2 sat": "20564-1",
      saturation: "20564-1",
      \u8840\u6C27\u98FD\u548C\u5EA6: "20564-1",
      cto2: "57800-5",
      // Oxygen content in Blood by calculation (mL/dL)
      // 11555-0 is the true generic-Blood term for actual base excess (ABE).
      // SBE aliases temporarily share it only inside lookup; the final mapper
      // removes that candidate unless venous evidence selects 19237-7.
      "base excess": "11555-0",
      abe: "11555-0",
      be: "11555-0",
      beecf: "60840-6",
      // Base excess in extracellular fluid by calculation
      "a/a o2": "78354-8",
      // Arterial-alveolar oxygen partial-pressure ratio
      // Hospital/LIS-qualified labels observed in a real 09041B blood-gas panel.
      // The NHI order proves generic Blood but not a vessel; use only the active
      // vessel-neutral Blood terms (LOINC 2.82, verified 2026-07-16).
      "be \u9E7C\u8D85\u91CF": "11555-0",
      "k(gas)\u9240": "6298-4",
      "na(gas)\u9209": "2947-0",
      temp: "8310-5",
      // patient temperature recorded with blood-gas analysis
      temperature: "8310-5",
      \u6EAB\u5EA6: "8310-5"
    },
    // ── CBC basic panel (08011C) ─────────────────────────
    // NHI 08011C bills the basic CBC items (RBC + indices, HGB, HCT,
    // PLT, WBC). Without per-item LOINCs under the panel, MCV / MCHC /
    // RDW were being shadowed:
    //   • MCV "平均紅血球容積" → matched global "紅血球" → 789-8 (RBC) ✗
    //   • MCHC "MCHC" → no key matched → fell back to panel 58410-2 ✗
    //   • RDW → no key matched → fell back to panel 58410-2 ✗
    //   • Basophil / Lymphocyte / Monocyte → fell to "白血球" → 6690-2 ✗
    // Panel-scoped table runs BEFORE the global one so the longer,
    // specific CJK / ASCII keys win. All LOINCs verified at loinc.org
    // (Long Common Name documented inline). Bug report 2026-05-27.
    "08011C": {
      // RBC indices — longer CJK keys first so they beat the bare
      // "紅血球" key in the global LOINC_MAP path. (longest-key-wins
      // semantics in _findLongestMatch make insertion order irrelevant
      // within this dict but readability still benefits.)
      \u5E73\u5747\u7D05\u8840\u7403\u5BB9\u7A4D: "787-2",
      // MCV — Erythrocyte mean corpuscular volume
      \u5E73\u5747\u7D05\u8840\u7403\u9AD4\u7A4D: "787-2",
      mcv: "787-2",
      \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20\u6FC3\u5EA6: "786-4",
      // MCHC — Erythrocytes mean corpuscular HGB concentration
      mchc: "786-4",
      \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20: "785-6",
      // MCH — Erythrocyte mean corpuscular hemoglobin
      mch: "785-6",
      \u7D05\u8840\u7403\u5206\u5E03\u5BEC\u5EA6: "788-0",
      // RDW — Erythrocyte distribution width
      \u7D05\u8840\u7403\u9AD4\u7A4D\u5206\u4F48\u5BEC\u5EA6: "788-0",
      rdw: "788-0",
      // CBC basic counts — shared with the single-analyte billing codes
      // (08002C / 08003C / 08004C / 08006C) below; see
      // CBC_COMPONENT_KEYS const below for the source of truth.
      ...CBC_COMPONENT_KEYS,
      // v0.12.2 (SMART app dev v0.12.1 audit 2026-05-29): hospital
      // 中國北港醫 ships CBC differential rows under BOTH 08013C (CBC W
      // diff billing) AND 08011C (CBC-8項 umbrella billing) for the
      // same draw. v0.11.11 spread CBC_DIFF_KEYS into 08013C but NOT
      // into 08011C — so the 08011C-billed diff rows still fell back
      // to panel-default 6690-2 (WBC count) for all diff cells. Mirror
      // the spread so per-analyte LOINCs (706-2 Basophils / 713-8
      // Eosinophils / 736-9 Lymphocytes / 770-8 Neutrophils / 5905-5
      // Monocytes / 740-1 Metamyelocyte / 764-1 Band) win regardless
      // of which CBC NHI code the hospital bills under.
      ...CBC_DIFF_KEYS
    },
    // ── CBC sibling billing codes (v0.9.10 Part 5 + Part 6) ──
    // Single-analyte billing codes promoted to display-first so when a
    // hospital LIS swaps display vs code (e.g. row billed 08004C HCT
    // but display text reads "HGB"), the unambiguous display wins. Each
    // sibling spreads BOTH CBC_COMPONENT_KEYS (basic counts) AND
    // CBC_DIFF_KEYS (differential percentages) — hospitals bill the
    // diff rows under whatever CBC code their LIS uses (中國北港醫
    // observed billing diff under 08002C WBC count; bug report Part 6
    // bug N3). Fallback path C still hits NHI_TO_LOINC entry for empty/
    // unrecognised displays.
    "08002C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // WBC count billing
    "08003C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // Hemoglobin billing
    "08004C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // Hematocrit billing
    "08006C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // Platelet count billing
    // ── Urine creatinine sibling codes (v0.9.10 Part 6 N2) ──
    // See URINE_BIOCHEM_KEYS const docstring. When hospital bills UACR
    // workup under 09016C / 12111C, the actual analyte (microalbumin
    // vs creatinine vs UACR ratio) is distinguished only by display.
    "09016C": URINE_BIOCHEM_KEYS,
    "12111C": URINE_BIOCHEM_KEYS,
    // 糞便一般檢查 — true multi-member panel, no invented parent LOINC.
    "07009C": STOOL_ROUTINE_ANALYTE_KEYS,
    // ── Bone-marrow morphology/differential (08128B) ───────────────
    // 08128B is a real multi-row panel, not one Observation. Member LOINCs are
    // taken from the active 47286-0 bone-marrow differential panel. Keeping the
    // aliases panel-scoped prevents bone-marrow cells from inheriting the blood
    // differential LOINCs with the same display names.
    "08128B": {
      myeloblast: "11113-8",
      myeloblasts: "11113-8",
      \u539F\u59CB\u9AA8\u9AD3\u7403: "11113-8",
      myelocyte: "11114-6",
      myelocytes: "11114-6",
      \u9AA8\u9AD3\u7403: "11114-6",
      metamyelocyte: "11111-2",
      metamyelocytes: "11111-2",
      \u5F8C\u9AA8\u9AD3\u7403: "11111-2",
      promyelocyte: "11120-3",
      promyelocytes: "11120-3",
      \u524D\u9AA8\u9AD3\u7403: "11120-3",
      blast: "11150-0",
      blasts: "11150-0",
      \u82BD\u7D30\u80DE: "11150-0",
      lymphocyte: "11108-8",
      lymphocytes: "11108-8",
      \u6DCB\u5DF4\u7403: "11108-8",
      \u6DCB\u5DF4\u7D30\u80DE: "11108-8",
      "plasma cell": "11118-7",
      "plasma cells": "11118-7",
      \u6F3F\u7D30\u80DE: "11118-7",
      basophil: "11105-4",
      basophils: "11105-4",
      \u55DC\u9E7C\u6027\u7403: "11105-4",
      eosinophil: "11152-6",
      eosinophils: "11152-6",
      \u55DC\u9178\u6027\u7403: "11152-6",
      monocyte: "11112-0",
      monocytes: "11112-0",
      \u55AE\u6838\u7403: "11112-0",
      neutrophil: "11115-3",
      neutrophils: "11115-3",
      \u55DC\u4E2D\u6027\u7403: "11115-3",
      "band neutrophil": "11103-9",
      "band form": "11103-9",
      \u5E36\u72C0\u55DC\u4E2D\u6027\u7403: "11103-9",
      "segmented neutrophil": "11128-6",
      "segmented neutrophils": "11128-6",
      \u5206\u8449\u55DC\u4E2D\u6027\u7403: "11128-6",
      megakaryocyte: "11110-4",
      megakaryocytes: "11110-4",
      \u5DE8\u6838\u7D30\u80DE: "11110-4",
      "erythroid cell": "40689-2",
      "erythroid cells": "40689-2",
      \u7D05\u8840\u7403\u7CFB\u7D30\u80DE: "40689-2",
      "m:e ratio": "11138-5",
      "m/e ratio": "11138-5",
      "myeloid erythroid ratio": "11138-5",
      \u7C92\u7D05\u6BD4: "11138-5"
    },
    // ── Iron/TIBC workup (09035C) ──────────────────────────────────
    // Taiwan hospitals can emit Fe, TIBC, UIBC and transferrin saturation as
    // sibling rows under 09035C. Unknown rows fall back to the 50190-8 panel and
    // are suppressed on Observation by isPanelDefaultFallback().
    "09035C": {
      "transferrin saturation": "2502-3",
      "iron saturation": "2502-3",
      "fe saturation": "2502-3",
      "sat fe": "2502-3",
      \u9435\u98FD\u548C\u5EA6: "2502-3",
      \u8F49\u9435\u86CB\u767D\u98FD\u548C\u5EA6: "2502-3",
      uibc: "2501-5",
      "unsaturated iron binding capacity": "2501-5",
      \u672A\u98FD\u548C\u9435\u7D50\u5408\u80FD: "2501-5",
      tibc: "2500-7",
      "total iron binding capacity": "2500-7",
      "iron binding capacity": "2500-7",
      \u7E3D\u9435\u7D50\u5408\u80FD: "2500-7",
      \u7E3D\u9435\u7D50\u5408\u529B: "2500-7",
      \u7E3D\u9435\u7D50\u5408\u80FD\u529B: "2500-7",
      \u7E3D\u9435\u7D50\u5408\u5BB9\u91CF: "2500-7",
      "serum iron": "2498-4",
      iron: "2498-4",
      fe: "2498-4",
      \u8840\u6E05\u9435: "2498-4"
    },
    // ── BNP / NT-proBNP shared billing code (12193C) ──────────────
    // The NHI code alone cannot distinguish the two analytes. Route only when
    // the row label is explicit; mojibake seen in hospital exports can replace
    // the final peptide character, so the highly specific N端前B型 prefix is the
    // safe Chinese discriminator for NT-proBNP.
    "12193C": {
      "nt-probnp": "33762-6",
      "pro-bnp": "33762-6",
      probnp: "33762-6",
      "pro bnp": "33762-6",
      n\u7AEF\u524Db\u578B: "33762-6",
      bnp: "30934-4"
    },
    // NHI 12020C names a generic M. pneumoniae antibody test. Hospitals may
    // expose IgM specifically; only that explicit qualitative immunoassay row is
    // safe to map to 5257-1. A bare/generic antibody row remains uncoded.
    "12020C": {
      "mycoplasma pneumoniae igm": "5257-1",
      "mycoplasma igm": "5257-1",
      \u80BA\u708E\u9EF4\u6F3F\u83CCigm: "5257-1",
      \u80BA\u708E\u9709\u6F3F\u83CCigm: "5257-1"
    },
    // 14004B is shared by serum and CSF at Taiwan hospitals. These aliases name
    // the serum/plasma quantitative immunoassay; an explicit CSF marker triggers
    // the specimen veto in observation.ts and therefore never emits 5124-3.
    "14004B": {
      "cmv igg": "5124-3",
      "cytomegalovirus igg": "5124-3",
      \u5DE8\u7D30\u80DE\u75C5\u6BD2igg: "5124-3",
      \u5DE8\u5927\u7D30\u80DE\u75C5\u6BD2igg: "5124-3"
    },
    // 12184C is organism-generic. Only an explicit CMV-DNA quantitative row is
    // mapped; 72493-0 is the IU/mL serum/plasma viral-load term used by the
    // reviewed hospital exports.
    "12184C": {
      "cmv dna": "72493-0",
      "cytomegalovirus dna": "72493-0",
      \u5DE8\u7D30\u80DE\u75C5\u6BD2dna: "72493-0",
      \u5DE8\u5927\u7D30\u80DE\u75C5\u6BD2dna: "72493-0"
    },
    // Combined rapid-flu kits often emit both A and B result rows under either
    // billing code. The order code remains the path-C fallback, while explicit
    // sub-row labels must select the matching virus type.
    "14065C": {
      "influenza a": "31859-2",
      "inf a": "31859-2",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2a\u578B: "31859-2",
      \u6D41\u884C\u6027\u611F\u5192a\u578B: "31859-2",
      "influenza b": "31864-2",
      "inf b": "31864-2",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2b\u578B: "31864-2",
      \u6D41\u884C\u6027\u611F\u5192b\u578B: "31864-2"
    },
    "14066C": {
      "influenza a": "31859-2",
      "inf a": "31859-2",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2a\u578B: "31859-2",
      \u6D41\u884C\u6027\u611F\u5192a\u578B: "31859-2",
      "influenza b": "31864-2",
      "inf b": "31864-2",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2b\u578B: "31864-2",
      \u6D41\u884C\u6027\u611F\u5192b\u578B: "31864-2"
    },
    // ── Serum protein electrophoresis (09065B; v0.10.0) ─────
    // SPE reports 5 fractions (Albumin / α1 / α2 / β / γ globulins) plus
    // A/G ratio. Each fraction has its own LOINC verified at loinc.org.
    // Previously all 6 sub-rows collapsed to 90991-1 (SPE panel LOINC) —
    // SMART app pivot-by-LOINC merged everything into one column.
    "09065B": {
      // Specific fractions — long names first (longest-match wins)
      "alpha-1 globulin": "2865-4",
      "alpha 1 globulin": "2865-4",
      "\u03B11-globulin": "2865-4",
      \u03B11: "2865-4",
      "alpha-2 globulin": "2868-8",
      "alpha 2 globulin": "2868-8",
      "\u03B12-globulin": "2868-8",
      \u03B12: "2868-8",
      "beta globulin": "2871-2",
      "\u03B2-globulin": "2871-2",
      \u03B2: "2871-2",
      "gamma globulin": "2874-6",
      "\u03B3-globulin": "2874-6",
      \u03B3: "2874-6",
      "a/g ratio": "1759-0",
      // Albumin/Globulin ratio
      "a/g": "1759-0",
      "alb/glb": "1759-0",
      // v0.11.11 (SMART app dev bug 3a 2026-05-29): Total Protein (T.P)
      // row was inheriting the SPE panel LOINC 90991-1. T.P is the total
      // serum protein measurement, distinct LOINC.
      // 2885-2 verified at loinc.org 2026-05-29:
      //   Component=Protein, Property=MCnc, System=Ser/Plas (Class=CHEM)
      "total protein": "2885-2",
      "t.p": "2885-2",
      "t. p": "2885-2",
      "t p": "2885-2",
      tp: "2885-2",
      \u7E3D\u86CB\u767D: "2885-2",
      \u8840\u6E05\u7E3D\u86CB\u767D: "2885-2",
      \u7E3D\u86CB\u767D\u8CEA: "2885-2",
      // 2026-07-03 audit: 2865-7 was an INVALID LOINC (check-digit fail; loinc.org
      // confirms "2865-7 does not exist" — 2865-4 is alpha-1 globulin). Correct
      // SPE-albumin code is 2862-1 (WebFetch loinc.org: Albumin, MCnc, Ser/Plas,
      // Electrophoresis), fitting the fraction series 2862/2865/2868/2871/2874.
      albumin: "2862-1",
      // Albumin in SPE context (was invalid 2865-7)
      \u767D\u86CB\u767D: "2862-1",
      alb: "2862-1"
    },
    // ── Flow cytometry CD markers (12204B; v0.10.0) ─────────
    // Lymphocyte surface markers — each CD subtype has its own LOINC.
    // Previously all CD3/CD4/CD8/CD19/CD56/ratio rows collapsed to
    // 20584-9 (Lymphocyte subset panel). Critical for HIV monitoring
    // (CD4 absolute count is the actionable indicator).
    "12204B": {
      // v0.11.4 audit fix: trailing "+" in keys breaks \b regex boundary
      // (+ is non-word, end-of-string after non-word has no \b). Keys
      // dropped trailing + so "CD3+/CD4+" display still matches via the
      // "cd3+/cd4" prefix substring. Keys with leading + and bare CD#
      // also need careful ordering — _findLongestMatch picks longest
      // match, so combined ratio keys must outrank bare cd3/cd4/cd8 by
      // length to avoid CD3 winning over the CD3+/CD4+ ratio entry.
      "cd3+/cd4": "8123-2",
      // CD3+CD4+ (T4 helper) cells/cells
      "cd3+/cd8": "8101-8",
      // CD3+CD8+ (T8 suppressor) cells/cells (was deprecated/wrong 8128-1)
      "cd4/cd8 ratio": "54218-3",
      "cd4/cd8": "54218-3",
      "cd8/cd4": "54218-3",
      "cd16+cd56": "8112-5",
      "cd16/cd56": "8112-5",
      // Percentage defaults; flowMarkerUnitFix() promotes cells/µL rows to the
      // absolute-count twins. Bare CD16/CD56 are deliberately absent: CD16 alone
      // and CD56 alone do not prove the CD3-CD16+CD56+ NK-cell phenotype.
      cd3: "8124-0",
      // CD3 cells/cells in Blood (%)
      cd4: "8123-2",
      // CD3+CD4+ cells/cells in Blood (%)
      cd8: "8101-8",
      // CD3+CD8+ cells/cells in Blood (%)
      cd19: "8117-4"
      // CD19 cells/cells in Blood (%)
    },
    // ── DLCO (17009B; v0.10.0) ──────────────────────────────
    // Carbon monoxide diffusing capacity test — reports DLCO + alveolar
    // volume (VA) + DLCO/VA ratio as 3 sub-rows. LOINCs verified at
    // loinc.org. Pulmonary function rarely surfaces in 健康存摺 but the
    // panel exists for completeness.
    "17009B": {
      // 2026-06-13 LOINC audit: all three sub-rows were WRONG and scrambled —
      // DLCO→24341-0 (an arterial-blood-gas PANEL), KCO→19911-7 (plain DLCO),
      // VA→19850-7 (inspiratory capacity). Corrected (WebFetch loinc.org, rule
      // #5): DLCO=19911-7, DLCO/VA(KCO)=19914-1. VA (肺泡容積) has no clean
      // single-analyte LOINC found → left UNMAPPED per rule #7 (NHI-code-only
      // beats a wrong code), longest-match keys ordered so the ratio wins.
      "dlco/va": "19914-1",
      // DLCO/VA = transfer coefficient (KCO)
      "dlco/alveolar volume": "19914-1",
      kco: "19914-1",
      dlco: "19911-7",
      // Diffusion capacity.carbon monoxide
      "dlco sb": "19911-7",
      // single-breath DLCO
      \u4E00\u6C27\u5316\u78B3\u80BA\u7030\u6563\u91CF: "19911-7"
    },
    // ── Serum creatinine + eGFR piggyback (09015C) ──────
    // NHI bills creatinine under 09015C; Taiwan labs auto-calculate eGFR
    // (CKD-EPI / MDRD) and append it as a separate sub-row using the
    // SAME 09015C billing code, distinguished only by display text.
    // Without this panel-scoped table, every 09015C row inherited LOINC
    // 2160-0 (serum creatinine) and SMART apps routed eGFR values into
    // the creatinine column — patient-safety issue (eGFR=33 displayed as
    // CREA=33 mg/dL is instantly mistaken for acute kidney failure).
    //
    // eGFR formula routing is handled once by resolveEgfrFormulaLoinc(), because
    // it needs row text AND the original unit. Explicit MDRD / CKD-EPI / CKD-EPI
    // 2021 labels get their formula-specific terms; an unlabeled eGFR with
    // positive /1.73 m2 evidence gets neutral 69405-9; otherwise it is emitted
    // NHI/HIS-local-code-only. Do not duplicate eGFR aliases in this table — a
    // table-only route cannot enforce the unit evidence gate.
    //
    // 77147-7 (MDRD, Ser/Plas/Bld) replaces the older 33914-3 (MDRD,
    // Ser/Plas) which LOINC marks DISCOURAGED and maps forward to 77147-7.
    // WebFetch-verified loinc.org 2026-07-07 (both Active-status checked).
    // The explicit creatinine entries are duplicated from the global
    // LOINC_MAP so the panel is self-contained.
    "09015C": {
      creatinine: "2160-0",
      crea: "2160-0",
      // Some hospitals ship serum creatinine as "CRE" / "CRE(STAT)" (no
      // trailing 'a'), so the longer "crea" key never substring-matches
      // "cre(stat)" and the row fell through with NO LOINC (H fixture: 30×
      // 09015C | CRE(STAT) | mg/dL | Blood unmapped). Panel-scoped bare
      // "cre" is safe: longest-match still routes true "creatinine"/"crea"
      // rows first, and every 09015C row is creatinine/eGFR so there is no
      // collateral (eGFR displays carry no "cre" token). Also covers "cre.".
      cre: "2160-0",
      \u808C\u9178\u9150: "2160-0",
      \u808C\u9150\u9178: "2160-0",
      \u8840\u4E2D\u808C\u9178\u9150: "2160-0",
      // 北港 B-channel uses the simplified synonym "肌酐(血液)" while
      // the mirrored A-channel row says Creatinine. Keep this alias exact and
      // blood-qualified so it cannot shadow a future urine-qualified row.
      "\u808C\u9150(\u8840\u6DB2)": "2160-0",
      // v0.12.1 (SMART app dev bug 10 2026-05-29): some hospitals bill
      // urine creatinine under serum-billing code 09015C with the
      // display annotating "(尿液)". Without explicit urine variants
      // here, longest-match returns the bare "肌酸酐" key → 2160-0
      // serum LOINC even though the row is urine. Longer urine-
      // annotated keys win. 2161-8 = "Creatinine [Mass/volume] in
      // Urine" (verified at loinc.org/2161-8/ earlier).
      "\u808C\u9178\u9150(\u5C3F\u6DB2)(\u534A\u5B9A\u91CF)": "2161-8",
      "\u808C\u9178\u9150(\u5C3F\u6DB2)": "2161-8",
      "\u808C\u9178\u9150(\u5C3F)": "2161-8",
      "\u808C\u9178\u9150(u)": "2161-8",
      // ASCII keys ending in ")" fail \b regex boundary at end of match
      // (same \b-non-word-char-no-boundary issue documented in v0.11.13
      // APTT ratio fix). Use opening-paren-only form so \b at end fires
      // on the word char preceding ")" — "creatinine(u" matches inside
      // "creatinine(u)" with \b after "u".
      "creatinine(u": "2161-8",
      "creatinine(urine": "2161-8",
      // v0.13.1 (app dev urinalysis A/B audit 2026-06-02): A-channel ships
      // the abbreviation "CREA(U)(半定量)" — "creatinine(u" did NOT match
      // (no "creatinine" substring in "crea(u)"), so it fell to global
      // LOINC_MAP "crea" → 2160-0 SERUM creatinine while the B-channel
      // "肌酸酐(尿液)" correctly got urine 2161-8. Add the abbreviated
      // opening-paren form. Same verified LOINC 2161-8 "Creatinine
      // [Mass/volume] in Urine" — WebFetch loinc.org/2161-8 confirmed
      // 2026-06-02 (System Urine). ✅
      "crea(u": "2161-8",
      "crea(urine": "2161-8",
      "u-creatinine": "2161-8",
      "urine creatinine": "2161-8",
      "creatinine, urine": "2161-8"
    },
    // ── PT/INR panel (08026C) ────────────────────────────
    // Taiwan labs bill PT (seconds) and INR (ratio) under the SAME 08026C
    // code, distinguished only by display string. Without this panel
    // table both rows mapped to LOINC 6301-6 (INR); a warfarin trend
    // view would plot a PT=12 sec point as INR=12 (instant overdose
    // alarm) or merge PT and INR into one series. Each LOINC verified
    // at loinc.org:
    //   5902-2  Prothrombin time (PT) in Platelet poor plasma by
    //           Coagulation assay
    //   6301-6  INR in Platelet poor plasma by Coagulation assay
    //   5894-1  Prothrombin time (PT) Control in Platelet poor plasma
    //           by Coagulation assay
    // Order is longest-key-wins inside _findLongestMatch so insertion
    // order doesn't matter, but readability benefits from
    // longest-specific first.
    "08026C": {
      "international normalized ratio": "6301-6",
      // Exact Chinese INR label paired with A-channel "INR" in the real
      // fixtures. 6301-6 is the active INR in platelet-poor plasma term.
      \u570B\u969B\u6A19\u6E96\u5316\u6BD4\u503C: "6301-6",
      // v0.11.9 (SMART app dev report 2026-05-29 + loinc.org audit):
      // 5894-1's canonical name is "Prothrombin time (PT) actual/Normal"
      // — Component=Prothrombin time actual/Normal, Property=RelTime
      // (a RATIO, not a control reading). Earlier v0.9.10 mapping of
      // "PT control" / "對照" / "對照組" / "prothrombin time control"
      // → 5894-1 was based on the misread that 5894-1 was a "control"
      // LOINC. It is NOT — these displays describe lab QC control plasma
      // readings, which have no clinical LOINC fit and are already
      // candidates for the QC filter (looksLikeQcControl). Removing the
      // wrong LOINC mapping so any "Control PT" rows that slip past the
      // QC filter fall back to NHI-coding-only, rather than being
      // mis-labelled as a PT-ratio analyte.
      "prothrombin time": "5902-2",
      // Common LIS misspelling observed in transferred NHI data.
      "prothrombine time": "5902-2",
      "pt (sec)": "5902-2",
      "pt sec": "5902-2",
      "pt-sec": "5902-2",
      \u51DD\u8840\u9176\u539F\u6642\u9593: "5902-2",
      // 脢 (U+8122) is a glyph variant of 酶 (U+9176) that 長庚嘉義 LIS ships
      // on the B (定期上傳) channel: assaY_ITEM_NAME="凝血脢原時間" while the A
      // channel ships "P.T". Without this alias the B row missed 5902-2, fell
      // to the panel default (stripped → no LOINC), and so carried a DIFFERENT
      // cross-channel dedup key than the A row → the A+B PT pair never collapsed
      // and TWO PT (11.9 sec) survived (user report 2026-06-16, 5/18 急診).
      \u51DD\u8840\u8122\u539F\u6642\u9593: "5902-2",
      \u51DD\u8840\u6642\u9593: "5902-2",
      // Bug report 2026-05-27 v0.11.1: 長庚嘉義 LIS prints "P.T" (dot-
      // separated initials). `_keywordMatches` uses \b...\b regex on
      // ASCII keys, and the period in "p.t" breaks the implicit word
      // boundary that "pt" relied on — so `pt` key never matched and
      // path-C fallback returned NHI_TO_LOINC = 6301-6 (INR) for a
      // 11.9 sec PT measurement. Patient-safety-adjacent: SMART app
      // would plot 11.9 in the INR column (looks like fatal INR=11.9
      // → emergency reversal). Adding period-separated variants.
      "p.t": "5902-2",
      "p . t": "5902-2",
      "p t": "5902-2",
      inr: "6301-6",
      pt: "5902-2"
    },
    // ── APTT panel (08036C) ──────────────────────────────
    // Taiwan labs bill TWO sub-rows under 08036C:
    //   1. "APTT" / "活化部份凝血活酶時間" — value in seconds (~25-35 sec
    //      normal). LOINC 14979-9 (aPTT in PPP, Property=Time).
    //   2. "Heparin治療範圍參考倍數" / "APTT data/mean" / "APTT actual/normal"
    //      — ratio (patient APTT / lab normal mean), value ~1.0 ± dimensionless.
    //      LOINC 63561-5 (aPTT actual/normal in PPP, Property=RelTime).
    // Before v0.11.9 BOTH rows mapped to 14979-9 — a ratio value of 1.08
    // displayed under APTT-time column would read as fatally low APTT
    // (normal lower bound ~25 sec), or render seconds units on a unitless
    // ratio. SMART app dev report 2026-05-29.
    //
    // LOINC verified at loinc.org (2026-05-29):
    //   14979-9 Component=aPTT, Property=Time, System=PPP (seconds)
    //   63561-5 Component=aPTT actual/normal, Property=RelTime, System=PPP (ratio)
    //
    // Longest-key-wins via _findLongestMatch — so the longer ratio
    // synonyms get priority over the bare "APTT" → time fallback when
    // a row's display contains both substrings.
    "08036C": {
      // Ratio variants — Taiwan LIS shows "Heparin治療範圍參考倍數"
      // (Heparin therapeutic range reference multiplier) when reporting
      // the APTT ratio for heparin monitoring. Also "APTT data/mean"
      // (denominator-explicit form) and "actual/normal" verbiage.
      heparin\u6CBB\u7642\u7BC4\u570D\u53C3\u8003\u500D\u6578: "63561-5",
      heparin\u6CBB\u7642\u7BC4\u570D: "63561-5",
      \u6CBB\u7642\u7BC4\u570D\u53C3\u8003\u500D\u6578: "63561-5",
      \u53C3\u8003\u500D\u6578: "63561-5",
      "aptt data/mean": "63561-5",
      "aptt actual/normal": "63561-5",
      "aptt ratio": "63561-5",
      "aptt mean": "63561-5",
      // v0.11.13: parenthesised variant ("APTT (ratio)" with space + paren)
      // observed in v0.11.10 lockdown test. \b-bounded "aptt (ratio)" key
      // doesn't match at the trailing ")" (non-word char has no \b before
      // end of string). Workaround: add bare "ratio" key — \b around the
      // ASCII word "ratio" matches even inside parens, longest-match wins
      // over bare "aptt" (5 chars > 4). Combined with "{ratio}" unit
      // pre-canonicalisation, this routes the ratio analyte cleanly.
      ratio: "63561-5",
      "aptt-ratio": "63561-5",
      // Bare time variants — fall through to seconds LOINC.
      aptt: "14979-9",
      "a.p.t.t": "14979-9",
      \u6D3B\u5316\u90E8\u4EFD\u51DD\u8840\u6D3B\u9176\u6642\u9593: "14979-9",
      \u90E8\u4EFD\u51DD\u8840\u6D3B\u9176\u6642\u9593: "14979-9",
      \u51DD\u8840\u6D3B\u9176\u6642\u9593: "14979-9"
    },
    // ── Synovial / body-fluid panel (16008C) ─────────────
    // 16008C bills the full body-fluid analysis: appearance / color /
    // WBC count / differential. Each sub-item has its own specimen-
    // aware LOINC. Panel-scoped table runs before the global one so
    // shorter generic keys (e.g. global "wbc" → 6690-2 blood WBC)
    // can't shadow the body-fluid specific LOINCs. Each LOINC verified
    // at loinc.org:
    // 2026-07-12 — 16008C is SYNOVIAL-fluid-specific (NHI 項目名「關節液常規檢查分析
    // / Synovial Fluid Routine」, 檢體=關節液; web-confirmed 屏基 檢驗手冊), so the
    // sub-items use Synovial-fluid LOINCs (rule #5 有專屬用專屬), replacing the
    // earlier generic "Body fluid" codes. All loinc.org-verified 2026-07-12 (Active,
    // System = Synv fld, property matches the old generic twin):
    //   14664-7 Color of Synovial fluid            (was 6824-7  Body fluid)
    //   26469-7 Leukocytes [#/volume] in Synv fld  (was 26466-3 Body fluid; drops the
    //           "by Manual count" method — method-less is safer when method unknown)
    //   17836-8 Neutrophils/Leukocytes in Synv fld, NFr (was 26513-2 Body fluid; LOINC
    //           v2.79 renamed the component from "…/100 leukocytes" → "…/Leukocytes")
    //   26483-8 Lymphocytes/Leukocytes in Synv fld, NFr (was 11031-2 Body fluid)
    // Diff stays % (NFr). If a real 16008C row reports the diff as absolute #/volume,
    // revisit to the Synovial [#/volume] variants. "sf.*" = Taiwan LIS "SF" (Synovial
    // Fluid) prefix in raw display text.
    // ── Ascitic/peritoneal fluid analysis (16002C) ───────────────
    // The code alone is not specimen evidence. observation.ts consults this
    // table only after explicit ascites/peritoneal wording has proved the fluid.
    "16002C": {
      ...buildRoutes({
        NEUTROPHIL: "26514-0",
        LYMPHOCYTE: "26482-0",
        MONOCYTE: "35020-7",
        MACROPHAGE: "35020-7",
        EOSINOPHIL: "30380-0",
        BASOPHIL: "35069-4",
        LEUKOCYTE_COUNT: "26468-9",
        ERYTHROCYTE_COUNT: "26457-2"
      }),
      neu: "26514-0",
      "mono macro": "35020-7",
      wbc: "26468-9",
      leukocyte: "26468-9",
      leukocytes: "26468-9",
      \u767D\u8840\u7403: "26468-9",
      rbc: "26457-2",
      erythrocyte: "26457-2",
      erythrocytes: "26457-2",
      \u7D05\u8840\u7403: "26457-2",
      "rivalta test": "98021-9",
      rivalta: "98021-9"
    },
    // ── Pleural fluid routine analysis (16003C = 胸水常規分析) ──────────────
    // Pleural-fluid-specific LOINCs for the full panel (differential / counts /
    // physical / chemistry), all loinc.org-verified 2026-07-13 (LOINC 2.82) from
    // the "Cell count and Differential panel - Pleural fluid" (34562-9). Differential
    // + counts + physical come from CELL_ALIASES via buildRoutes (same variant lists
    // as blood/synovial — no per-specimen drift). Serous fluids report TOTAL
    // NUCLEATED CELLS (58904-4), and LOINC MERGES monocytes+macrophages into one
    // code (35021-5), so both MONOCYTE and MACROPHAGE route there. Chemistry is
    // listed directly (panel-scoped) so the pleural glucose/LDH/protein rows resolve
    // to their pleural LOINCs without the serum-veto stripping them first.
    "16003C": {
      ...buildRoutes(
        {
          NEUTROPHIL: "30455-0",
          LYMPHOCYTE: "26481-2",
          MONOCYTE: "35021-5",
          MACROPHAGE: "35021-5",
          EOSINOPHIL: "30379-2",
          BASOPHIL: "35070-2",
          REACTIVE_LYMPHOCYTE: "33370-8",
          LEUKOCYTE_COUNT: "26467-1",
          ERYTHROCYTE_COUNT: "26456-4",
          NUCLEATED_CELL_COUNT: "58904-4",
          COLOR: "14662-1",
          APPEARANCE: "14620-9",
          PH: "2750-8",
          SPECIFIC_GRAVITY: "14349-5"
        },
        { scope: "16003C" }
      ),
      // Chemistry — panel-scoped pleural (16003C IS pleural, so bypass serum veto).
      glucose: "2346-5",
      "glucose ac": "2346-5",
      \u8461\u8404\u7CD6: "2346-5",
      ldh: "2530-4",
      "l.d.h.": "2530-4",
      "l d h": "2530-4",
      protein: "2882-9",
      "total protein": "2882-9",
      \u5168\u86CB\u767D: "2882-9",
      "abnormal cell": "34983-7",
      // unidentified cells/leukocytes fraction, %
      "abnormal cells": "34983-7"
    },
    "16008C": {
      // Cell differential — SAME variants as blood CBC (CELL_ALIASES), routed to
      // Synovial-fluid LOINCs. Via buildRoutes the synovial panel now gets the FULL
      // variant set (lym / 淋巴 / neut / 嗜中性球 / mono …) the hand-copied list was
      // missing — the drift this refactor fixes — plus the 16008C-scoped LIS typo
      // "lymohocyte" (missing 'p', real P20105). The bare "neutrophil"/"lym" keys
      // also match the Taiwan "SF." prefix ("sf neutrophil" ⊃ \bneutrophil\b), so
      // the old redundant "sf.*" keys are gone. Monocyte %: the ONLY Synovial NFr
      // differential code is the mono+macro merge 21395-9 "Monocytes+Macrophages/
      // Leukocytes:NFr:Pt:Synv fld:Qn:Manual count" (loinc.org 2026-07-13) — there
      // is NO monocyte-only NFr for synovial, same mono+macro merge convention as
      // the pleural 35021-5. Per rule #5「有專屬用專屬」use the Synovial-specific
      // 21395-9 over the generic body-fluid 26487-9; the Manual-count method axis
      // (siblings 17836-8/26483-8 are method-less) is the only synovial option and
      // is accurate for a manual-microscopy differential. MACROPHAGE routes here
      // too (the code IS mono+macro). System=Synovial → specimen resolves cleanly.
      ...buildRoutes(
        {
          NEUTROPHIL: "17836-8",
          LYMPHOCYTE: "26483-8",
          MONOCYTE: "21395-9",
          MACROPHAGE: "21395-9"
        },
        { scope: "16008C" }
      ),
      "sf.wbc": "26469-7",
      "sf wbc": "26469-7",
      wbc: "26469-7",
      leukocyte: "26469-7",
      leukocytes: "26469-7",
      "sf.rbc": "26458-0",
      // Erythrocytes [#/volume] in Synovial fluid
      "sf rbc": "26458-0",
      rbc: "26458-0",
      erythrocyte: "26458-0",
      erythrocytes: "26458-0",
      "sf.color": "14664-7",
      "sf color": "14664-7",
      color: "14664-7",
      \u984F\u8272: "14664-7",
      "sf.appearance": "29605-3",
      // Appearance of Synovial fluid
      "sf appearance": "29605-3",
      appearance: "29605-3",
      \u5916\u89C0: "29605-3",
      "sf.viscosity": "14950-0",
      // Viscosity of Synovial fluid, Qualitative
      "sf viscosity": "14950-0",
      viscosity: "14950-0",
      \u9ECF\u7A20\u5EA6: "14950-0",
      \u9ECF\u5EA6: "14950-0",
      glucose: "2348-1",
      // Glucose [Mass/volume] in Synovial fluid
      glucosc: "2348-1",
      // LIS typo (missing 'e') — real P20105 "Glucosc"
      \u8461\u8404\u7CD6: "2348-1",
      protein: "2886-0",
      // Protein [Mass/volume] in Synovial fluid
      \u86CB\u767D: "2886-0",
      \u86CB\u767D\u8CEA: "2886-0"
    },
    // ── CBC with auto diff (08013C) ──────────────────────
    // 08013C reports each cell type as a PERCENT of leukocytes (per 100),
    // distinct LOINCs from the absolute-count series (08010C Eosinophil
    // count → 711-2 is a different billing code with the count semantics).
    // Adding these here so under 08013C the diff entries route to the
    // /100 leukocytes LOINCs instead of falling to global eosinophil
    // count or "白血球" → WBC.
    "08013C": {
      // Differential percentages — shared with the CBC sibling billing
      // codes (08002C / 08003C / 08004C / 08006C) above; see
      // CBC_DIFF_KEYS const for the source of truth (includes singular
      // "Segment" Part 4 fix + 淋巴白血球 / 單核白血球 / 嗜中性白血球
      // wider CJK variants added v0.9.10 Part 6 N3).
      ...CBC_DIFF_KEYS,
      // v0.11.11 (SMART app dev bug 2 2026-05-29): basic CBC component
      // displays (Hct, Hb, RBC indices) also appear under 08013C diff
      // panel printout in some Taiwan LIS. Without these mappings, e.g.
      // "Hct(血球容積比)" rows previously fell to panel LOINC 57021-8
      // (CBC W Auto Diff panel). Adding the shared component keys here
      // routes basic CBC entries to their canonical LOINCs.
      ...CBC_COMPONENT_KEYS,
      // WBC absolute count can also appear on the diff panel printout.
      \u767D\u8840\u7403: "6690-2",
      wbc: "6690-2"
    }
  };
  function isAsciiOnly(s) {
    for (let i = 0; i < s.length; i++) {
      if (s.charCodeAt(i) > 127) return false;
    }
    return true;
  }
  var LAB_SYNONYMS = {
    // Diabetes
    \u91A3\u5316\u8840\u7D05\u7D20: "HBA1C",
    \u7CD6\u5316\u8840\u8272\u7D20: "HBA1C",
    \u7CD6\u5316\u8840\u7D05\u7D20: "HBA1C",
    "GLYCATED HEMOGLOBIN": "HBA1C",
    HBA1C: "HBA1C",
    A1C: "HBA1C",
    \u7A7A\u8179\u8840\u7CD6: "GLUCOSE_FASTING",
    "FASTING GLUCOSE": "GLUCOSE_FASTING",
    \u8461\u8404\u7CD6: "GLUCOSE",
    \u8840\u7CD6: "GLUCOSE",
    GLUCOSE: "GLUCOSE",
    // CBC
    \u767D\u8840\u7403\u8A08\u6578: "WBC",
    \u767D\u8840\u7403: "WBC",
    WBC: "WBC",
    \u7D05\u8840\u7403\u8A08\u6578: "RBC",
    \u7D05\u8840\u7403: "RBC",
    RBC: "RBC",
    \u8840\u7D05\u7D20: "HEMOGLOBIN",
    \u8840\u8272\u7D20: "HEMOGLOBIN",
    HEMOGLOBIN: "HEMOGLOBIN",
    HGB: "HEMOGLOBIN",
    // v0.11.7 pre-existing gap (defensive): "Hb" was missing from
    // LAB_SYNONYMS so Hb display canonical → "hb" (fallback), not
    // HEMOGLOBIN → cross-language merge with "血紅素" never happened.
    HB: "HEMOGLOBIN",
    \u8840\u5BB9\u7A4D\u6BD4: "HEMATOCRIT",
    HEMATOCRIT: "HEMATOCRIT",
    HCT: "HEMATOCRIT",
    \u8840\u5C0F\u677F: "PLATELET",
    PLATELET: "PLATELET",
    PLT: "PLATELET",
    // CBC indices (10-char and 7-char CJK forms beat bare 紅血球)
    \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20\u6FC3\u5EA6: "MCHC",
    \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20: "MCH",
    \u5E73\u5747\u7D05\u8840\u7403\u6FC3\u5EA6: "MCHC",
    \u5E73\u5747\u7D05\u8840\u7403\u9AD4\u7A4D: "MCV",
    \u7D05\u8840\u7403\u5206\u5E03\u5BEC\u5EA6: "RDW",
    MCV: "MCV",
    MCH: "MCH",
    MCHC: "MCHC",
    RDW: "RDW",
    // CBC differential
    \u55DC\u4E2D\u6027\u767D\u8840\u7403: "NEUTROPHIL",
    \u55DC\u4F0A\u7D05\u6027\u767D\u8840\u7403: "EOSINOPHIL",
    \u55DC\u9178\u6027\u767D\u8840\u7403: "EOSINOPHIL",
    \u55DC\u9E7C\u6027\u767D\u8840\u7403: "BASOPHIL",
    \u6DCB\u5DF4\u7403: "LYMPHOCYTE",
    \u55AE\u6838\u7403: "MONOCYTE",
    EOSINOPHILS: "EOSINOPHIL",
    EOSINOPHIL: "EOSINOPHIL",
    NEUTROPHILS: "NEUTROPHIL",
    NEUTROPHIL: "NEUTROPHIL",
    BASOPHILS: "BASOPHIL",
    BASOPHIL: "BASOPHIL",
    LYMPHOCYTES: "LYMPHOCYTE",
    LYMPHOCYTE: "LYMPHOCYTE",
    MONOCYTES: "MONOCYTE",
    MONOCYTE: "MONOCYTE",
    // Lipid — LDL/HDL must precede bare CHOLESTEROL.
    "LDL CHOLESTEROL": "LDL_C",
    "LDL-CHOLESTEROL": "LDL_C",
    "HDL CHOLESTEROL": "HDL_C",
    "HDL-CHOLESTEROL": "HDL_C",
    \u4F4E\u5BC6\u5EA6\u81BD\u56FA\u9187: "LDL_C",
    \u9AD8\u5BC6\u5EA6\u81BD\u56FA\u9187: "HDL_C",
    \u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "LDL_C",
    \u9AD8\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "HDL_C",
    \u8840\u6E05\u7E3D\u81BD\u56FA\u9187: "TOTAL_CHOLESTEROL",
    \u7E3D\u81BD\u56FA\u9187: "TOTAL_CHOLESTEROL",
    "T-CHOLESTEROL": "TOTAL_CHOLESTEROL",
    "T-CHOL": "TOTAL_CHOLESTEROL",
    "TOTAL CHOLESTEROL": "TOTAL_CHOLESTEROL",
    CHOLESTEROL: "TOTAL_CHOLESTEROL",
    CHOL: "TOTAL_CHOLESTEROL",
    \u4E09\u9178\u7518\u6CB9\u916F: "TRIGLYCERIDE",
    TRIGLYCERIDE: "TRIGLYCERIDE",
    "HDL-C": "HDL_C",
    HDL: "HDL_C",
    \u9AD8\u5BC6\u5EA6\u8102\u86CB\u767D: "HDL_C",
    "LDL-C(DIRECT)": "LDL_C",
    "LDL-C": "LDL_C",
    LDL: "LDL_C",
    \u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D: "LDL_C",
    // Renal — urine creatinine variants before serum.
    // v0.11.7 fix (bug 2026-05-28): added longer-keyed entries for
    // 肌酸酐(尿液) / 微白蛋白/肌酐酸比值 so urinalysis half-quantitative
    // rows don't collide with serum creatinine via shorter "肌酸酐" key.
    // Original short keys (肌酸酐 / 肌酐酸 → CREATININE) preserved for
    // serum rows; longer urinalysis-specific keys take priority via
    // longest-match in canonicalLabKey.
    "\u5FAE\u767D\u86CB\u767D/\u808C\u9150\u9178\u6BD4\u503C": "UACR",
    UACR: "UACR",
    "MALB/CRE": "UACR",
    "ALB/CRE": "UACR",
    "\u808C\u9178\u9150(\u5C3F\u6DB2)": "URINE_CREATININE",
    \u5C3F\u6DB2\u808C\u9178\u9150: "URINE_CREATININE",
    "URINE CREATININE": "URINE_CREATININE",
    "CREATININE(U)": "URINE_CREATININE",
    "CREATININE-U": "URINE_CREATININE",
    "CREA(U)": "URINE_CREATININE",
    "CREA-U": "URINE_CREATININE",
    "U-CRE": "URINE_CREATININE",
    "U-CREA": "URINE_CREATININE",
    \u808C\u9178\u9150: "CREATININE",
    \u808C\u9150\u9178: "CREATININE",
    "CREATININE(B)": "CREATININE",
    CREATININE: "CREATININE",
    CREA: "CREATININE",
    CRTN: "CREATININE",
    EGFR: "EGFR",
    \u5C3F\u7D20\u6C2E: "BUN",
    BUN: "BUN",
    \u5C3F\u9178\u9E7C\u5EA6: "URINE_PH",
    \u5C3F\u6DB2\u9178\u9E7C\u5EA6: "URINE_PH",
    \u9178\u9E7C\u5EA6: "PH",
    \u5C3F\u9178: "URIC_ACID",
    "URIC ACID": "URIC_ACID",
    URIC_ACID: "URIC_ACID",
    // Liver
    AST: "AST",
    ALT: "ALT",
    GOT: "AST",
    GPT: "ALT",
    \u81BD\u7D05\u7D20: "BILIRUBIN",
    BILIRUBIN: "BILIRUBIN",
    // v0.11.7 (bug 2026-05-28): longer keys for urinalysis to prevent
    // collision with serum analytes — 微白蛋白(尿) wasn't 白蛋白; 白血
    // 球酯脢 wasn't blood 白血球. Longer keys take priority via
    // longest-match sorting.
    "\u5FAE\u767D\u86CB\u767D(\u5C3F)": "URINE_MICROALBUMIN",
    \u5FAE\u767D\u86CB\u767D: "URINE_MICROALBUMIN",
    "MALB(U)": "URINE_MICROALBUMIN",
    MICROALBUMIN: "URINE_MICROALBUMIN",
    \u767D\u86CB\u767D: "ALBUMIN",
    ALBUMIN: "ALBUMIN",
    \u767D\u8840\u7403\u916F\u8122: "URINE_LEU_ESTERASE",
    \u767D\u8840\u7403\u916F\u9176: "URINE_LEU_ESTERASE",
    "WBC ESTERASE": "URINE_LEU_ESTERASE",
    "LEUKOCYTE ESTERASE": "URINE_LEU_ESTERASE",
    // Cardiac
    \u5FC3\u808C\u65CB\u8F49\u86CB\u767D: "TROPONIN",
    TROPONIN: "TROPONIN",
    BNP: "BNP",
    \u5FC3\u81DF: "TROPONIN",
    // Thyroid
    \u7532\u72C0\u817A\u523A\u6FC0\u7D20: "TSH",
    TSH: "TSH",
    \u6E38\u96E2\u7532\u72C0\u817A\u7D20: "FREE_T4",
    "FREE T4": "FREE_T4",
    FT4: "FREE_T4",
    // Misc
    C\u53CD\u61C9\u6027\u86CB\u767D: "CRP",
    "C-REACTIVE PROTEIN": "CRP",
    CRP: "CRP",
    "HS-CRP": "HS_CRP",
    \u651D\u8B77\u817A\u7279\u7570\u6297\u539F: "PSA",
    PSA: "PSA",
    \u9435\u86CB\u767D: "FERRITIN",
    FERRITIN: "FERRITIN",
    \u8449\u9178: "FOLATE",
    FOLATE: "FOLATE",
    \u7DAD\u751F\u7D20B12: "VITAMIN_B12",
    "VIT B12": "VITAMIN_B12",
    "VITAMIN B12": "VITAMIN_B12",
    \u76AE\u8CEA\u7D20: "CORTISOL",
    CORTISOL: "CORTISOL",
    \u6885\u6BD2: "RPR",
    RPR: "RPR",
    \u96B1\u7403\u83CC\u6297\u539F: "CRYPTOCOCCAL_AG",
    CRYPAG: "CRYPTOCOCCAL_AG",
    \u8840\u6C28: "AMMONIA",
    AMMONIA: "AMMONIA",
    \u51DD\u8840\u9176\u539F\u6642\u9593: "PT",
    APTT: "APTT",
    INR: "INR"
  };
  var LAB_SYNONYM_KEYS_SORTED = Object.keys(LAB_SYNONYMS).sort((a, b) => b.length - a.length);
  var URINALYSIS_PANEL_SYNONYMS = {
    // English / abbreviation variants
    GLUCOSE: "URINE_GLUCOSE",
    "U-SUGAR": "URINE_GLUCOSE",
    SUGAR: "URINE_GLUCOSE",
    "U-GLUCOSE": "URINE_GLUCOSE",
    COLOR: "URINE_COLOR",
    COLOUR: "URINE_COLOR",
    BLOOD: "URINE_OCCULT_BLOOD",
    "U-BLOOD": "URINE_OCCULT_BLOOD",
    OB: "URINE_OCCULT_BLOOD",
    "OCCULT BLOOD": "URINE_OCCULT_BLOOD",
    PROTEIN: "URINE_PROTEIN",
    "U-PRO": "URINE_PROTEIN",
    "U-PROTEIN": "URINE_PROTEIN",
    KETONE: "URINE_KETONES",
    KETONES: "URINE_KETONES",
    KET: "URINE_KETONES",
    NITRITE: "URINE_NITRITE",
    NIT: "URINE_NITRITE",
    TURBIDITY: "URINE_TURBIDITY",
    "SP.GRAVITY": "URINE_SG",
    SG: "URINE_SG",
    "S.G.": "URINE_SG",
    "S.G": "URINE_SG",
    "SPECIFIC GRAVITY": "URINE_SG",
    UROBILINOGEN: "URINE_UROBILINOGEN",
    UBG: "URINE_UROBILINOGEN",
    URO: "URINE_UROBILINOGEN",
    // pH variants — v0.11.7 missing in initial commit; user reported
    // pH (英) + 酸鹼值 (中) still as 2 rows in 06013C bundle.
    PH: "URINE_PH",
    "P.H.": "URINE_PH",
    "P.H": "URINE_PH",
    "U-PH": "URINE_PH",
    // Bilirubin variants — separate from serum BILIRUBIN so urine
    // bilirubin (06013C) doesn't cross-panel-collide with serum
    // total bilirubin (09029C). Within scope, English "Bilirubin" and
    // CJK 膽紅素 both → URINE_BILIRUBIN → merge as 1 row.
    BILIRUBIN: "URINE_BILIRUBIN",
    BILI: "URINE_BILIRUBIN",
    "U-BILI": "URINE_BILIRUBIN",
    // CJK variants — paired with English above so cross-language dedup works
    \u5C3F\u7CD6: "URINE_GLUCOSE",
    \u984F\u8272: "URINE_COLOR",
    \u5C3F\u6F5B\u8840: "URINE_OCCULT_BLOOD",
    \u5C3F\u86CB\u767D: "URINE_PROTEIN",
    \u916E\u9AD4: "URINE_KETONES",
    \u4E9E\u785D\u9178\u9E7D: "URINE_NITRITE",
    \u6FC1\u5EA6: "URINE_TURBIDITY",
    \u6BD4\u91CD: "URINE_SG",
    \u5C3F\u81BD\u7D20\u539F: "URINE_UROBILINOGEN",
    \u9178\u9E7C\u503C: "URINE_PH",
    \u9178\u9E7C\u5EA6: "URINE_PH",
    \u81BD\u7D05\u7D20: "URINE_BILIRUBIN"
  };
  var CODE_SCOPED_SYNONYMS = {
    "06013C": URINALYSIS_PANEL_SYNONYMS
  };
  var CODE_SCOPED_CJK_KEYS_SORTED = Object.fromEntries(
    Object.entries(CODE_SCOPED_SYNONYMS).map(([code, table]) => [
      code,
      Object.keys(table).filter((k) => !isAsciiOnly(k)).sort((a, b) => b.length - a.length)
    ])
  );
  var VENOUS_GAS_REQUIRED_LOINCS = /* @__PURE__ */ new Set(["2746-6", "2021-4", "2705-2"]);
  var VENOUS_GAS_ALLOWED_LOINCS = /* @__PURE__ */ new Set([
    ...VENOUS_GAS_REQUIRED_LOINCS,
    "14627-4",
    "2027-1",
    "1927-3",
    "2711-0",
    "8310-5"
  ]);
  var PAGE_TYPE_ORDER = CANONICAL_PAGE_TYPE_ORDER;

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/helpers.ts
  var import_js_sha13 = __toESM(require_sha12(), 1);
  var TAIWAN_CITY_COUNTY2 = "(?:\u57FA\u9686\u5E02|\u81FA\u5317\u5E02|\u53F0\u5317\u5E02|\u65B0\u5317\u5E02|\u6843\u5712\u5E02|\u81FA\u4E2D\u5E02|\u53F0\u4E2D\u5E02|\u81FA\u5357\u5E02|\u53F0\u5357\u5E02|\u9AD8\u96C4\u5E02|\u65B0\u7AF9\u5E02|\u5609\u7FA9\u5E02|\u65B0\u7AF9\u7E23|\u82D7\u6817\u7E23|\u5F70\u5316\u7E23|\u5357\u6295\u7E23|\u96F2\u6797\u7E23|\u5609\u7FA9\u7E23|\u5C4F\u6771\u7E23|\u5B9C\u862D\u7E23|\u82B1\u84EE\u7E23|\u81FA\u6771\u7E23|\u53F0\u6771\u7E23|\u6F8E\u6E56\u7E23|\u91D1\u9580\u7E23|\u9023\u6C5F\u7E23)";
  var DETAILED_TAIWAN_ADDRESS_RE2 = new RegExp(
    `${TAIWAN_CITY_COUNTY2}[^\\s<\uFF0C\u3002\uFF1B;\u3001,()\uFF08\uFF09]{0,90}(?:\u5927\u9053|\u8DEF|\u8857|\u5DF7|\u5F04|\u865F|\u91CC|\u6751|\u9130)[^\\s<\uFF0C\u3002\uFF1B;\u3001,()\uFF08\uFF09]{0,90}`,
    "g"
  );
  var PHONE_LABEL_PATTERN2 = "(?:\u806F\u7D61\u96FB\u8A71|\u9023\u7D61\u96FB\u8A71|\u884C\u52D5\u96FB\u8A71(?:\u865F\u78BC)?|\u624B\u6A5F(?:\u865F\u78BC)?|\u96FB\u8A71(?:\u865F\u78BC)?|\\b(?:phone\\s*(?:number|no\\.?|#)?|telephone\\s*(?:number|no\\.?|#)?|mobile(?:\\s+phone)?\\s*(?:number|no\\.?|#)?)(?![A-Za-z]))";
  var PHONE_VALUE_PATTERN2 = "[+\uFF0B]?[ \\t\\u3000]*(?:[\uFF08(][ \\t\\u3000]*)?[0-9\uFF10-\uFF19](?:[0-9\uFF10-\uFF19 \\t\\u3000().\uFF08\uFF09\uFF0E\\-\uFF0D\u2013\u2014/\uFF0F]{0,40}[0-9\uFF10-\uFF19])?(?:[ \\t\\u3000]*(?:#|\uFF03|\u5206\u6A5F|ext\\.?)[ \\t\\u3000]*[0-9\uFF10-\uFF19]{1,8})?";
  var PHONE_INLINE_LAYOUT_PATTERN2 = "(?:[ \\t\\u3000]|&nbsp;|&#160;|&#x0*a0;|<\\/?(?:b|strong|span|font|em|i)\\b[^>]*>)*";
  var PHONE_LABEL_SEPARATOR_PATTERN2 = "(?:\\s*[:\uFF1A]\\s*|[ \\t\\u3000]+)?";
  var LABELED_PHONE_VALUE_RE2 = new RegExp(
    `(${PHONE_LABEL_PATTERN2}${PHONE_LABEL_SEPARATOR_PATTERN2}${PHONE_INLINE_LAYOUT_PATTERN2}(?:<\\/td>\\s*<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN2})?)(${PHONE_VALUE_PATTERN2})`,
    "gi"
  );
  var BARE_PHONE_CELL_VALUE_RE2 = new RegExp(
    `(<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN2}${PHONE_LABEL_PATTERN2}${PHONE_INLINE_LAYOUT_PATTERN2}<\\/td>\\s*<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN2})(${PHONE_VALUE_PATTERN2})`,
    "gi"
  );
  var LABELED_ADDRESS_VALUE_RE2 = new RegExp(
    `((?:\u6236\u7C4D\u5730\u5740|\u901A\u8A0A\u5730\u5740|\u806F\u7D61\u5730\u5740|\u73FE\u4F4F\u5730\u5740|\u4F4F\u5740|\u5730\u5740)\\s*[:\uFF1A]\\s*(?:<\\/b>\\s*)?(?:<\\/td>\\s*<td[^>]*>\\s*(?:<b>\\s*<\\/b>\\s*)?)?)([^<\\n\\r]+?)(?=<|\\n|\\r|\\s*(?:[-_=]{8,}|(?:SNOMED|DX|GROSS(?:\\s+(?:D|FINDING))?|MICRO(?:SCOPIC\\s+FINDING|\\s+D)?|PATHOLOGICAL\\s+DIAGNOSIS|DIAGNOSIS|\u81E8\u5E8A\u8A3A\u65B7|\u75C5\u7406\u8A3A\u65B7|\u6253\u5B57\u54E1|\u75C5\u7406\u91AB\u5E2B|\u5C1A\u6709\u5831\u544A|\u75C5\u89E3\u5C08\u91AB\u5B57|\u5165\u9662\u79D1\u5225|\u51FA\u9662\u79D1\u5225|\u4F4F\u9662\u5929\u6578|ISS\u5206\u6578|\u91AB\u7642\u6A5F\u69CB\u540D\u7A31|\u91AB\u7642\u6A5F\u69CB\u4EE3\u78BC|${PHONE_LABEL_PATTERN2})\\s*[:\uFF1A])|$)`,
    "gi"
  );

  // ../packages/fhir-mapper/src/lab-source-reconciliation.ts
  var BASE = "https://cloud-wildcatch.invalid/fhir";
  var LAB_COPY_URL = `${BASE}/StructureDefinition/medcloud-lab-source-copy`;
  var DATA_MARK_URL = `${BASE}/StructureDefinition/medcloud-source-data-mark`;

  // ../packages/fhir-mapper/src/medcloud-bundle.ts
  var BRIDGE_NAMESPACE = "https://cloud-wildcatch.invalid/fhir";
  var MEDCLOUD_SOURCE_SYSTEM_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-source-system`;
  var MEDCLOUD_SOURCE_SYSTEM_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-source-system`;
  var SOURCE_MODULE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/source-module`;
  var SOURCE_CAPTURE_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/sid/source-capture-artifact`;
  var SOURCE_ROW_OCCURRENCE_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/sid/source-row-occurrence`;
  var ADAPTER_VERSION_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/adapter-version`;
  var DATA_CLASS_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/data-class`;
  var MODULE_COMPLETENESS_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/module-completeness`;
  var BUNDLE_VALIDATION_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/bundle-validation`;
  var DATA_QUALITY_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/data-quality`;
  var POSSIBLE_DUPLICATE_SOURCE_OBSERVATION_TAG = "possible-duplicate-source-observation";
  var POSSIBLE_DUPLICATE_SOURCE_RESOURCE_TAG = "possible-duplicate-source-resource";
  var MEDCLOUD_IMAGING_CASE_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/IdentifierSystem/medcloud-imaging-case`;
  var PROVIDER_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/sid/medcloud-provider`;
  var MASKED_TW_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/IdentifierSystem/masked-tw-national-id`;
  var MASKED_MEDCLOUD_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/IdentifierSystem/masked-medcloud-patient-id`;
  function maskMediCloudIdentifier(value) {
    const normalized = String(value ?? "").normalize("NFKC").trim().toUpperCase().replace(/[X*＊•●．・]/g, "X");
    return /^[A-Z0-9]{6,32}$/.test(normalized) ? normalized.slice(0, Math.max(2, normalized.length - 4)) + "XXXX" : normalized;
  }
  var DATASET_SCOPE_TAG_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/source-dataset-scope`;
  var CAPTURED_AT_TAG_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/source-captured-at`;
  var LOCAL_MEDICAL_ORDER_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-local-medical-order`;
  var NHI_DENTAL_PROGRAM_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-nhi-dental-program-service`;
  var LOCAL_MEDICATION_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-local-medication`;
  var NHI_VIEWER_REQUEST_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-nhi-viewer-request`;
  var IMAGING_CONTRAST_MEDIA_USE_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-imaging-contrast-media-use`;
  var MEDCLOUD_MEDICATION_REMAINING_SUMMARY_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-medication-remaining-summary`;
  var MEDCLOUD_RELATED_MEDICATION_REMAINING_SUMMARY_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-related-medication-remaining-summary`;
  var MEDCLOUD_INGREDIENT_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-drug-ingredient`;
  var MEDCLOUD_BASIC_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-basic-resource-type`;
  var MEDCLOUD_SPECIAL_MATERIAL_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-special-material-record`;
  var MEDCLOUD_DRUG_GROUP_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/IdentifierSystem/medcloud-drug-group`;
  var MEDCLOUD_SCREENING_RESULT_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-screening-result-code`;
  var MEDCLOUD_OBSERVATION_PROGRAM_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-observation-program`;
  var MEDCLOUD_ALLERGY_ASSERTION_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-allergy-assertion`;
  var MEDCLOUD_PAGE_TYPE_ORDER = [...PAGE_TYPE_ORDER, "service_requests", "special_materials"];

  // ../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message2;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message2 = "Required";
        } else {
          message2 = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message2 = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message2 = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message2 = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message2 = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message2 = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message2 = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message2 = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message2 = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message2 = `${message2} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message2 = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message2 = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message2 = `Invalid ${issue.validation}`;
        } else {
          message2 = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message2 = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message2 = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message2 = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message2 = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message2 = "Number must be finite";
        break;
      default:
        message2 = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message: message2 };
  };
  var en_default = errorMap;

  // ../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message2) => typeof message2 === "string" ? { message: message2 } : message2 || {};
    errorUtil2.toString = (message2) => typeof message2 === "string" ? message2 : message2?.message;
  })(errorUtil || (errorUtil = {}));

  // ../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message: message2 } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message2 ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message2 ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message2 ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message2) {
      const getIssueProperties = (val) => {
        if (typeof message2 === "string" || typeof message2 === "undefined") {
          return { message: message2 };
        } else if (typeof message2 === "function") {
          return message2(val);
        } else {
          return message2;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message2) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message2)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message2) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message2) });
    }
    url(message2) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message2) });
    }
    emoji(message2) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message2) });
    }
    uuid(message2) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message2) });
    }
    nanoid(message2) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message2) });
    }
    cuid(message2) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message2) });
    }
    cuid2(message2) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message2) });
    }
    ulid(message2) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message2) });
    }
    base64(message2) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message2) });
    }
    base64url(message2) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message2)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message2) {
      return this._addCheck({ kind: "date", message: message2 });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message2) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message2) });
    }
    regex(regex, message2) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message2)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message2) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    endsWith(value, message2) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    min(minLength, message2) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message2)
      });
    }
    max(maxLength, message2) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message2)
      });
    }
    length(len, message2) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message2)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message2) {
      return this.min(1, errorUtil.errToObj(message2));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message2) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message2)
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    finite(message2) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message2)
      });
    }
    safe(message2) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message2) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    max(maxDate, message2) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message2) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message2) }
      });
    }
    max(maxLength, message2) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message2) }
      });
    }
    length(len, message2) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message2) }
      });
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message2) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message2 !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message2).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message2) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message2) }
      });
    }
    max(maxSize, message2) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message2) }
      });
    }
    size(size, message2) {
      return this.min(size, message2).max(size, message2);
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = /* @__PURE__ */ Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: ((arg) => ZodString.create({ ...arg, coerce: true })),
    number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
    boolean: ((arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    })),
    bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
    date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
  };
  var NEVER = INVALID;

  // ../packages/contracts/src/completeness.ts
  var CompletenessSchema = external_exports.enum(["complete", "empty", "partial", "failed"]);

  // ../packages/contracts/src/context.ts
  var PatientContextHashSchema = external_exports.string().min(16).max(256).regex(/^[A-Za-z0-9_-]+$/, "patientContextHash must be hex or base64url-like");
  var ProviderContextSchema = external_exports.object({
    identifier: external_exports.string().min(1).optional(),
    display: external_exports.string().min(1).optional()
  }).strict();
  var RecordContextSchema = external_exports.object({
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    sourceRecordKeyHmac: external_exports.string().min(16).optional(),
    capturedAt: external_exports.string().datetime({ offset: true }),
    adapterVersion: external_exports.string().min(1),
    patientContextHash: PatientContextHashSchema,
    provider: ProviderContextSchema.optional()
  }).strict();

  // ../packages/contracts/src/date.ts
  var DatePrecisionSchema = external_exports.enum(["year", "month", "day", "minute", "second"]);
  var DateSourceFormatSchema = external_exports.enum([
    "iso-date",
    "iso-date-time",
    "gregorian-slash",
    "roc-slash",
    "compact-date"
  ]);
  var NormalizedDateSchema = external_exports.object({
    value: external_exports.string().min(4),
    original: external_exports.string().min(1),
    precision: DatePrecisionSchema,
    sourceFormat: DateSourceFormatSchema,
    /** Present only when the source explicitly supplied Z or a numeric offset. */
    timezoneOffset: external_exports.string().regex(/^(?:Z|[+-]\d{2}:\d{2})$/).optional()
  }).strict();

  // ../packages/contracts/src/warning.ts
  var AdapterWarningCodeSchema = external_exports.enum([
    "access-restricted",
    "http-error",
    "invalid-json",
    "invalid-response",
    "invalid-row",
    "unknown-field",
    "missing-source-field",
    "invalid-date",
    "missing-clinical-content",
    "source-document-unavailable",
    "source-medication-duration-unavailable"
  ]);
  var WarningSeveritySchema = external_exports.enum(["info", "warning", "error"]);
  var AdapterWarningSchema = external_exports.object({
    code: AdapterWarningCodeSchema,
    severity: WarningSeveritySchema,
    path: external_exports.string().min(1),
    field: external_exports.string().min(1).optional(),
    message: external_exports.string().min(1)
  }).strict();
  var SOURCE_DATA_WARNING_CODES = [
    "invalid-date",
    "missing-clinical-content",
    "source-document-unavailable",
    "source-medication-duration-unavailable"
  ];
  var SOURCE_DATA_WARNING_CODE_SET = new Set(SOURCE_DATA_WARNING_CODES);
  function isSourceDataWarningCode(code) {
    return SOURCE_DATA_WARNING_CODE_SET.has(code);
  }

  // ../packages/contracts/src/module-result.ts
  var MapperPageTypeSchema = external_exports.enum([
    "observations",
    "medications",
    "diagnostic_reports",
    "procedures",
    "encounters",
    "document_references",
    "service_requests",
    "allergies",
    "special_materials"
  ]);
  var ModuleErrorSchema = external_exports.object({
    code: external_exports.string().min(1),
    message: external_exports.string().min(1)
  }).strict();
  var ModuleResultBaseSchema = external_exports.object({
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    adapterVersion: external_exports.string().min(1),
    capturedAt: external_exports.string().datetime({ offset: true }),
    patientContextHash: PatientContextHashSchema,
    pageType: MapperPageTypeSchema,
    completeness: CompletenessSchema,
    warnings: external_exports.array(AdapterWarningSchema),
    error: ModuleErrorSchema.optional()
  });
  var ModuleResultSchema = ModuleResultBaseSchema.extend({
    records: external_exports.array(external_exports.unknown())
  }).strict();

  // ../packages/contracts/src/source-envelope.ts
  var SourceEnvelopeBaseSchema = external_exports.object({
    schemaVersion: external_exports.string().min(1),
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    adapterVersion: external_exports.string().min(1),
    runId: external_exports.string().min(1),
    capturedAt: external_exports.string().datetime({ offset: true }),
    sourceEventTime: external_exports.string().min(1).optional(),
    timePrecision: DatePrecisionSchema.optional(),
    authoritativeWindow: external_exports.object({
      start: external_exports.string().min(1).optional(),
      end: external_exports.string().min(1).optional()
    }).strict().optional(),
    completeness: CompletenessSchema,
    sourceRecordKeyHmac: external_exports.string().min(16).optional(),
    providerIdentifier: external_exports.string().min(1).optional(),
    patientContextHash: PatientContextHashSchema
  });
  var SourceEnvelopeSchema = SourceEnvelopeBaseSchema.extend({
    payload: external_exports.unknown()
  }).strict();

  // ../packages/medcloud-adapter/src/common.ts
  var import_js_sha14 = __toESM(require_sha12(), 1);

  // ../packages/medcloud-adapter/src/parser.ts
  var ResponseBodySchema = external_exports.object({
    log2time: external_exports.string().nullable().optional(),
    robject: external_exports.array(external_exports.unknown())
  });

  // ../packages/medcloud-adapter/src/schemas.ts
  var nullableString = external_exports.string().nullable().optional();
  var nullableNumber = external_exports.number().nullable().optional();
  var presentationString = external_exports.string().nullable().optional().transform((value) => value ?? "");
  var observedLabel = presentationString.describe("observed-field");
  var observedOrdinal = nullableNumber.describe("observed-field");
  var Imue0060RowSchema = external_exports.object({
    assay_item_name: external_exports.string(),
    assay_mark: nullableString,
    assay_method: presentationString,
    assay_tp_cname: nullableString,
    assay_value: external_exports.string(),
    case_time: external_exports.string(),
    consult_value: presentationString,
    data_mark: nullableString,
    fee_ym: observedLabel,
    func_type: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    inspect_mode: nullableString,
    inspect_result: nullableString,
    memo_data: nullableString,
    order_code: external_exports.string(),
    order_name: external_exports.string(),
    path_diag_1: nullableString,
    path_diag_2: nullableString,
    path_diag_3: nullableString,
    r: observedOrdinal,
    real_inspect_date: external_exports.string(),
    recipe_date: nullableString,
    unit_data: presentationString
  });
  var Imue0008RowSchema = external_exports.object({
    ay_flag: observedLabel,
    chr_hosp_id: nullableString,
    cure_e_date: nullableString,
    // Observed September 2026: source marker passed to NHI's allergy editor.
    // Accepted as metadata only; do not infer a clinical code or care setting.
    data_source: nullableString,
    // MediCloud can omit the duration on claimed inpatient medication rows.
    day: external_exports.number().nullable(),
    drug_65_mark: nullableString,
    drug_atc3_code: external_exports.string(),
    drug_atc5_code: external_exports.string(),
    drug_atc5_name: presentationString,
    drug_atc7_code: external_exports.string(),
    drug_code: external_exports.string(),
    drug_date: external_exports.string(),
    drug_ename: presentationString,
    drug_fre: presentationString,
    drug_group11_name: nullableString,
    drug_ing_code: external_exports.string(),
    drug_ing_name: presentationString,
    drug_left: external_exports.number(),
    drug_multi_mark: nullableString,
    drug_std_qty: nullableNumber,
    dup_drug_mark: nullableString,
    fee_ym: nullableString,
    func_seq_no: observedLabel,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: presentationString,
    icd_code: external_exports.string(),
    qty: external_exports.number(),
    r: observedOrdinal
  });
  var Imue0130RowSchema = external_exports.object({
    assay_item_name: nullableString,
    assay_tp_cname: external_exports.string(),
    assay_value: nullableString,
    case_report_type: external_exports.string(),
    case_time: nullableString,
    ctmri: nullableString,
    ctmri_mark: external_exports.string(),
    cure_path: nullableString,
    cure_path_name: nullableString,
    data_mark: external_exports.string(),
    eec_link: nullableString,
    eec_mark: external_exports.string(),
    fee_ym: observedLabel,
    file_qty: nullableNumber,
    file_type: nullableString,
    func_type: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    inspect_mode: nullableString,
    inspect_result: nullableString.describe("observed-field"),
    ipl_case_seq_no: nullableString,
    memo_data: nullableString,
    ord_mark: nullableString,
    order_code: external_exports.string(),
    order_name: external_exports.string(),
    path_diag_1: nullableString,
    path_diag_2: nullableString,
    path_diag_3: nullableString,
    r: observedOrdinal,
    read_pos: nullableString,
    real_inspect_date: external_exports.string(),
    recipe_date: nullableString,
    unit_data: nullableString
  });
  var Imue0030RowSchema = external_exports.object({
    ctmri_mark: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    exe_e_date: nullableString,
    exe_s_date: external_exports.string(),
    fee_ym: nullableString,
    file_qty: nullableNumber,
    file_type: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    ipl_case_seq_no: nullableString,
    ord_mark: nullableString,
    order_code: external_exports.string(),
    order_ename: nullableString,
    order_qty: nullableNumber,
    r: observedOrdinal,
    read_pos: nullableString
  });
  var Imue0010RowSchema = external_exports.object({
    child_birthday: nullableString,
    child_mark: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    exam_type: nullableString,
    exe_e_date: nullableString,
    exe_s_date: external_exports.string(),
    fee_ym: nullableString,
    func_date: nullableString,
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_code: external_exports.string(),
    order_ename: external_exports.string(),
    order_qty: nullableNumber,
    r: observedOrdinal
  });
  var Imue0120RowSchema = external_exports.object({
    atc5: nullableString.describe("observed-field"),
    drug_group_code: nullableString,
    drug_type: nullableString,
    edate: nullableString,
    funcDate: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_code: nullableString,
    ingredient: nullableString.describe("observed-field"),
    order_drug_day: external_exports.union([external_exports.string(), external_exports.number()]).nullable().optional(),
    pres_med_day: external_exports.union([external_exports.string(), external_exports.number()])
  });
  var Imue0140RowSchema = external_exports.object({});
  var Imue0070RowSchema = external_exports.object({
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    in_date: external_exports.string(),
    mds_file: nullableString,
    mds_pdf_file: nullableString,
    out_date: nullableString,
    pdf_mark: nullableString,
    pdf_reply_mark: nullableString,
    r: observedOrdinal
  });
  var Imue0080RowSchema = external_exports.object({
    cure_e_date: nullableString,
    cure_grade: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    cure_type: nullableString,
    exe_e_date: nullableString,
    exe_s_date: nullableString,
    fee_ym: nullableString,
    func_date: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_qty: nullableNumber,
    r: observedOrdinal
  });
  var Imue0040RowSchema = external_exports.object({
    allerg_drug_group: nullableString,
    allerg_severity_level: nullableString,
    allergens_oth: nullableString,
    data_source: nullableString,
    data_type: nullableString,
    del_reason: nullableString,
    drug_ing_code: nullableString,
    drug_ing_oth: nullableString,
    drug_group_oth: nullableString,
    drug_name: nullableString,
    gene_order_code: nullableString,
    gene_order_oth: nullableString,
    genetic_test: nullableString,
    hosp: nullableString,
    occur_date: nullableString,
    r: nullableNumber,
    sympton_name: nullableString,
    upload_d: nullableString,
    upload_flag: nullableString
  });
  var Imue0020RowSchema = external_exports.object({
    cure_path: nullableString,
    cure_path_name: nullableString,
    exe_e_date: nullableString,
    exe_s_date: nullableString,
    fee_ym: nullableString,
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: observedLabel,
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_code: external_exports.string(),
    order_ename: nullableString,
    order_qty: nullableNumber,
    r: nullableNumber
  });
  var Imue0200RowSchema = external_exports.object({
    func_date: nullableString,
    hosp: presentationString,
    hosp_id: nullableString,
    icd_cname: nullableString,
    icd_code: nullableString,
    met_c_name: nullableString,
    met_e_name: nullableString,
    met_type: nullableString,
    order_code: presentationString,
    doh_license_no: nullableString,
    pdt_model: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    order_qty: nullableNumber,
    fee_ym: nullableString,
    data_source: nullableString,
    r: nullableNumber
  });

  // ../packages/medcloud-adapter/src/imue0130.ts
  var NHI_RADIOLOGY_REPORT_ORDER_CODES = /* @__PURE__ */ new Set([
    // X-ray
    "32001C",
    "32002C",
    "32006C",
    "32007C",
    "32008C",
    "32009C",
    "32010C",
    "32011C",
    "32012C",
    "32013C",
    "32014C",
    "32015C",
    "32016C",
    "32017C",
    "32018C",
    "32022C",
    "32023C",
    "33005B",
    "33012B",
    // CT
    "33070B",
    "33071B",
    "33072B",
    // MRI
    "33084B",
    "33085B"
  ]);
  var NHI_NON_PATHOLOGY_REPORT_ORDER_CODES = /* @__PURE__ */ new Set([
    ...NHI_RADIOLOGY_REPORT_ORDER_CODES,
    // Endoscopy (OTH)
    "28002C",
    "28016C",
    "28017C",
    "28023C",
    // Electroneurodiagnostic (EN)
    "17008B",
    "20001C",
    "20019B",
    "20023B",
    // Electrocardiac (EC)
    "18001C",
    "18015B",
    "18019C",
    // Vascular ultrasound (VUS)
    "18008C",
    "18010C",
    "18041B",
    "20013C",
    "20026B",
    // Cardiac catheterization (CTH)
    "18020B",
    "18022B",
    "33076B",
    "33077B",
    // Nuclear medicine scan (NMS)
    "26025B",
    "26029B",
    "26072B",
    // Pulmonary function (PF)
    "17003C",
    "17004C",
    "17006C",
    "17019C",
    // Cardiac ultrasound (CUS)
    "18005C",
    "18006C",
    "18007C",
    "18033B",
    // Obstetric ultrasound (OUS)
    "19010C",
    // Radiology ultrasound (RUS)
    "19001C",
    "19002B",
    "19003C",
    "19005C",
    "19009C",
    "19012C",
    "19014C",
    "19015C",
    "19016C",
    "19017C",
    "19018C",
    "21008C",
    "23504C",
    // Vascular interventions (RAD)
    "33074B",
    "33075B"
  ]);

  // src/module-labels.ts
  var MEDCLOUD_MODULE_LABELS = Object.fromEntries(
    MEDCLOUD_CLINICAL_MODULES.map((module) => [module.sourceModule, module.label])
  );

  // src/mapping-failure.ts
  var ERROR_KINDS = ["Error", "TypeError", "RangeError", "ReferenceError", "SyntaxError", "EvalError"];
  var VALIDATION_CODES = /* @__PURE__ */ new Set([
    "bundle-shape",
    "patient-isolation",
    "resource-identity",
    "duplicate-resource-identity",
    "duplicate-full-url",
    "full-url",
    "full-url-identity",
    "invalid-reference",
    "broken-reference",
    "provenance-coverage",
    "non-finite-number",
    "null-element",
    "empty-string",
    "empty-array",
    "empty-object"
  ]);
  function mappingFailureText(value) {
    if (!value || typeof value !== "object") return "";
    const diagnostic = value;
    const stages = {
      "mapper-input": "\u8F38\u5165\u8CC7\u6599\u6574\u7406",
      "bundle-build": "FHIR \u7D44\u88DD",
      "bundle-validation": "FHIR \u5B8C\u6574\u6027\u6AA2\u67E5"
    };
    const stage = diagnostic.stage;
    if (!stage || !Object.hasOwn(stages, stage)) return "";
    const kind = ERROR_KINDS.find((name) => name === diagnostic.kind) ?? "Unknown";
    const checks = Array.isArray(diagnostic.checks) ? [...new Set(diagnostic.checks.filter((code) => VALIDATION_CODES.has(code)))].sort() : [];
    return `\u8A3A\u65B7\uFF1A${stages[stage]}\uFF0F${kind}${checks.length ? `\uFF0F${checks.join(", ")}` : ""}\u3002`;
  }

  // src/popup-model.ts
  function buildMedcloudFilename(maskedId, capturedAt, version, partial = false) {
    const pad = (value) => String(value).padStart(2, "0");
    const capturedDate = `${capturedAt.getFullYear()}${pad(capturedAt.getMonth() + 1)}${pad(capturedAt.getDate())}`;
    const privacySafeId = maskMediCloudIdentifier(maskedId);
    const normalizedId = privacySafeId.trim().replace(/[Xx*＊•●．・]/g, "X");
    const safeId = (normalizedId || "unknown").replace(/[^A-Za-z0-9_-]/g, "_");
    const safeVersion = String(version || "unknown").replace(/[^A-Za-z0-9._-]/g, "_");
    return `medcloud-${safeId}-${capturedDate}-v${safeVersion}${partial ? "-partial" : ""}.json`;
  }
  function buildMedcloudRawFilename(maskedId, capturedAt, version) {
    return buildMedcloudFilename(maskedId, capturedAt, version).replace(/^medcloud-/, "medcloud-raw-");
  }
  function normalizeWizardStep(step) {
    if (!Number.isFinite(step)) return 1;
    return Math.max(1, Math.min(3, Math.trunc(step)));
  }
  var RESOURCE_LABELS = {
    Patient: "\u75C5\u4EBA\u8CC7\u6599",
    Encounter: "\u5C31\u91AB\u7D00\u9304",
    Condition: "\u8A3A\u65B7\u7D00\u9304",
    Observation: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C",
    DiagnosticReport: "\u6AA2\u67E5\u5831\u544A",
    ServiceRequest: "\u6AA2\u67E5\u5B89\u6392",
    ImagingStudy: "\u5F71\u50CF\u6AA2\u67E5",
    MedicationRequest: "\u7528\u85E5\u7D00\u9304",
    MedicationDispense: "\u9818\u85E5\u7D00\u9304",
    Procedure: "\u8655\u7F6E\u7D00\u9304",
    DocumentReference: "\u75C5\u6B77\u6458\u8981",
    AllergyIntolerance: "\u904E\u654F\u7D00\u9304",
    Immunization: "\u9810\u9632\u63A5\u7A2E",
    Basic: "\u5176\u4ED6\u81E8\u5E8A\u7D00\u9304",
    Organization: "\u91AB\u7642\u9662\u6240",
    Provenance: "\u8CC7\u6599\u4F86\u6E90\u7D00\u9304"
  };
  var DETAIL_LABEL_ORDER = [
    "\u75C5\u4EBA\u8CC7\u6599",
    "\u5C31\u91AB\u7D00\u9304",
    "\u8A3A\u65B7\u7D00\u9304",
    "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C",
    "\u6AA2\u67E5\u5831\u544A",
    "\u6AA2\u67E5\u5B89\u6392",
    "\u5F71\u50CF\u6AA2\u67E5",
    "\u7528\u85E5\u7D00\u9304",
    "\u9818\u85E5\u7D00\u9304",
    "\u8655\u7F6E\u7D00\u9304",
    "\u75C5\u6B77\u6458\u8981",
    "\u904E\u654F\u7D00\u9304",
    "\u9810\u9632\u63A5\u7A2E",
    "\u5176\u4ED6\u81E8\u5E8A\u7D00\u9304",
    "\u91AB\u7642\u9662\u6240",
    "\u8CC7\u6599\u4F86\u6E90\u7D00\u9304",
    "\u5176\u4ED6\u8CC7\u6599"
  ];
  function formatResultElapsed(milliseconds) {
    if (!Number.isFinite(milliseconds) || Number(milliseconds) < 0) return "";
    const seconds = Math.max(0, Math.round(Number(milliseconds) / 1e3));
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return remainingSeconds > 0 ? `${minutes}m ${remainingSeconds}s` : `${minutes}m`;
  }
  function formatResultAge(completedAt, now = Date.now()) {
    if (!Number.isFinite(completedAt) || Number(completedAt) <= 0) return "";
    const elapsed = Math.max(0, now - Number(completedAt));
    const minutes = Math.floor(elapsed / 6e4);
    if (minutes < 1) return "\u525B\u525B\u5B8C\u6210";
    if (minutes < 60) return `${minutes} \u5206\u9418\u524D`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} \u5C0F\u6642\u524D`;
    return `${Math.floor(hours / 24)} \u5929\u524D`;
  }
  var ERROR_REASON = {
    HTTP_0: "\u4F86\u6E90\u7AEF\u9EDE\u6C92\u6709\u56DE\u61C9",
    HTTP_413: "\u4F86\u6E90\u56DE\u61C9\u8D85\u904E\u53EF\u5B89\u5168\u8655\u7406\u7684\u5927\u5C0F",
    INVALID_JSON: "\u4F86\u6E90\u56DE\u50B3\u5167\u5BB9\u4E0D\u662F\u6709\u6548 JSON",
    HTTP_401: "\u96F2\u7AEF\u75C5\u6B77\u767B\u5165\u5DF2\u5931\u6548\u6216\u6388\u6B0A\u672A\u901A\u904E\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u96F2\u7AEF\u75C5\u6B77\uFF0C\u5FC5\u8981\u6642\u91CD\u65B0\u767B\u5165\uFF0C\u518D\u91CD\u8A66\u3002",
    INVALID_RESPONSE: "\u4F86\u6E90\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u7248\u672C\u4E0D\u7B26",
    NO_VALID_ROWS: "\u4F86\u6E90\u5217\u5168\u90E8\u4E0D\u7B26\u5408\u76EE\u524D\u652F\u63F4\u683C\u5F0F",
    ADAPTER_EXCEPTION: "\u6A21\u7D44\u8F49\u63DB\u7A0B\u5F0F\u767C\u751F\u4F8B\u5916",
    MAPPER_INPUT_EXCEPTION: "\u6B64\u6A21\u7D44\u8CC7\u6599\u6574\u7406\u5931\u6557\uFF1B\u5176\u9918\u53EF\u7528\u8CC7\u6599\u5DF2\u4FDD\u7559\uFF0C\u539F\u59CB\u56DE\u61C9\u53EF\u4E0B\u8F09",
    FHIR_MODULE_EXCEPTION: "\u6B64\u6A21\u7D44 FHIR \u7D44\u88DD\u5931\u6557\uFF1B\u5176\u9918\u53EF\u7528\u8CC7\u6599\u5DF2\u4FDD\u7559\uFF0C\u539F\u59CB\u56DE\u61C9\u53EF\u4E0B\u8F09",
    FHIR_MODULE_CONFLICT: "\u6B64\u6A21\u7D44\u8207\u5176\u4ED6\u8CC7\u6599\u5408\u4F75\u6642\u767C\u751F\u885D\u7A81\uFF1B\u5DF2\u4FDD\u7559\u53EF\u7D44\u88DD\u7684\u8CC7\u6599\uFF0C\u539F\u59CB\u56DE\u61C9\u53EF\u4E0B\u8F09"
  };
  var WARNING_REASON = {
    "access-restricted": () => "\u76EE\u524D\u91AB\u4E8B\u4EBA\u54E1\u5361\u7121\u6B64\u9805\u8CC7\u6599\u6B0A\u9650",
    "http-error": () => "\u4F86\u6E90\u7AEF\u9EDE\u53D6\u5F97\u5931\u6557",
    "invalid-json": () => "\u4F86\u6E90\u56DE\u50B3\u5167\u5BB9\u4E0D\u662F\u6709\u6548 JSON",
    "invalid-response": () => "\u4F86\u6E90\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u7248\u672C\u4E0D\u7B26",
    "invalid-row": (count) => `${count} \u500B\u4F86\u6E90\u6B04\u4F4D\u4E0D\u7B26\u5408\u76EE\u524D\u652F\u63F4\u683C\u5F0F`,
    "unknown-field": (count) => `\u4F86\u6E90\u51FA\u73FE ${count} \u500B\u5C1A\u672A\u652F\u63F4\u7684\u65B0\u6B04\u4F4D\uFF08\u5DF2\u5FFD\u7565\uFF09`,
    "missing-source-field": (count) => `\u4F86\u6E90\u7F3A\u5C11\u9810\u671F\u6B04\u4F4D\uFF08${count} \u9805\u63D0\u9192\uFF1B\u53EF\u7528\u5167\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u9700\u6838\u5C0D\u539F\u59CB\u8CC7\u6599\uFF09`,
    "invalid-date": (count) => `${count} \u500B\u65E5\u671F\u7121\u6CD5\u8FA8\u8B58`,
    "missing-clinical-content": (count) => `${count} \u7B46\u7F3A\u5C11\u53EF\u8F49\u63DB\u7684\u81E8\u5E8A\u5167\u5BB9`,
    "source-document-unavailable": (count) => `\u4F86\u6E90\u672A\u63D0\u4F9B ${count} \u4EFD\u9810\u671F\u7684\u51FA\u9662\u75C5\u6458\uFF1B\u4F4F\u9662\u7D00\u9304\u672C\u8EAB\u5DF2\u5B8C\u6210\u8F49\u63DB`,
    "source-medication-duration-unavailable": (count) => `\u4F86\u6E90\u672A\u63D0\u4F9B ${count} \u7B46\u7528\u85E5\u5929\u6578\uFF1B\u7528\u85E5\u7D00\u9304\u5DF2\u4FDD\u7559\uFF0C\u5929\u6578\u7DAD\u6301\u672A\u77E5`,
    [POSSIBLE_DUPLICATE_SOURCE_OBSERVATION_TAG]: (count) => `${count} \u7B46\u6AA2\u9A57\u7D50\u679C\u5728\u4F86\u6E90\u91CD\u8907\u51FA\u73FE\uFF08\u540C\u65E5\u3001\u540C\u9662\u6240\u3001\u540C\u5831\u544A\u3001\u540C\u9805\u76EE\u3001\u540C\u6578\u503C\uFF09\uFF0C\u5DF2\u5168\u90E8\u4FDD\u7559\u4F9B\u6838\u5C0D`,
    [POSSIBLE_DUPLICATE_SOURCE_RESOURCE_TAG]: (count) => `${count} \u7B46\u7D00\u9304\u5728\u4F86\u6E90\u91CD\u8907\u51FA\u73FE\uFF0C\u5DF2\u5168\u90E8\u4FDD\u7559\u4F9B\u6838\u5C0D`,
    "viewer-descriptor-mismatch": (count) => `${count} \u4EFD\u5F71\u50CF\u6AA2\u8996\u8CC7\u8A0A\u672A\u5B8C\u6574\u8F49\u63DB\uFF1B\u5176\u9918\u8CC7\u6599\u4ECD\u53EF\u4F7F\u7528`
  };
  var DATA_QUALITY_NOTICE_CODES = /* @__PURE__ */ new Set([
    POSSIBLE_DUPLICATE_SOURCE_OBSERVATION_TAG,
    POSSIBLE_DUPLICATE_SOURCE_RESOURCE_TAG
  ]);
  function isDataQualityNoticeCode(code) {
    return DATA_QUALITY_NOTICE_CODES.has(code);
  }
  var SOURCE_DATA_NOTICE_CODES = /* @__PURE__ */ new Set([
    ...SOURCE_DATA_WARNING_CODES,
    ...DATA_QUALITY_NOTICE_CODES
  ]);
  var FHIR_ISSUE_REASON = {
    "bundle-shape": "FHIR Bundle \u7D50\u69CB\u4E0D\u5B8C\u6574",
    "non-finite-number": "FHIR \u6578\u503C\u4E0D\u662F\u53EF\u4EA4\u63DB\u7684\u6709\u9650\u6578\u5B57",
    "null-element": "FHIR \u9663\u5217\u542B null \u9805\u76EE",
    "empty-string": "FHIR \u6B04\u4F4D\u542B\u4E0D\u5408\u6CD5\u7684\u7A7A\u5B57\u4E32",
    "empty-array": "FHIR \u6B04\u4F4D\u542B\u4E0D\u5408\u6CD5\u7684\u7A7A\u9663\u5217",
    "empty-object": "FHIR \u6B04\u4F4D\u542B\u4E0D\u5408\u6CD5\u7684\u7A7A\u7269\u4EF6",
    "resource-identity": "FHIR \u8CC7\u6E90\u7F3A\u5C11\u5408\u6CD5\u8B58\u5225",
    "duplicate-resource-identity": "\u8F49\u63DB\u5F8C\u767C\u751F\u91CD\u8907\u8CC7\u6E90\u8B58\u5225",
    "invalid-reference": "FHIR \u8CC7\u6E90\u542B\u683C\u5F0F\u4E0D\u5408\u6CD5\u7684\u53C3\u7167",
    "broken-reference": "FHIR \u8CC7\u6E90\u53C3\u7167\u7684\u76EE\u6A19\u4E0D\u5B58\u5728",
    "unresolved-reference": "FHIR \u8CC7\u6E90\u542B\u7121\u6CD5\u89E3\u6790\u7684\u53C3\u7167",
    "duplicate-full-url": "FHIR Bundle \u51FA\u73FE\u91CD\u8907 fullUrl",
    "full-url": "FHIR Bundle \u9805\u76EE\u7F3A\u5C11\u5408\u6CD5 fullUrl",
    "full-url-identity": "FHIR resource id \u8207 fullUrl \u4E0D\u4E00\u81F4",
    "resource-identity-mismatch": "FHIR resource id \u8207 fullUrl \u4E0D\u4E00\u81F4",
    "patient-isolation": "FHIR Bundle \u6DF7\u5165\u4E0D\u540C\u75C5\u4EBA\u7684\u8CC7\u6599",
    "provenance-coverage": "FHIR \u8CC7\u6E90\u7F3A\u5C11\u8CC7\u6599\u4F86\u6E90\u7D00\u9304",
    "viewer-descriptor-mismatch": "\u5F71\u50CF\u6AA2\u8996\u8CC7\u8A0A\u672A\u5B8C\u6574\u8F49\u63DB"
  };
  function positiveInteger(value) {
    return Number.isInteger(value) && Number(value) > 0 ? Number(value) : 0;
  }
  function moduleReason(module) {
    const dropped = positiveInteger(module.droppedResourceCount);
    const retainedInvalid = positiveInteger(module.retainedInvalidResourceCount);
    const errorCode = typeof module.errorCode === "string" ? module.errorCode : "";
    if (errorCode) return ERROR_REASON[errorCode] ?? `\u6A21\u7D44\u8655\u7406\u5931\u6557\uFF08${errorCode}\uFF09`;
    if (dropped > 0) {
      const issueReason = (module.issueCodes ?? []).map((code) => FHIR_ISSUE_REASON[code]).find(Boolean);
      return `${dropped} \u7B46\u8F49\u63DB\u5F8C\u672A\u7D0D\u5165${issueReason ? `\uFF1A${issueReason}` : ""}`;
    }
    if (retainedInvalid > 0) {
      const issueReason = (module.issueCodes ?? []).map((code) => FHIR_ISSUE_REASON[code]).find(Boolean);
      return `${retainedInvalid} \u7B46\u8CC7\u6E90\u5DF2\u4FDD\u7559\u4F46\u672A\u901A\u904E FHIR \u9A57\u8B49${issueReason ? `\uFF1A${issueReason}` : ""}`;
    }
    const warnings = Object.entries(module.warningCounts ?? {}).filter(
      ([code, count]) => !isSourceDataWarningCode(code) && !isDataQualityNoticeCode(code) && positiveInteger(count) > 0
    ).sort(([left], [right]) => left.localeCompare(right));
    const actionableWarning = warnings.map(([code, count]) => WARNING_REASON[code]?.(positiveInteger(count))).find(Boolean);
    if (actionableWarning) return actionableWarning;
    const warningCount = positiveInteger(module.warningCount);
    if (warningCount > 0) return `\u6709 ${warningCount} \u500B\u683C\u5F0F\u8B66\u544A`;
    return module.completeness === "failed" ? "\u6B64\u6A21\u7D44\u6C92\u6709\u7522\u751F\u53EF\u7528\u8CC7\u6599\uFF0C\u4E14\u7A0B\u5F0F\u672A\u63D0\u4F9B\u932F\u8AA4\u539F\u56E0\uFF08\u9700\u4FEE\u6B63\uFF09" : "\u8F49\u63DB\u72C0\u614B\u70BA partial\uFF0C\u4F46\u7A0B\u5F0F\u672A\u63D0\u4F9B\u932F\u8AA4\u539F\u56E0\uFF08\u9700\u4FEE\u6B63\uFF09";
  }
  function moduleDiagnostic(module) {
    const parts = [module.sourceModule, module.completeness.toUpperCase()];
    const records = positiveInteger(module.sourceRecordCount);
    if (records > 0) parts.push(`RECORDS=${records}`);
    if (module.errorCode) parts.push(`ERROR=${module.errorCode}`);
    const warnings = Object.entries(module.warningCounts ?? {}).filter(([, count]) => positiveInteger(count) > 0).sort(([left], [right]) => left.localeCompare(right)).map(([code, count]) => `${code}:${positiveInteger(count)}`);
    if (warnings.length > 0) parts.push(`WARN=${warnings.join(",")}`);
    const dropped = positiveInteger(module.droppedResourceCount);
    if (dropped > 0) parts.push(`DROPPED=${dropped}`);
    const retainedInvalid = positiveInteger(module.retainedInvalidResourceCount);
    if (retainedInvalid > 0) parts.push(`RETAINED_INVALID=${retainedInvalid}`);
    if (module.issueCodes?.length) parts.push(`ISSUE=${[...module.issueCodes].sort().join(",")}`);
    if ((module.completeness === "partial" || module.completeness === "failed") && !module.errorCode && warnings.length === 0 && dropped === 0 && retainedInvalid === 0 && !module.issueCodes?.length) {
      parts.push("ERROR=MISSING_PARTIAL_DIAGNOSTIC");
    }
    return parts.join(" | ");
  }
  function affectedSourceRecords(module, allowedCodes) {
    return (module.warningLocations ?? []).filter((warning) => !allowedCodes || allowedCodes.has(warning.code)).map((warning) => {
      const documentRow = /^_cloudWildcatchDocuments\[(\d+)\]\.html$/.exec(warning.path);
      const sourceRow = /^robject\[(\d+)\](?:\.(.+))?$/.exec(warning.path);
      const label = documentRow ? `\u4F86\u6E90\u7B2C ${Number(documentRow[1]) + 1} \u7B46\uFF08robject[${documentRow[1]}]\uFF09\uFF1A\u51FA\u9662\u75C5\u6458\u672A\u7531\u4F86\u6E90\u63D0\u4F9B` : sourceRow ? `\u4F86\u6E90\u7B2C ${Number(sourceRow[1]) + 1} \u7B46\uFF08robject[${sourceRow[1]}]\uFF09${sourceRow[2] ? `\u6B04\u4F4D ${sourceRow[2]}` : ""}` : `\u4F86\u6E90\u4F4D\u7F6E ${warning.path}${warning.field ? `\uFF08\u6B04\u4F4D ${warning.field}\uFF09` : ""}`;
      return {
        kind: "source",
        label,
        diagnostic: `${warning.code} | PATH=${warning.path}`
      };
    });
  }
  function incompleteModuleDetails(moduleStatuses, droppedResources = [], retainedInvalidResources = []) {
    return (moduleStatuses ?? []).filter(
      (module) => module.completeness === "partial" || module.completeness === "failed"
    ).map((module) => {
      const conversionWarningCodes = new Set(
        Object.keys(module.warningCounts ?? {}).filter(
          (code) => !isSourceDataWarningCode(code) && !isDataQualityNoticeCode(code)
        )
      );
      const sourceWarnings = affectedSourceRecords(module, conversionWarningCodes);
      const dropped = droppedResources.filter((resource) => resource.sourceModule === module.sourceModule).map((resource) => ({
        kind: "dropped-resource",
        label: `${resource.resourceType}/${resource.id ?? "(\u7121 ID)"}`,
        diagnostic: [...resource.issueCodes].sort().join(",")
      }));
      const retainedInvalid = retainedInvalidResources.filter((resource) => resource.sourceModule === module.sourceModule).map((resource) => ({
        kind: "retained-invalid-resource",
        label: `${resource.resourceType}/${resource.id ?? "(\u7121 ID)"}`,
        diagnostic: [...resource.issueCodes].sort().join(",")
      }));
      return {
        sourceModule: module.sourceModule,
        label: MEDCLOUD_MODULE_LABELS[module.sourceModule] ?? module.sourceModule,
        completeness: module.completeness,
        reason: moduleReason(module),
        diagnostic: moduleDiagnostic(module),
        affectedRecords: [...sourceWarnings, ...retainedInvalid, ...dropped]
      };
    });
  }
  function sourceDataNoticeDetails(moduleStatuses) {
    return (moduleStatuses ?? []).flatMap((module) => {
      const warnings = Object.entries(module.warningCounts ?? {}).filter(
        ([code, count]) => SOURCE_DATA_NOTICE_CODES.has(code) && positiveInteger(count) > 0
      ).sort(([left], [right]) => left.localeCompare(right));
      if (warnings.length === 0) return [];
      const reason = warnings.map(([code, count]) => WARNING_REASON[code]?.(positiveInteger(count))).filter((value) => Boolean(value)).join("\uFF1B");
      return [{
        sourceModule: module.sourceModule,
        label: MEDCLOUD_MODULE_LABELS[module.sourceModule] ?? module.sourceModule,
        reason: reason || "\u4F86\u6E90\u8CC7\u6599\u6709\u9700\u4EBA\u5DE5\u6838\u5C0D\u7684\u5167\u5BB9",
        diagnostic: [
          module.sourceModule,
          "SOURCE_DATA_WARNING",
          `WARN=${warnings.map(([code, count]) => `${code}:${positiveInteger(count)}`).join(",")}`
        ].join(" | "),
        affectedRecords: affectedSourceRecords(module, SOURCE_DATA_NOTICE_CODES)
      }];
    });
  }
  function partialDiagnosticText(summary, version) {
    const modules = incompleteModuleDetails(
      summary.moduleStatuses,
      summary.droppedResources,
      summary.retainedInvalidResources
    );
    const lines = [
      `Cloud Wildcatch v${version} partial conversion diagnostics`,
      ...modules.flatMap((module) => [
        `${module.label}: ${module.diagnostic}`,
        ...module.affectedRecords.map(
          (record) => `  ${record.kind === "source" ? "SOURCE" : record.kind === "retained-invalid-resource" ? "RETAINED_INVALID_RESOURCE" : "DROPPED_RESOURCE"} ${record.label} | ${record.diagnostic}`
        )
      ])
    ];
    const dropped = positiveInteger(summary.droppedResourceCount);
    if (dropped > 0) lines.push(`TOTAL_DROPPED=${dropped}`);
    const retainedInvalid = Math.max(
      positiveInteger(summary.retainedInvalidResourceCount),
      summary.retainedInvalidResources?.length ?? 0
    );
    if (retainedInvalid > 0) lines.push(`TOTAL_RETAINED_INVALID=${retainedInvalid}`);
    if (summary.validation.valid === false) {
      const issues = Array.isArray(summary.validation.issues) ? summary.validation.issues : [];
      const codes = [...new Set(issues.map((issue) => issue?.code).filter((code) => typeof code === "string" && Object.hasOwn(FHIR_ISSUE_REASON, code)))].sort();
      lines.push(`BUNDLE_VALIDATION_FAILED${codes.length ? ` | ISSUES=${codes.join(",")}` : ""}`);
    }
    if (modules.length === 0 && dropped === 0 && retainedInvalid === 0 && summary.validation.valid !== false) {
      lines.push("NO_PARTIAL_DETAILS");
    }
    return lines.join("\n");
  }
  function presentBundleSummary(summary) {
    const resourceEntries = Object.entries(summary.resourceCounts).filter(([, count]) => Number.isFinite(count) && count > 0).sort(([left], [right]) => left.localeCompare(right));
    const totalResources = resourceEntries.reduce((sum, [, count]) => sum + count, 0);
    const detailCountByLabel = /* @__PURE__ */ new Map();
    for (const [resourceType, count] of resourceEntries) {
      const label = RESOURCE_LABELS[resourceType] ?? "\u5176\u4ED6\u8CC7\u6599";
      detailCountByLabel.set(label, (detailCountByLabel.get(label) ?? 0) + count);
    }
    const detailRows = DETAIL_LABEL_ORDER.filter((label) => detailCountByLabel.has(label)).map((label) => ({ label, count: detailCountByLabel.get(label) }));
    const incompleteModuleCount = summary.moduleStatuses.filter(
      (module) => module.completeness === "partial" || module.completeness === "failed"
    ).length;
    const droppedResourceCount = Number.isFinite(summary.droppedResourceCount) ? Math.max(0, Number(summary.droppedResourceCount)) : 0;
    const retainedInvalidResourceCount = Math.max(
      positiveInteger(summary.retainedInvalidResourceCount),
      summary.retainedInvalidResources?.length ?? 0
    );
    const retainedInvalidDisposition = summary.outputDisposition === "retained-invalid";
    const hasRetainedInvalid = summary.validation.valid === false || retainedInvalidDisposition || retainedInvalidResourceCount > 0;
    const incompleteModules = incompleteModuleDetails(
      summary.moduleStatuses,
      summary.droppedResources,
      summary.retainedInvalidResources
    );
    const sourceDataNotices = sourceDataNoticeDetails(summary.moduleStatuses);
    const sourceDataNoticeCount = sourceDataNotices.reduce((sum, notice) => {
      const module = summary.moduleStatuses.find(
        (status) => status.sourceModule === notice.sourceModule
      );
      return sum + Object.entries(module?.warningCounts ?? {}).reduce(
        (warningSum, [code, count]) => warningSum + (SOURCE_DATA_NOTICE_CODES.has(code) ? positiveInteger(count) : 0),
        0
      );
    }, 0);
    const hasIncompleteModules = incompleteModuleCount > 0 || droppedResourceCount > 0 || hasRetainedInvalid;
    const hasSourceDataNotices = sourceDataNotices.length > 0;
    const hasAuthorizationFailure = summary.moduleStatuses.some((module) => ["HTTP_401", "HTTP_403"].includes(module.errorCode ?? ""));
    const authorizationNote = "\u96F2\u7AEF\u75C5\u6B77\u767B\u5165\u5DF2\u5931\u6548\u6216\u6388\u6B0A\u672A\u901A\u904E\uFF0C\u7121\u6CD5\u53D6\u5F97\u90E8\u5206\u6216\u5168\u90E8\u8CC7\u6599\u3002\u8ACB\u91CD\u65B0\u6574\u7406\u96F2\u7AEF\u75C5\u6B77\u9801\u9762\uFF0C\u5FC5\u8981\u6642\u91CD\u65B0\u767B\u5165\uFF0C\u78BA\u8A8D\u7528\u85E5\u6216\u6AA2\u9A57\u9801\u80FD\u8F09\u5165\u5F8C\u518D\u91CD\u8A66\u3002\u53EA reload \u64F4\u5145\u529F\u80FD\u4E0D\u6703\u66F4\u65B0\u767B\u5165\u72C0\u614B\u3002";
    const allModulesFailed = summary.moduleStatuses.length > 0 && summary.moduleStatuses.every((module) => module.completeness === "failed");
    const problemScope = incompleteModules.length > 0 ? `\u554F\u984C\u4F86\u6E90\uFF1A${incompleteModules.map((module) => module.label).join("\u3001")}\u3002` : "";
    const sourceNoticeScope = sourceDataNotices.length > 0 ? `\u63D0\u9192\u4F86\u6E90\uFF1A${sourceDataNotices.map((notice) => notice.label).join("\u3001")}\u3002` : "";
    return {
      // A completed result already passed the builder's patient-isolation and
      // JSON creation boundaries. Validation state controls the warning copy,
      // never whether the user may retrieve or deliver that completed result.
      canDownload: true,
      hasAuthorizationFailure,
      hasRetainedInvalid,
      hasIncompleteModules,
      hasSourceDataNotices,
      hasVisibleIssues: hasIncompleteModules || hasSourceDataNotices,
      incompleteModuleCount,
      sourceDataNoticeCount,
      droppedResourceCount,
      retainedInvalidResourceCount,
      totalResources,
      summaryText: hasAuthorizationFailure && allModulesFailed ? "\u672A\u53D6\u5F97\u81E8\u5E8A\u8CC7\u6599\uFF08\u6240\u6709\u8CC7\u6599\u4F86\u6E90\u5747\u5931\u6557\uFF09" : `\u5171 ${totalResources} \u7B46\u5065\u5EB7\u7D00\u9304`,
      issueTitle: hasAuthorizationFailure ? "\u96F2\u7AEF\u75C5\u6B77\u767B\u5165\uFF0F\u6388\u6B0A\u5931\u6557" : hasRetainedInvalid ? "FHIR \u9A57\u8B49\u5931\u6557" : hasIncompleteModules ? "\u90E8\u5206\u8CC7\u6599\u8F49\u63DB\u5931\u6557" : hasSourceDataNotices ? "\u4F86\u6E90\u8CC7\u6599\u63D0\u9192" : "",
      completenessNote: hasAuthorizationFailure ? `${authorizationNote}${allModulesFailed ? "\u672C\u6B21\u672A\u53D6\u5F97\u81E8\u5E8A\u8CC7\u6599\uFF0C\u4E0B\u8F09\u6A94\u50C5\u4F9B\u554F\u984C\u6392\u67E5\u3002" : "\u5DF2\u6210\u529F\u53D6\u5F97\u7684\u8CC7\u6599\u4ECD\u53EF\u4E0B\u8F09\u6216\u67E5\u770B\uFF1B\u6A94\u540D\u6A19\u793A partial\u3002"}${problemScope}` : hasRetainedInvalid ? `${problemScope}${retainedInvalidResourceCount > 0 ? `\u5176\u4E2D ${retainedInvalidResourceCount} \u7B46` : "\u90E8\u5206"}\u8CC7\u6E90\u5DF2\u4FDD\u7559\u4F46\u672A\u901A\u904E FHIR \u9A57\u8B49\uFF1B\u4ECD\u53EF\u4E0B\u8F09\u6216\u9001\u5230 MediPrisma\uFF0C\u4F7F\u7528\u6642\u8ACB\u6838\u5C0D\u3002\u9019\u4E0D\u662F\u5B8C\u5168\u901A\u904E\u9A57\u8B49\u7684 FHIR \u6A94\u6848\u3002${droppedResourceCount > 0 ? `\u53E6\u6709 ${droppedResourceCount} \u7B46\u56E0\u683C\u5F0F\u7121\u6CD5\u8F49\u63DB\u800C\u672A\u7D0D\u5165\u3002` : ""}` : hasIncompleteModules ? `${problemScope}${droppedResourceCount > 0 ? `\u5176\u4E2D ${droppedResourceCount} \u7B46\u56E0\u683C\u5F0F\u7121\u6CD5\u8F49\u63DB\u800C\u672A\u7D0D\u5165\u3002` : ""}\u53EF\u7528\u8CC7\u6599\u4ECD\u53EF\u4E0B\u8F09\u6216\u65BC MediPrisma \u67E5\u770B\uFF1B\u6A94\u540D\u6703\u6A19\u793A partial\uFF0C\u5931\u6557\u539F\u56E0\u8207\u4F4D\u7F6E\u5217\u65BC\u4E0B\u65B9\u3002` : hasSourceDataNotices ? `${sourceNoticeScope}\u8F49\u63DB\u5DF2\u5B8C\u6210\uFF1B\u9019\u662F\u4F86\u6E90\u8CC7\u6599\u672C\u8EAB\u7684\u7F3A\u6F0F\u6216\u7570\u5E38\uFF0C\u4E0D\u6703\u52A0\u4E0A partial \u6A94\u540D\uFF0C\u4E5F\u4E0D\u964D\u4F4E\u8F49\u63DB\u5B8C\u6574\u5EA6\u3002` : "",
      incompleteModules,
      sourceDataNotices,
      detailRows
    };
  }
  function acquisitionErrorMessage(error) {
    const candidate = error;
    const code = typeof candidate?.code === "string" ? candidate.code : "";
    const name = typeof candidate?.name === "string" ? candidate.name : "";
    const sourceModule = typeof candidate?.sourceModule === "string" && /^IMUE\d{4}$/.test(candidate.sourceModule) ? candidate.sourceModule : "";
    const modulePrefix = sourceModule ? `${sourceModule} ` : "";
    const diagnostic = (value) => `\uFF08\u932F\u8AA4\u4EE3\u78BC\uFF1A${value}\uFF09`;
    switch (code) {
      case "ALL_MODULES_FAILED": {
        const failures = Array.isArray(candidate?.moduleFailures) ? candidate.moduleFailures.slice(0, Object.keys(MEDCLOUD_MODULE_LABELS).length).filter((item) => item && typeof item === "object" && typeof item.sourceModule === "string" && Object.hasOwn(MEDCLOUD_MODULE_LABELS, item.sourceModule) && ["authorization", "network", "format", "too-large"].includes(item.reason)) : [];
        const reasons = [...new Set(failures.map((item) => item.reason))];
        const actions = {
          authorization: "\u767B\u5165\uFF0F\u6388\u6B0A\u672A\u901A\u904E\uFF1A\u8ACB\u91CD\u65B0\u767B\u5165\u96F2\u7AEF\u75C5\u6B77\u3002",
          network: "\u7DB2\u8DEF\u6216\u5065\u4FDD\u670D\u52D9\u8ACB\u6C42\u5931\u6557\uFF1A\u8ACB\u78BA\u8A8D\u9023\u7DDA\u3001\u7A0D\u5F8C\u91CD\u8A66\u3002",
          format: "\u4F86\u6E90\u683C\u5F0F\u4E0D\u76F8\u5BB9\uFF1A\u8ACB\u78BA\u8A8D\u96F2\u7AEF\u75C5\u6B77\u529F\u80FD\u9801\u53EF\u6B63\u5E38\u67E5\u770B\uFF1B\u4ECD\u767C\u751F\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u4F86\u6E90\u540D\u7A31\u4F9B\u76F8\u5BB9\u6027\u6AA2\u67E5\u3002",
          "too-large": "\u4F86\u6E90\u56DE\u61C9\u8D85\u904E\u5B89\u5168\u5927\u5C0F\u9650\u5236\uFF1A\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u4F86\u6E90\u540D\u7A31\u3002"
        };
        const sources = failures.length ? `\u4F86\u6E90\uFF1A${failures.map((item) => MEDCLOUD_MODULE_LABELS[item.sourceModule]).join("\u3001")}\u3002` : "";
        return `\u6240\u6709\u8CC7\u6599\u4F86\u6E90\u5747\u672A\u6210\u529F\u53D6\u5F97\uFF0C\u4E0D\u4EE3\u8868\u75C5\u4EBA\u6C92\u6709\u75C5\u6B77\uFF1B\u5C1A\u672A\u9001\u5230\u91AB\u6790\u3002${sources}${reasons.length ? reasons.map((reason) => actions[reason]).join("") : "\u539F\u56E0\u5C1A\u672A\u78BA\u8A8D\uFF0C\u8ACB\u78BA\u8A8D\u529F\u80FD\u9801\u80FD\u8F09\u5165\uFF1B\u4ECD\u5931\u6557\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u3002"}\uFF08\u932F\u8AA4\u4EE3\u78BC\uFF1AALL_MODULES_FAILED\uFF09`;
      }
      case "BACKGROUND_JOB_TIMEOUT":
        return "\u9019\u6B21\u8655\u7406\u5DF2\u903E\u6642\u4E26\u505C\u6B62\uFF0C\u672A\u9001\u51FA\u672A\u5B8C\u6210\u7684\u8CC7\u6599\u3002\u8ACB\u4FDD\u6301\u76EE\u524D\u75C5\u4EBA\u9801\u9762\u958B\u555F\uFF0C\u78BA\u8A8D\u7DB2\u8DEF\u5F8C\u91CD\u8A66\uFF08\u932F\u8AA4\u4EE3\u78BC\uFF1ABACKGROUND_JOB_TIMEOUT\uFF09\u3002";
      case "NOT_MEDCLOUD":
        return "\u76EE\u524D\u5206\u9801\u4E0D\u662F\u96F2\u7AEF\u75C5\u6B77\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u5F8C\u518D\u8A66\u3002";
      case "PATIENT_CONTEXT_UNAVAILABLE":
        return `\u9801\u9762\u5DF2\u958B\u555F\uFF0C\u4F46\u5C1A\u672A\u5075\u6E2C\u5230\u552F\u4E00\u7684\u76EE\u524D\u75C5\u4EBA ${diagnostic(code)}\uFF1B\u8ACB\u78BA\u8A8D\u8B80\u5361\u5B8C\u6210\u4E14\u75C5\u4EBA\u8CC7\u6599\u5DF2\u986F\u793A\u3002`;
      case "PATIENT_IDENTIFIER_UNREADABLE":
        return `\u96F2\u6293\u7121\u6CD5\u8FA8\u8B58\u9801\u9762\u7684\u75C5\u4EBA\u8B49\u865F\u6216\u906E\u7F69\u904E\u591A ${diagnostic(code)}\uFF1B\u5C1A\u672A\u958B\u59CB\u6293\u53D6\u3002\u4E0D\u9650\u672C\u570B\u8EAB\u5206\u8B49\uFF0C\u5C45\u7559\u8B49\uFF0F\u7D71\u4E00\u8B49\u865F\u4EA6\u53EF\u4F7F\u7528\u3002\u8ACB\u78BA\u8A8D\u8B80\u5361\u5B8C\u6210\u3001\u91CD\u65B0\u6574\u7406\u5F8C\u91CD\u8A66\uFF1B\u4ECD\u5931\u6557\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u8B49\u865F\u985E\u578B\uFF0C\u52FF\u63D0\u4F9B\u5B8C\u6574\u8B49\u865F\u3002`;
      case "PATIENT_CONTEXT_AMBIGUOUS":
        return `\u9801\u9762\u540C\u6642\u986F\u793A\u4E0D\u540C\u75C5\u4EBA\uFF0C\u7121\u6CD5\u5B89\u5168\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA ${diagnostic(code)}\uFF1B\u672A\u958B\u59CB\u6293\u53D6\uFF0C\u8ACB\u91CD\u65B0\u9032\u5165\u6B63\u78BA\u75C5\u4EBA\u7684\u96F2\u7AEF\u75C5\u6B77\u5F8C\u91CD\u8A66\u3002`;
      case "PATIENT_PROBE_FAILED":
        return `\u96F2\u6293\u8B80\u53D6\u75C5\u4EBA\u9801\u9762\u5931\u6557\u6216\u903E\u6642 ${diagnostic(code)}\uFF1B\u672A\u958B\u59CB\u6293\u53D6\uFF0C\u8ACB\u91CD\u65B0\u6574\u7406\u96F2\u7AEF\u75C5\u6B77\u5F8C\u518D\u9EDE Logo\u3002\u82E5\u6301\u7E8C\u5931\u6557\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u3002`;
      case "PATIENT_CONTEXT_CHANGED":
        return `\u53D6\u5F97\u671F\u9593\u75C5\u4EBA\u5DF2\u5207\u63DB ${diagnostic(code)}\uFF1B\u672C\u6B21\u7D50\u679C\u5DF2\u4F5C\u5EE2\uFF0C\u8ACB\u78BA\u8A8D\u75C5\u4EBA\u5F8C\u91CD\u8A66\u3002`;
      case "AUTHORIZATION_UNAVAILABLE":
        return `\u5DF2\u5075\u6E2C\u5230\u75C5\u4EBA\uFF0C\u4F46\u5C1A\u672A\u53D6\u5F97\u53EF\u7528\u6388\u6B0A ${diagnostic(code)}\uFF1B\u9019\u4E0D\u4EE3\u8868\u672A\u767B\u5165\uFF0C\u5C1A\u672A\u6293\u53D6\u6216\u9001\u51FA\u75C5\u6B77\u3002\u8ACB\u5728\u75C5\u4EBA\u8CC7\u6599\u986F\u793A\u5F8C\u958B\u555F\u5C1A\u672A\u8F09\u5165\u7684\u7528\u85E5\uFF0F\u6AA2\u9A57\u529F\u80FD\u9801\uFF0C\u518D\u9EDE Logo\uFF1B\u4ECD\u5931\u6557\u8ACB\u91CD\u65B0\u767B\u5165\u3002\u5DF2\u5FEB\u53D6\u7684\u9801\u9762\u53CD\u8986\u9EDE\u91CD\u8A66\u4E0D\u6703\u6539\u5584\uFF1B\u6301\u7E8C\u767C\u751F\u8ACB\u56DE\u5831\u4EE3\u78BC\u3002`;
      case "AUTHORIZATION_PATIENT_NOT_READY":
        return `\u6388\u6B0A\u8ACB\u6C42\u65E9\u65BC\u75C5\u4EBA\u8CC7\u6599\u986F\u793A ${diagnostic(code)}\uFF1B\u70BA\u907F\u514D\u7528\u5230\u4E0D\u540C\u75C5\u4EBA\u7684\u6388\u6B0A\uFF0C\u5DF2\u505C\u6B62\uFF0C\u672A\u6293\u53D6\u6216\u9001\u51FA\u75C5\u6B77\u3002\u8ACB\u91CD\u65B0\u767B\u5165\uFF0C\u7B49\u75C5\u4EBA\u8CC7\u6599\u986F\u793A\u5F8C\u958B\u555F\u5C1A\u672A\u8F09\u5165\u7684\u529F\u80FD\u9801\u518D\u8A66\uFF1B\u82E5\u91CD\u8907\u767C\u751F\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\uFF0C\u4E0D\u9700\u63D0\u4F9B\u8B49\u865F\u6216\u75C5\u6B77\u3002`;
      case "AUTHORIZATION_EXPIRED":
        return `\u5148\u524D\u53D6\u5F97\u7684\u6388\u6B0A\u5DF2\u904E\u671F ${diagnostic(code)}\uFF1B\u672A\u9001\u51FA\u8CC7\u6599\u3002\u8ACB\u91CD\u65B0\u767B\u5165\u96F2\u7AEF\u75C5\u6B77\uFF0C\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u8207\u529F\u80FD\u9801\u53EF\u8F09\u5165\u5F8C\u518D\u9EDE Logo\uFF1B\u53EA\u91CD\u8F09\u64F4\u5145\u529F\u80FD\u4E0D\u6703\u66F4\u65B0\u767B\u5165\u6388\u6B0A\u3002`;
      case "AUTHORIZATION_FAILED":
        return `${modulePrefix}\u5065\u4FDD API \u62D2\u7D55\u76EE\u524D\u6388\u6B0A ${diagnostic(code)}\u3002\u9801\u9762\u53EF\u80FD\u4ECD\u986F\u793A\u5DF2\u767B\u5165\uFF1B\u8ACB\u5148\u91CD\u65B0\u6574\u7406\uFF0C\u82E5\u4ECD\u5931\u6557\u518D\u91CD\u65B0\u767B\u5165\u3002`;
      case "RESPONSE_SHAPE_INVALID":
        return `${modulePrefix}\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u683C\u5F0F\u4E0D\u7B26 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u6A21\u7D44\u540D\u7A31\u3002`;
      case "CAPTURE_INJECTION_FAILED":
        return `\u64F4\u5145\u529F\u80FD\u7121\u6CD5\u5728\u76EE\u524D\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\u555F\u52D5\u64F7\u53D6\u7A0B\u5F0F ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u8A72\u5206\u9801\u5F8C\u518D\u8A66\u3002`;
      case "CAPTURE_RESULT_MISSING":
        return `\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\u6C92\u6709\u56DE\u50B3\u64F7\u53D6\u7D50\u679C ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u5206\u9801\u8207\u64F4\u5145\u529F\u80FD\u5F8C\u518D\u8A66\u3002`;
      case "CAPTURE_FAILED":
        return `${modulePrefix}\u8CC7\u6599\u8ACB\u6C42\u672A\u5B8C\u6210 ${diagnostic(code)}\uFF1B\u8ACB\u78BA\u8A8D\u7DB2\u8DEF\u8207\u5206\u9801\u4ECD\u958B\u555F\u5F8C\u518D\u8A66\u3002`;
      case "SOURCE_ENVELOPE_INVALID":
        return `${modulePrefix}\u8CC7\u6599\u5C01\u88DD\u9A57\u8B49\u5931\u6557 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u6A21\u7D44\u540D\u7A31\u3002`;
      case "NO_MODULE_DATA":
        return `\u96F2\u7AEF\u75C5\u6B77\u6C92\u6709\u56DE\u50B3\u4EFB\u4F55\u53EF\u8655\u7406\u6A21\u7D44 ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u5F8C\u91CD\u8A66\u3002`;
      case "MODULE_ADAPTATION_FAILED":
        return `${modulePrefix}\u8CC7\u6599\u8F49\u63DB\u5931\u6557 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u6A21\u7D44\u540D\u7A31\u3002`;
      case "FHIR_MAPPING_FAILED":
        return `FHIR \u7D44\u88DD\u6216\u5B8C\u6574\u6027\u6AA2\u67E5\u5931\u6557 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u932F\u8AA4\u4EE3\u78BC\u3002${mappingFailureText(candidate?.mappingFailure)}`;
      default:
        if (name === "PatientContextChangedError") {
          return `\u53D6\u5F97\u671F\u9593\u75C5\u4EBA\u5DF2\u5207\u63DB ${diagnostic("PATIENT_CONTEXT_CHANGED")}\uFF1B\u672C\u6B21\u7D50\u679C\u5DF2\u4F5C\u5EE2\uFF0C\u8ACB\u78BA\u8A8D\u75C5\u4EBA\u5F8C\u91CD\u8A66\u3002`;
        }
        return `\u80CC\u666F\u8655\u7406\u767C\u751F\u672A\u5206\u985E\u932F\u8AA4 ${diagnostic("BACKGROUND_JOB_FAILED")}\uFF1B\u9019\u4E0D\u4EE3\u8868\u672A\u767B\u5165\uFF0C\u8ACB\u91CD\u65B0\u6574\u7406\u5206\u9801\u5F8C\u518D\u8A66\uFF0C\u82E5\u6301\u7E8C\u767C\u751F\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u3002`;
    }
  }

  // src/mediprisma-settings.ts
  var MEDIPRISMA_DESTINATION_KEY = "cloud-wildcatch:mediprisma-destination-v1";
  function normalizeMediPrismaDestination(raw) {
    if (!raw.trim()) return MEDIPRISMA_APP_URL;
    const url = new URL(raw.trim());
    if (!isAllowedMediPrismaAppUrl(url.href) || url.search || url.hash || url.username || url.password) {
      throw new Error("\u8ACB\u8F38\u5165 https://mediprisma.tw/app/ \u6216 https://mediprisma.tw/app-hmc/\uFF0C\u4E0D\u9700\u586B\u5BEB\u53C3\u6578\u3002");
    }
    return `${url.origin}${url.pathname.replace(/\/$/, "")}/`;
  }
  async function readMediPrismaDestination() {
    const stored = await chrome.storage.local?.get(MEDIPRISMA_DESTINATION_KEY);
    const value = stored?.[MEDIPRISMA_DESTINATION_KEY];
    if (value === void 0) return MEDIPRISMA_APP_URL;
    if (typeof value !== "string") throw new Error("\u63A5\u6536\u7DB2\u5740\u8A2D\u5B9A\u7121\u6548\uFF0C\u8ACB\u91CD\u65B0\u5132\u5B58\u8A2D\u5B9A\u3002");
    return normalizeMediPrismaDestination(value);
  }
  async function saveMediPrismaDestination(raw) {
    const destination = normalizeMediPrismaDestination(raw);
    await chrome.storage.local.set({ [MEDIPRISMA_DESTINATION_KEY]: destination });
    return destination;
  }

  // src/mediprisma-permission.ts
  async function requestMediPrismaPermission(runId) {
    const manifest = chrome.runtime.getManifest();
    const declared = manifest.host_permissions ?? [];
    const optionalDeclared = manifest.optional_host_permissions ?? [];
    const required = MEDIPRISMA_ORIGIN_PATTERNS.filter((pattern) => declared.includes(pattern));
    const optional = MEDIPRISMA_ORIGIN_PATTERNS.filter(
      (pattern) => optionalDeclared.includes(pattern)
    );
    if (required.length === 0 && optional.length === 0) {
      return {
        granted: false,
        reason: "\u76EE\u524D\u8F09\u5165\u7684\u64F4\u5145\u529F\u80FD\u9084\u6C92\u6709 MediPrisma \u6B0A\u9650\u8A2D\u5B9A\uFF0C\u8ACB\u5230 chrome://extensions \u91CD\u65B0\u8F09\u5165\u5F8C\u518D\u8A66\u3002"
      };
    }
    const armPromise = chrome.runtime.sendMessage({
      type: ARM_MEDIPRISMA_HANDOFF,
      runId
    });
    if (required.length > 0) {
      const armed = await armPromise.catch(() => void 0);
      return armed?.ok ? { granted: true } : {
        granted: false,
        reason: armed?.error || "\u76EE\u524D\u7121\u6CD5\u6E96\u5099\u5728 MediPrisma \u67E5\u770B\u3002"
      };
    }
    const disarm = async () => {
      await armPromise.catch(() => void 0);
      await chrome.runtime.sendMessage({ type: DISARM_MEDIPRISMA_HANDOFF }).catch(() => void 0);
    };
    try {
      const granted = await chrome.permissions.request({
        origins: [...optional]
      });
      if (!granted) {
        await disarm();
        return {
          granted: false,
          reason: "\u5C1A\u672A\u5141\u8A31 MediPrisma \u7DB2\u7AD9\u5B58\u53D6\uFF1B\u5065\u5EB7\u7D00\u9304\u6C92\u6709\u9001\u51FA\u3002"
        };
      }
      const armed = await armPromise;
      if (!armed?.ok) {
        return {
          granted: false,
          reason: armed?.error || "\u76EE\u524D\u7121\u6CD5\u6E96\u5099\u5728 MediPrisma \u67E5\u770B\u3002"
        };
      }
      return { granted: true };
    } catch {
      await disarm();
      return {
        granted: false,
        reason: "Chrome \u7121\u6CD5\u986F\u793A MediPrisma \u6B0A\u9650\u8981\u6C42\uFF1B\u5065\u5EB7\u7D00\u9304\u6C92\u6709\u9001\u51FA\u3002"
      };
    }
  }

  // src/async-timeout.ts
  var AsyncTimeoutError = class extends Error {
    constructor() {
      super("ASYNC_OPERATION_TIMED_OUT");
      this.name = "AsyncTimeoutError";
    }
  };
  function withTimeout(operation, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timeoutId = globalThis.setTimeout(() => {
        reject(new AsyncTimeoutError());
      }, timeoutMs);
      void Promise.resolve(operation).then(
        (value) => {
          globalThis.clearTimeout(timeoutId);
          resolve(value);
        },
        (error) => {
          globalThis.clearTimeout(timeoutId);
          reject(error);
        }
      );
    });
  }

  // src/source/medcloud.ts
  var MEDCLOUD_ORIGIN = "https://medcloud2.nhi.gov.tw";
  var MEDCLOUD_MODULES = MEDCLOUD_CAPTURE_MODULES;
  var MediCloudAcquisitionError = class extends Error {
    constructor(code, sourceModule) {
      super(code);
      this.code = code;
      this.sourceModule = sourceModule;
      this.name = "MediCloudAcquisitionError";
    }
    code;
    sourceModule;
  };
  var PATIENT_CONTEXT_HMAC_KEY = "cloud-wildcatch:patient-context-hmac-key-v1";
  var patientContextHmacKeyPromise = null;
  function randomPatientContextHmacKey() {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/u, "");
  }
  async function readOrCreatePatientContextHmacKey() {
    const stored = await chrome.storage.session.get(PATIENT_CONTEXT_HMAC_KEY);
    const existing = stored[PATIENT_CONTEXT_HMAC_KEY];
    if (typeof existing === "string" && /^[A-Za-z0-9_-]{43}$/u.test(existing)) {
      return existing;
    }
    const created = randomPatientContextHmacKey();
    await chrome.storage.session.set({ [PATIENT_CONTEXT_HMAC_KEY]: created });
    return created;
  }
  async function getPatientContextHmacKey() {
    if (!patientContextHmacKeyPromise) {
      const create = () => readOrCreatePatientContextHmacKey();
      const pending = typeof navigator !== "undefined" && navigator.locks ? navigator.locks.request(
        PATIENT_CONTEXT_HMAC_KEY,
        create
      ) : create();
      patientContextHmacKeyPromise = pending;
      void pending.catch(() => {
        patientContextHmacKeyPromise = null;
      });
    }
    return patientContextHmacKeyPromise;
  }
  async function probeMediCloudPatient(tabId) {
    try {
      const patientContextHmacKey = await withTimeout(getPatientContextHmacKey(), 3e3);
      const results = await withTimeout(chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: captureMediCloudInPage,
        args: [{ origin: MEDCLOUD_ORIGIN, runId: crypto.randomUUID(), patientContextHmacKey, modules: [], probeOnly: true }]
      }), 3e3);
      const result = results[0]?.result;
      if (result?.ok && result.patient) return { ok: true, patientContextHash: result.patientContextHash, ...result.patient };
      if (result && !result.ok && ["NOT_MEDCLOUD", "PATIENT_CONTEXT_UNAVAILABLE", "PATIENT_IDENTIFIER_UNREADABLE", "PATIENT_CONTEXT_AMBIGUOUS"].includes(result.code)) {
        return { ok: false, code: result.code };
      }
      return { ok: false, code: "PATIENT_PROBE_FAILED" };
    } catch {
      return { ok: false, code: "PATIENT_PROBE_FAILED" };
    }
  }
  async function captureMediCloudInPage(request) {
    const fatalState = { result: null };
    const fail = (code, sourceModule) => {
      const result = {
        ok: false,
        code,
        ...sourceModule && /^IMUE\d{4}$/.test(sourceModule) ? { sourceModule } : {}
      };
      if (code === "PATIENT_CONTEXT_CHANGED" || code === "CAPTURE_CANCELLED") {
        fatalState.result ??= result;
        for (const controller of captureState.controllers) controller.abort();
      }
      return result;
    };
    if (location.origin !== request.origin || !location.pathname.startsWith("/imu/")) {
      return fail("NOT_MEDCLOUD");
    }
    const CAPTURE_REGISTRY_KEY = "__cloudWildcatchCaptureRegistryV1";
    const CLINICAL_RESPONSE_LIMIT_BYTES = 5e7;
    const MODULE_REQUEST_TIMEOUT_MS = 3e4;
    const API_CONCURRENCY = request.apiConcurrency === 15 ? 15 : request.apiConcurrency === 12 ? 12 : 3;
    const VIEWER_REQUEST_TIMEOUT_MS = 15e3;
    const OVERALL_CAPTURE_TIMEOUT_MS = 3 * 6e4;
    const pageWindow = window;
    const registry = pageWindow[CAPTURE_REGISTRY_KEY] instanceof Map ? pageWindow[CAPTURE_REGISTRY_KEY] : /* @__PURE__ */ new Map();
    pageWindow[CAPTURE_REGISTRY_KEY] = registry;
    const supersededState = registry.get(request.runId);
    if (supersededState) {
      supersededState.cancelled = true;
      for (const controller of supersededState.controllers ?? []) controller.abort();
    }
    const captureState = {
      controllers: /* @__PURE__ */ new Set(),
      cancelled: false,
      completedModules: 0,
      totalModules: request.modules.length,
      moduleAcquisition: []
    };
    registry.set(request.runId, captureState);
    const captureDeadline = Date.now() + OVERALL_CAPTURE_TIMEOUT_MS;
    const originalFetch = window.fetch;
    const fetchText = async (input, init, timeoutMs, maxBytes) => {
      if (captureState.cancelled) throw new DOMException("Capture cancelled", "AbortError");
      const remainingMs = captureDeadline - Date.now();
      if (remainingMs <= 0) throw new DOMException("Capture deadline exceeded", "TimeoutError");
      const controller = new AbortController();
      captureState.controllers.add(controller);
      const timer = window.setTimeout(
        () => controller.abort(new DOMException("Request timed out", "TimeoutError")),
        Math.max(1, Math.min(timeoutMs, remainingMs))
      );
      try {
        const response = await originalFetch.call(window, input, {
          ...init,
          signal: controller.signal
        });
        const retryAfter = response.headers.get("Retry-After")?.trim();
        const retryAfterMs = retryAfter ? /^\d+$/.test(retryAfter) ? Number(retryAfter) * 1e3 : Date.parse(retryAfter) - Date.now() : NaN;
        const retryMetadata = Number.isFinite(retryAfterMs) ? { retryAfterMs: Math.max(0, retryAfterMs) } : {};
        const declaredLength = Number(response.headers.get("content-length"));
        if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
          controller.abort();
          return { status: response.status, ok: response.ok, text: "", tooLarge: true };
        }
        if (!response.body) {
          return { status: response.status, ok: response.ok, text: "", tooLarge: false, ...retryMetadata };
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        const parts = [];
        let totalBytes = 0;
        while (true) {
          const chunk = await reader.read();
          if (chunk.done) break;
          totalBytes += chunk.value.byteLength;
          if (totalBytes > maxBytes) {
            await reader.cancel().catch(() => void 0);
            controller.abort();
            return { status: response.status, ok: response.ok, text: "", tooLarge: true };
          }
          parts.push(decoder.decode(chunk.value, { stream: true }));
        }
        parts.push(decoder.decode());
        return { status: response.status, ok: response.ok, text: parts.join(""), tooLarge: false, ...retryMetadata };
      } finally {
        window.clearTimeout(timer);
        captureState.controllers.delete(controller);
      }
    };
    let activeRequests = 0;
    const requestWaiters = [];
    let checkPatientContext = async () => true;
    const limitedFetchText = async (input, init, timeoutMs, maxBytes) => {
      if (activeRequests >= API_CONCURRENCY) {
        await new Promise((resolve) => requestWaiters.push(resolve));
      } else {
        activeRequests += 1;
      }
      try {
        if (captureState.cancelled || fatalState.result) throw new DOMException("Capture stopped", "AbortError");
        if (checkPatientContext && !await checkPatientContext()) throw new DOMException("Patient changed", "AbortError");
        if (captureState.cancelled || fatalState.result) throw new DOMException("Capture stopped", "AbortError");
        const response = await fetchText(input, init, timeoutMs, maxBytes);
        if (checkPatientContext && !await checkPatientContext()) throw new DOMException("Patient changed", "AbortError");
        if (captureState.cancelled || fatalState.result) throw new DOMException("Capture stopped", "AbortError");
        return response;
      } finally {
        const next = requestWaiters.shift();
        if (next) next();
        else activeRequests -= 1;
      }
    };
    const waitForRetry = async (delayMs) => {
      if (captureState.cancelled || fatalState.result) throw new DOMException("Capture stopped", "AbortError");
      const controller = new AbortController();
      captureState.controllers.add(controller);
      let timer;
      try {
        await new Promise((resolve, reject) => {
          controller.signal.addEventListener("abort", () => reject(new DOMException("Capture stopped", "AbortError")), { once: true });
          timer = window.setTimeout(resolve, delayMs);
        });
      } finally {
        window.clearTimeout(timer);
        captureState.controllers.delete(controller);
      }
    };
    const boundedFetchText = async (input, init, timeoutMs, maxBytes) => {
      const maxAttempts = request.viewerRequest ? 1 : 3;
      for (let attempt = 0; ; attempt += 1) {
        let response;
        let failure;
        try {
          response = await limitedFetchText(input, init, timeoutMs, maxBytes);
        } catch (error) {
          failure = error;
        }
        if (captureState.cancelled || fatalState.result) throw new DOMException("Capture stopped", "AbortError");
        const retryable = !response || !response.tooLarge && [408, 429, 500, 502, 503, 504].includes(response.status);
        const delayMs = Math.max(
          750 * 2 ** attempt,
          response && [429, 503].includes(response.status) ? response.retryAfterMs ?? 0 : 0
        );
        if (!retryable || attempt + 1 >= maxAttempts || Date.now() + delayMs >= captureDeadline) {
          if (response) return response;
          throw failure;
        }
        await waitForRetry(delayMs);
      }
    };
    try {
      let patchedOpen2 = function(method, url, ...rest) {
        authorizationUrls.set(this, isAuthorizationSource(url));
        originalOpen.apply(this, [method, url, ...rest]);
      }, patchedSetRequestHeader2 = function(name, value) {
        if (authorizationUrls.get(this) && name.toLowerCase() === "authorization") captureAuthorization(value);
        originalSetRequestHeader.call(this, name, value);
      }, patchedFetch2 = function(input, init) {
        const headers = new Headers(input instanceof Request ? input.headers : void 0);
        new Headers(init?.headers).forEach((value, name) => headers.set(name, value));
        if (isAuthorizationSource(input instanceof Request ? input.url : String(input))) captureAuthorization(headers.get("authorization"));
        return originalFetch.call(window, input, init);
      };
      var patchedOpen = patchedOpen2, patchedSetRequestHeader = patchedSetRequestHeader2, patchedFetch = patchedFetch2;
      let identityFailure = "PATIENT_CONTEXT_UNAVAILABLE";
      const readPatientIdentity = () => {
        identityFailure = "PATIENT_CONTEXT_UNAVAILABLE";
        const roots = Array.from(document.querySelectorAll(
          ".member-info, .IMQ-info, .patient-info, .patient-data, [class*='memberInfo'], [class*='patient-info']"
        ));
        const visibleRoots = roots.filter((root) => root.getClientRects().length > 0 || Array.from(root.querySelectorAll(".idno, .name")).some((field) => field.getClientRects().length > 0));
        const candidates = visibleRoots.slice(0, 50).flatMap((root) => {
          const text = (value) => (value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
          const field = (selector) => text(root.querySelector(selector)?.textContent);
          const rootText = text(root.textContent);
          const label = /^(?:身分證(?:統一編)?號(?:碼)?|身份證號(?:碼)?|統一證號|居留證號(?:碼)?|護照號(?:碼)?|證號)\s*[:：]?\s*/;
          const labelled = /(?:身分證(?:統一編)?號(?:碼)?|身份證號(?:碼)?|統一證號|居留證號(?:碼)?|護照號(?:碼)?|證號)\s*[:：]\s*([A-Z0-9*•●.・]{6,32})(?![A-Z0-9*•●.・])/i.exec(rootText)?.[1];
          if (root.querySelector(".idno") && !field(".idno") && !labelled) return [];
          const structuredId = (field(".idno") || labelled || "").replace(label, "").trim();
          const inlineIdentity = /^([A-Z0-9*•●.・]{6,32})\s+(男|女|男性|女性|其他|未知|male|female)$/i.exec(structuredId);
          const identifier = inlineIdentity?.[1] ?? structuredId;
          const known = /\b([A-Z][A-Z0-9][0-9X*•●.・]{8})(?![A-Z0-9*•●.・])/i;
          const match = structuredId ? /^(?=.{6,32}$)(?=.*\d)[A-Z0-9*•●.・]+$/i.test(identifier) ? identifier : void 0 : known.exec(rootText)?.[1];
          if (!match) {
            if (rootText) identityFailure = "PATIENT_IDENTIFIER_UNREADABLE";
            return [];
          }
          const idToken = match.toUpperCase().replace(/[*•●.・]/g, "X");
          const masked = /[*•●.・]/.test(match) || idToken.slice(2).includes("X");
          if (masked && idToken.replace(/X/g, "").length < 6) {
            identityFailure = "PATIENT_IDENTIFIER_UNREADABLE";
            return [];
          }
          const structuredName = field(".name");
          const name = structuredName ? text(structuredName.replace(/^(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*/, "")) : /(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*([^\s｜|,，;；]{2,8})/.exec(rootText)?.[1] ?? "";
          const rawBirth = field(".birth") || /(?:出生年月日|出生日期|生日)\s*[:：]?\s*(\d{2,4}[\/.\-年]\d{1,2}[\/.\-月]\d{1,2})/.exec(rootText)?.[1] || "";
          const birthMatch = /(\d{2,4})[\/.\-年](\d{1,2})[\/.\-月](\d{1,2})/.exec(rawBirth);
          let birth = text(rawBirth.replace(/^(?:出生年月日|出生日期|生日)\s*[:：]?\s*/, ""));
          if (birthMatch) {
            let year = Number(birthMatch[1]);
            if (birthMatch[1].length <= 3 && year > 0) year += 1911;
            const month = Number(birthMatch[2]), day = Number(birthMatch[3]);
            const date = new Date(Date.UTC(year, month - 1, day));
            if (date.getUTCFullYear() === year && date.getUTCMonth() + 1 === month && date.getUTCDate() === day) {
              birth = String(year).padStart(4, "0") + "-" + String(month).padStart(2, "0") + "-" + String(day).padStart(2, "0");
            }
          }
          const rawSex = text((field(".sex") || inlineIdentity?.[2] || /(?:生理性別|性別)\s*[:：]?\s*(男|女|其他|未知|male|female)/i.exec(rootText)?.[1] || (labelled ? /[A-Z0-9*•●.・]{6,32}\s+(男|女|男性|女性|其他|未知|male|female)(?=\s|$)/i.exec(rootText)?.[1] : "") || "").replace(/^(?:生理性別|性別)\s*[:：]?\s*/, "")).toLowerCase();
          const sex = ["\u7537", "\u7537\u6027", "male"].includes(rawSex) ? "male" : ["\u5973", "\u5973\u6027", "female"].includes(rawSex) ? "female" : rawSex;
          const context = [idToken, masked ? name : "", masked ? birth : "", masked ? sex : ""].join("\n");
          return [{ context, idToken, sourceId: match.toUpperCase(), name, birth, sex, visible: root.getClientRects().length > 0 }];
        });
        const preferred = candidates.some((candidate) => candidate.visible) ? candidates.filter((candidate) => candidate.visible) : candidates;
        const unique = new Map(preferred.map((candidate) => [candidate.context, candidate]));
        if (unique.size > 1) identityFailure = "PATIENT_CONTEXT_AMBIGUOUS";
        return unique.size === 1 ? unique.values().next().value : null;
      };
      const patientContextText = () => readPatientIdentity()?.context ?? null;
      const AUTH_READER_KEY = "__cloudWildcatchReadAuthorizationV1";
      if (request.installObserver) {
        if (typeof pageWindow[AUTH_READER_KEY] !== "function") {
          let cached = null;
          let lastFailure = "AUTHORIZATION_UNAVAILABLE";
          let missingTimer;
          let expiryTimer;
          const invalidateOnContextChange = () => {
            if (!cached) return;
            const context = patientContextText();
            if (context && context !== cached.context) cached = null;
            if (context) {
              window.clearTimeout(missingTimer);
              missingTimer = void 0;
            } else if (missingTimer === void 0) missingTimer = window.setTimeout(() => {
              if (!patientContextText()) cached = null;
              missingTimer = void 0;
            }, 1e3);
          };
          const observer = new window.MutationObserver(invalidateOnContextChange);
          observer.observe(document, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["class", "style", "hidden"] });
          const expiresAt = (bearer) => {
            const maximum = Date.now() + 30 * 6e4;
            try {
              const payload = bearer.replace(/^Bearer\s+/i, "").split(".")[1];
              if (!payload) return maximum;
              const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
              const exp = JSON.parse(atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "="))).exp;
              return typeof exp === "number" && Number.isFinite(exp) ? Math.min(maximum, exp * 1e3) : maximum;
            } catch {
              return maximum;
            }
          };
          const trusted = (input) => {
            try {
              const url = new URL(String(input), location.href);
              return url.origin === request.origin && url.pathname.startsWith("/imu/api/");
            } catch {
              return false;
            }
          };
          const observe = (value) => {
            invalidateOnContextChange();
            const context = patientContextText();
            if (context && value && /^Bearer\s+\S+$/i.test(value.trim())) {
              cached = { context, bearer: value.trim(), expiresAt: expiresAt(value.trim()) };
              lastFailure = "AUTHORIZATION_UNAVAILABLE";
              window.clearTimeout(expiryTimer);
              expiryTimer = window.setTimeout(() => {
                if (cached && cached.expiresAt <= Date.now()) {
                  cached = null;
                  lastFailure = "AUTHORIZATION_EXPIRED";
                }
              }, Math.max(0, cached.expiresAt - Date.now()));
            } else if (!context && value && /^Bearer\s+\S+$/i.test(value.trim())) {
              lastFailure = "AUTHORIZATION_PATIENT_NOT_READY";
            }
          };
          const reader = (context, invalidate) => {
            if (invalidate && cached?.bearer === invalidate) {
              cached = null;
              lastFailure = "AUTHORIZATION_FAILED";
            }
            if (cached && cached.expiresAt <= Date.now()) {
              cached = null;
              lastFailure = "AUTHORIZATION_EXPIRED";
            }
            if (!cached || cached.context !== context || patientContextText() !== context) {
              cached = null;
              return "";
            }
            return cached.bearer;
          };
          reader.diagnostic = () => lastFailure;
          pageWindow[AUTH_READER_KEY] = reader;
          const clearObservedAuthorization = () => {
            cached = null;
            lastFailure = "AUTHORIZATION_UNAVAILABLE";
          };
          document.addEventListener("click", (event) => {
            const control = event.target instanceof window.Element ? event.target.closest("a,button") : null;
            if (/請換卡再按我|登出|切換病人/.test(control?.textContent ?? "")) clearObservedAuthorization();
          }, true);
          window.addEventListener("pagehide", () => {
            clearObservedAuthorization();
            observer.disconnect();
            window.clearTimeout(missingTimer);
            window.clearTimeout(expiryTimer);
          }, { once: true });
          const xhrUrls = /* @__PURE__ */ new WeakMap();
          const open = XMLHttpRequest.prototype.open;
          const setHeader = XMLHttpRequest.prototype.setRequestHeader;
          XMLHttpRequest.prototype.open = function(method, url, ...rest) {
            xhrUrls.set(this, trusted(url));
            return open.apply(this, [method, url, ...rest]);
          };
          XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
            if (xhrUrls.get(this) && name.toLowerCase() === "authorization") observe(value);
            return setHeader.call(this, name, value);
          };
          const fetch = window.fetch;
          window.fetch = function(input, init) {
            if (trusted(input instanceof Request ? input.url : String(input))) {
              const headers = new Headers(input instanceof Request ? input.headers : void 0);
              new Headers(init?.headers).forEach((value, name) => headers.set(name, value));
              observe(headers.get("authorization"));
            }
            return fetch.call(window, input, init);
          };
        }
        return { ok: true, patientContextHash: "", capturedAt: (/* @__PURE__ */ new Date()).toISOString(), modules: [] };
      }
      const readObservedAuthorization = (context, invalidate) => {
        const reader = pageWindow[AUTH_READER_KEY];
        return typeof reader === "function" ? reader(context, invalidate) : "";
      };
      const patientContextKeyBytes = Uint8Array.from(
        atob(request.patientContextHmacKey.replace(/-/g, "+").replace(/_/g, "/") + "="),
        (character) => character.charCodeAt(0)
      );
      const patientContextKey = await crypto.subtle.importKey(
        "raw",
        patientContextKeyBytes,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      const hashContext = async (value) => {
        const bytes = new TextEncoder().encode(`nhi-medcloud-patient-context-v1
${value}`);
        const digest = await crypto.subtle.sign("HMAC", patientContextKey, bytes);
        return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
      };
      const identity = readPatientIdentity();
      const contextBeforeText = identity?.context;
      if (!identity || !contextBeforeText) return fail(identityFailure);
      const patientContextHash = await hashContext(contextBeforeText);
      if (request.probeOnly) {
        const privacySafeId = identity.idToken.slice(0, Math.max(2, identity.idToken.length - 4)) + "XXXX";
        const maskedName = identity.name ? `${identity.name[0] ?? ""}O${identity.name.length > 2 ? identity.name.at(-1) ?? "" : ""}` : "";
        const maskedId = privacySafeId.replace(/X/g, "\u2022");
        const birth = /(\d{2,4})[\/.\-年](\d{1,2})[\/.\-月](\d{1,2})/.exec(identity.birth);
        let age = "";
        let birthDate = "";
        if (birth) {
          const yearToken = birth[1] ?? "";
          let year = Number(yearToken);
          if (yearToken.length <= 3 && year > 0) year += 1911;
          const month = Number(birth[2]);
          const day = Number(birth[3]);
          const candidate = new Date(Date.UTC(year, month - 1, day));
          if (candidate.getUTCFullYear() === year && candidate.getUTCMonth() + 1 === month && candidate.getUTCDate() === day) {
            const now2 = /* @__PURE__ */ new Date();
            let years = now2.getFullYear() - year;
            if (now2.getMonth() + 1 < month || now2.getMonth() + 1 === month && now2.getDate() < day) years -= 1;
            if (years >= 0 && years <= 150) {
              birthDate = `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
              age = `${years}\u6B72`;
            }
          }
        }
        const genderRaw = identity.sex.toLowerCase();
        const gender = genderRaw === "male" ? "\u7537" : genderRaw === "female" ? "\u5973" : genderRaw;
        const genderCode = genderRaw === "male" || genderRaw === "\u7537" || genderRaw === "\u7537\u6027" ? "male" : genderRaw === "female" || genderRaw === "\u5973" || genderRaw === "\u5973\u6027" ? "female" : genderRaw === "\u5176\u4ED6" ? "other" : "unknown";
        const display = [maskedName, age, gender, maskedId].filter(Boolean).join("  \xB7  ") || `\u75C5\u4EBA ${patientContextHash.slice(0, 8)}\u2026`;
        return {
          ok: true,
          patientContextHash,
          capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
          modules: [],
          patient: {
            display,
            identity: {
              maskedId: privacySafeId,
              sourceId: identity.sourceId,
              name: identity.name,
              ...birthDate ? { birthDate } : {},
              gender: genderCode
            }
          }
        };
      }
      checkPatientContext = async () => {
        let context = patientContextText();
        for (let attempt = 0; !context && attempt < 5 && !captureState.cancelled; attempt += 1) {
          await new Promise((resolve) => window.setTimeout(resolve, 100));
          context = patientContextText();
        }
        if (!context || await hashContext(context) !== patientContextHash || patientContextText() !== context) {
          fail("PATIENT_CONTEXT_CHANGED");
          return false;
        }
        return true;
      };
      const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
      const originalOpen = XMLHttpRequest.prototype.open;
      const authorizationUrls = /* @__PURE__ */ new WeakMap();
      const isAuthorizationSource = (input) => {
        try {
          const url = new URL(String(input), location.href);
          return url.origin === request.origin && url.pathname.startsWith("/imu/api/");
        } catch {
          return false;
        }
      };
      let resolveAuthorization;
      let authorization = readObservedAuthorization(contextBeforeText);
      const authorizationPromise = new Promise((resolve) => {
        resolveAuthorization = resolve;
      });
      const captureAuthorization = (value) => {
        const candidate = typeof value === "string" ? value.trim() : "";
        if (!authorization && patientContextText() === contextBeforeText && /^Bearer\s+\S+$/i.test(candidate)) {
          authorization = candidate;
          resolveAuthorization?.(candidate);
        }
      };
      const waitForAuthorization = async (timeoutMs) => {
        if (authorization) return authorization;
        return Promise.race([
          authorizationPromise,
          new Promise((resolve) => window.setTimeout(() => resolve(null), timeoutMs))
        ]);
      };
      const visibleRouteLinks = () => Array.from(document.querySelectorAll("a[href]")).filter((anchor) => {
        try {
          const url = new URL(anchor.href, location.href);
          return anchor.getClientRects().length > 0 && url.origin === request.origin && /^\/imu\/IMUE1000\//i.test(url.pathname);
        } catch {
          return false;
        }
      });
      let authorizationForRun = authorization || null;
      const originalPath = location.pathname;
      let changedRoute = false;
      const routePaths = Array.from(new Set(
        visibleRouteLinks().map((anchor) => new URL(anchor.href, location.href).pathname)
      ));
      const candidatePaths = [
        originalPath,
        ...routePaths.filter((path) => path !== originalPath)
      ].slice(0, 20);
      XMLHttpRequest.prototype.setRequestHeader = patchedSetRequestHeader2;
      XMLHttpRequest.prototype.open = patchedOpen2;
      window.fetch = patchedFetch2;
      try {
        for (const [index, routePath] of candidatePaths.entries()) {
          if (authorizationForRun) break;
          if (captureState.cancelled) break;
          const route = visibleRouteLinks().find(
            (anchor) => new URL(anchor.href, location.href).pathname === routePath
          );
          if (!route) continue;
          route.click();
          if (routePath !== originalPath) changedRoute = true;
          authorizationForRun = await waitForAuthorization(index === 0 ? 1500 : 750);
          if (authorizationForRun) break;
        }
      } finally {
        XMLHttpRequest.prototype.setRequestHeader = originalSetRequestHeader;
        XMLHttpRequest.prototype.open = originalOpen;
        window.fetch = originalFetch;
        if (changedRoute) {
          visibleRouteLinks().find((anchor) => new URL(anchor.href, location.href).pathname === originalPath)?.click();
        }
      }
      if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
      if (!authorizationForRun) {
        const reader = pageWindow[AUTH_READER_KEY];
        const code = typeof reader?.diagnostic === "function" ? reader.diagnostic() : "AUTHORIZATION_UNAVAILABLE";
        return fail(["AUTHORIZATION_PATIENT_NOT_READY", "AUTHORIZATION_EXPIRED", "AUTHORIZATION_FAILED"].includes(code) ? code : "AUTHORIZATION_UNAVAILABLE");
      }
      if (!await checkPatientContext()) {
        return fail("PATIENT_CONTEXT_CHANGED");
      }
      if (request.viewerRequest) {
        if (request.viewerRequest.expectedPatientContextHash !== patientContextHash) {
          return fail("PATIENT_CONTEXT_CHANGED");
        }
        const descriptor = request.viewerRequest.descriptor;
        const safePart = (value, maxLength) => {
          if (typeof value !== "string" || value.length > maxLength) return null;
          if (/[\u0000-\u001f\u007f@]/u.test(value)) return null;
          return value;
        };
        const iplCaseSeqNo = safePart(descriptor?.iplCaseSeqNo, 256);
        const readPos = safePart(descriptor?.readPos, 128);
        const fileType = safePart(descriptor?.fileType, 128);
        const fileQty = safePart(descriptor?.fileQty, 32);
        const feeYm = safePart(descriptor?.feeYm, 64);
        if (descriptor?.version !== 1 || !["IMUE0030", "IMUE0130"].includes(descriptor?.procId ?? "") || !iplCaseSeqNo || readPos === null || !["", "Y"].includes(descriptor?.ordMark ?? "invalid") || fileType === null || fileQty === null || feeYm === null) {
          return fail("VIEWER_REQUEST_INVALID");
        }
        const normalizeRocFeeYm = (value) => {
          const digits = value.replace(/\D/g, "");
          if (digits.length === 5) {
            const month = Number(digits.slice(3, 5));
            return month >= 1 && month <= 12 ? digits : "";
          }
          if (digits.length >= 6) {
            const year = Number(digits.slice(0, 4));
            const month = Number(digits.slice(4, 6));
            if (month < 1 || month > 12) return "";
            return year > 1911 ? `${year - 1911}${digits.slice(4, 6)}` : digits.slice(0, 5);
          }
          return "";
        };
        const basicFeeYmFromResponse = (value) => {
          const candidates = [value];
          const keys = [
            "body",
            "data",
            "value",
            "basic_fee_ym",
            "basicFeeYm",
            "fee_ym",
            "feeYm"
          ];
          for (let index = 0; index < candidates.length && index < 16; index += 1) {
            const candidate = candidates[index];
            if (typeof candidate === "string" || typeof candidate === "number") {
              const normalized = normalizeRocFeeYm(String(candidate));
              if (normalized) return normalized;
              continue;
            }
            if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue;
            const record = candidate;
            for (const key of keys) if (key in record) candidates.push(record[key]);
          }
          return "";
        };
        const isTrustedViewerUrl = (value) => {
          if (typeof value !== "string" || value.length === 0 || value.length > 1e5) return false;
          try {
            const viewerUrl = new URL(value);
            return viewerUrl.protocol === "https:" && viewerUrl.port === "" && viewerUrl.username === "" && viewerUrl.password === "" && (viewerUrl.hostname === "nhi.gov.tw" || viewerUrl.hostname.endsWith(".nhi.gov.tw"));
          } catch {
            return false;
          }
        };
        let basicFeeYm = "";
        try {
          const basicFeeResponse = await boundedFetchText(
            new URL("/imu/api/imuecommon/imuecommon/basic-fee-ym", request.origin).toString(),
            {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: { Accept: "application/json", Authorization: authorizationForRun }
            },
            VIEWER_REQUEST_TIMEOUT_MS,
            2e5
          );
          if (basicFeeResponse.status === 401 || basicFeeResponse.status === 403) {
            return fail("AUTHORIZATION_FAILED");
          }
          if (basicFeeResponse.tooLarge) return fail("RESPONSE_TOO_LARGE");
          const text = basicFeeResponse.text;
          let value = text;
          try {
            value = JSON.parse(text);
          } catch {
            value = text;
          }
          basicFeeYm = basicFeeYmFromResponse(value);
        } catch {
          basicFeeYm = "";
        }
        const rowFeeYm = normalizeRocFeeYm(feeYm);
        const ordMark = descriptor.ordMark === "Y" && (!basicFeeYm || !rowFeeYm || Number(rowFeeYm) <= Number(basicFeeYm)) ? "Y" : "";
        const clientData = [iplCaseSeqNo, readPos, ordMark, fileType, fileQty].join("@");
        for (let attempt = 0; attempt < 3; attempt += 1) {
          if (attempt > 0) await new Promise((resolve) => window.setTimeout(resolve, 750));
          if (!await checkPatientContext()) {
            return fail("PATIENT_CONTEXT_CHANGED");
          }
          let response;
          try {
            response = await boundedFetchText(
              new URL("/imu/api/imuecommon/imuecommon/get-ctmri2", request.origin).toString(),
              {
                method: "POST",
                credentials: "include",
                cache: "no-store",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json;charset=UTF-8",
                  Authorization: authorizationForRun
                },
                body: JSON.stringify({ ProcID: descriptor.procId, ClientData: clientData })
              },
              VIEWER_REQUEST_TIMEOUT_MS,
              2e5
            );
          } catch {
            continue;
          }
          if (response.status === 401 || response.status === 403) {
            return fail("AUTHORIZATION_FAILED");
          }
          const text = response.text;
          if (response.ok && !response.tooLarge) {
            try {
              const parsed = JSON.parse(text);
              const viewerUrl = parsed.ctmri_url ?? parsed.body?.ctmri_url;
              if (isTrustedViewerUrl(viewerUrl)) {
                return {
                  ok: true,
                  capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
                  patientContextHash,
                  modules: [],
                  viewerUrl
                };
              }
            } catch {
            }
          }
          const retryable = response.ok || response.status === 408 || response.status === 425 || response.status === 429 || response.status >= 500;
          if (!retryable) break;
        }
        return fail("VIEWER_UNAVAILABLE");
      }
      const pad = (value) => String(value).padStart(2, "0");
      const now = /* @__PURE__ */ new Date();
      const clientDateTime = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
      const query = new URLSearchParams({ cli_datetime: clientDateTime, insert_log: "true" });
      const modules = new Array(request.modules.length);
      const captureModule = async (module) => {
        if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
        if (!await checkPatientContext()) {
          return fail("PATIENT_CONTEXT_CHANGED");
        }
        const url = new URL(module.datasetScope, request.origin);
        url.search = query.toString();
        let response;
        try {
          response = await boundedFetchText(
            url.toString(),
            {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: {
                Accept: "application/json",
                Authorization: authorizationForRun
              }
            },
            MODULE_REQUEST_TIMEOUT_MS,
            CLINICAL_RESPONSE_LIMIT_BYTES
          );
        } catch {
          response = { status: 0, ok: false, text: "", tooLarge: false };
        }
        if (response.status === 401) readObservedAuthorization(contextBeforeText, authorizationForRun);
        if (module.sourceModule === "IMUE0140") {
          if (!await checkPatientContext()) return fail("PATIENT_CONTEXT_CHANGED");
          let hepatitis = { status: 0, body: "" };
          try {
            const hepatitisUrl = new URL("/imu/api/imue0180/imue0180s01/hbcv-data", request.origin);
            hepatitisUrl.search = query.toString();
            const extra = await boundedFetchText(hepatitisUrl.toString(), {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: { Accept: "application/json", Authorization: authorizationForRun }
            }, MODULE_REQUEST_TIMEOUT_MS, CLINICAL_RESPONSE_LIMIT_BYTES);
            hepatitis = { status: extra.tooLarge ? 413 : extra.status, body: extra.ok && !extra.tooLarge ? extra.text : "" };
          } catch {
          }
          if (!await checkPatientContext()) return fail("PATIENT_CONTEXT_CHANGED");
          let combined = { _cloudWildcatchPrimaryBody: response.ok && !response.tooLarge ? response.text : "" };
          try {
            const primary = response.ok && !response.tooLarge ? JSON.parse(response.text) : null;
            if (primary && typeof primary === "object" && !Array.isArray(primary)) combined = primary;
          } catch {
          }
          combined._cloudWildcatchHepatitis = hepatitis;
          let combinedBody = JSON.stringify(combined);
          if (new TextEncoder().encode(combinedBody).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
            combined._cloudWildcatchHepatitis = { status: 413, body: "" };
            combinedBody = JSON.stringify(combined);
          }
          const combinedTooLarge = new TextEncoder().encode(combinedBody).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES;
          return {
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: response.tooLarge || combinedTooLarge ? 413 : response.status,
            body: combinedTooLarge ? "" : combinedBody
          };
        }
        if (response.status === 401) {
          readObservedAuthorization(contextBeforeText, authorizationForRun);
          return {
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 401,
            body: ""
          };
        }
        if (response.status === 403) {
          return {
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 403,
            body: ""
          };
        }
        if (response.tooLarge) {
          return {
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 413,
            body: ""
          };
        }
        let body = response.text;
        if (module.sourceModule === "IMUE0060" && response.ok) {
          if (!await checkPatientContext()) return fail("PATIENT_CONTEXT_CHANGED");
          let history = { status: 0, body: "" };
          try {
            const historyUrl = new URL("/imu/api/imue0060/imue0060s03/get-data", request.origin);
            historyUrl.search = query.toString();
            const result = await boundedFetchText(historyUrl.toString(), {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: { Accept: "application/json", Authorization: authorizationForRun }
            }, MODULE_REQUEST_TIMEOUT_MS, CLINICAL_RESPONSE_LIMIT_BYTES);
            history = { status: result.tooLarge ? 413 : result.status, body: result.ok && !result.tooLarge ? result.text : "" };
          } catch {
          }
          if (!await checkPatientContext()) return fail("PATIENT_CONTEXT_CHANGED");
          try {
            const parsed = JSON.parse(body);
            if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
              parsed._cloudWildcatchLabHistory = history;
              body = JSON.stringify(parsed);
              if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
                parsed._cloudWildcatchLabHistory = { status: 413, body: "" };
                body = JSON.stringify(parsed);
              }
            }
          } catch {
          }
        }
        if (module.sourceModule === "IMUE0070" && !response.ok) body = "";
        if (module.sourceModule === "IMUE0070" && response.ok) {
          try {
            const parsedBody = JSON.parse(body);
            const rows = Array.isArray(parsedBody.robject) ? parsedBody.robject : [];
            const documentJobs = rows.flatMap((row, rowIndex) => {
              const handle = typeof row?.mds_file === "string" ? row.mds_file.trim() : "";
              return handle ? [{ rowIndex, handle }] : [];
            });
            const documentRowIndexes = documentJobs.map(({ rowIndex }) => rowIndex);
            const documents = new Array(documentJobs.length);
            const SHOW_XML_CONCURRENCY = 3;
            const SHOW_XML_TIMEOUT_MS = 3e4;
            const documentState = { nextJobIndex: 0, fatalError: null };
            const stopDocumentFetches = (error) => {
              if (documentState.fatalError) return;
              documentState.fatalError = error;
              fail(error, module.sourceModule);
            };
            const fetchDocumentWorker = async () => {
              while (!documentState.fatalError && !fatalState.result && !captureState.cancelled) {
                const jobIndex = documentState.nextJobIndex;
                documentState.nextJobIndex += 1;
                const job = documentJobs[jobIndex];
                if (!job) return;
                if (!await checkPatientContext()) {
                  stopDocumentFetches("PATIENT_CONTEXT_CHANGED");
                  return;
                }
                const detailNow = /* @__PURE__ */ new Date();
                const detailTimestamp = `${detailNow.getFullYear()}${pad(detailNow.getMonth() + 1)}${pad(detailNow.getDate())}${pad(detailNow.getHours())}${pad(detailNow.getMinutes())}${pad(detailNow.getSeconds())}${String(Math.floor(detailNow.getMilliseconds() / 10)).padStart(2, "0")}${String(detailNow.getMilliseconds()).padStart(3, "0")}`;
                try {
                  const detailResponse = await boundedFetchText(
                    new URL("/imu/api/imue0070/imue0070s01/show-xml", request.origin).toString(),
                    {
                      method: "POST",
                      credentials: "include",
                      cache: "no-store",
                      headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json;charset=UTF-8",
                        Authorization: authorizationForRun
                      },
                      body: JSON.stringify({ FileName: `${job.handle}@${detailTimestamp}` })
                    },
                    SHOW_XML_TIMEOUT_MS,
                    CLINICAL_RESPONSE_LIMIT_BYTES
                  );
                  if (detailResponse.status === 401) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 401 };
                    continue;
                  }
                  if (detailResponse.status === 403) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 403 };
                    continue;
                  }
                  if (detailResponse.tooLarge) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 413 };
                    continue;
                  }
                  const detailBody = detailResponse.text;
                  if (!await checkPatientContext()) {
                    stopDocumentFetches("PATIENT_CONTEXT_CHANGED");
                    return;
                  }
                  let html = "";
                  if (detailResponse.ok) {
                    try {
                      const detail = JSON.parse(detailBody);
                      const returnedHtml = typeof detail.html === "string" ? detail.html : detail.body?.html;
                      if (typeof returnedHtml === "string") html = returnedHtml;
                    } catch {
                      html = "";
                    }
                  }
                  documents[jobIndex] = {
                    rowIndex: job.rowIndex,
                    status: detailResponse.status,
                    ...html ? { html } : {}
                  };
                } catch {
                  if (!documentState.fatalError) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 0 };
                  }
                }
              }
            };
            const documentWorkerCount = Math.min(
              SHOW_XML_CONCURRENCY,
              documentJobs.length
            );
            await Promise.all(
              Array.from({ length: documentWorkerCount }, () => fetchDocumentWorker())
            );
            if (documentState.fatalError) {
              return fail(documentState.fatalError, module.sourceModule);
            }
            for (const row of rows) {
              row.mds_file = null;
              row.mds_pdf_file = null;
            }
            parsedBody._cloudWildcatchDocumentsAttempted = true;
            parsedBody._cloudWildcatchDocumentRowIndexes = documentRowIndexes;
            parsedBody._cloudWildcatchDocuments = documents.filter(
              (document2) => document2 !== void 0
            );
            body = JSON.stringify(parsedBody);
            if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
              return {
                sourceModule: module.sourceModule,
                datasetScope: module.datasetScope,
                status: 413,
                body: ""
              };
            }
          } catch {
          }
        }
        if (module.sourceModule === "IMUE0130" && response.ok) {
          try {
            const parsedBody = JSON.parse(body);
            const rows = Array.isArray(parsedBody.robject) ? parsedBody.robject : [];
            const rowIndexes = rows.map((row, rowIndex) => row?.ctmri_mark === "Y" ? rowIndex : -1).filter((rowIndex) => rowIndex >= 0).slice(0, 200);
            const sourceValue = (value) => value === null || value === void 0 ? "" : String(value);
            const viewerRequests = rowIndexes.flatMap((rowIndex) => {
              const row = rows[rowIndex] ?? {};
              const iplCaseSeqNo = sourceValue(row.ipl_case_seq_no).trim();
              if (!iplCaseSeqNo) return [];
              return [{
                rowIndex,
                descriptor: {
                  version: 1,
                  procId: "IMUE0130",
                  iplCaseSeqNo,
                  readPos: sourceValue(row.read_pos),
                  ordMark: row.ord_mark === "Y" ? "Y" : "",
                  fileType: sourceValue(row.file_type),
                  fileQty: sourceValue(row.file_qty),
                  feeYm: sourceValue(row.fee_ym)
                }
              }];
            });
            parsedBody._cloudWildcatchViewerRequestsAttempted = true;
            parsedBody._cloudWildcatchViewerRequestRowIndexes = rowIndexes;
            parsedBody._cloudWildcatchViewerRequests = viewerRequests;
            body = JSON.stringify(parsedBody);
            if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
              return {
                sourceModule: module.sourceModule,
                datasetScope: module.datasetScope,
                status: 413,
                body: ""
              };
            }
          } catch {
          }
        }
        if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
          return { sourceModule: module.sourceModule, datasetScope: module.datasetScope, status: 413, body: "" };
        }
        return {
          sourceModule: module.sourceModule,
          datasetScope: module.datasetScope,
          status: response.status,
          body
        };
      };
      let nextModuleIndex = 0;
      const captureWorker = async () => {
        while (!captureState.cancelled && !fatalState.result) {
          const index = nextModuleIndex++;
          const module = request.modules[index];
          if (!module) return;
          const result = await captureModule(module);
          if ("ok" in result) {
            fatalState.result ??= result;
            for (const controller of captureState.controllers) controller.abort();
            return;
          }
          if (captureState.cancelled || fatalState.result) return;
          modules[index] = result;
          captureState.moduleAcquisition.push({
            sourceModule: result.sourceModule,
            httpStatus: result.status,
            bodyReceived: result.body.length > 0
          });
          captureState.completedModules += 1;
        }
      };
      await Promise.all(Array.from(
        { length: Math.min(API_CONCURRENCY, request.modules.length) },
        () => captureWorker()
      ));
      if (fatalState.result) return fatalState.result;
      if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
      if (!await checkPatientContext()) {
        return fail("PATIENT_CONTEXT_CHANGED");
      }
      return {
        ok: true,
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        patientContextHash,
        modules
      };
    } finally {
      for (const controller of captureState.controllers) controller.abort();
      if (registry.get(request.runId) === captureState) registry.delete(request.runId);
    }
  }
  function cancelMediCloudCaptureInPage(runId) {
    const registry = window["__cloudWildcatchCaptureRegistryV1"];
    if (!(registry instanceof Map)) return;
    const state = registry.get(runId);
    if (!state) return;
    state.cancelled = true;
    for (const controller of state.controllers ?? []) controller.abort();
  }
  async function cancelMediCloudCapture(tabId, runId) {
    if (!runId) return;
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      world: "MAIN",
      func: cancelMediCloudCaptureInPage,
      args: [runId]
    }).catch(() => void 0);
  }
  async function loadMediCloudEnvelopes(tabId, runId, apiConcurrency = 15) {
    let executionResults;
    try {
      const patientContextHmacKey = await withTimeout(getPatientContextHmacKey(), 3e3);
      executionResults = await withTimeout(chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: captureMediCloudInPage,
        args: [
          {
            origin: MEDCLOUD_ORIGIN,
            runId,
            patientContextHmacKey,
            apiConcurrency,
            modules: MEDCLOUD_MODULES.map(({ sourceModule, datasetScope }) => ({
              sourceModule,
              datasetScope
            }))
          }
        ]
      }), 195e3);
    } catch (error) {
      void withTimeout(cancelMediCloudCapture(tabId, runId), 2e3).catch(() => void 0);
      throw new MediCloudAcquisitionError(error instanceof AsyncTimeoutError ? "BACKGROUND_JOB_TIMEOUT" : "CAPTURE_INJECTION_FAILED");
    }
    const capture = executionResults[0]?.result;
    if (!capture) throw new MediCloudAcquisitionError("CAPTURE_RESULT_MISSING");
    if (!capture.ok) throw new MediCloudAcquisitionError(capture.code, capture.sourceModule);
    return capture.modules.map((module) => {
      const candidate = {
        schemaVersion: "1.0.0",
        sourceSystem: "nhi-medcloud",
        sourceModule: module.sourceModule,
        datasetScope: module.datasetScope,
        adapterVersion: MEDCLOUD_ADAPTER_VERSION,
        runId,
        capturedAt: capture.capturedAt,
        completeness: module.status >= 200 && module.status < 300 ? "complete" : module.status === 403 ? "partial" : "failed",
        patientContextHash: capture.patientContextHash,
        payload: { status: module.status, body: module.body }
      };
      try {
        return SourceEnvelopeSchema.parse(candidate);
      } catch {
        throw new MediCloudAcquisitionError("SOURCE_ENVELOPE_INVALID", module.sourceModule);
      }
    });
  }

  // src/popup.ts
  var MEDCLOUD_LANDING = "https://medcloud2.nhi.gov.tw/imu/IMUE1000";
  var byId = (id) => document.getElementById(id);
  var runButton = byId("run");
  var rawButton = byId("raw-data-btn");
  var message = byId("message");
  var resultZone = byId("result-zone");
  var resultActions = byId("result-actions");
  var downloadButton = byId("download-btn");
  var openInMediPrismaButton = byId("open-in-mediprisma-btn");
  var clearStateButton = byId("clear-state-btn");
  var cancelJobButton = byId("cancel-job-btn");
  var copyErrorButton = byId("copy-error-btn");
  var resultFile = byId("result-file");
  var resultFilename = byId("result-filename");
  var resultFileMeta = byId("result-file-meta");
  var resultSummary = byId("result-summary");
  var resultStageTitle = byId("result-stage-title");
  var resultCompletenessWarning = byId("result-completeness-warning");
  var resultCompletenessTitle = byId("result-completeness-title");
  var resultCompletenessNote = byId("result-completeness-note");
  var resultCompletenessIssues = byId("result-completeness-issues");
  var copyPartialButton = byId("copy-partial-btn");
  var resultProgressIcon = byId("result-progress-icon");
  var resultSuccessIcon = byId("result-success-icon");
  var resultErrorIcon = byId("result-error-icon");
  var resultDetails = byId("result-details");
  var resultDetailsLabel = byId("result-details-label");
  var resultBreakdown = byId("result-breakdown");
  var resultSafety = byId("result-safety");
  var downloadButtonLabel = byId("download-btn-label");
  var moduleStatusSummary = byId("module-status-summary");
  var activePatient = byId("active-patient");
  var activePatientValue = byId("active-patient-value");
  var redetectNote = byId("redetect-note");
  var activeStep = 1;
  var medCloudTabId = null;
  var loggedIn = false;
  var patient = null;
  var backgroundStatus = null;
  var pendingResultReady = false;
  var pendingPatientKey = "";
  var pendingFilename = "";
  var jobRunning = false;
  var downloadCompleted = false;
  var maskNameEnabled = false;
  var privacyPreferenceWrite = Promise.resolve();
  var includeImagingViewerLinks = true;
  var patientProbeInFlight = false;
  var firstPatientProbeSettled = false;
  var handoffStarting = false;
  var clearStarting = false;
  var cancelStarting = false;
  var popupInitialized = false;
  function isMedCloudUrl(raw) {
    try {
      return new URL(raw ?? "").hostname === "medcloud2.nhi.gov.tw";
    } catch {
      return false;
    }
  }
  function patientKey(value) {
    return value?.patientContextHash ?? "";
  }
  function displayPatient(value) {
    if (!value) return "";
    const safeDisplay = value.display || `\u75C5\u4EBA ${value.patientContextHash.slice(0, 8)}\u2026`;
    const fullName = String(value.identity.name ?? "").trim();
    if (maskNameEnabled || !value.display) return safeDisplay;
    const parts = value.display.split(/\s*·\s*/).filter(Boolean);
    if (parts.length <= 1) return fullName || value.identity.sourceId || safeDisplay;
    if (fullName) parts[0] = fullName;
    if (value.identity.sourceId && parts.length > 1) parts[parts.length - 1] = value.identity.sourceId;
    return parts.join("  \xB7  ");
  }
  function patientMismatch() {
    return Boolean(patient && pendingPatientKey && patientKey(patient) !== pendingPatientKey);
  }
  function formatBytes(value) {
    if (!Number.isFinite(value) || Number(value) < 0) return "";
    const bytes = Number(value);
    if (bytes < 1024) return `${bytes} bytes`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  function completionTime(status) {
    if (!status) return void 0;
    if (status.completedAt) return status.completedAt;
    return status.phase === "complete" ? status.updatedAt : void 0;
  }
  function setMessage(text, kind, stageTitle = "", runningSlow = false) {
    if (!message || !resultZone) return;
    message.textContent = text;
    message.className = `status${kind ? ` ${kind}` : ""}`;
    if (resultStageTitle) {
      resultStageTitle.textContent = stageTitle;
      resultStageTitle.hidden = !stageTitle;
    }
    resultZone.dataset.runningSlow = String(Boolean(stageTitle && runningSlow));
    if (resultSuccessIcon) {
      resultSuccessIcon.toggleAttribute("hidden", !(kind === "success" && pendingResultReady));
    }
    resultProgressIcon?.toggleAttribute("hidden", !jobRunning || kind !== void 0 || !text);
    resultErrorIcon?.toggleAttribute("hidden", kind !== "error" || !text);
    resultZone.hidden = !text && !pendingResultReady && !jobRunning;
  }
  function moduleElement(module) {
    return document.querySelector(`[data-module="${module}"]`);
  }
  function renderModules(context = {}) {
    const presentation = presentModuleStages(context);
    for (const row of presentation.rows) {
      const element = moduleElement(row.sourceModule);
      if (!element) continue;
      element.className = "module-states";
      element.setAttribute("aria-label", `${row.label}\uFF1A\u539F\u59CB\u8CC7\u6599${row.acquisition.text}\uFF1BFHIR ${row.conversion.text}`);
      element.replaceChildren(...["acquisition", "conversion"].map((stage) => {
        const cell = document.createElement("span");
        cell.dataset[stage] = row.sourceModule;
        cell.className = `module-state ${row[stage].tone}`.trim();
        cell.textContent = row[stage].text;
        cell.title = row[stage].detail ?? row[stage].text;
        return cell;
      }));
    }
    if (!moduleStatusSummary) return;
    moduleStatusSummary.replaceChildren(...[presentation.acquisitionSummary, presentation.conversionSummary].map((text) => {
      const line = document.createElement("span");
      line.textContent = text;
      return line;
    }));
  }
  function clearLocalResult() {
    backgroundStatus = null;
    pendingResultReady = false;
    pendingPatientKey = "";
    pendingFilename = "";
    jobRunning = false;
    downloadCompleted = false;
    handoffStarting = false;
    if (resultSummary) resultSummary.hidden = true;
    if (resultCompletenessWarning) resultCompletenessWarning.hidden = true;
    resultCompletenessIssues?.replaceChildren();
    if (copyPartialButton) {
      copyPartialButton.hidden = true;
      copyPartialButton.textContent = "\u8907\u88FD\u554F\u984C\u660E\u7D30";
    }
    resultSuccessIcon?.setAttribute("hidden", "");
    resultProgressIcon?.setAttribute("hidden", "");
    resultErrorIcon?.setAttribute("hidden", "");
    if (resultDetails) {
      resultDetails.hidden = true;
      resultDetails.open = false;
    }
    if (resultDetailsLabel) resultDetailsLabel.textContent = "\u67E5\u770B\u660E\u7D30";
    resultBreakdown?.replaceChildren();
    if (resultSafety) resultSafety.hidden = true;
  }
  function renderBundleSummary(summary) {
    const presentation = presentBundleSummary(summary);
    if (resultCompletenessWarning) {
      resultCompletenessWarning.hidden = !presentation.hasVisibleIssues;
      resultCompletenessWarning.setAttribute(
        "role",
        presentation.hasIncompleteModules ? "alert" : "status"
      );
      resultCompletenessWarning.setAttribute("aria-live", "polite");
    }
    if (resultCompletenessTitle) {
      resultCompletenessTitle.textContent = presentation.issueTitle;
    }
    if (resultCompletenessNote) {
      resultCompletenessNote.textContent = presentation.completenessNote;
    }
    if (resultCompletenessIssues) {
      resultCompletenessIssues.replaceChildren();
      const appendIssue = (issue, stateText, stateClass) => {
        const item = document.createElement("li");
        const head = document.createElement("span");
        head.className = "partial-issue-head";
        const label = document.createElement("span");
        label.textContent = issue.label;
        const state = document.createElement("span");
        state.className = `partial-issue-state${stateClass ? ` ${stateClass}` : ""}`;
        state.textContent = stateText;
        head.append(label, state);
        const reason = document.createElement("span");
        reason.className = "partial-issue-reason";
        reason.textContent = issue.reason;
        const diagnostic = document.createElement("code");
        diagnostic.className = "partial-issue-code";
        diagnostic.textContent = issue.diagnostic;
        item.append(head, reason, diagnostic);
        if (issue.affectedRecords.length > 0) {
          const records = document.createElement("ul");
          records.className = "partial-record-list";
          for (const affected of issue.affectedRecords) {
            const record = document.createElement("li");
            const recordLabel = document.createElement("span");
            recordLabel.className = "partial-record-label";
            recordLabel.textContent = affected.kind === "source" ? affected.label : affected.kind === "retained-invalid-resource" ? `\u5DF2\u4FDD\u7559\u4F46\u4E0D\u5408\u6CD5 ${affected.label}` : `\u672A\u7D0D\u5165\u8CC7\u6E90 ${affected.label}`;
            const recordCode = document.createElement("code");
            recordCode.className = "partial-record-code";
            recordCode.textContent = affected.diagnostic;
            record.append(recordLabel, recordCode);
            records.append(record);
          }
          item.append(records);
        }
        resultCompletenessIssues.append(item);
      };
      for (const issue of presentation.incompleteModules) {
        appendIssue(
          issue,
          issue.completeness === "failed" ? "\u5931\u6557" : "\u8F49\u63DB\u5931\u6557",
          issue.completeness === "failed" ? "failed" : ""
        );
      }
      for (const notice of presentation.sourceDataNotices) {
        appendIssue(notice, "\u4F86\u6E90\u63D0\u9192", "warning");
      }
    }
    if (copyPartialButton) {
      copyPartialButton.hidden = !presentation.hasIncompleteModules;
      copyPartialButton.textContent = "\u8907\u88FD\u554F\u984C\u660E\u7D30";
    }
    if (resultSummary) {
      resultSummary.hidden = false;
      const completedAt = completionTime(backgroundStatus);
      const elapsed = backgroundStatus && completedAt ? formatResultElapsed(completedAt - backgroundStatus.startedAt) : "";
      resultSummary.textContent = [
        presentation.summaryText,
        elapsed ? `\u8017\u6642 ${elapsed}` : ""
      ].filter(Boolean).join(" \xB7 ");
    }
    if (resultBreakdown && resultDetails) {
      resultBreakdown.replaceChildren();
      for (const detail of presentation.detailRows) {
        const row = document.createElement("div");
        row.className = "result-breakdown-row";
        const label = document.createElement("span");
        label.className = "result-breakdown-label";
        label.textContent = detail.label;
        const value = document.createElement("span");
        value.className = "result-breakdown-value";
        value.textContent = `${detail.count} \u7B46`;
        row.append(label, value);
        resultBreakdown.append(row);
      }
      resultDetails.hidden = presentation.detailRows.length === 0;
    }
    return presentation.canDownload;
  }
  function stepDone(step) {
    if (step === 1) return loggedIn && Boolean(patientKey(patient));
    if (step === 2) return pendingResultReady || downloadCompleted;
    return false;
  }
  function renderWizard() {
    document.body.dataset.activeStep = String(activeStep);
    document.querySelectorAll("#wizard-stepper li[data-step]").forEach((item) => {
      const step = Number(item.dataset.step);
      item.toggleAttribute("aria-current", step === activeStep);
      item.setAttribute("aria-selected", String(step === activeStep));
      if (stepDone(step)) item.dataset.done = "true";
      else delete item.dataset.done;
    });
    const onTab = medCloudTabId !== null;
    byId("open-medcloud-section").hidden = onTab;
    byId("medcloud-needs-login-section").hidden = !onTab || loggedIn;
    byId("login-ok-section").hidden = !onTab || !loggedIn;
    if (runButton) {
      runButton.disabled = !stepDone(1) || jobRunning;
      runButton.textContent = backgroundStatus && hasAvailableBackgroundResult(backgroundStatus) ? "\u91CD\u65B0\u53D6\u5F97" : "\u53D6\u5F97\u96F2\u7AEF\u75C5\u6B77\u8CC7\u6599";
      runButton.title = "\u91CD\u65B0\u5F9E\u96F2\u7AEF\u75C5\u6B77\u53D6\u5F97\u6700\u65B0\u8CC7\u6599\uFF1B\u53EA\u60F3\u958B\u555F\u5DF2\u4FDD\u5B58\u7D50\u679C\uFF0C\u8ACB\u4F7F\u7528\u53F3\u5074 Logo \u6216\u300C\u5728 MediPrisma \u958B\u555F\u300D\u3002";
    }
    if (rawButton) rawButton.disabled = !stepDone(1) || jobRunning;
    if (activePatient && activePatientValue) {
      const label = displayPatient(patient);
      activePatient.hidden = !label;
      activePatientValue.textContent = label;
    }
    const privacyStale = pendingResultReady && !isPrivacyOutputCurrent(backgroundStatus, maskNameEnabled);
    const downloadReady = pendingResultReady && !privacyStale && firstPatientProbeSettled && !patientMismatch();
    if (privacyStale) setMessage(PRIVACY_STALE_MESSAGE, "error");
    const bundlePresentation = backgroundStatus?.summary ? presentBundleSummary(backgroundStatus.summary) : null;
    const incompleteResult = bundlePresentation?.hasIncompleteModules ?? false;
    const hasVisibleIssues = bundlePresentation?.hasVisibleIssues ?? false;
    if (resultActions) resultActions.hidden = !downloadReady;
    if (resultFile) resultFile.hidden = !downloadReady;
    if (resultSafety) resultSafety.hidden = !downloadReady;
    if (resultCompletenessWarning) {
      resultCompletenessWarning.hidden = !downloadReady || !hasVisibleIssues;
    }
    if (downloadReady && resultFilename && resultFileMeta) {
      resultFilename.textContent = pendingFilename || "medcloud-health-record.json";
      const size = formatBytes(backgroundStatus?.resultBytes);
      const age = formatResultAge(completionTime(backgroundStatus));
      resultFileMeta.textContent = [
        bundlePresentation?.hasRetainedInvalid ? "FHIR \u9A57\u8B49\u6709\u63D0\u9192\u7684\u5065\u5EB7\u7D00\u9304\u6A94" : incompleteResult ? "\u90E8\u5206\u8F49\u63DB\u7D50\u679C\u6A94" : "\u5065\u5EB7\u7D00\u9304\u6A94",
        size,
        age
      ].filter(Boolean).join(" \xB7 ");
    }
    if (downloadButton) downloadButton.disabled = !downloadReady;
    if (downloadButtonLabel) {
      downloadButtonLabel.textContent = backgroundStatus?.downloadedAt || downloadCompleted ? "\u518D\u6B21\u4E0B\u8F09" : "\u4E0B\u8F09\u6A94\u6848";
    }
    if (openInMediPrismaButton) {
      openInMediPrismaButton.disabled = !downloadReady || backgroundStatus?.phase === "complete" && backgroundStatus.deliveryMode === "mediprisma" && !backgroundStatus.errorCode || handoffStarting;
      openInMediPrismaButton.title = downloadReady && bundlePresentation?.hasRetainedInvalid ? "FHIR \u9A57\u8B49\u6709\u63D0\u9192\uFF1B\u4ECD\u53EF\u9001\u5230 MediPrisma\uFF0C\u8ACB\u6838\u5C0D\u8CC7\u6599" : "";
    }
    const clearableState = Boolean(backgroundStatus && backgroundStatus.phase !== "running");
    if (clearStateButton) {
      clearStateButton.hidden = !clearableState;
      clearStateButton.disabled = !clearableState || clearStarting;
    }
    if (cancelJobButton) {
      cancelJobButton.hidden = !jobRunning;
      cancelJobButton.disabled = !jobRunning || cancelStarting;
      cancelJobButton.textContent = cancelStarting ? "\u6B63\u5728\u53D6\u6D88\u2026" : "\u53D6\u6D88\u53D6\u5F97";
    }
    if (copyErrorButton) {
      copyErrorButton.hidden = !reportableErrorCode();
    }
  }
  function reportableErrorCode() {
    const code = backgroundStatus?.errorCode;
    return typeof code === "string" && /^[A-Z][A-Z0-9_]{2,63}$/.test(code) ? code : "";
  }
  function setStep(step) {
    activeStep = normalizeWizardStep(step);
    renderWizard();
  }
  function renderBackgroundMessage() {
    const waiting = backgroundStatus?.phase === "running" && backgroundStatus.outpatientNeedsLogin === true;
    for (const id of ["open-outpatient-his", "outpatient-cloud-only"]) {
      const button = byId(id);
      if (button) button.hidden = !waiting;
    }
    if (!backgroundStatus) return;
    if (backgroundStatus.phase === "running") {
      const presentation = runningJobStagePresentation(backgroundStatus);
      setMessage(backgroundStatus.outpatientMessage || presentation.detail, void 0, presentation.title, presentation.slow);
      return;
    }
    if (hasAvailableBackgroundResult(backgroundStatus) && !backgroundStatus.errorCode) {
      const presentation = backgroundStatus.summary ? presentBundleSummary(backgroundStatus.summary) : null;
      const isIncomplete = presentation?.hasIncompleteModules ?? false;
      const hasSourceDataNotices = presentation?.hasSourceDataNotices ?? false;
      const hospitalNotice = hospitalResultNotice(backgroundStatus);
      setMessage(
        presentation?.hasAuthorizationFailure ? "\u96F2\u7AEF\u75C5\u6B77\u767B\u5165\uFF0F\u6388\u6B0A\u5931\u6557\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u96F2\u7AEF\u75C5\u6B77\uFF0C\u5FC5\u8981\u6642\u91CD\u65B0\u767B\u5165\u5F8C\u91CD\u8A66" : isIncomplete || hasSourceDataNotices || hospitalNotice ? appendDistinctNotices(backgroundStatus.message || (isIncomplete ? "\u90E8\u5206\u8CC7\u6599\u8F49\u63DB\u5931\u6557\uFF1B\u8ACB\u67E5\u770B\u4E0B\u65B9\u932F\u8AA4\u660E\u7D30\u3002" : "\u8CC7\u6599\u5DF2\u6E96\u5099\u5B8C\u6210\uFF1B\u53E6\u6709\u4F86\u6E90\u8CC7\u6599\u63D0\u9192\uFF0C\u8ACB\u67E5\u770B\u4E0B\u65B9\u660E\u7D30\u3002"), hospitalNotice) : "\u8CC7\u6599\u5DF2\u6E96\u5099\u5B8C\u6210",
        isIncomplete ? "error" : hasSourceDataNotices || hospitalNotice ? void 0 : "success"
      );
      return;
    }
    setMessage(
      backgroundStatus.message,
      backgroundStatus.phase === "error" || backgroundStatus.errorCode ? "error" : void 0
    );
  }
  async function clearMismatchedBackgroundJob(status) {
    const response = await chrome.runtime.sendMessage({
      type: CLEAR_BACKGROUND_JOB,
      runId: status.runId
    }).catch(() => void 0);
    if (response?.ok) return;
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const current = stored[BACKGROUND_JOB_STATUS_KEY];
    if (isBackgroundJobStatus(current) && current.runId === status.runId && current.phase !== "running") {
      await clearBackgroundResults(status.runId);
      await chrome.storage.session.remove([
        BACKGROUND_JOB_STATUS_KEY,
        BACKGROUND_JOB_REQUEST_KEY
      ]);
    }
  }
  async function verifyPendingPatientAtEgress() {
    const status = backgroundStatus;
    if (!status?.tabId) {
      await failEgress(status, "unreachable");
      return false;
    }
    const probe = await probeMediCloudPatient(status.tabId).catch(() => null);
    if (probe?.ok && probe.patientContextHash === status.patientContextHash && probe.patientContextHash === pendingPatientKey) {
      patient = {
        patientContextHash: probe.patientContextHash,
        display: probe.display,
        identity: probe.identity
      };
      loggedIn = true;
      return true;
    }
    await failEgress(status, probe?.ok ? "changed" : "unreachable");
    return false;
  }
  async function failEgress(status, cause) {
    patient = null;
    loggedIn = false;
    if (status) await clearMismatchedBackgroundJob(status);
    clearLocalResult();
    renderModules();
    setMessage(
      cause === "changed" ? "\u756B\u9762\u4E0A\u7684\u75C5\u4EBA\u5DF2\u6539\u8B8A\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u66AB\u5B58\u7D50\u679C\u5DF2\u6E05\u9664\uFF0C\u8ACB\u91CD\u65B0\u53D6\u5F97\u3002" : "\u627E\u4E0D\u5230\u539F\u672C\u7684\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\uFF0C\u7121\u6CD5\u78BA\u8A8D\u75C5\u4EBA\uFF0C\u66AB\u5B58\u7D50\u679C\u5DF2\u6E05\u9664\uFF1B\u8ACB\u91CD\u65B0\u958B\u555F\u96F2\u7AEF\u75C5\u6B77\u5F8C\u518D\u53D6\u5F97\u4E00\u6B21\u3002",
      "error"
    );
    renderWizard();
  }
  async function clearCurrentBackgroundState() {
    const status = backgroundStatus;
    if (!status || status.phase === "running" || clearStarting) return;
    clearStarting = true;
    renderWizard();
    const response = await chrome.runtime.sendMessage({
      type: CLEAR_BACKGROUND_JOB,
      runId: status.runId
    }).catch(() => void 0);
    if (!response?.ok) {
      clearStarting = false;
      setMessage("\u76EE\u524D\u7121\u6CD5\u79FB\u9664\u66AB\u5B58\u8CC7\u6599\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\uFF1B\u539F\u6709\u7D50\u679C\u4ECD\u4FDD\u7559\u3002", "error");
      renderWizard();
      return;
    }
    clearLocalResult();
    clearStarting = false;
    renderModules();
    setMessage("");
    setStep(2);
  }
  async function cancelRunningBackgroundJob() {
    const status = backgroundStatus;
    if (!status || status.phase !== "running" || cancelStarting) return;
    cancelStarting = true;
    renderWizard();
    const response = await chrome.runtime.sendMessage({
      type: CLEAR_BACKGROUND_JOB,
      runId: status.runId
    }).catch(() => void 0);
    cancelStarting = false;
    if (!response?.ok) {
      setMessage("\u76EE\u524D\u7121\u6CD5\u53D6\u6D88\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66\u3002", "error");
      renderWizard();
      return;
    }
    clearLocalResult();
    renderModules();
    setMessage("\u5DF2\u53D6\u6D88\u9019\u6B21\u53D6\u5F97\uFF1B\u53EF\u91CD\u65B0\u958B\u59CB\u3002");
    setStep(2);
  }
  function resetForMismatchedPatient(status) {
    if (status.phase === "running") {
      backgroundStatus = status;
      pendingPatientKey = status.patientContextHash;
      pendingFilename = "";
      pendingResultReady = false;
      downloadCompleted = false;
      jobRunning = true;
      if (resultSummary) resultSummary.hidden = true;
      renderModules();
      setMessage("\u5DF2\u5075\u6E2C\u5230\u5207\u63DB\u75C5\u4EBA\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u8CC7\u6599\u6B63\u5728\u5B89\u5168\u505C\u6B62\uFF0C\u53D6\u5F97\u72C0\u614B\u5DF2\u6E05\u7A7A\u3002", "error");
      setStep(2);
      void clearMismatchedBackgroundJob(status);
      return;
    }
    clearLocalResult();
    renderModules();
    setMessage("\u5DF2\u5075\u6E2C\u5230\u5207\u63DB\u75C5\u4EBA\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u53D6\u5F97\u72C0\u614B\u8207\u5F85\u4E0B\u8F09\u7D50\u679C\u5DF2\u6E05\u9664\u3002", "success");
    setStep(2);
    void clearMismatchedBackgroundJob(status);
  }
  function applyBackgroundStatus(value) {
    if (!isBackgroundJobStatus(value)) {
      clearLocalResult();
      renderModules();
      setMessage("");
      renderWizard();
      return;
    }
    if (patient && patientKey(patient) !== value.patientContextHash) {
      resetForMismatchedPatient(value);
      return;
    }
    backgroundStatus = value;
    pendingPatientKey = value.patientContextHash;
    pendingFilename = value.filename ?? "";
    jobRunning = value.phase === "running";
    pendingResultReady = hasAvailableBackgroundResult(value);
    downloadCompleted = Boolean(value.downloadedAt) || value.phase === "downloaded";
    if (value.phase === "running") {
      if (resultSummary) resultSummary.hidden = true;
      renderModules(value);
      setStep(2);
    } else if (pendingResultReady) {
      renderModules(value);
      if (!value.summary || !renderBundleSummary(value.summary)) pendingResultReady = false;
      setStep(2);
    } else if (value.phase === "error") {
      if (resultSummary) resultSummary.hidden = true;
      renderModules(value);
      setStep(2);
    } else {
      if (resultSummary) resultSummary.hidden = true;
      renderModules(value);
      setStep(3);
    }
    renderBackgroundMessage();
    renderWizard();
  }
  async function restoreBackgroundStatus() {
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const status = stored[BACKGROUND_JOB_STATUS_KEY];
    applyBackgroundStatus(status);
  }
  async function loadPreferences() {
    maskNameEnabled = await loadPopupMaskNamePreference();
    const maskOn = byId("mask-name-on");
    const maskOff = byId("mask-name-off");
    if (maskOn) maskOn.checked = maskNameEnabled;
    if (maskOff) maskOff.checked = !maskNameEnabled;
  }
  async function probePatient(showFeedback = false) {
    if (!medCloudTabId || patientProbeInFlight) return;
    patientProbeInFlight = true;
    if (showFeedback && redetectNote) {
      redetectNote.hidden = false;
      redetectNote.textContent = "\u6B63\u5728\u91CD\u65B0\u5075\u6E2C\u76EE\u524D\u75C5\u4EBA\u2026";
    }
    try {
      const response = await probeMediCloudPatient(medCloudTabId);
      patient = response.ok ? {
        patientContextHash: response.patientContextHash,
        display: response.display,
        identity: response.identity
      } : null;
      loggedIn = response.ok;
      firstPatientProbeSettled = true;
      if (backgroundStatus && patientMismatch()) applyBackgroundStatus(backgroundStatus);
      else {
        renderBackgroundMessage();
        renderWizard();
      }
      if (redetectNote && (showFeedback || !response.ok)) {
        redetectNote.hidden = false;
        redetectNote.textContent = patientKey(patient) ? "\u5DF2\u91CD\u65B0\u5075\u6E2C\u96F2\u7AEF\u75C5\u6B77\u76EE\u524D\u75C5\u4EBA\u3002" : acquisitionErrorMessage(response.ok ? null : { code: response.code });
      } else if (redetectNote && response.ok) {
        redetectNote.hidden = true;
      }
    } catch {
      loggedIn = false;
      patient = null;
      if (showFeedback && redetectNote) redetectNote.textContent = "\u75C5\u4EBA\u5075\u6E2C\u5931\u6557\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u96F2\u7AEF\u75C5\u6B77\u3002";
      renderWizard();
    } finally {
      patientProbeInFlight = false;
      firstPatientProbeSettled = true;
    }
  }
  async function detectContext() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    medCloudTabId = tab?.id !== void 0 && isMedCloudUrl(tab.url) ? tab.id : null;
    if (!medCloudTabId) {
      firstPatientProbeSettled = true;
      loggedIn = false;
      patient = null;
      renderWizard();
      return;
    }
    await probePatient();
    if (!backgroundStatus && stepDone(1) && activeStep === 1) setStep(2);
  }
  async function verifyPendingPrivacyAtEgress(runId) {
    try {
      await privacyPreferenceWrite;
      const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
      const status = stored[BACKGROUND_JOB_STATUS_KEY];
      const enabled = await readMaskNamePreference();
      if (!runId || !isBackgroundJobStatus(status) || status.runId !== runId || !hasAvailableBackgroundResult(status) || !isPrivacyOutputCurrent(status, enabled) || !isPrivacyOutputCurrent(backgroundStatus, maskNameEnabled)) {
        setMessage(PRIVACY_STALE_MESSAGE, "error");
        renderWizard();
        return false;
      }
      return true;
    } catch {
      setMessage("\u7121\u6CD5\u78BA\u8A8D\u53BB\u8B58\u5225\u5316\u8A2D\u5B9A\uFF0C\u672A\u9001\u51FA\u5065\u5EB7\u7D00\u9304\uFF1B\u8ACB\u91CD\u65B0\u53D6\u5F97\u3002", "error");
      return false;
    }
  }
  async function downloadBundle() {
    if (!pendingResultReady || patientMismatch()) return;
    const runId = backgroundStatus?.runId;
    if (!await verifyPendingPrivacyAtEgress(runId)) return;
    if (!await verifyPendingPatientAtEgress()) return;
    const result = await readBackgroundResult(runId);
    if (!isBackgroundJobResult(result) || result.runId !== backgroundStatus?.runId || result.patientContextHash !== pendingPatientKey || result.expiresAt <= Date.now()) {
      setMessage("\u9019\u6B21\u8CC7\u6599\u5DF2\u904E\u671F\u6216\u4E0D\u5B58\u5728\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u91CD\u65B0\u53D6\u5F97\u3002", "error");
      pendingResultReady = false;
      renderWizard();
      return;
    }
    let json;
    try {
      json = await decodeBackgroundBundle(result);
    } catch {
      setMessage("\u9019\u6B21\u66AB\u5B58\u8CC7\u6599\u7121\u6CD5\u8B80\u53D6\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u91CD\u65B0\u53D6\u5F97\u3002", "error");
      return;
    }
    if (!await verifyPendingPatientAtEgress()) return;
    if (!await verifyPendingPrivacyAtEgress(runId)) return;
    const isValidatedFhir = backgroundStatus?.summary?.validation.valid === true;
    const blob = new Blob([json], {
      type: isValidatedFhir ? "application/fhir+json;charset=utf-8" : "application/json;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename || pendingFilename || "medcloud-health-record.json";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
    const response = await chrome.runtime.sendMessage({
      type: MARK_BACKGROUND_JOB_DOWNLOADED,
      runId: result.runId
    }).catch(() => void 0);
    downloadCompleted = true;
    if (!response?.ok) {
      const presentation = backgroundStatus?.summary ? presentBundleSummary(backgroundStatus.summary) : null;
      setMessage(
        presentation?.hasRetainedInvalid ? "\u6A94\u6848\u4E0B\u8F09\u5DF2\u958B\u59CB\uFF1B\u5167\u542B FHIR \u9A57\u8B49\u63D0\u9192\uFF0C\u4ECD\u53EF\u5728 MediPrisma \u67E5\u770B\uFF0C\u8ACB\u6838\u5C0D\u8CC7\u6599\u3002" : "\u6A94\u6848\u4E0B\u8F09\u5DF2\u958B\u59CB\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u518D\u6B21\u4E0B\u8F09\u6216\u5728 MediPrisma \u67E5\u770B\u3002",
        "success"
      );
    }
    renderWizard();
    setStep(2);
  }
  async function openPendingBundleInMediPrisma() {
    if (!pendingResultReady || patientMismatch() || !backgroundStatus || handoffStarting) {
      return;
    }
    const runId = backgroundStatus.runId;
    if (!await verifyPendingPrivacyAtEgress(runId)) return;
    if (!await verifyPendingPatientAtEgress()) return;
    handoffStarting = true;
    if (openInMediPrismaButton) openInMediPrismaButton.textContent = "\u6B63\u5728\u958B\u555F\u2026";
    renderWizard();
    try {
      const permission = await requestMediPrismaPermission(runId);
      if (!permission.granted) {
        setMessage(
          `${permission.reason || "\u672A\u6388\u6B0A\u5B58\u53D6 MediPrisma\uFF1B\u5065\u5EB7\u7D00\u9304\u6C92\u6709\u9001\u51FA\u3002"}\u4ECD\u53EF\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002`,
          "error"
        );
        return;
      }
      if (!await verifyPendingPatientAtEgress()) return;
      if (!await verifyPendingPrivacyAtEgress(runId)) return;
      const response = await chrome.runtime.sendMessage({
        type: OPEN_PENDING_BUNDLE_IN_MEDIPRISMA
      });
      if (!response?.ok) {
        throw new Error(response?.error || "\u7121\u6CD5\u5728 MediPrisma \u958B\u555F");
      }
      if (openInMediPrismaButton) openInMediPrismaButton.textContent = "MediPrisma \u5DF2\u958B\u555F";
    } catch (error) {
      setMessage(error instanceof Error && error.message === PRIVACY_STALE_MESSAGE ? PRIVACY_STALE_MESSAGE : "\u7121\u6CD5\u5728 MediPrisma \u958B\u555F\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002", "error");
    } finally {
      handoffStarting = false;
      if (openInMediPrismaButton?.textContent !== "MediPrisma \u5DF2\u958B\u555F") {
        if (openInMediPrismaButton) openInMediPrismaButton.textContent = "\u5728 MediPrisma \u67E5\u770B";
      }
      renderWizard();
    }
  }
  function triggerJsonDownload(json, filename, mimeType) {
    const blob = new Blob([json], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function downloadRetainedRawCapture() {
    const runId = backgroundStatus?.runId;
    if (!runId || patientMismatch()) return false;
    const result = await readBackgroundResult(runId).catch(() => null);
    if (!isBackgroundJobResult(result) || result.schemaVersion !== 5 && (result.schemaVersion !== 4 || !result.rawCapture) || result.runId !== runId || result.patientContextHash !== pendingPatientKey || result.expiresAt <= Date.now()) {
      return false;
    }
    const rawCapture = result.schemaVersion === 5 ? result : result.schemaVersion === 4 ? result.rawCapture : void 0;
    if (!rawCapture) return false;
    if (!await verifyPendingPatientAtEgress()) return true;
    let json;
    try {
      json = await decodeBackgroundPayload(rawCapture, runId);
    } catch {
      return false;
    }
    if (!await verifyPendingPatientAtEgress()) return true;
    triggerJsonDownload(json, rawCapture.filename, "application/json");
    setMessage("\u5DF2\u7528\u9019\u6B21\u53D6\u5F97\u7684\u539F\u59CB\u8CC7\u6599\u76F4\u63A5\u4E0B\u8F09\uFF0C\u672A\u91CD\u65B0\u8B80\u53D6\u96F2\u7AEF\u75C5\u6B77\u3002", "success");
    renderWizard();
    return true;
  }
  async function downloadRawCapture(tabId, detectedPatient) {
    jobRunning = true;
    renderModules({ phase: "running", stage: "capture", rawOnly: true });
    let moduleAcquisition;
    setMessage("\u6B63\u5728\u53D6\u5F97\u539F\u59CB\u8CC7\u6599\uFF08\u901A\u5E38\u6578\u79D2\u5167\u5B8C\u6210\uFF09\uFF1B\u5B8C\u6210\u524D\u8ACB\u52FF\u9EDE\u64CA\u8996\u7A97\u5916\uFF0C\u5426\u5247\u6703\u4E2D\u65B7\u4E14\u4E0D\u6703\u7522\u751F\u6A94\u6848\u3002", void 0);
    renderWizard();
    try {
      const envelopes = await loadMediCloudEnvelopes(tabId, crypto.randomUUID());
      if (envelopes.length === 0 || envelopes.some((envelope) => envelope.patientContextHash !== detectedPatient.patientContextHash)) {
        throw new Error("patient-context-mismatch");
      }
      const endpoints = Object.fromEntries(envelopes.map((envelope) => [
        envelope.datasetScope,
        {
          status: envelope.payload.status,
          body: typeof envelope.payload.body === "string" ? envelope.payload.body : JSON.stringify(envelope.payload.body)
        }
      ]));
      const payload = {
        patient: detectedPatient.identity.maskedId || `context-${detectedPatient.patientContextHash.slice(0, 12)}`,
        capturedAt: envelopes[0].capturedAt,
        endpoints
      };
      moduleAcquisition = summarizeCapturedEndpoints(endpoints);
      triggerJsonDownload(
        JSON.stringify(payload, null, 2),
        buildMedcloudRawFilename(
          detectedPatient.identity.maskedId,
          new Date(envelopes[0].capturedAt),
          chrome.runtime.getManifest().version
        ),
        "application/json"
      );
      renderModules({ phase: "complete", rawOnly: true, moduleAcquisition });
      setMessage("\u539F\u59CB\u8CC7\u6599\u5DF2\u4E0B\u8F09\uFF1B\u672C\u5DE5\u5177\u4E0D\u6703\u4FDD\u5B58\u9019\u4EFD\u8CC7\u6599\u3002", "success");
    } catch (error) {
      renderModules({ phase: "error", rawOnly: true, moduleAcquisition });
      setMessage(moduleAcquisition ? "\u5DF2\u53D6\u5F97\u539F\u59CB\u56DE\u61C9\uFF0C\u4F46\u672A\u80FD\u5EFA\u7ACB\u4E0B\u8F09\u6A94\u6848\uFF1B\u8ACB\u91CD\u8A66\u3002" : `\u539F\u59CB\u8CC7\u6599\u53D6\u5F97\u5931\u6557\uFF1B\u672A\u7522\u751F\u6A94\u6848\u3002${acquisitionErrorMessage(error)}`, "error");
    } finally {
      jobRunning = false;
      renderWizard();
    }
  }
  runButton?.addEventListener("click", async () => {
    await privacyPreferenceWrite;
    if (!medCloudTabId || !patientKey(patient) || !patient) {
      setStep(1);
      return;
    }
    const request = {
      tabId: medCloudTabId,
      runId: crypto.randomUUID(),
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      expectedPatientContextHash: patient.patientContextHash,
      maskNameEnabled,
      includeImagingViewerLinks,
      patientIdentity: patient.identity
    };
    applyBackgroundStatus(runningJobStatus(request));
    try {
      const response = await chrome.runtime.sendMessage({
        type: START_BACKGROUND_JOB,
        payload: request
      });
      if (!response?.ok) {
        await restoreBackgroundStatus();
        if (response?.code !== "JOB_RUNNING") {
          setMessage("\u76EE\u524D\u7121\u6CD5\u958B\u59CB\u53D6\u5F97\u8CC7\u6599\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u64F4\u5145\u529F\u80FD\u5F8C\u518D\u8A66\u3002", "error");
        }
      }
    } catch {
      await restoreBackgroundStatus().catch(() => void 0);
      setMessage("\u64F4\u5145\u529F\u80FD\u76EE\u524D\u6C92\u6709\u56DE\u61C9\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u5F8C\u518D\u8A66\u3002", "error");
    }
  });
  rawButton?.addEventListener("click", async () => {
    if (!medCloudTabId || !patientKey(patient) || !patient) {
      setStep(1);
      return;
    }
    if (await downloadRetainedRawCapture()) return;
    void downloadRawCapture(medCloudTabId, patient);
  });
  byId("open-medcloud-btn")?.addEventListener("click", async () => {
    const [existing] = await chrome.tabs.query({ url: "https://medcloud2.nhi.gov.tw/imu/*" }).catch(() => []);
    if (existing?.id !== void 0) {
      await chrome.tabs.update(existing.id, { active: true });
      if (existing.windowId !== void 0) {
        await chrome.windows.update(existing.windowId, { focused: true }).catch(() => void 0);
      }
    } else {
      await chrome.tabs.create({ url: MEDCLOUD_LANDING });
    }
    window.close();
  });
  byId("medcloud-reload-btn")?.addEventListener("click", async () => {
    if (medCloudTabId) await chrome.tabs.update(medCloudTabId, { url: MEDCLOUD_LANDING, active: true });
    else await chrome.tabs.create({ url: MEDCLOUD_LANDING });
    window.close();
  });
  byId("redetect-patient-btn")?.addEventListener("click", () => {
    void probePatient(true);
  });
  byId("download-btn")?.addEventListener("click", () => {
    void downloadBundle();
  });
  byId("open-in-mediprisma-btn")?.addEventListener("click", () => {
    void openPendingBundleInMediPrisma();
  });
  clearStateButton?.addEventListener("click", () => {
    void clearCurrentBackgroundState();
  });
  cancelJobButton?.addEventListener("click", () => {
    void cancelRunningBackgroundJob();
  });
  copyErrorButton?.addEventListener("click", async () => {
    const code = reportableErrorCode();
    if (!code || !copyErrorButton) return;
    const payload = `${code} (v${chrome.runtime.getManifest().version})`;
    try {
      await navigator.clipboard.writeText(payload);
      copyErrorButton.textContent = "\u5DF2\u8907\u88FD";
    } catch {
      copyErrorButton.textContent = "\u7121\u6CD5\u8907\u88FD";
    }
    window.setTimeout(() => {
      if (copyErrorButton) copyErrorButton.textContent = "\u8907\u88FD\u4EE3\u78BC";
    }, 2e3);
  });
  copyPartialButton?.addEventListener("click", async () => {
    const summary = backgroundStatus?.summary;
    if (!summary || !copyPartialButton) return;
    const payload = partialDiagnosticText(summary, chrome.runtime.getManifest().version);
    try {
      await navigator.clipboard.writeText(payload);
      copyPartialButton.textContent = "\u5DF2\u8907\u88FD";
    } catch {
      copyPartialButton.textContent = "\u7121\u6CD5\u8907\u88FD";
    }
    window.setTimeout(() => {
      if (copyPartialButton) copyPartialButton.textContent = "\u8907\u88FD\u554F\u984C\u660E\u7D30";
    }, 2e3);
  });
  resultDetails?.addEventListener("toggle", () => {
    if (resultDetailsLabel) {
      resultDetailsLabel.textContent = resultDetails.open ? "\u6536\u5408\u660E\u7D30" : "\u67E5\u770B\u660E\u7D30";
    }
  });
  byId("login-ok-next")?.addEventListener("click", () => setStep(2));
  byId("back-to-download-btn")?.addEventListener("click", () => setStep(2));
  byId("open-smart-app-btn")?.addEventListener("click", async () => {
    try {
      await chrome.tabs.create({ url: await readMediPrismaDestination() });
    } catch {
      const status = byId("destination-status");
      if (status) status.textContent = "\u7121\u6CD5\u8B80\u53D6\u63A5\u6536\u7DB2\u5740\uFF0C\u8ACB\u91CD\u65B0\u5132\u5B58\u8A2D\u5B9A\u5F8C\u518D\u8A66\u3002";
      setSettingsOpen(true);
    }
  });
  byId("mask-name-toggle")?.addEventListener("change", () => {
    maskNameEnabled = byId("mask-name-on")?.checked === true;
    const enabled = maskNameEnabled;
    privacyPreferenceWrite = privacyPreferenceWrite.then(async () => {
      await saveMaskNamePreference(enabled);
      try {
        localStorage.setItem(MASK_NAME_PREFERENCE_KEY, String(enabled));
      } catch {
      }
    }).catch(async () => {
      await loadPreferences();
      renderWizard();
      setMessage("\u53BB\u8B58\u5225\u5316\u8A2D\u5B9A\u5132\u5B58\u5931\u6557\uFF0C\u5DF2\u9084\u539F\uFF1B\u8ACB\u91CD\u65B0\u8A2D\u5B9A\u5F8C\u518D\u8A66\u3002", "error");
    });
    renderWizard();
  });
  document.querySelectorAll("#wizard-stepper li[data-step]").forEach((item) => {
    const activate = () => setStep(Number(item.dataset.step));
    item.addEventListener("click", activate);
    item.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        activate();
      }
    });
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes[MASK_NAME_PREFERENCE_KEY]) {
      maskNameEnabled = changes[MASK_NAME_PREFERENCE_KEY].newValue !== false;
      const maskOn = byId("mask-name-on"), maskOff = byId("mask-name-off");
      if (maskOn) maskOn.checked = maskNameEnabled;
      if (maskOff) maskOff.checked = !maskNameEnabled;
      renderWizard();
    }
    if (areaName === "session" && changes[BACKGROUND_JOB_STATUS_KEY]) {
      applyBackgroundStatus(changes[BACKGROUND_JOB_STATUS_KEY]?.newValue);
    }
  });
  window.setInterval(() => {
    if (medCloudTabId) void probePatient();
  }, 3e3);
  window.setInterval(() => {
    if (backgroundStatus?.phase === "running") renderBackgroundMessage();
  }, 1e3);
  var settingsToggle = byId("settings-toggle");
  var settingsPanel = byId("destination-settings");
  var settingsHelp = Array.from(document.querySelectorAll(".settings-help-button")).map((button) => {
    const tooltip = byId(button.getAttribute("aria-controls") || "");
    const container = button.closest(".settings-help");
    let pinned = false;
    let leaveTimer;
    const position = () => {
      if (!tooltip || tooltip.hidden) return;
      const anchor = button.getBoundingClientRect();
      const bounds = tooltip.getBoundingClientRect();
      const left = Math.max(12, Math.min(anchor.right - bounds.width, window.innerWidth - bounds.width - 12));
      const below = anchor.bottom + 6;
      const top = below + bounds.height <= window.innerHeight - 12 ? below : anchor.top - bounds.height - 6;
      tooltip.style.left = `${left}px`;
      tooltip.style.top = `${Math.max(12, top)}px`;
    };
    const close = () => {
      clearTimeout(leaveTimer);
      pinned = false;
      if (tooltip) tooltip.hidden = true;
      button.setAttribute("aria-expanded", "false");
    };
    const open = () => {
      clearTimeout(leaveTimer);
      settingsHelp.forEach((help) => {
        if (help.button !== button) help.close();
      });
      if (tooltip) tooltip.hidden = false;
      button.setAttribute("aria-expanded", "true");
      position();
    };
    container?.addEventListener("pointerenter", open);
    container?.addEventListener("pointerleave", () => {
      leaveTimer = setTimeout(() => {
        if (!pinned && document.activeElement !== button) close();
      }, 120);
    });
    button.addEventListener("focus", open);
    button.addEventListener("blur", (event) => {
      if (!pinned || event.relatedTarget && !container?.contains(event.relatedTarget)) close();
    });
    button.addEventListener("click", () => {
      if (pinned) close();
      else {
        open();
        pinned = true;
      }
    });
    return { button, container, close, position };
  });
  document.addEventListener("click", (event) => {
    settingsHelp.forEach((help) => {
      if (!help.container?.contains(event.target)) help.close();
    });
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && settingsHelp.some((help) => help.button.getAttribute("aria-expanded") === "true")) {
      event.preventDefault();
      settingsHelp.forEach((help) => help.close());
    }
  });
  window.addEventListener("resize", () => settingsHelp.forEach((help) => help.position()));
  window.addEventListener("scroll", () => settingsHelp.forEach((help) => help.position()), true);
  function setSettingsOpen(open) {
    if (!settingsToggle || !settingsPanel) return;
    settingsHelp.forEach((help) => help.close());
    settingsPanel.hidden = !open;
    document.body.dataset.settingsOpen = String(open);
    settingsToggle.setAttribute("aria-label", open ? "\u95DC\u9589\u8A2D\u5B9A" : "\u8A2D\u5B9A");
    settingsToggle.title = open ? "\u95DC\u9589\u8A2D\u5B9A" : "\u8A2D\u5B9A";
    settingsToggle.setAttribute("aria-expanded", String(open));
    if (open) byId("settings-title")?.focus();
    else settingsToggle.focus();
  }
  if (new URLSearchParams(location.search).get("settings") === "outpatient") setSettingsOpen(true);
  settingsToggle?.addEventListener("click", () => {
    setSettingsOpen(settingsPanel?.hidden === true);
  });
  settingsPanel?.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      if (settingsHelp.some((help) => help.button.getAttribute("aria-expanded") === "true")) {
        settingsHelp.forEach((help) => help.close());
        return;
      }
      setSettingsOpen(false);
    }
  });
  var destinationInput = byId("destination-url");
  var outpatientEnabledInput = byId("outpatient-enabled");
  var outpatientPeerInput = byId("outpatient-peer-id");
  var outpatientSettingsStatus = byId("outpatient-settings-status");
  for (const [id, action] of [["open-outpatient-his", "open_login"], ["outpatient-cloud-only", "cloud_only"]]) {
    byId(id)?.addEventListener("click", async () => {
      if (!backgroundStatus?.outpatientNeedsLogin || patientMismatch()) return;
      const button = byId(id);
      button.disabled = true;
      try {
        const response = await chrome.runtime.sendMessage({ type: OUTPATIENT_ACTION, runId: backgroundStatus.runId, action });
        if (!response?.ok) setMessage("\u5DE5\u4F5C\u72C0\u614B\u5DF2\u8B8A\u66F4\uFF0C\u8ACB\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u3002", "error");
      } catch {
        setMessage("\u7121\u6CD5\u9023\u63A5\u5317\u69AE\u64F4\u5145\u529F\u80FD\uFF0C\u8ACB\u78BA\u8A8D\u76EE\u524D\u5DE5\u4F5C\u3002", "error");
      } finally {
        button.disabled = false;
        await restoreBackgroundStatus();
      }
    });
  }
  byId("save-outpatient-settings")?.addEventListener("click", async () => {
    const button = byId("save-outpatient-settings");
    const enabled = outpatientEnabledInput?.checked === true;
    button.disabled = true;
    try {
      const peerId = outpatientPeerInput?.value.trim() || "";
      const nextEnabled = enabled && !!peerId;
      await saveOutpatientSettings(nextEnabled, peerId);
      if (outpatientEnabledInput) outpatientEnabledInput.checked = nextEnabled;
      await restoreBackgroundStatus().catch(() => void 0);
      if (outpatientSettingsStatus) outpatientSettingsStatus.textContent = !peerId ? "\u5DF2\u89E3\u9664\u5317\u69AE\u914D\u5C0D\uFF08\u6025\u8A3A\u8207\u9580\u8A3A\uFF09\u3002" : enabled ? "\u5DF2\u555F\u7528\uFF1A\u5F9E site=vghtpe \u5317\u69AE\u5165\u53E3\u555F\u52D5\u6642\uFF0C\u4E00\u4F75\u6574\u5408\u5317\u69AE\u9580\u8A3A\u3002" : "\u5DF2\u95DC\u9589\u9580\u8A3A\u6574\u5408\uFF1B\u6025\u8A3A\u914D\u5C0D\u4ECD\u4FDD\u7559\u3002";
    } catch {
      if (outpatientSettingsStatus) outpatientSettingsStatus.textContent = "\u8ACB\u586B\u5165\u5317\u69AE\u64F4\u5145\u529F\u80FD\u7684 32 \u5B57\u5143 ID\uFF0C\u4E14\u4E0D\u53EF\u8207\u672C\u96F2\u7AEF ID \u76F8\u540C\u3002";
    } finally {
      button.disabled = false;
    }
  });
  void Promise.all([readOutpatientEnabled(), readOutpatientPeerId()]).then(([enabled, peer]) => {
    if (outpatientEnabledInput) outpatientEnabledInput.checked = enabled;
    if (outpatientPeerInput) outpatientPeerInput.value = peer || "";
    const ownId = byId("outpatient-own-id");
    if (ownId) ownId.textContent = chrome.runtime.id;
  }).catch(() => {
    if (outpatientSettingsStatus) outpatientSettingsStatus.textContent = "\u7121\u6CD5\u8B80\u53D6\u5317\u69AE\u6574\u5408\u8A2D\u5B9A\uFF0C\u8ACB\u91CD\u65B0\u958B\u555F\u8996\u7A97\u3002";
  });
  var destinationStatus = byId("destination-status");
  byId("save-destination")?.addEventListener("click", async () => {
    if (!destinationInput || !destinationStatus) return;
    const button = byId("save-destination");
    button.disabled = true;
    try {
      const saved = await saveMediPrismaDestination(destinationInput.value);
      destinationInput.value = saved;
      destinationInput.removeAttribute("aria-invalid");
      destinationStatus.textContent = saved === MEDIPRISMA_APP_URL ? "\u5DF2\u5132\u5B58\uFF0C\u4F7F\u7528\u9810\u8A2D\u63A5\u6536\u7DB2\u5740\u3002" : "\u5DF2\u5132\u5B58\uFF0C\u4E0B\u6B21\u50B3\u9001\u6642\u4F7F\u7528\u6B64\u7DB2\u5740\u3002";
    } catch {
      destinationInput.setAttribute("aria-invalid", "true");
      destinationStatus.textContent = "\u5132\u5B58\u5931\u6557\u3002\u8ACB\u78BA\u8A8D\u7DB2\u5740\u70BA https://mediprisma.tw/app/ \u6216 https://mediprisma.tw/app-hmc/\uFF0C\u4E14\u672A\u586B\u5BEB\u53C3\u6578\u3002";
    } finally {
      button.disabled = false;
    }
  });
  if (destinationInput) {
    void readMediPrismaDestination().then((saved) => {
      destinationInput.value = saved;
    }).catch(() => {
      if (destinationStatus) destinationStatus.textContent = "\u7121\u6CD5\u8B80\u53D6\u8A2D\u5B9A\uFF0C\u8ACB\u91CD\u65B0\u5132\u5B58\u63A5\u6536\u7DB2\u5740\u3002";
    });
  }
  renderWizard();
  if (typeof chrome !== "undefined" && chrome.runtime?.id) {
    if (byId("version")) byId("version").textContent = `v${chrome.runtime.getManifest().version}`;
    const initializePopup = async () => {
      if (popupInitialized) return;
      popupInitialized = true;
      await loadPreferences();
      await restoreBackgroundStatus();
      await detectContext();
    };
    void initializePopup().catch(() => {
      renderWizard();
    });
  }
})();
/*! Bundled license information:

js-sha1/src/sha1.js:
  (*
   * [js-sha1]{@link https://github.com/emn178/js-sha1}
   *
   * @version 0.7.0
   * @author Chen, Yi-Cyuan [emn178@gmail.com]
   * @copyright Chen, Yi-Cyuan 2014-2024
   * @license MIT
   *)

@voho0000/nhi-clinical-mapper/dist/index.js:
  (*! For license information please see index.js.LEGAL.txt *)
*/
