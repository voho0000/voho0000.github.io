"use strict";
(() => {
  // src/background-job.ts
  var START_ONE_CLICK_FLOW = "medcloud:start-one-click-flow";
  var GET_ONE_CLICK_FLOW_STATE = "medcloud:get-one-click-flow-state";
  var ONE_CLICK_FLOW_STATE_CHANGED = "medcloud:one-click-flow-state-changed";
  var BACKGROUND_RESULT_TTL_MS = 60 * 60 * 1e3;
  var BACKGROUND_JOB_RECOVERY_WINDOW_MS = 10 * 60 * 1e3;

  // src/async-timeout.ts
  var AsyncTimeoutError = class extends Error {
    constructor() {
      super("ASYNC_OPERATION_TIMED_OUT");
      this.name = "AsyncTimeoutError";
    }
  };
  function withTimeout(operation, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timeoutId = globalThis.setTimeout(() => {
        reject(new AsyncTimeoutError());
      }, timeoutMs);
      void Promise.resolve(operation).then(
        (value) => {
          globalThis.clearTimeout(timeoutId);
          resolve(value);
        },
        (error) => {
          globalThis.clearTimeout(timeoutId);
          reject(error);
        }
      );
    });
  }

  // src/winforms-url-automation.ts
  var WINFORMS_PATIENT_WAIT_TIMEOUT_MS = 3e4;
  function shouldAutoLaunchFromWinForms(search) {
    const params = new URLSearchParams(search);
    return params.get("type")?.toLowerCase() === "icc" && params.get("medcloud2") === "auto";
  }

  // src/launcher.ts
  var HOST_ID = "cloud-wildcatch-one-click-launcher";
  var START_RESPONSE_TIMEOUT_MS = WINFORMS_PATIENT_WAIT_TIMEOUT_MS + 5e3;
  var STATE_RESPONSE_TIMEOUT_MS = 3e3;
  var FALLBACK_STATE_POLL_MS = 15e3;
  var VALID_PHASES = /* @__PURE__ */ new Set([
    "idle",
    "ready",
    "running",
    "opening",
    "error",
    "done"
  ]);
  function isLiveMediCloudPage() {
    return location.origin === "https://medcloud2.nhi.gov.tw" && location.pathname.startsWith("/imu/");
  }
  function isOneClickFlowState(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return VALID_PHASES.has(String(record.phase)) && typeof record.label === "string" && record.label.length <= 80 && typeof record.detail === "string" && record.detail.length <= 500 && typeof record.canStart === "boolean" && (record.diagnosticCode === void 0 || typeof record.diagnosticCode === "string" && /^[A-Z][A-Z0-9_]{2,63}$/.test(record.diagnosticCode));
  }
  function idleState() {
    return {
      phase: "idle",
      label: "\u53D6\u5F97\u75C5\u6B77\u4E26\u9001\u5230 MediPrisma",
      detail: "\u53D6\u5F97\u76EE\u524D\u75C5\u4EBA\u7684\u8EAB\u5206\u8207\u81E8\u5E8A\u53C3\u8003\u8CC7\u6599\uFF0C\u5728\u672C\u6A5F\u8F49\u6210 FHIR \u4E26\u4EA4\u7D66 MediPrisma \u672C\u6A5F\u532F\u5165\uFF1B\u5F71\u50CF Viewer URL \u53EA\u7528\u65BC\u7ACB\u5373\u958B\u555F\uFF0C\u4E0D\u5BEB\u5165 FHIR \u6216\u4EA4\u7D66 MediPrisma\u3002",
      canStart: true
    };
  }
  function launcherLogo() {
    return `
    <svg viewBox="0 0 512 512" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="cwc-fire" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#f15a24"/>
          <stop offset="100%" stop-color="#ef4136"/>
        </linearGradient>
        <linearGradient id="cwc-core" x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stop-color="#fbb040" stop-opacity=".8"/>
          <stop offset="100%" stop-color="#ffd400" stop-opacity=".6"/>
        </linearGradient>
      </defs>
      <path d="M89 412c-39 0-64-30-60-67 4-36 32-64 68-66-7-61 27-134 82-167 26-15 53-8 71 16 20-61 79-96 142-85 62 11 105 66 98 133-2 21-7 40-16 56 47 19 53 56 34 83-9 13-22 22-38 25 7 38-22 72-62 72H89"
        fill="#eaf6ff" stroke="#0072bc" stroke-width="30" stroke-linecap="round" stroke-linejoin="round"/>
      <g transform="translate(36 80.5) scale(.8)">
        <path d="M180 220v160" stroke="#009b4d" stroke-width="45" stroke-linecap="round"/>
        <circle cx="180" cy="160" r="35" fill="#009b4d"/>
      </g>
      <g transform="translate(66.4 76) scale(.8)">
        <path d="M332 380s98-40 98-140c0-100-50-160-90-200 0 0 20 60 0 120S256 40 256 40s44 110 24 200 52 140 52 140Z" fill="url(#cwc-fire)"/>
        <path d="M310 340s60-30 60-100c0-60-30-100-50-130 0 0 10 40 0 80s-50-70-50-70 20 60 10 120 30 100 30 100Z" fill="url(#cwc-core)"/>
      </g>
      <path d="M180 280h120" stroke="#009b4d" stroke-width="35" stroke-linecap="round" opacity=".8"/>
      <rect x="160" y="400" width="192" height="15" rx="7" fill="#0072bc"/>
    </svg>
  `;
  }
  function mountLauncher() {
    if (!isLiveMediCloudPage() || document.getElementById(HOST_ID)) return;
    const host = document.createElement("div");
    host.id = HOST_ID;
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
    <style>
      :host {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        right: max(16px, env(safe-area-inset-right));
        top: 52%;
        transform: translateY(-50%);
        color-scheme: light;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans TC", sans-serif;
      }
      :host([hidden]) { display: none; }
      *, *::before, *::after { box-sizing: border-box; }
      button {
        width: 62px;
        min-height: 62px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 10px;
        overflow: hidden;
        padding: 6px;
        border: 1px solid rgba(0, 114, 188, .28);
        border-radius: 999px;
        background: rgba(255, 255, 255, .97);
        color: #0f3057;
        box-shadow: 0 10px 30px rgba(15, 48, 87, .22), 0 2px 8px rgba(15, 48, 87, .12);
        cursor: pointer;
        transition: width .2s ease, box-shadow .2s ease, border-color .2s ease, transform .2s ease;
        -webkit-font-smoothing: antialiased;
      }
      button:hover,
      button:focus-visible,
      button:is(
        [data-state="checking"],
        [data-state="ready"],
        [data-state="running"],
        [data-state="opening"],
        [data-state="error"]
      ) {
        width: min(286px, calc(100vw - 32px));
        border-color: rgba(0, 114, 188, .58);
        box-shadow: 0 14px 34px rgba(15, 48, 87, .27), 0 3px 9px rgba(15, 48, 87, .14);
      }
      button:hover { transform: translateX(-2px); }
      button:focus-visible {
        outline: 3px solid rgba(37, 99, 235, .28);
        outline-offset: 3px;
      }
      button:disabled {
        cursor: wait;
        opacity: 1;
      }
      .mark {
        position: relative;
        width: 48px;
        height: 48px;
        flex: 0 0 48px;
        display: grid;
        place-items: center;
        border-radius: 50%;
        background: #f7fcff;
      }
      .mark svg { width: 44px; height: 44px; display: block; }
      .copy {
        min-width: 0;
        padding-right: 12px;
        opacity: 0;
        transform: translateX(6px);
        transition: opacity .16s ease, transform .16s ease;
        text-align: left;
        white-space: nowrap;
      }
      button:hover .copy,
      button:focus-visible .copy,
      button:is(
        [data-state="checking"],
        [data-state="ready"],
        [data-state="running"],
        [data-state="opening"],
        [data-state="error"]
      ) .copy {
        opacity: 1;
        transform: translateX(0);
      }
      .label {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 14px;
        line-height: 1.35;
        font-weight: 700;
        letter-spacing: .01em;
      }
      .hint {
        display: block;
        margin-top: 2px;
        overflow: hidden;
        text-overflow: ellipsis;
        color: #60758b;
        font-size: 11px;
        line-height: 1.35;
        font-weight: 500;
      }
      button[data-state="running"] .mark::after,
      button[data-state="opening"] .mark::after,
      button[data-state="checking"] .mark::after {
        content: "";
        position: absolute;
        inset: -2px;
        border: 3px solid rgba(0, 114, 188, .16);
        border-top-color: #0072bc;
        border-radius: 50%;
        animation: cwc-spin .85s linear infinite;
      }
      button[data-state="error"] {
        width: min(430px, calc(100vw - 32px));
        min-height: 92px;
        border-color: rgba(185, 28, 28, .42);
        background: #fffafa;
        color: #991b1b;
      }
      button[data-state="error"] .copy {
        padding-top: 4px;
        padding-bottom: 4px;
        white-space: normal;
      }
      button[data-state="error"] .hint {
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
      }
      .diagnostic {
        display: block;
        width: fit-content;
        margin-top: 5px;
        padding: 2px 6px;
        border: 1px solid rgba(185, 28, 28, .22);
        border-radius: 4px;
        background: rgba(185, 28, 28, .06);
        color: #7f1d1d;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        /* The code a clinician is asked to report must not be the smallest
           text on a clinic monitor. */
        font-size: 12px;
        line-height: 1.35;
        letter-spacing: .02em;
      }
      .diagnostic[hidden] { display: none; }
      button[data-state="done"] {
        border-color: rgba(4, 120, 87, .38);
        background: #f4fff9;
        color: #065f46;
      }
      button[data-state="ready"] {
        border-color: rgba(217, 119, 6, .42);
        background: #fffbeb;
        color: #92400e;
      }
      @keyframes cwc-spin { to { transform: rotate(360deg); } }
      @media (prefers-reduced-motion: reduce) {
        button, .copy { transition: none; }
        button[data-state] .mark::after { animation-duration: 1.8s; }
      }
      @media (max-width: 640px) {
        :host { right: 10px; top: auto; bottom: 18px; transform: none; }
        button:hover,
        button:focus-visible,
        button:is(
          [data-state="checking"],
          [data-state="ready"],
          [data-state="running"],
          [data-state="opening"],
          [data-state="error"]
        ) {
          width: min(260px, calc(100vw - 20px));
        }
        button[data-state="error"] {
          width: min(340px, calc(100vw - 20px));
        }
      }
    </style>
    <button type="button" data-state="idle" aria-label="\u53D6\u5F97\u75C5\u6B77\u4E26\u9001\u5230 MediPrisma">
      <span class="mark">${launcherLogo()}</span>
      <span class="copy">
        <span class="label">\u53D6\u5F97\u75C5\u6B77\u4E26\u9001\u5230 MediPrisma</span>
        <span class="hint">\u672C\u6A5F\u8F49\u6210 FHIR \u2192 MediPrisma</span>
        <span class="diagnostic" hidden></span>
      </span>
    </button>
    <span class="live" role="status" aria-live="polite" style="position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0"></span>
  `;
    document.documentElement.appendChild(host);
    const button = shadow.querySelector("button");
    const label = shadow.querySelector(".label");
    const hint = shadow.querySelector(".hint");
    const diagnostic = shadow.querySelector(".diagnostic");
    const live = shadow.querySelector(".live");
    if (!button || !label || !hint || !diagnostic || !live) {
      host.remove();
      return;
    }
    let state = idleState();
    let requestInFlight = false;
    let runtimeUnavailable = false;
    const render = (next) => {
      if (next === "checking") {
        button.dataset.state = "checking";
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.setAttribute("aria-label", "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA");
        button.title = "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u2026";
        label.textContent = "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA\u2026";
        hint.textContent = "\u5373\u5C07\u958B\u59CB\u4E00\u9375\u8655\u7406";
        diagnostic.hidden = true;
        diagnostic.textContent = "";
        live.textContent = "\u6B63\u5728\u78BA\u8A8D\u76EE\u524D\u75C5\u4EBA";
        return;
      }
      state = next;
      button.dataset.state = next.phase;
      button.disabled = !next.canStart;
      button.toggleAttribute(
        "aria-busy",
        next.phase === "running" || next.phase === "opening"
      );
      button.setAttribute("aria-label", next.label);
      button.title = next.detail;
      label.textContent = next.label;
      hint.textContent = next.phase === "idle" ? "\u672C\u6A5F\u8F49\u6210 FHIR \u2192 MediPrisma" : next.detail;
      diagnostic.hidden = !next.diagnosticCode;
      diagnostic.textContent = next.diagnosticCode ? `\u932F\u8AA4\u4EE3\u78BC ${next.diagnosticCode}` : "";
      live.textContent = next.label;
    };
    const applyResponse = (response) => {
      if (isOneClickFlowState(response?.state)) {
        runtimeUnavailable = false;
        render(response.state);
        return;
      }
      runtimeUnavailable = true;
      render({
        phase: "error",
        label: "\u64F4\u5145\u529F\u80FD\u5DF2\u66F4\u65B0\uFF0C\u9EDE\u6B64\u91CD\u65B0\u8F09\u5165",
        detail: "\u91CD\u65B0\u8F09\u5165\u96F2\u7AEF\u75C5\u6B77\u9801\u9762\u5F8C\uFF0C\u6703\u81EA\u52D5\u9023\u63A5\u65B0\u7248\u64F4\u5145\u529F\u80FD\u3002",
        canStart: true
      });
    };
    const sendOneClickMessage = (type, timeoutMs) => withTimeout(
      chrome.runtime.sendMessage({ type }),
      timeoutMs
    );
    const startFlow = async () => {
      if (!state.canStart || requestInFlight) return;
      if (runtimeUnavailable) {
        requestInFlight = true;
        render("checking");
        label.textContent = "\u6B63\u5728\u91CD\u65B0\u8F09\u5165\u9801\u9762\u2026";
        hint.textContent = "\u5373\u5C07\u9023\u63A5\u65B0\u7248\u64F4\u5145\u529F\u80FD";
        location.reload();
        return;
      }
      requestInFlight = true;
      render("checking");
      try {
        const response = await sendOneClickMessage(
          START_ONE_CLICK_FLOW,
          START_RESPONSE_TIMEOUT_MS
        );
        applyResponse(response);
      } catch {
        requestInFlight = false;
        await refresh();
      } finally {
        requestInFlight = false;
      }
    };
    const refresh = async () => {
      if (!isLiveMediCloudPage()) {
        host.hidden = true;
        return;
      }
      host.hidden = false;
      if (requestInFlight) return;
      try {
        const response = await sendOneClickMessage(
          GET_ONE_CLICK_FLOW_STATE,
          STATE_RESPONSE_TIMEOUT_MS
        );
        applyResponse(response);
      } catch {
        applyResponse(void 0);
      }
    };
    button.addEventListener("click", () => {
      void startFlow();
    });
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || typeof message !== "object" || Array.isArray(message)) return;
      const candidate = message;
      if (candidate.type === ONE_CLICK_FLOW_STATE_CHANGED && isOneClickFlowState(candidate.state)) {
        render(candidate.state);
      }
    });
    window.setInterval(() => {
      if (state.phase === "running" || state.phase === "opening") {
        void refresh();
      }
    }, FALLBACK_STATE_POLL_MS);
    const autoLaunch = shouldAutoLaunchFromWinForms(location.search);
    if (autoLaunch) void startFlow();
    else void refresh();
  }
  mountLauncher();
})();
