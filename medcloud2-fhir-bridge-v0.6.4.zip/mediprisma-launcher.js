"use strict";
(() => {
  // src/mediprisma-launch-protocol.ts
  var MEDIPRISMA_LAUNCH_ORIGIN = "https://mediprisma.tw";
  var MEDIPRISMA_LAUNCH_SITE = "vghtpe";
  var MEDIPRISMA_ENCRYPTED_CREDENTIAL = "a256gcm.v1.tgl2jQWbtxSUD1ni.oYRirKb2NWUj5tfHMGWv9x5bVLAyb_e8nw.fN7CtZbNmzKOuHJdOBQEww";
  var MEDIPRISMA_LAUNCH_CONTEXT_TYPE = "MEDIPRISMA_LAUNCH_CONTEXT";
  var MEDIPRISMA_LAUNCH_CONTEXT_ACK_TYPE = "MEDIPRISMA_LAUNCH_CONTEXT_ACK";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isEncryptedMediPrismaCredential(value) {
    return typeof value === "string" && /^a256gcm\.v1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/u.test(value);
  }
  function isExactMediPrismaLaunchUrl(raw) {
    try {
      const url = new URL(raw);
      if (url.origin !== MEDIPRISMA_LAUNCH_ORIGIN || url.pathname !== "/app/" || url.hash !== "") {
        return false;
      }
      let entryCount = 0;
      url.searchParams.forEach(() => {
        entryCount += 1;
      });
      return entryCount === 2 && url.searchParams.getAll("medcloud2").length === 1 && url.searchParams.get("medcloud2") === "auto" && url.searchParams.getAll("site").length === 1 && url.searchParams.get("site") === MEDIPRISMA_LAUNCH_SITE;
    } catch {
      return false;
    }
  }
  function isMediPrismaLaunchContextAck(data, messageId) {
    return isRecord(data) && data.type === MEDIPRISMA_LAUNCH_CONTEXT_ACK_TYPE && data.messageId === messageId;
  }

  // src/mediprisma-launch-context.ts
  var MEDIPRISMA_LAUNCH_RETRY_MS = 500;
  var MEDIPRISMA_LAUNCH_TIMEOUT_MS = 3e4;
  async function startMediPrismaLaunchContext(runtime) {
    if (!isExactMediPrismaLaunchUrl(runtime.currentUrl())) return null;
    if (!isEncryptedMediPrismaCredential(runtime.encryptedCredential)) return null;
    const messageId = runtime.randomUUID();
    let activeCredential = runtime.encryptedCredential;
    let stopped = false;
    let retryTimer;
    let expiryTimer;
    let removeMessageListener = () => void 0;
    let removePageHideListener = () => void 0;
    const stop = () => {
      if (stopped) return;
      stopped = true;
      if (retryTimer !== void 0) runtime.cancel(retryTimer);
      if (expiryTimer !== void 0) runtime.cancel(expiryTimer);
      removeMessageListener();
      removePageHideListener();
      activeCredential = "";
    };
    const send = () => {
      if (stopped) return;
      if (!isExactMediPrismaLaunchUrl(runtime.currentUrl())) {
        stop();
        return;
      }
      runtime.postMessage({
        source: "medcloud2-extension",
        type: MEDIPRISMA_LAUNCH_CONTEXT_TYPE,
        version: 1,
        messageId,
        site: MEDIPRISMA_LAUNCH_SITE,
        credential: activeCredential
      }, MEDIPRISMA_LAUNCH_ORIGIN);
      retryTimer = runtime.schedule(send, MEDIPRISMA_LAUNCH_RETRY_MS);
    };
    removeMessageListener = runtime.addMessageListener((event) => {
      if (event.origin === MEDIPRISMA_LAUNCH_ORIGIN && event.source === runtime.pageWindow && isMediPrismaLaunchContextAck(event.data, messageId)) {
        stop();
      }
    });
    removePageHideListener = runtime.addPageHideListener(stop);
    expiryTimer = runtime.schedule(stop, MEDIPRISMA_LAUNCH_TIMEOUT_MS);
    send();
    return { messageId, stop };
  }

  // src/mediprisma-launcher.ts
  void startMediPrismaLaunchContext({
    currentUrl: () => location.href,
    pageWindow: window,
    randomUUID: () => crypto.randomUUID(),
    encryptedCredential: MEDIPRISMA_ENCRYPTED_CREDENTIAL,
    postMessage: (message, targetOrigin) => window.postMessage(message, targetOrigin),
    addMessageListener: (listener) => {
      const wrapped = (event) => listener(event);
      window.addEventListener("message", wrapped);
      return () => window.removeEventListener("message", wrapped);
    },
    addPageHideListener: (listener) => {
      window.addEventListener("pagehide", listener, { once: true });
      return () => window.removeEventListener("pagehide", listener);
    },
    schedule: (callback, delayMs) => setTimeout(callback, delayMs),
    cancel: (handle) => clearTimeout(handle)
  }).catch(() => void 0);
})();
