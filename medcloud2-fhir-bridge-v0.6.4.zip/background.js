"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // (disabled):crypto
  var require_crypto = __commonJS({
    "(disabled):crypto"() {
    }
  });

  // (disabled):../../../../../../../node_modules/buffer/index.js
  var require_buffer = __commonJS({
    "(disabled):../../../../../../../node_modules/buffer/index.js"() {
    }
  });

  // ../node_modules/js-sha1/src/sha1.js
  var require_sha1 = __commonJS({
    "../node_modules/js-sha1/src/sha1.js"(exports, module) {
      (function() {
        "use strict";
        var INPUT_ERROR = "input is invalid type";
        var FINALIZE_ERROR = "finalize already called";
        var WINDOW = typeof window === "object";
        var root = WINDOW ? window : {};
        if (root.JS_SHA1_NO_WINDOW) {
          WINDOW = false;
        }
        var WEB_WORKER = !WINDOW && typeof self === "object";
        var NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === "object" && process.versions && process.versions.node;
        if (NODE_JS) {
          root = global;
        } else if (WEB_WORKER) {
          root = self;
        }
        var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === "object" && module.exports;
        var AMD = typeof define === "function" && define.amd;
        var ARRAY_BUFFER = !root.JS_SHA1_NO_ARRAY_BUFFER && typeof ArrayBuffer !== "undefined";
        var HEX_CHARS = "0123456789abcdef".split("");
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var OUTPUT_TYPES = ["hex", "array", "digest", "arrayBuffer"];
        var blocks = [];
        var isArray = Array.isArray;
        if (root.JS_SHA1_NO_NODE_JS || !isArray) {
          isArray = function(obj) {
            return Object.prototype.toString.call(obj) === "[object Array]";
          };
        }
        var isView = ArrayBuffer.isView;
        if (ARRAY_BUFFER && (root.JS_SHA1_NO_ARRAY_BUFFER_IS_VIEW || !isView)) {
          isView = function(obj) {
            return typeof obj === "object" && obj.buffer && obj.buffer.constructor === ArrayBuffer;
          };
        }
        var formatMessage = function(message) {
          var type = typeof message;
          if (type === "string") {
            return [message, true];
          }
          if (type !== "object" || message === null) {
            throw new Error(INPUT_ERROR);
          }
          if (ARRAY_BUFFER && message.constructor === ArrayBuffer) {
            return [new Uint8Array(message), false];
          }
          if (!isArray(message) && !isView(message)) {
            throw new Error(INPUT_ERROR);
          }
          return [message, false];
        };
        var createOutputMethod = function(outputType) {
          return function(message) {
            return new Sha1(true).update(message)[outputType]();
          };
        };
        var createMethod = function() {
          var method = createOutputMethod("hex");
          if (NODE_JS) {
            method = nodeWrap(method);
          }
          method.create = function() {
            return new Sha1();
          };
          method.update = function(message) {
            return method.create().update(message);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createOutputMethod(type);
          }
          return method;
        };
        var nodeWrap = function(method) {
          var crypto2 = require_crypto();
          var Buffer2 = require_buffer().Buffer;
          var bufferFrom;
          if (Buffer2.from && !root.JS_SHA1_NO_BUFFER_FROM) {
            bufferFrom = Buffer2.from;
          } else {
            bufferFrom = function(message) {
              return new Buffer2(message);
            };
          }
          var nodeMethod = function(message) {
            if (typeof message === "string") {
              return crypto2.createHash("sha1").update(message, "utf8").digest("hex");
            } else {
              if (message === null || message === void 0) {
                throw new Error(INPUT_ERROR);
              } else if (message.constructor === ArrayBuffer) {
                message = new Uint8Array(message);
              }
            }
            if (isArray(message) || isView(message) || message.constructor === Buffer2) {
              return crypto2.createHash("sha1").update(bufferFrom(message)).digest("hex");
            } else {
              return method(message);
            }
          };
          return nodeMethod;
        };
        var createHmacOutputMethod = function(outputType) {
          return function(key, message) {
            return new HmacSha1(key, true).update(message)[outputType]();
          };
        };
        var createHmacMethod = function() {
          var method = createHmacOutputMethod("hex");
          method.create = function(key) {
            return new HmacSha1(key);
          };
          method.update = function(key, message) {
            return method.create(key).update(message);
          };
          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createHmacOutputMethod(type);
          }
          return method;
        };
        function Sha1(sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }
          this.h0 = 1732584193;
          this.h1 = 4023233417;
          this.h2 = 2562383102;
          this.h3 = 271733878;
          this.h4 = 3285377520;
          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
        }
        Sha1.prototype.update = function(message) {
          if (this.finalized) {
            throw new Error(FINALIZE_ERROR);
          }
          var result = formatMessage(message);
          message = result[0];
          var isString = result[1];
          var code, index = 0, i, length = message.length || 0, blocks2 = this.blocks;
          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks2[0] = this.block;
              this.block = blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
            }
            if (isString) {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message.charCodeAt(index);
                if (code < 128) {
                  blocks2[i >>> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 2048) {
                  blocks2[i >>> 2] |= (192 | code >>> 6) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else if (code < 55296 || code >= 57344) {
                  blocks2[i >>> 2] |= (224 | code >>> 12) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                } else {
                  code = 65536 + ((code & 1023) << 10 | message.charCodeAt(++index) & 1023);
                  blocks2[i >>> 2] |= (240 | code >>> 18) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 12 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code >>> 6 & 63) << SHIFT[i++ & 3];
                  blocks2[i >>> 2] |= (128 | code & 63) << SHIFT[i++ & 3];
                }
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks2[i >>> 2] |= message[index] << SHIFT[i++ & 3];
              }
            }
            this.lastByteIndex = i;
            this.bytes += i - this.start;
            if (i >= 64) {
              this.block = blocks2[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }
          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }
          return this;
        };
        Sha1.prototype.finalize = function() {
          if (this.finalized) {
            return;
          }
          this.finalized = true;
          var blocks2 = this.blocks, i = this.lastByteIndex;
          blocks2[16] = this.block;
          blocks2[i >>> 2] |= EXTRA[i & 3];
          this.block = blocks2[16];
          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }
            blocks2[0] = this.block;
            blocks2[16] = blocks2[1] = blocks2[2] = blocks2[3] = blocks2[4] = blocks2[5] = blocks2[6] = blocks2[7] = blocks2[8] = blocks2[9] = blocks2[10] = blocks2[11] = blocks2[12] = blocks2[13] = blocks2[14] = blocks2[15] = 0;
          }
          blocks2[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks2[15] = this.bytes << 3;
          this.hash();
        };
        Sha1.prototype.hash = function() {
          var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
          var f, j, t, blocks2 = this.blocks;
          for (j = 16; j < 80; ++j) {
            t = blocks2[j - 3] ^ blocks2[j - 8] ^ blocks2[j - 14] ^ blocks2[j - 16];
            blocks2[j] = t << 1 | t >>> 31;
          }
          for (j = 0; j < 20; j += 5) {
            f = b & c | ~b & d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1518500249 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | ~a & c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1518500249 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | ~e & b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1518500249 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | ~d & a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1518500249 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | ~c & e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1518500249 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 40; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e + 1859775393 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d + 1859775393 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c + 1859775393 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b + 1859775393 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a + 1859775393 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 60; j += 5) {
            f = b & c | b & d | c & d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 1894007588 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a & b | a & c | b & c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 1894007588 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e & a | e & b | a & b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 1894007588 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d & e | d & a | e & a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 1894007588 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c & d | c & e | d & e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 1894007588 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          for (; j < 80; j += 5) {
            f = b ^ c ^ d;
            t = a << 5 | a >>> 27;
            e = t + f + e - 899497514 + blocks2[j] << 0;
            b = b << 30 | b >>> 2;
            f = a ^ b ^ c;
            t = e << 5 | e >>> 27;
            d = t + f + d - 899497514 + blocks2[j + 1] << 0;
            a = a << 30 | a >>> 2;
            f = e ^ a ^ b;
            t = d << 5 | d >>> 27;
            c = t + f + c - 899497514 + blocks2[j + 2] << 0;
            e = e << 30 | e >>> 2;
            f = d ^ e ^ a;
            t = c << 5 | c >>> 27;
            b = t + f + b - 899497514 + blocks2[j + 3] << 0;
            d = d << 30 | d >>> 2;
            f = c ^ d ^ e;
            t = b << 5 | b >>> 27;
            a = t + f + a - 899497514 + blocks2[j + 4] << 0;
            c = c << 30 | c >>> 2;
          }
          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return HEX_CHARS[h0 >>> 28 & 15] + HEX_CHARS[h0 >>> 24 & 15] + HEX_CHARS[h0 >>> 20 & 15] + HEX_CHARS[h0 >>> 16 & 15] + HEX_CHARS[h0 >>> 12 & 15] + HEX_CHARS[h0 >>> 8 & 15] + HEX_CHARS[h0 >>> 4 & 15] + HEX_CHARS[h0 & 15] + HEX_CHARS[h1 >>> 28 & 15] + HEX_CHARS[h1 >>> 24 & 15] + HEX_CHARS[h1 >>> 20 & 15] + HEX_CHARS[h1 >>> 16 & 15] + HEX_CHARS[h1 >>> 12 & 15] + HEX_CHARS[h1 >>> 8 & 15] + HEX_CHARS[h1 >>> 4 & 15] + HEX_CHARS[h1 & 15] + HEX_CHARS[h2 >>> 28 & 15] + HEX_CHARS[h2 >>> 24 & 15] + HEX_CHARS[h2 >>> 20 & 15] + HEX_CHARS[h2 >>> 16 & 15] + HEX_CHARS[h2 >>> 12 & 15] + HEX_CHARS[h2 >>> 8 & 15] + HEX_CHARS[h2 >>> 4 & 15] + HEX_CHARS[h2 & 15] + HEX_CHARS[h3 >>> 28 & 15] + HEX_CHARS[h3 >>> 24 & 15] + HEX_CHARS[h3 >>> 20 & 15] + HEX_CHARS[h3 >>> 16 & 15] + HEX_CHARS[h3 >>> 12 & 15] + HEX_CHARS[h3 >>> 8 & 15] + HEX_CHARS[h3 >>> 4 & 15] + HEX_CHARS[h3 & 15] + HEX_CHARS[h4 >>> 28 & 15] + HEX_CHARS[h4 >>> 24 & 15] + HEX_CHARS[h4 >>> 20 & 15] + HEX_CHARS[h4 >>> 16 & 15] + HEX_CHARS[h4 >>> 12 & 15] + HEX_CHARS[h4 >>> 8 & 15] + HEX_CHARS[h4 >>> 4 & 15] + HEX_CHARS[h4 & 15];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function() {
          this.finalize();
          var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
          return [
            h0 >>> 24 & 255,
            h0 >>> 16 & 255,
            h0 >>> 8 & 255,
            h0 & 255,
            h1 >>> 24 & 255,
            h1 >>> 16 & 255,
            h1 >>> 8 & 255,
            h1 & 255,
            h2 >>> 24 & 255,
            h2 >>> 16 & 255,
            h2 >>> 8 & 255,
            h2 & 255,
            h3 >>> 24 & 255,
            h3 >>> 16 & 255,
            h3 >>> 8 & 255,
            h3 & 255,
            h4 >>> 24 & 255,
            h4 >>> 16 & 255,
            h4 >>> 8 & 255,
            h4 & 255
          ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function() {
          this.finalize();
          var buffer = new ArrayBuffer(20);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          return buffer;
        };
        function HmacSha1(key, sharedMemory) {
          var i, result = formatMessage(key);
          key = result[0];
          if (result[1]) {
            var bytes = [], length = key.length, index = 0, code;
            for (i = 0; i < length; ++i) {
              code = key.charCodeAt(i);
              if (code < 128) {
                bytes[index++] = code;
              } else if (code < 2048) {
                bytes[index++] = 192 | code >>> 6;
                bytes[index++] = 128 | code & 63;
              } else if (code < 55296 || code >= 57344) {
                bytes[index++] = 224 | code >>> 12;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              } else {
                code = 65536 + ((code & 1023) << 10 | key.charCodeAt(++i) & 1023);
                bytes[index++] = 240 | code >>> 18;
                bytes[index++] = 128 | code >>> 12 & 63;
                bytes[index++] = 128 | code >>> 6 & 63;
                bytes[index++] = 128 | code & 63;
              }
            }
            key = bytes;
          }
          if (key.length > 64) {
            key = new Sha1(true).update(key).array();
          }
          var oKeyPad = [], iKeyPad = [];
          for (i = 0; i < 64; ++i) {
            var b = key[i] || 0;
            oKeyPad[i] = 92 ^ b;
            iKeyPad[i] = 54 ^ b;
          }
          Sha1.call(this, sharedMemory);
          this.update(iKeyPad);
          this.oKeyPad = oKeyPad;
          this.inner = true;
          this.sharedMemory = sharedMemory;
        }
        HmacSha1.prototype = new Sha1();
        HmacSha1.prototype.finalize = function() {
          Sha1.prototype.finalize.call(this);
          if (this.inner) {
            this.inner = false;
            var innerHash = this.array();
            Sha1.call(this, this.sharedMemory);
            this.update(this.oKeyPad);
            this.update(innerHash);
            Sha1.prototype.finalize.call(this);
          }
        };
        var exports2 = createMethod();
        exports2.sha1 = exports2;
        exports2.sha1.hmac = createHmacMethod();
        if (COMMON_JS) {
          module.exports = exports2;
        } else {
          root.sha1 = exports2;
          if (AMD) {
            define(function() {
              return exports2;
            });
          }
        }
      })();
    }
  });

  // ../packages/medcloud-adapter/src/constants.ts
  var MEDCLOUD_ADAPTER_VERSION = "0.6.4";
  var IMUE0060_SOURCE_MODULE = "IMUE0060";
  var IMUE0060_DATASET_SCOPE = "/imu/api/imue0060/imue0060s02/get-data";
  var IMUE0008_SOURCE_MODULE = "IMUE0008";
  var IMUE0008_DATASET_SCOPE = "/imu/api/imue0008/imue0008s02/get-data";
  var IMUE0130_SOURCE_MODULE = "IMUE0130";
  var IMUE0130_DATASET_SCOPE = "/imu/api/imue0130/imue0130s02/get-data";
  var IMUE0030_SOURCE_MODULE = "IMUE0030";
  var IMUE0030_DATASET_SCOPE = "/imu/api/imue0030/imue0030s02/get-data";
  var IMUE0010_SOURCE_MODULE = "IMUE0010";
  var IMUE0010_DATASET_SCOPE = "/imu/api/imue0010/imue0010s02/get-data";
  var IMUE0120_SOURCE_MODULE = "IMUE0120";
  var IMUE0120_DATASET_SCOPE = "/imu/api/imue0120/imue0120s01/pres-med-day";
  var IMUE0140_SOURCE_MODULE = "IMUE0140";
  var IMUE0140_DATASET_SCOPE = "/imu/api/imue0140/imue0140s01/hpa-data";
  var IMUE0070_SOURCE_MODULE = "IMUE0070";
  var IMUE0070_DATASET_SCOPE = "/imu/api/imue0070/imue0070s02/get-data";
  var IMUE0080_SOURCE_MODULE = "IMUE0080";
  var IMUE0080_DATASET_SCOPE = "/imu/api/imue0080/imue0080s02/get-data";
  var IMUE0150_SOURCE_MODULE = "IMUE0150";
  var IMUE0150_DATASET_SCOPE = "/imu/api/imue0150/imue0150s01/hpa-data";
  var MEDCLOUD_CLINICAL_MODULES = [
    { sourceModule: IMUE0060_SOURCE_MODULE, datasetScope: IMUE0060_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C" },
    { sourceModule: IMUE0008_SOURCE_MODULE, datasetScope: IMUE0008_DATASET_SCOPE, label: "\u897F\u91AB\u7528\u85E5" },
    { sourceModule: IMUE0130_SOURCE_MODULE, datasetScope: IMUE0130_DATASET_SCOPE, label: "\u6587\u5B57\u5831\u544A" },
    { sourceModule: IMUE0030_SOURCE_MODULE, datasetScope: IMUE0030_DATASET_SCOPE, label: "\u7259\u79D1\u8655\u7F6E" },
    { sourceModule: IMUE0010_SOURCE_MODULE, datasetScope: IMUE0010_DATASET_SCOPE, label: "\u6AA2\u67E5\u6AA2\u9A57\u7D00\u9304" },
    { sourceModule: IMUE0070_SOURCE_MODULE, datasetScope: IMUE0070_DATASET_SCOPE, label: "\u4F4F\u9662\u53CA\u51FA\u9662\u75C5\u6B77\u6458\u8981" },
    { sourceModule: IMUE0080_SOURCE_MODULE, datasetScope: IMUE0080_DATASET_SCOPE, label: "\u5FA9\u5065\u91AB\u7642\u7D00\u9304" },
    { sourceModule: IMUE0120_SOURCE_MODULE, datasetScope: IMUE0120_DATASET_SCOPE, label: "\u9580\u8A3A\u85E5\u54C1\u9918\u85E5\u65E5\u6578" },
    { sourceModule: IMUE0140_SOURCE_MODULE, datasetScope: IMUE0140_DATASET_SCOPE, label: "\u6210\u4EBA\u9810\u9632\u4FDD\u5065" },
    { sourceModule: IMUE0150_SOURCE_MODULE, datasetScope: IMUE0150_DATASET_SCOPE, label: "\u764C\u75C7\u7BE9\u6AA2\u7D50\u679C" }
  ];

  // ../packages/medcloud-adapter/src/coding.ts
  var NHI_MEDICAL_ORDER_CODE_RE = /^\d{5}[A-Z]$/;
  var KNOWN_NHI_DENTAL_PROGRAM_CODES = /* @__PURE__ */ new Set(["91090C", "P7301C", "P7302C"]);
  var NHI_DENTAL_PROGRAM_TRANSITION_DATE = "2024-03-01";
  var NHI_DENTAL_PROGRAM_CODE_SYSTEM = "https://cloud-wildcatch.invalid/fhir/CodeSystem/medcloud-nhi-dental-program-service";
  var NHI_DENTAL_PROGRAM_CODE_SYSTEM_VERSION = "2024-03-01";
  function hasReasonableNhiMedicalOrderCode(value) {
    return NHI_MEDICAL_ORDER_CODE_RE.test(String(value ?? "").trim().toUpperCase());
  }
  function isKnownNhiDentalProgramCode(value) {
    return KNOWN_NHI_DENTAL_PROGRAM_CODES.has(String(value ?? "").trim().toUpperCase());
  }
  function usesNhiDentalProgramCodeSystem(value, performedDate) {
    if (!isKnownNhiDentalProgramCode(value)) return false;
    const date = String(performedDate ?? "").trim().slice(0, 10);
    return !/^\d{4}-\d{2}-\d{2}$/.test(date) || date >= NHI_DENTAL_PROGRAM_TRANSITION_DATE;
  }

  // ../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message = "Required";
        } else {
          message = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message = `Invalid ${issue.validation}`;
        } else {
          message = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message = "Number must be finite";
        break;
      default:
        message = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message };
  };
  var en_default = errorMap;

  // ../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
    errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
  })(errorUtil || (errorUtil = {}));

  // ../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message) {
      const getIssueProperties = (val) => {
        if (typeof message === "string" || typeof message === "undefined") {
          return { message };
        } else if (typeof message === "function") {
          return message(val);
        } else {
          return message;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
    }
    url(message) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
    }
    emoji(message) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
    }
    uuid(message) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
    }
    nanoid(message) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
    }
    cuid(message) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
    }
    cuid2(message) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
    }
    ulid(message) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
    }
    base64(message) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
    }
    base64url(message) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message) {
      return this._addCheck({ kind: "date", message });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
    }
    regex(regex, message) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    endsWith(value, message) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    min(minLength, message) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message)
      });
    }
    max(maxLength, message) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message)
      });
    }
    length(len, message) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message) {
      return this.min(1, errorUtil.errToObj(message));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message)
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    finite(message) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message)
      });
    }
    safe(message) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    max(maxDate, message) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message) }
      });
    }
    max(maxLength, message) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message) }
      });
    }
    length(len, message) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message) }
      });
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message) }
      });
    }
    max(maxSize, message) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message) }
      });
    }
    size(size, message) {
      return this.min(size, message).max(size, message);
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = /* @__PURE__ */ Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: ((arg) => ZodString.create({ ...arg, coerce: true })),
    number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
    boolean: ((arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    })),
    bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
    date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
  };
  var NEVER = INVALID;

  // ../packages/contracts/src/completeness.ts
  var CompletenessSchema = external_exports.enum(["complete", "empty", "partial", "failed"]);
  function markPartial(completeness) {
    return completeness === "complete" ? "partial" : completeness;
  }

  // ../packages/contracts/src/context.ts
  var PatientContextHashSchema = external_exports.string().min(16).max(256).regex(/^[A-Za-z0-9_-]+$/, "patientContextHash must be hex or base64url-like");
  var ProviderContextSchema = external_exports.object({
    identifier: external_exports.string().min(1).optional(),
    display: external_exports.string().min(1).optional()
  }).strict();
  var RecordContextSchema = external_exports.object({
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    sourceRecordKeyHmac: external_exports.string().min(16).optional(),
    capturedAt: external_exports.string().datetime({ offset: true }),
    adapterVersion: external_exports.string().min(1),
    patientContextHash: PatientContextHashSchema,
    provider: ProviderContextSchema.optional()
  }).strict();

  // ../packages/contracts/src/date.ts
  var DatePrecisionSchema = external_exports.enum(["year", "month", "day", "minute", "second"]);
  var DateSourceFormatSchema = external_exports.enum([
    "iso-date",
    "iso-date-time",
    "gregorian-slash",
    "roc-slash",
    "compact-date"
  ]);
  var NormalizedDateSchema = external_exports.object({
    value: external_exports.string().min(4),
    original: external_exports.string().min(1),
    precision: DatePrecisionSchema,
    sourceFormat: DateSourceFormatSchema,
    /** Present only when the source explicitly supplied Z or a numeric offset. */
    timezoneOffset: external_exports.string().regex(/^(?:Z|[+-]\d{2}:\d{2})$/).optional()
  }).strict();

  // ../packages/contracts/src/warning.ts
  var AdapterWarningCodeSchema = external_exports.enum([
    "http-error",
    "invalid-json",
    "invalid-response",
    "invalid-row",
    "unknown-field",
    "invalid-date",
    "missing-clinical-content"
  ]);
  var WarningSeveritySchema = external_exports.enum(["info", "warning", "error"]);
  var AdapterWarningSchema = external_exports.object({
    code: AdapterWarningCodeSchema,
    severity: WarningSeveritySchema,
    path: external_exports.string().min(1),
    field: external_exports.string().min(1).optional(),
    message: external_exports.string().min(1)
  }).strict();

  // ../packages/contracts/src/module-result.ts
  var MapperPageTypeSchema = external_exports.enum([
    "observations",
    "medications",
    "diagnostic_reports",
    "procedures",
    "encounters",
    "document_references",
    "service_requests"
  ]);
  var ModuleErrorSchema = external_exports.object({
    code: external_exports.string().min(1),
    message: external_exports.string().min(1)
  }).strict();
  var ModuleResultBaseSchema = external_exports.object({
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    adapterVersion: external_exports.string().min(1),
    capturedAt: external_exports.string().datetime({ offset: true }),
    patientContextHash: PatientContextHashSchema,
    pageType: MapperPageTypeSchema,
    completeness: CompletenessSchema,
    warnings: external_exports.array(AdapterWarningSchema),
    error: ModuleErrorSchema.optional()
  });
  var ModuleResultSchema = ModuleResultBaseSchema.extend({
    records: external_exports.array(external_exports.unknown())
  }).strict();

  // ../packages/contracts/src/source-envelope.ts
  var SourceEnvelopeBaseSchema = external_exports.object({
    schemaVersion: external_exports.string().min(1),
    sourceSystem: external_exports.literal("nhi-medcloud"),
    sourceModule: external_exports.string().min(1),
    datasetScope: external_exports.string().min(1),
    adapterVersion: external_exports.string().min(1),
    runId: external_exports.string().min(1),
    capturedAt: external_exports.string().datetime({ offset: true }),
    sourceEventTime: external_exports.string().min(1).optional(),
    timePrecision: DatePrecisionSchema.optional(),
    authoritativeWindow: external_exports.object({
      start: external_exports.string().min(1).optional(),
      end: external_exports.string().min(1).optional()
    }).strict().optional(),
    completeness: CompletenessSchema,
    sourceRecordKeyHmac: external_exports.string().min(16).optional(),
    providerIdentifier: external_exports.string().min(1).optional(),
    patientContextHash: PatientContextHashSchema
  });
  var SourceEnvelopeSchema = SourceEnvelopeBaseSchema.extend({
    payload: external_exports.unknown()
  }).strict();

  // ../packages/medcloud-adapter/src/common.ts
  var import_js_sha1 = __toESM(require_sha1(), 1);
  function adapterVersion(context) {
    return context.adapterVersion ?? MEDCLOUD_ADAPTER_VERSION;
  }
  function encounterClassFromSource(...values) {
    const source = values.filter(Boolean).join(" ").trim();
    if (/(?:急診|emergency|\bEMER\b|\bER\b)/i.test(source)) {
      return { class: "EMER", kind: "\u6025\u8A3A" };
    }
    if (/(?:住院|inpatient|\bIMP\b|\bIPD\b)/i.test(source)) {
      return { class: "IMP", kind: "\u4F4F\u9662" };
    }
    if (/(?:門診|outpatient|\bAMB\b|\bOPD\b)/i.test(source)) {
      return { class: "AMB", kind: "\u9580\u8A3A" };
    }
    return void 0;
  }
  function canonicalSourceValue(value, omittedKeys) {
    if (Array.isArray(value)) {
      return value.map((item) => canonicalSourceValue(item, omittedKeys));
    }
    if (!value || typeof value !== "object") return value ?? null;
    return Object.fromEntries(
      Object.entries(value).filter(([key]) => !omittedKeys.has(key)).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0).map(([key, child]) => [key, canonicalSourceValue(child, omittedKeys)])
    );
  }
  function stableSourceRecordKeys(rows, omitKeys = ["r"]) {
    const omitted = new Set(omitKeys);
    const occurrences = /* @__PURE__ */ new Map();
    return rows.map((row) => {
      const fingerprint = (0, import_js_sha1.sha1)(
        JSON.stringify(canonicalSourceValue(row, omitted))
      );
      const ordinal = (occurrences.get(fingerprint) ?? 0) + 1;
      occurrences.set(fingerprint, ordinal);
      return `${fingerprint}#${ordinal}`;
    });
  }
  function recordMetadata(context, sourceModule, datasetScope, hospId, normalizedDate, warnings) {
    return {
      sourceSystem: "nhi-medcloud",
      sourceModule,
      datasetScope,
      adapterVersion: adapterVersion(context),
      capturedAt: context.capturedAt,
      patientContextHash: context.patientContextHash,
      ...hospId ? { hosp_id: hospId } : {},
      ...normalizedDate ? { normalized_date: normalizedDate, date_precision: normalizedDate.precision } : {},
      warnings
    };
  }
  function mustDegrade(warnings) {
    return warnings.some(
      (warning) => warning.code === "invalid-date" || warning.code === "invalid-response" || warning.code === "missing-clinical-content" || warning.code === "unknown-field"
    );
  }
  function moduleResult(parsed, context, records, adapterWarnings) {
    const warnings = [...parsed.warnings, ...adapterWarnings];
    let completeness = parsed.completeness;
    if (mustDegrade(warnings)) completeness = markPartial(completeness);
    return {
      sourceSystem: "nhi-medcloud",
      sourceModule: parsed.sourceModule,
      datasetScope: parsed.datasetScope,
      adapterVersion: adapterVersion(context),
      capturedAt: context.capturedAt,
      patientContextHash: context.patientContextHash,
      pageType: parsed.pageType,
      completeness,
      warnings,
      records,
      ...parsed.error ? { error: parsed.error } : {}
    };
  }
  function missingClinicalContentWarning(path) {
    return {
      code: "missing-clinical-content",
      severity: "warning",
      path,
      message: "Source row has no clinical content required by this mapper output."
    };
  }

  // ../packages/medcloud-adapter/src/date.ts
  var ISO_DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
  var ISO_DATE_TIME_RE = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(Z|[+-]\d{2}:\d{2})?$/;
  var GREGORIAN_SLASH_RE = /^(\d{4})\/(\d{1,2})\/(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/;
  var ROC_SLASH_RE = /^(\d{1,3})\/(\d{1,2})\/(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/;
  var COMPACT_DATE_RE = /^(\d{4})(\d{2})(\d{2})$/;
  function pad2(value) {
    return String(value).padStart(2, "0");
  }
  function isLeapYear(year) {
    return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  }
  function isValidCalendarDate(year, month, day) {
    if (!Number.isInteger(year) || year < 1 || month < 1 || month > 12 || day < 1) return false;
    const monthDays = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    return day <= (monthDays[month - 1] ?? 0);
  }
  function isValidTime(hour, minute, second) {
    if (hour === void 0 && minute === void 0 && second === void 0) return true;
    if (hour === void 0 || minute === void 0) return false;
    return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59 && (second === void 0 || second >= 0 && second <= 59);
  }
  function isValidOffset(offset) {
    if (!offset || offset === "Z") return true;
    const match = /^([+-])(\d{2}):(\d{2})$/.exec(offset);
    if (!match) return false;
    const hours = Number(match[2]);
    const minutes = Number(match[3]);
    return hours < 14 ? minutes <= 59 : hours === 14 && minutes === 0;
  }
  function invalidDateWarning(path) {
    return {
      code: "invalid-date",
      severity: "warning",
      path,
      message: "Date does not match a supported calendar format."
    };
  }
  function buildDate(original, year, month, day, sourceFormat, hour, minute, second, fraction, timezoneOffset) {
    if (!isValidCalendarDate(year, month, day) || !isValidTime(hour, minute, second) || !isValidOffset(timezoneOffset)) {
      return void 0;
    }
    const datePart = `${String(year).padStart(4, "0")}-${pad2(month)}-${pad2(day)}`;
    let value = datePart;
    let precision = "day";
    if (hour !== void 0 && minute !== void 0) {
      value += `T${pad2(hour)}:${pad2(minute)}`;
      precision = "minute";
      if (second !== void 0) {
        value += `:${pad2(second)}${fraction ? `.${fraction}` : ""}`;
        precision = "second";
      }
      if (timezoneOffset) value += timezoneOffset;
    }
    return {
      value,
      original,
      precision,
      sourceFormat,
      ...timezoneOffset ? { timezoneOffset } : {}
    };
  }
  function parseMedCloudDate(raw, path = "date") {
    if (raw === null || raw === void 0 || raw === "") return { warnings: [] };
    if (typeof raw !== "string") return { warnings: [invalidDateWarning(path)] };
    const original = raw.trim();
    if (!original) return { warnings: [] };
    const isoDate = ISO_DATE_RE.exec(original);
    if (isoDate) {
      const date = buildDate(original, Number(isoDate[1]), Number(isoDate[2]), Number(isoDate[3]), "iso-date");
      return date ? { date, warnings: [] } : { warnings: [invalidDateWarning(path)] };
    }
    const isoDateTime = ISO_DATE_TIME_RE.exec(original);
    if (isoDateTime) {
      const date = buildDate(
        original,
        Number(isoDateTime[1]),
        Number(isoDateTime[2]),
        Number(isoDateTime[3]),
        "iso-date-time",
        Number(isoDateTime[4]),
        Number(isoDateTime[5]),
        isoDateTime[6] === void 0 ? void 0 : Number(isoDateTime[6]),
        isoDateTime[7],
        isoDateTime[8]
      );
      return date ? { date, warnings: [] } : { warnings: [invalidDateWarning(path)] };
    }
    const gregorian = GREGORIAN_SLASH_RE.exec(original);
    if (gregorian) {
      const date = buildDate(
        original,
        Number(gregorian[1]),
        Number(gregorian[2]),
        Number(gregorian[3]),
        "gregorian-slash",
        gregorian[4] === void 0 ? void 0 : Number(gregorian[4]),
        gregorian[5] === void 0 ? void 0 : Number(gregorian[5]),
        gregorian[6] === void 0 ? void 0 : Number(gregorian[6])
      );
      return date ? { date, warnings: [] } : { warnings: [invalidDateWarning(path)] };
    }
    const roc = ROC_SLASH_RE.exec(original);
    if (roc) {
      const rocYear = Number(roc[1]);
      const date = buildDate(
        original,
        rocYear + 1911,
        Number(roc[2]),
        Number(roc[3]),
        "roc-slash",
        roc[4] === void 0 ? void 0 : Number(roc[4]),
        roc[5] === void 0 ? void 0 : Number(roc[5]),
        roc[6] === void 0 ? void 0 : Number(roc[6])
      );
      return rocYear > 0 && date ? { date, warnings: [] } : { warnings: [invalidDateWarning(path)] };
    }
    const compact = COMPACT_DATE_RE.exec(original);
    if (compact) {
      const date = buildDate(original, Number(compact[1]), Number(compact[2]), Number(compact[3]), "compact-date");
      return date ? { date, warnings: [] } : { warnings: [invalidDateWarning(path)] };
    }
    return { warnings: [invalidDateWarning(path)] };
  }
  function toMapperDate(date) {
    if (!date) return void 0;
    return date.precision !== "day" && date.timezoneOffset ? date.value : date.value.slice(0, 10);
  }

  // ../packages/medcloud-adapter/src/parser.ts
  var RESPONSE_FIELDS = /* @__PURE__ */ new Set([
    "log2time",
    "robject",
    "_cloudWildcatchDocumentsAttempted",
    "_cloudWildcatchDocumentRowIndexes",
    "_cloudWildcatchDocuments",
    "_cloudWildcatchViewerLinksAttempted",
    "_cloudWildcatchViewerLinkRowIndexes",
    "_cloudWildcatchViewerLinks",
    "_cloudWildcatchViewerRequestsAttempted",
    "_cloudWildcatchViewerRequestRowIndexes",
    "_cloudWildcatchViewerRequests"
  ]);
  var ResponseBodySchema = external_exports.object({
    log2time: external_exports.string().nullable().optional(),
    robject: external_exports.array(external_exports.unknown())
  });
  function structuralWarning(code, severity, path, message, field) {
    return { code, severity, path, message, ...field ? { field } : {} };
  }
  function failed(sourceModule, datasetScope, pageType, warning, error) {
    return {
      sourceModule,
      datasetScope,
      pageType,
      completeness: "failed",
      rows: [],
      warnings: [warning],
      error
    };
  }
  function isObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function parseObservedResponse(response, rowSchema, sourceModule, datasetScope, pageType) {
    if (!Number.isInteger(response.status) || response.status < 200 || response.status >= 300) {
      const status = Number.isInteger(response.status) ? response.status : "invalid";
      return failed(
        sourceModule,
        datasetScope,
        pageType,
        structuralWarning("http-error", "error", "status", `HTTP response status indicates failure (${status}).`),
        { code: `HTTP_${status}`, message: "The source endpoint did not return a successful response." }
      );
    }
    let body = response.body;
    if (typeof body === "string") {
      if (!body.trim()) {
        return failed(
          sourceModule,
          datasetScope,
          pageType,
          structuralWarning("invalid-json", "error", "body", "Response body is empty or is not valid JSON."),
          { code: "INVALID_JSON", message: "The source response could not be parsed." }
        );
      }
      try {
        body = JSON.parse(body);
      } catch {
        return failed(
          sourceModule,
          datasetScope,
          pageType,
          structuralWarning("invalid-json", "error", "body", "Response body is empty or is not valid JSON."),
          { code: "INVALID_JSON", message: "The source response could not be parsed." }
        );
      }
    }
    const bodyWarnings = [];
    if (isObject(body)) {
      for (const field of Object.keys(body).filter((key) => !RESPONSE_FIELDS.has(key)).sort()) {
        bodyWarnings.push(
          structuralWarning(
            "unknown-field",
            "warning",
            "body",
            `Unknown source field '${field}' was ignored.`,
            field
          )
        );
      }
    }
    const parsedBody = ResponseBodySchema.safeParse(body);
    if (!parsedBody.success) {
      return failed(
        sourceModule,
        datasetScope,
        pageType,
        structuralWarning("invalid-response", "error", "body", "Response does not match the observed module envelope."),
        { code: "INVALID_RESPONSE", message: "The source response has an unsupported structure." }
      );
    }
    if (parsedBody.data.robject.length === 0) {
      return {
        sourceModule,
        datasetScope,
        pageType,
        completeness: "empty",
        rows: [],
        warnings: bodyWarnings,
        body
      };
    }
    const knownFields = new Set(Object.keys(rowSchema.shape));
    const rows = [];
    const warnings = [...bodyWarnings];
    let invalidRows = 0;
    const unknownFieldRowCounts = /* @__PURE__ */ new Map();
    parsedBody.data.robject.forEach((rawRow, index) => {
      const rowPath = `robject[${index}]`;
      const rowWarnings = [];
      if (isObject(rawRow)) {
        for (const field of Object.keys(rawRow).filter((key) => !knownFields.has(key)).sort()) {
          unknownFieldRowCounts.set(field, (unknownFieldRowCounts.get(field) ?? 0) + 1);
        }
      }
      const parsedRow = rowSchema.safeParse(rawRow);
      if (!parsedRow.success) {
        invalidRows += 1;
        const issueWarnings = parsedRow.error.issues.map((issue) => {
          const fieldPath = issue.path.map(String).join(".");
          const path = fieldPath ? `${rowPath}.${fieldPath}` : rowPath;
          const field = issue.path.length > 0 ? String(issue.path[issue.path.length - 1]) : void 0;
          return structuralWarning(
            "invalid-row",
            "warning",
            path,
            "Source row does not match the observed schema at this field.",
            field
          );
        });
        warnings.push(...rowWarnings, ...issueWarnings);
        return;
      }
      warnings.push(...rowWarnings);
      rows.push({ index, data: parsedRow.data, warnings: rowWarnings });
    });
    for (const [field, rowCount] of [...unknownFieldRowCounts].sort(
      ([left], [right]) => left.localeCompare(right)
    )) {
      warnings.push(
        structuralWarning(
          "unknown-field",
          "warning",
          "robject",
          `Unknown source field '${field}' was ignored on ${rowCount} row(s).`,
          field
        )
      );
    }
    let completeness = invalidRows > 0 ? "partial" : "complete";
    let error;
    if (rows.length === 0) {
      completeness = "failed";
      error = { code: "NO_VALID_ROWS", message: "No source rows matched the observed schema." };
    }
    return {
      sourceModule,
      datasetScope,
      pageType,
      completeness,
      rows,
      warnings,
      ...error ? { error } : {},
      body
    };
  }

  // ../packages/medcloud-adapter/src/schemas.ts
  var nullableString = external_exports.string().nullable().optional();
  var nullableNumber = external_exports.number().nullable().optional();
  var presentationString = external_exports.string().nullable().optional().transform((value) => value ?? "");
  var Imue0060RowSchema = external_exports.object({
    assay_item_name: external_exports.string(),
    assay_mark: nullableString,
    assay_method: presentationString,
    assay_tp_cname: nullableString,
    assay_value: external_exports.string(),
    case_time: external_exports.string(),
    consult_value: presentationString,
    data_mark: nullableString,
    fee_ym: external_exports.string(),
    func_type: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    inspect_mode: nullableString,
    inspect_result: nullableString,
    memo_data: nullableString,
    order_code: external_exports.string(),
    order_name: external_exports.string(),
    path_diag_1: nullableString,
    path_diag_2: nullableString,
    path_diag_3: nullableString,
    r: external_exports.number(),
    real_inspect_date: external_exports.string(),
    recipe_date: nullableString,
    unit_data: presentationString
  });
  var Imue0008RowSchema = external_exports.object({
    ay_flag: external_exports.string(),
    chr_hosp_id: nullableString,
    cure_e_date: nullableString,
    day: external_exports.number(),
    drug_65_mark: nullableString,
    drug_atc3_code: external_exports.string(),
    drug_atc5_code: external_exports.string(),
    drug_atc5_name: presentationString,
    drug_atc7_code: external_exports.string(),
    drug_code: external_exports.string(),
    drug_date: external_exports.string(),
    drug_ename: presentationString,
    drug_fre: presentationString,
    drug_group11_name: nullableString,
    drug_ing_code: external_exports.string(),
    drug_ing_name: presentationString,
    drug_left: external_exports.number(),
    drug_multi_mark: nullableString,
    drug_std_qty: nullableNumber,
    dup_drug_mark: nullableString,
    fee_ym: nullableString,
    func_seq_no: external_exports.string(),
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: presentationString,
    icd_code: external_exports.string(),
    qty: external_exports.number(),
    r: external_exports.number()
  });
  var Imue0130RowSchema = external_exports.object({
    assay_item_name: nullableString,
    assay_tp_cname: external_exports.string(),
    assay_value: nullableString,
    case_report_type: external_exports.string(),
    case_time: nullableString,
    ctmri: nullableString,
    ctmri_mark: external_exports.string(),
    cure_path: nullableString,
    cure_path_name: nullableString,
    data_mark: external_exports.string(),
    eec_link: nullableString,
    eec_mark: external_exports.string(),
    fee_ym: external_exports.string(),
    file_qty: nullableNumber,
    file_type: nullableString,
    func_type: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    inspect_mode: nullableString,
    inspect_result: nullableString,
    ipl_case_seq_no: nullableString,
    memo_data: nullableString,
    ord_mark: nullableString,
    order_code: external_exports.string(),
    order_name: external_exports.string(),
    path_diag_1: nullableString,
    path_diag_2: nullableString,
    path_diag_3: nullableString,
    r: external_exports.number(),
    read_pos: nullableString,
    real_inspect_date: external_exports.string(),
    recipe_date: nullableString,
    unit_data: nullableString
  });
  var Imue0030RowSchema = external_exports.object({
    ctmri_mark: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    exe_e_date: nullableString,
    exe_s_date: external_exports.string(),
    fee_ym: nullableString,
    file_qty: nullableNumber,
    file_type: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    ipl_case_seq_no: nullableString,
    ord_mark: nullableString,
    order_code: external_exports.string(),
    order_ename: nullableString,
    order_qty: nullableNumber,
    r: external_exports.number(),
    read_pos: nullableString
  });
  var Imue0010RowSchema = external_exports.object({
    child_birthday: nullableString,
    child_mark: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    exam_type: nullableString,
    exe_e_date: nullableString,
    exe_s_date: external_exports.string(),
    fee_ym: nullableString,
    func_date: nullableString,
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_code: external_exports.string(),
    order_ename: external_exports.string(),
    order_qty: nullableNumber,
    r: external_exports.number()
  });
  var Imue0120RowSchema = external_exports.object({
    atc5: nullableString,
    drug_group_code: nullableString,
    drug_type: nullableString,
    edate: nullableString,
    funcDate: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_code: nullableString,
    ingredient: nullableString,
    order_drug_day: external_exports.union([external_exports.string(), external_exports.number()]).nullable().optional(),
    pres_med_day: external_exports.union([external_exports.string(), external_exports.number()])
  });
  var Imue0140RowSchema = external_exports.object({});
  var Imue0070RowSchema = external_exports.object({
    func_type: nullableString,
    func_type_name: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    in_date: external_exports.string(),
    mds_file: nullableString,
    mds_pdf_file: nullableString,
    out_date: nullableString,
    pdf_mark: nullableString,
    pdf_reply_mark: nullableString,
    r: external_exports.number()
  });
  var Imue0080RowSchema = external_exports.object({
    cure_e_date: nullableString,
    cure_grade: nullableString,
    cure_path: nullableString,
    cure_path_name: nullableString,
    cure_type: nullableString,
    exe_e_date: nullableString,
    exe_s_date: nullableString,
    fee_ym: nullableString,
    func_date: nullableString,
    hosp: external_exports.string(),
    hosp_id: external_exports.string(),
    icd_cname: nullableString,
    icd_code: nullableString,
    order_qty: nullableNumber,
    r: external_exports.number()
  });

  // ../packages/medcloud-adapter/src/imue0008.ts
  var MEDICATION_SOURCE_SETTING = /^(?:門診|藥局|急診|住院|outpatient|pharmacy|emergency|inpatient|OPD|ER|IPD)$/i;
  var MEDICATION_SOURCE_SETTING_IN_TEXT = /(?:^|[;；,，|｜/／:：()（）\s])((?:門診|藥局|急診|住院|outpatient|pharmacy|emergency|inpatient|OPD|ER|IPD))(?=$|[;；,，|｜/／:：()（）\s])/i;
  function medicationSourceSetting(hospital) {
    const compositeSegments = hospital.split(/[;；]/).slice(1).map((segment) => segment.trim());
    const compositeSetting = compositeSegments.find(
      (segment) => MEDICATION_SOURCE_SETTING.test(segment)
    );
    if (compositeSetting) return compositeSetting;
    const text = hospital.trim();
    if (MEDICATION_SOURCE_SETTING.test(text)) return text;
    return MEDICATION_SOURCE_SETTING_IN_TEXT.exec(text)?.[1];
  }
  function isOutpatientSetting(setting) {
    return /^(?:門診|outpatient|OPD)$/i.test(setting ?? "");
  }
  function parseImue0008Response(response) {
    return parseObservedResponse(
      response,
      Imue0008RowSchema,
      IMUE0008_SOURCE_MODULE,
      IMUE0008_DATASET_SCOPE,
      "medications"
    );
  }
  function adaptImue0008Response(response, context) {
    const parsed = parseImue0008Response(response);
    const records = [];
    const adapterWarnings = [];
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [parsedIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const authoredDate = parseMedCloudDate(row.drug_date, `${path}.drug_date`);
      const endDate = parseMedCloudDate(row.cure_e_date, `${path}.cure_e_date`);
      const rowWarnings = [...source.warnings, ...authoredDate.warnings, ...endDate.warnings];
      adapterWarnings.push(...authoredDate.warnings, ...endDate.warnings);
      const drugName = row.drug_ename.trim() || row.drug_ing_name.trim();
      if (!drugName) {
        const warning = missingClinicalContentWarning(`${path}.drug_ename`);
        adapterWarnings.push(warning);
        continue;
      }
      const mapperDate = toMapperDate(authoredDate.date);
      const mapperEndDate = toMapperDate(endDate.date);
      const sourceSetting = medicationSourceSetting(row.hosp);
      const functionSequence = row.func_seq_no.trim();
      if (!functionSequence) {
        const warning = missingClinicalContentWarning(`${path}.func_seq_no`);
        rowWarnings.push(warning);
        adapterWarnings.push(warning);
      }
      const sourceRecordKey = sourceRecordKeys[parsedIndex];
      records.push({
        ...recordMetadata(
          context,
          IMUE0008_SOURCE_MODULE,
          IMUE0008_DATASET_SCOPE,
          row.hosp_id,
          authoredDate.date,
          rowWarnings
        ),
        ...mapperDate ? { date: mapperDate } : {},
        ...mapperEndDate ? { end_date: mapperEndDate } : {},
        source_record_key: sourceRecordKey,
        // The raw drug code, with no terminology claim: the adapter cannot prove
        // membership in the national NHI drug CodeSystem. The fhir-mapper
        // wrapper asserts medication-nhi-tw only for codes matching the observed
        // NHI shape and demotes everything else to a bridge-local system.
        code: row.drug_code,
        drug_name: drugName,
        quantity: row.qty,
        duration_days: row.day,
        ...row.drug_fre ? { dosage_text: row.drug_fre } : {},
        hospital: row.hosp,
        ...sourceSetting ? { source_setting: sourceSetting } : {},
        ...isOutpatientSetting(sourceSetting) ? { encounter_class: "AMB", encounter_kind: "\u9580\u8A3A" } : {},
        ...row.icd_cname ? { indication: row.icd_cname, indication_zh: row.icd_cname } : {},
        ...row.icd_code ? { indication_code: row.icd_code } : {},
        ...row.drug_atc5_name ? { drug_class: row.drug_atc5_name } : {},
        ...row.drug_atc3_code ? { atc3_code: row.drug_atc3_code } : {},
        ...row.drug_atc5_code ? { atc5_code: row.drug_atc5_code } : {},
        ...row.drug_atc7_code ? { atc7_code: row.drug_atc7_code } : {},
        ...row.drug_ing_code ? { ingredient_code: row.drug_ing_code } : {},
        ...row.drug_ing_name ? { ingredient_name: row.drug_ing_name } : {},
        ...endDate.date ? { end_date_normalized: endDate.date } : {}
      });
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }

  // ../packages/medcloud-adapter/src/imue0060.ts
  function parseImue0060Response(response) {
    return parseObservedResponse(
      response,
      Imue0060RowSchema,
      IMUE0060_SOURCE_MODULE,
      IMUE0060_DATASET_SCOPE,
      "observations"
    );
  }
  function adaptImue0060Response(response, context) {
    const parsed = parseImue0060Response(response);
    const records = [];
    const adapterWarnings = [];
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [rowIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const realDate = parseMedCloudDate(row.real_inspect_date, `${path}.real_inspect_date`);
      const caseTime = parseMedCloudDate(row.case_time, `${path}.case_time`);
      const visitDate = parseMedCloudDate(row.recipe_date, `${path}.recipe_date`);
      const rowWarnings = [
        ...source.warnings,
        ...realDate.warnings,
        ...caseTime.warnings,
        ...visitDate.warnings
      ];
      adapterWarnings.push(...realDate.warnings, ...caseTime.warnings, ...visitDate.warnings);
      const normalizedDate = caseTime.date ?? realDate.date;
      const mapperDate = toMapperDate(realDate.date ?? caseTime.date);
      const mapperVisitDate = toMapperDate(visitDate.date);
      const abnormalFlag = row.assay_mark?.trim();
      records.push({
        ...recordMetadata(
          context,
          IMUE0060_SOURCE_MODULE,
          IMUE0060_DATASET_SCOPE,
          row.hosp_id,
          normalizedDate,
          rowWarnings
        ),
        ...mapperDate ? { date: mapperDate } : {},
        source_record_key: sourceRecordKeys[rowIndex],
        order_code: row.order_code,
        order_name: row.order_name,
        code: row.order_code || row.assay_item_name,
        display: row.assay_item_name || row.order_name,
        item_name: row.assay_item_name,
        value: row.assay_value,
        unit: row.unit_data,
        reference_range: row.consult_value,
        hospital: row.hosp,
        ...abnormalFlag ? { abnormal_flag: abnormalFlag } : {},
        nhi_source_channel: null,
        ...mapperVisitDate ? { nhi_visit_date: mapperVisitDate } : {},
        ...visitDate.date ? { visit_date_normalized: visitDate.date } : {},
        ...caseTime.date ? { case_time_normalized: caseTime.date } : {},
        ...(caseTime.date ?? realDate.date)?.value ? { group_instance_key: (caseTime.date ?? realDate.date).value } : {},
        ...row.assay_method ? { assay_method: row.assay_method } : {}
      });
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }

  // ../packages/medcloud-adapter/src/imue0130.ts
  function isObject2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function trustedViewerUrl(value) {
    if (typeof value !== "string" || value.length === 0 || value.length > 1e5) {
      return void 0;
    }
    try {
      const url = new URL(value);
      const isNhiHostname = url.hostname === "nhi.gov.tw" || url.hostname.endsWith(".nhi.gov.tw");
      if (url.protocol !== "https:" || url.port || url.username || url.password || !isNhiHostname) {
        return void 0;
      }
      return url.toString();
    } catch {
      return void 0;
    }
  }
  function viewerLinkCapture(source) {
    let body = source;
    if (typeof body === "string") {
      try {
        body = JSON.parse(body);
      } catch {
        return { attempted: false, expectedRowIndexes: /* @__PURE__ */ new Set(), urlsByRowIndex: /* @__PURE__ */ new Map() };
      }
    }
    if (!isObject2(body) || body._cloudWildcatchViewerLinksAttempted !== true) {
      return { attempted: false, expectedRowIndexes: /* @__PURE__ */ new Set(), urlsByRowIndex: /* @__PURE__ */ new Map() };
    }
    const expectedRowIndexes = new Set(
      Array.isArray(body._cloudWildcatchViewerLinkRowIndexes) ? body._cloudWildcatchViewerLinkRowIndexes.filter(
        (value) => Number.isInteger(value) && value >= 0
      ) : []
    );
    const urlsByRowIndex = /* @__PURE__ */ new Map();
    if (Array.isArray(body._cloudWildcatchViewerLinks)) {
      for (const item of body._cloudWildcatchViewerLinks) {
        if (!isObject2(item) || !Number.isInteger(item.rowIndex) || Number(item.rowIndex) < 0) {
          continue;
        }
        const url = trustedViewerUrl(item.url);
        if (url) urlsByRowIndex.set(Number(item.rowIndex), url);
      }
    }
    return { attempted: true, expectedRowIndexes, urlsByRowIndex };
  }
  function trustedViewerRequest(value) {
    if (!isObject2(value)) return void 0;
    const stringPart = (part, maxLength) => typeof part === "string" && part.length <= maxLength && !/[\u0000-\u001f\u007f@]/u.test(part) ? part : void 0;
    const iplCaseSeqNo = stringPart(value.iplCaseSeqNo, 256);
    const readPos = stringPart(value.readPos, 128);
    const fileType = stringPart(value.fileType, 128);
    const fileQty = stringPart(value.fileQty, 32);
    const feeYm = stringPart(value.feeYm, 64);
    if (value.version !== 1 || value.procId !== "IMUE0130" || !iplCaseSeqNo || readPos === void 0 || !["", "Y"].includes(String(value.ordMark ?? "invalid")) || fileType === void 0 || fileQty === void 0 || feeYm === void 0) {
      return void 0;
    }
    return {
      version: 1,
      procId: "IMUE0130",
      iplCaseSeqNo,
      readPos,
      ordMark: value.ordMark,
      fileType,
      fileQty,
      feeYm
    };
  }
  function viewerRequestCapture(source) {
    let body = source;
    if (typeof body === "string") {
      try {
        body = JSON.parse(body);
      } catch {
        return { attempted: false, expectedRowIndexes: /* @__PURE__ */ new Set(), descriptorsByRowIndex: /* @__PURE__ */ new Map() };
      }
    }
    if (!isObject2(body) || body._cloudWildcatchViewerRequestsAttempted !== true) {
      return { attempted: false, expectedRowIndexes: /* @__PURE__ */ new Set(), descriptorsByRowIndex: /* @__PURE__ */ new Map() };
    }
    const expectedRowIndexes = new Set(
      Array.isArray(body._cloudWildcatchViewerRequestRowIndexes) ? body._cloudWildcatchViewerRequestRowIndexes.filter(
        (value) => Number.isInteger(value) && value >= 0
      ) : []
    );
    const descriptorsByRowIndex = /* @__PURE__ */ new Map();
    if (Array.isArray(body._cloudWildcatchViewerRequests)) {
      for (const item of body._cloudWildcatchViewerRequests) {
        if (!isObject2(item) || !Number.isInteger(item.rowIndex) || Number(item.rowIndex) < 0) {
          continue;
        }
        const descriptor = trustedViewerRequest(item.descriptor);
        if (descriptor) descriptorsByRowIndex.set(Number(item.rowIndex), descriptor);
      }
    }
    return { attempted: true, expectedRowIndexes, descriptorsByRowIndex };
  }
  function reportCategory(row) {
    const text = [
      row.assay_tp_cname,
      row.assay_item_name,
      row.ctmri,
      row.inspect_mode,
      row.order_name
    ].filter(Boolean).join(" ");
    if (/(?:心導管|\b(?:cardiac|coronary)\s+catheteri[sz]ation\b)/i.test(text)) return "CTH";
    if (/(?:心(?:臟)?超音波|心臟超聲|\b(?:cardiac\s+ultrasound|echocardiogra(?:m|phy))\b)/i.test(text)) {
      return "CUS";
    }
    if (/(?:心電圖|心電檢查|\b(?:ECG|EKG|electrocardiogra(?:m|phy))\b)/i.test(text)) return "EC";
    if (/(?:病理|細胞)/.test(text)) return "PATH";
    if (/(?:檢驗|laboratory|\blab\b)/i.test(text)) return "LAB";
    if (/(?:放射|影像|X光|超音波|核磁|電腦斷層|\b(?:CT|MRI|XRAY)\b)/i.test(text)) return "RAD";
    return void 0;
  }
  function normalizedConclusionPart(value) {
    return value.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function reportConclusion(row) {
    const inspectResult = row.inspect_result?.trim() ?? "";
    const parts = inspectResult ? [inspectResult] : [];
    const seen = new Set(inspectResult ? [normalizedConclusionPart(inspectResult)] : []);
    [row.path_diag_1, row.path_diag_2, row.path_diag_3].forEach((value, index) => {
      const diagnosis = value?.trim() ?? "";
      if (!diagnosis) return;
      const key = normalizedConclusionPart(diagnosis);
      if (seen.has(key)) return;
      seen.add(key);
      parts.push(`\u75C5\u7406\u8A3A\u65B7 ${index + 1}\uFF1A${diagnosis}`);
    });
    return parts.join("\n");
  }
  function parseImue0130Response(response) {
    return parseObservedResponse(
      response,
      Imue0130RowSchema,
      IMUE0130_SOURCE_MODULE,
      IMUE0130_DATASET_SCOPE,
      "diagnostic_reports"
    );
  }
  function adaptImue0130Response(response, context) {
    const parsed = parseImue0130Response(response);
    const parsedBody = parsed.body ?? response.body;
    const viewerLinks = viewerLinkCapture(parsedBody);
    const viewerRequests = viewerRequestCapture(parsedBody);
    const records = [];
    const adapterWarnings = [];
    const stableKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    const sourceRecordKeys = new Map(
      parsed.rows.map((source, index) => [source.index, stableKeys[index]])
    );
    for (const source of parsed.rows) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const effectiveDate = parseMedCloudDate(row.real_inspect_date, `${path}.real_inspect_date`);
      const caseTime = parseMedCloudDate(row.case_time, `${path}.case_time`);
      const conclusion = reportConclusion(row);
      const rowWarnings = [...source.warnings, ...effectiveDate.warnings, ...caseTime.warnings];
      const viewerUrl = viewerLinks.urlsByRowIndex.get(source.index);
      const viewerRequest = viewerRequests.descriptorsByRowIndex.get(source.index);
      if (viewerLinks.attempted && viewerLinks.expectedRowIndexes.has(source.index) && !viewerUrl) {
        const warning = {
          code: "invalid-response",
          severity: "warning",
          path: `_cloudWildcatchViewerLinks[${source.index}]`,
          message: "The source did not return a trusted imaging viewer link for this row."
        };
        rowWarnings.push(warning);
        adapterWarnings.push(warning);
      }
      if (viewerRequests.attempted && viewerRequests.expectedRowIndexes.has(source.index) && !viewerRequest) {
        const warning = {
          code: "invalid-response",
          severity: "warning",
          path: `_cloudWildcatchViewerRequests[${source.index}]`,
          message: "The source row did not provide a valid on-demand viewer request descriptor."
        };
        rowWarnings.push(warning);
        adapterWarnings.push(warning);
      }
      adapterWarnings.push(...effectiveDate.warnings, ...caseTime.warnings);
      if (!conclusion && !viewerUrl && !viewerRequest) continue;
      const normalizedDate = caseTime.date ?? effectiveDate.date;
      const mapperDate = toMapperDate(effectiveDate.date ?? caseTime.date);
      const category = reportCategory(row);
      records.push({
        ...recordMetadata(
          context,
          IMUE0130_SOURCE_MODULE,
          IMUE0130_DATASET_SCOPE,
          row.hosp_id,
          normalizedDate,
          rowWarnings
        ),
        ...mapperDate ? { date: mapperDate } : {},
        code: row.order_code,
        display: row.order_name || row.assay_item_name || row.order_code,
        ...row.order_name ? { display_zh: row.order_name } : {},
        conclusion,
        hospital: row.hosp,
        ...category ? { category } : {},
        // Preserve the source code without claiming NHI terminology membership;
        // syntax alone is not sufficient evidence of CodeSystem membership.
        system: "LOCAL",
        // MediCloud does not expose a trustworthy report lifecycle status.
        status: "unknown",
        source_record_key: sourceRecordKeys.get(source.index),
        ...row.ipl_case_seq_no ? { iplCaseSeqNo: row.ipl_case_seq_no } : {},
        ...viewerUrl ? { viewerUrl } : {},
        ...viewerRequest ? { viewerRequest } : {},
        ...caseTime.date ? { case_time_normalized: caseTime.date } : {}
      });
    }
    const effectiveParsed = records.length === 0 && parsed.completeness === "complete" ? { ...parsed, completeness: "empty" } : parsed;
    return moduleResult(effectiveParsed, context, records, adapterWarnings);
  }

  // ../packages/medcloud-adapter/src/procedure-adapter.ts
  var NHI_DENTAL_DISPLAY_FALLBACKS = {
    "01271C": "\u74B0\u53E3\u5168\u666F X \u5149\u7247\u8A3A\u5BDF"
  };
  function dentalImagingProcedureKey(row, code, date, endDate) {
    if (row.ctmri_mark?.trim().toUpperCase() !== "Y") return void 0;
    return JSON.stringify([
      row.hosp_id?.trim() || row.hosp.trim(),
      date ?? "",
      endDate ?? "",
      code.toUpperCase(),
      row.icd_code?.trim().toUpperCase() ?? "",
      row.cure_path?.trim().toUpperCase() ?? "",
      row.cure_path_name?.trim() ?? "",
      row.read_pos?.trim() ?? "",
      row.order_ename?.trim() ?? "",
      row.order_qty ?? null
    ]);
  }
  function dentalProcedureDisplay(code, sourceDisplay) {
    const display = sourceDisplay?.trim() ?? "";
    return display || NHI_DENTAL_DISPLAY_FALLBACKS[code.trim().toUpperCase()] || code;
  }
  function adaptProcedureRows(parsed, context) {
    const records = [];
    const adapterWarnings = [];
    const seenDentalImagingProcedures = /* @__PURE__ */ new Set();
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [parsedIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const start = parseMedCloudDate(row.exe_s_date, `${path}.exe_s_date`);
      const end = parseMedCloudDate(row.exe_e_date, `${path}.exe_e_date`);
      const warnings = [...source.warnings, ...start.warnings, ...end.warnings];
      adapterWarnings.push(...start.warnings, ...end.warnings);
      const code = row.order_code.trim();
      const display = dentalProcedureDisplay(code, row.order_ename);
      if (!code && !display) {
        const warning = missingClinicalContentWarning(`${path}.order_code`);
        adapterWarnings.push(warning);
        continue;
      }
      const date = toMapperDate(start.date);
      const endDate = toMapperDate(end.date);
      const isKnownDentalProgramCode = isKnownNhiDentalProgramCode(code);
      const usesDentalProgramSystem = usesNhiDentalProgramCodeSystem(code, date);
      const readPosition = row.read_pos?.trim() ?? "";
      const encounter = encounterClassFromSource(row.cure_path, row.cure_path_name, row.hosp);
      const imagingProcedureKey = dentalImagingProcedureKey(row, code, date, endDate);
      if (imagingProcedureKey) {
        if (seenDentalImagingProcedures.has(imagingProcedureKey)) continue;
        seenDentalImagingProcedures.add(imagingProcedureKey);
      }
      records.push({
        ...recordMetadata(
          context,
          parsed.sourceModule,
          parsed.datasetScope,
          row.hosp_id,
          start.date,
          warnings
        ),
        ...date ? { date } : {},
        ...endDate ? { end_date: endDate } : {},
        code,
        display,
        display_zh: display,
        system: usesDentalProgramSystem ? "NHI_DENTAL_PROGRAM" : isKnownDentalProgramCode || hasReasonableNhiMedicalOrderCode(code) ? "NHI" : "LOCAL",
        ...usesDentalProgramSystem ? {
          code_system_uri: NHI_DENTAL_PROGRAM_CODE_SYSTEM,
          code_system_version: NHI_DENTAL_PROGRAM_CODE_SYSTEM_VERSION
        } : {},
        // IMUE0030 is the dental procedure record, not an order feed. A valid
        // execution date is source evidence that this same-day dental procedure
        // was performed and concluded; blank/unparseable dates remain unknown.
        status: date ? "completed" : "unknown",
        hospital: row.hosp,
        hospital_id: row.hosp_id,
        ...row.icd_code ? { reason_code: row.icd_code } : {},
        ...row.icd_cname ? { reason_zh: row.icd_cname } : {},
        ...typeof row.order_qty === "number" ? { quantity: row.order_qty } : {},
        ...readPosition ? { body_site: `\u7259\u4F4D ${readPosition}` } : {},
        ...encounter ? { encounter_class: encounter.class, encounter_kind: encounter.kind } : {},
        clinical_service_domain: "dental",
        source_record_key: sourceRecordKeys[parsedIndex]
      });
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }
  function parseImue0030Response(response) {
    return parseObservedResponse(response, Imue0030RowSchema, IMUE0030_SOURCE_MODULE, IMUE0030_DATASET_SCOPE, "procedures");
  }
  function adaptImue0030Response(response, context) {
    return adaptProcedureRows(parseImue0030Response(response), context);
  }
  function parseImue0010Response(response) {
    return parseObservedResponse(response, Imue0010RowSchema, IMUE0010_SOURCE_MODULE, IMUE0010_DATASET_SCOPE, "service_requests");
  }
  function adaptImue0010Response(response, context) {
    const parsed = parseImue0010Response(response);
    const records = [];
    const adapterWarnings = [];
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [parsedIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const start = parseMedCloudDate(row.exe_s_date, `${path}.exe_s_date`);
      const end = parseMedCloudDate(row.exe_e_date, `${path}.exe_e_date`);
      const warnings = [...source.warnings, ...start.warnings, ...end.warnings];
      adapterWarnings.push(...start.warnings, ...end.warnings);
      const code = row.order_code.trim();
      const display = row.order_ename.trim();
      if (!code && !display) {
        const warning = missingClinicalContentWarning(`${path}.order_code`);
        adapterWarnings.push(warning);
        continue;
      }
      const date = toMapperDate(start.date);
      const endDate = toMapperDate(end.date);
      const metadata = recordMetadata(
        context,
        parsed.sourceModule,
        parsed.datasetScope,
        row.hosp_id,
        start.date,
        warnings
      );
      const sourceRecordKey = sourceRecordKeys[parsedIndex];
      const encounter = encounterClassFromSource(row.cure_path, row.cure_path_name, row.hosp);
      records.push({
        ...metadata,
        target_page_type: "service_requests",
        ...date ? { date } : {},
        ...endDate ? { end_date: endDate } : {},
        code,
        display: display || code,
        system: hasReasonableNhiMedicalOrderCode(code) ? "NHI" : "LOCAL",
        status: "unknown",
        intent: "order",
        service_category: isLaboratoryExamType(row.exam_type) ? "laboratory" : isImagingExamType(row.exam_type, display) ? "imaging" : "other",
        hospital: row.hosp,
        hospital_id: row.hosp_id,
        ...row.icd_code ? { reason_code: row.icd_code } : {},
        ...row.icd_cname ? { reason_zh: row.icd_cname } : {},
        ...typeof row.order_qty === "number" ? { quantity: row.order_qty } : {},
        ...encounter ? { encounter_class: encounter.class, encounter_kind: encounter.kind } : {},
        source_record_key: sourceRecordKey
      });
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }
  function isLaboratoryExamType(value) {
    return /(?:生化|免疫|血液|血清|病毒|尿液|細菌|黴菌|微生物|寄生蟲|細胞|病理|試管|檢體|穿[刺剌]|分子|基因|毒物|laboratory|\blab\b)/i.test(
      value?.trim() ?? ""
    );
  }
  function isImagingExamType(examType, display) {
    return /(?:超音波|胸腔檢查|電腦斷層|斷層造影|核磁|磁振|攝影|造影|對比劑|放射|影像|ultrasound|\becho\b|computed tomography|\bct\b|\bmri\b|x[ -]?ray|radiology|contrast)/i.test(
      `${examType?.trim() ?? ""} ${display?.trim() ?? ""}`
    );
  }

  // ../packages/medcloud-adapter/src/imue0120.ts
  function parseImue0120Response(response) {
    return parseObservedResponse(response, Imue0120RowSchema, IMUE0120_SOURCE_MODULE, IMUE0120_DATASET_SCOPE, "medications");
  }
  function adaptImue0120Response(response, context) {
    const parsed = parseImue0120Response(response);
    const records = [];
    const adapterWarnings = [];
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [parsedIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const date = parseMedCloudDate(row.funcDate, `robject[${source.index}].funcDate`);
      adapterWarnings.push(...date.warnings);
      const mapperDate = toMapperDate(date.date);
      const ingredient = row.ingredient?.trim() ?? "";
      const atc5 = row.atc5?.trim().toUpperCase() ?? "";
      const drugName = ingredient || atc5;
      if (!drugName) {
        adapterWarnings.push(missingClinicalContentWarning(`robject[${source.index}].ingredient`));
        continue;
      }
      const remainingDaysText = String(row.pres_med_day ?? "").trim();
      const remainingDays = remainingDaysText === "" ? Number.NaN : Number(remainingDaysText);
      const prescribedDaysText = String(row.order_drug_day ?? "").trim();
      const prescribedDays = prescribedDaysText === "" ? Number.NaN : Number(prescribedDaysText);
      if (!remainingDaysText) {
        adapterWarnings.push(
          missingClinicalContentWarning(`robject[${source.index}].pres_med_day`)
        );
      } else if (!Number.isFinite(remainingDays) || remainingDays < 0 || !Number.isInteger(remainingDays)) {
        adapterWarnings.push({
          code: "invalid-response",
          severity: "warning",
          path: `robject[${source.index}].pres_med_day`,
          message: "Remaining medication days must be a finite non-negative integer."
        });
      }
      if (prescribedDaysText && (!Number.isFinite(prescribedDays) || prescribedDays < 0 || !Number.isInteger(prescribedDays))) {
        adapterWarnings.push({
          code: "invalid-response",
          severity: "warning",
          path: `robject[${source.index}].order_drug_day`,
          message: "Prescribed medication days must be a finite non-negative integer."
        });
      }
      records.push({
        ...recordMetadata(context, IMUE0120_SOURCE_MODULE, IMUE0120_DATASET_SCOPE, row.hosp_id, date.date, [...source.warnings, ...date.warnings]),
        ...mapperDate ? { date: mapperDate } : {},
        source_record_key: sourceRecordKeys[parsedIndex],
        // No source drug code: the mapper's empty-code path already lands these
        // on its local medication system.
        code: "",
        drug_name: drugName,
        ...Number.isInteger(prescribedDays) && prescribedDays >= 0 ? { duration_days: prescribedDays } : {},
        ...Number.isInteger(remainingDays) && remainingDays >= 0 ? { remaining_days: remainingDays } : {},
        hospital: row.hosp_id,
        ...row.icd_code ? { indication_code: row.icd_code } : {},
        ...atc5 ? { atc5_code: atc5 } : {},
        ...ingredient ? { ingredient_name: ingredient } : {}
      });
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }

  // ../packages/medcloud-adapter/src/imue0140.ts
  var MEASUREMENTS = {
    height: { display: "\u8EAB\u9AD8", unit: "cm" },
    weight: { display: "\u9AD4\u91CD", unit: "kg" },
    bmi: { display: "BMI", unit: "kg/m2" },
    waistline: { display: "\u8170\u570D", unit: "cm" },
    base_sbp: { display: "\u6536\u7E2E\u58D3", unit: "mm[Hg]" },
    base_ebp: { display: "\u8212\u5F35\u58D3", unit: "mm[Hg]" },
    cho: { display: "\u7E3D\u81BD\u56FA\u9187", unit: "mg/dL" },
    blod_tg: { display: "\u4E09\u9178\u7518\u6CB9\u8102", unit: "mg/dL" },
    hdl: { display: "HDL \u81BD\u56FA\u9187", unit: "mg/dL" },
    ldl: { display: "LDL \u81BD\u56FA\u9187", unit: "mg/dL" },
    blod_creat: { display: "Creatinine", unit: "mg/dL" },
    egfr: { display: "eGFR", unit: "mL/min/1.73m\xB2" },
    sgot: { display: "SGOT", unit: "U/L" },
    sgpt: { display: "SGPT", unit: "U/L" },
    urine_bun: { display: "BUN", unit: "mg/dL" },
    urine_ua: { display: "\u5C3F\u9178", unit: "mg/dL" },
    urine_protein: { display: "\u5C3F\u86CB\u767D", unit: "" },
    s_09005c: { display: "\u8840\u7CD6", unit: "mg/dL" },
    ba_diag_result: { display: "\u8840\u6DB2\u6AA2\u67E5\u5224\u8B80", unit: "" },
    blod_press_result: { display: "\u8840\u58D3\u5224\u8B80", unit: "" },
    lf_diag_result: { display: "\u809D\u529F\u80FD\u5224\u8B80", unit: "" },
    meta_syndr_result: { display: "\u4EE3\u8B1D\u75C7\u5019\u7FA4\u5224\u8B80", unit: "" },
    rf_diag_result: { display: "\u814E\u529F\u80FD\u5224\u8B80", unit: "" },
    s_09005c_diag_result: { display: "\u8840\u7CD6\u5224\u8B80", unit: "" },
    urine_ua_diag_result: { display: "\u5C3F\u9178\u5224\u8B80", unit: "" }
  };
  var VITAL_SIGN_FIELDS = /* @__PURE__ */ new Set([
    "height",
    "weight",
    "bmi",
    "waistline",
    "base_sbp",
    "base_ebp"
  ]);
  function observationCategory(field) {
    if (VITAL_SIGN_FIELDS.has(field)) return "vital-signs";
    return field.endsWith("_result") ? "survey" : "laboratory";
  }
  var MISSING_VALUE_RE = /^(?:null|[-\u2010-\u2015\u2212\uFE58\uFE63\uFF0D]+)$/i;
  function isMissingValue(value) {
    return value === "" || MISSING_VALUE_RE.test(value);
  }
  function bodyObject(response) {
    if (response.status < 200 || response.status >= 300) return null;
    try {
      const body = typeof response.body === "string" ? JSON.parse(response.body) : response.body;
      return body && typeof body === "object" && !Array.isArray(body) ? body : null;
    } catch {
      return null;
    }
  }
  function adaptImue0140Response(response, context) {
    const body = bodyObject(response);
    if (body && Array.isArray(body.robject) && body.robject.length === 0) {
      return {
        sourceSystem: "nhi-medcloud",
        sourceModule: IMUE0140_SOURCE_MODULE,
        datasetScope: IMUE0140_DATASET_SCOPE,
        adapterVersion: adapterVersion(context),
        capturedAt: context.capturedAt,
        patientContextHash: context.patientContextHash,
        pageType: "observations",
        completeness: "empty",
        warnings: [],
        records: []
      };
    }
    const root = body && typeof body.robject === "object" && body.robject !== null ? body.robject : void 0;
    const rows = root?.result_data;
    const healthRows = root?.health_data;
    const warnings = [];
    if (!Array.isArray(rows) || !Array.isArray(healthRows)) {
      return {
        sourceSystem: "nhi-medcloud",
        sourceModule: IMUE0140_SOURCE_MODULE,
        datasetScope: IMUE0140_DATASET_SCOPE,
        adapterVersion: adapterVersion(context),
        capturedAt: context.capturedAt,
        patientContextHash: context.patientContextHash,
        pageType: "observations",
        completeness: "failed",
        warnings,
        records: [],
        error: { code: "INVALID_RESPONSE", message: "The preventive-care response has an unsupported structure." }
      };
    }
    const records = [];
    const validRows = rows.filter(
      (raw) => !!raw && typeof raw === "object" && !Array.isArray(raw)
    );
    const sourceRecordKeys = stableSourceRecordKeys(validRows);
    validRows.forEach((row, rowIndex) => {
      for (const [field, definition] of Object.entries(MEASUREMENTS)) {
        const value = String(row[field] ?? "").trim();
        if (isMissingValue(value)) continue;
        const title = String(row.title ?? "").trim();
        const code = `adult-health-${field}`;
        records.push({
          ...recordMetadata(context, IMUE0140_SOURCE_MODULE, IMUE0140_DATASET_SCOPE, void 0, void 0, []),
          order_code: code,
          order_name: title ? `${definition.display} \u2014 ${title}` : definition.display,
          code,
          display: definition.display,
          item_name: definition.display,
          value,
          unit: definition.unit,
          reference_range: "",
          hospital: "",
          category: observationCategory(field),
          source_program: "adult-preventive",
          nhi_source_channel: null,
          source_record_key: `${sourceRecordKeys[rowIndex]}|${field}`
        });
      }
    });
    return {
      sourceSystem: "nhi-medcloud",
      sourceModule: IMUE0140_SOURCE_MODULE,
      datasetScope: IMUE0140_DATASET_SCOPE,
      adapterVersion: adapterVersion(context),
      capturedAt: context.capturedAt,
      patientContextHash: context.patientContextHash,
      pageType: "observations",
      completeness: records.length === 0 ? "empty" : "complete",
      warnings,
      records
    };
  }

  // ../packages/medcloud-adapter/src/imue0070.ts
  function parseImue0070Response(response) {
    return parseObservedResponse(
      response,
      Imue0070RowSchema,
      IMUE0070_SOURCE_MODULE,
      IMUE0070_DATASET_SCOPE,
      "encounters"
    );
  }
  function adaptImue0070Response(response, context) {
    const parsed = parseImue0070Response(response);
    const records = [];
    const adapterWarnings = [];
    const capturedDocuments = readCapturedDocuments(parsed.body ?? response.body);
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [parsedIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const admission = parseMedCloudDate(row.in_date, `${path}.in_date`);
      const discharge = parseMedCloudDate(row.out_date, `${path}.out_date`);
      adapterWarnings.push(...admission.warnings, ...discharge.warnings);
      const warnings = [...source.warnings, ...admission.warnings, ...discharge.warnings];
      const date = toMapperDate(admission.date);
      const endDate = toMapperDate(discharge.date);
      records.push({
        ...recordMetadata(
          context,
          IMUE0070_SOURCE_MODULE,
          IMUE0070_DATASET_SCOPE,
          row.hosp_id,
          admission.date,
          warnings
        ),
        ...date ? { date } : {},
        ...endDate ? { end_date: endDate } : {},
        class: "IMP",
        kind: "\u4F4F\u9662",
        channel: "\u96F2\u7AEF\u75C5\u6B77",
        hospital: row.hosp,
        hospital_id: row.hosp_id,
        ...row.icd_code ? { reason_code: row.icd_code } : {},
        ...row.icd_cname ? { reason_zh: row.icd_cname } : {},
        ...row.func_type_name ? { department: row.func_type_name } : {},
        func_seq_no: sourceRecordKeys[parsedIndex]
      });
      if (capturedDocuments.attempted && capturedDocuments.expectedRowIndexes.has(source.index)) {
        const document2 = capturedDocuments.byRowIndex.get(source.index);
        if (document2 && document2.status >= 200 && document2.status < 300 && document2.html.trim().length >= 10 && date) {
          const sourceRecordKey = sourceRecordKeys[parsedIndex];
          records.push({
            ...recordMetadata(
              context,
              IMUE0070_SOURCE_MODULE,
              IMUE0070_DATASET_SCOPE,
              row.hosp_id,
              admission.date,
              warnings
            ),
            target_page_type: "document_references",
            html: document2.html,
            row_id: sourceRecordKey,
            admission_date: date,
            ...endDate ? { discharge_date: endDate } : {},
            hospital: row.hosp,
            hospital_id: row.hosp_id,
            source_record_key: sourceRecordKey
          });
        } else {
          adapterWarnings.push(
            missingClinicalContentWarning(`_cloudWildcatchDocuments[${source.index}].html`)
          );
        }
      }
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }
  function readCapturedDocuments(body) {
    let candidate = body;
    if (typeof candidate === "string") {
      try {
        candidate = JSON.parse(candidate);
      } catch {
        return { attempted: false, expectedRowIndexes: /* @__PURE__ */ new Set(), byRowIndex: /* @__PURE__ */ new Map() };
      }
    }
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) {
      return { attempted: false, expectedRowIndexes: /* @__PURE__ */ new Set(), byRowIndex: /* @__PURE__ */ new Map() };
    }
    const object = candidate;
    const attempted = object._cloudWildcatchDocumentsAttempted === true;
    const expectedRowIndexes = new Set(
      Array.isArray(object._cloudWildcatchDocumentRowIndexes) ? object._cloudWildcatchDocumentRowIndexes.filter((value) => Number.isInteger(value)) : []
    );
    const byRowIndex = /* @__PURE__ */ new Map();
    if (!Array.isArray(object._cloudWildcatchDocuments)) {
      return { attempted, expectedRowIndexes, byRowIndex };
    }
    for (const item of object._cloudWildcatchDocuments) {
      if (!item || typeof item !== "object" || Array.isArray(item)) continue;
      const record = item;
      if (!Number.isInteger(record.rowIndex) || !Number.isInteger(record.status)) continue;
      byRowIndex.set(Number(record.rowIndex), {
        status: Number(record.status),
        html: typeof record.html === "string" ? record.html : ""
      });
    }
    return { attempted, expectedRowIndexes, byRowIndex };
  }

  // ../packages/medcloud-adapter/src/imue0080.ts
  function parseImue0080Response(response) {
    return parseObservedResponse(
      response,
      Imue0080RowSchema,
      IMUE0080_SOURCE_MODULE,
      IMUE0080_DATASET_SCOPE,
      "procedures"
    );
  }
  function adaptImue0080Response(response, context) {
    const parsed = parseImue0080Response(response);
    const records = [];
    const adapterWarnings = [];
    const sourceRecordKeys = stableSourceRecordKeys(
      parsed.rows.map((source) => source.data)
    );
    for (const [parsedIndex, source] of parsed.rows.entries()) {
      const row = source.data;
      const path = `robject[${source.index}]`;
      const start = parseMedCloudDate(row.exe_s_date || row.func_date, `${path}.exe_s_date`);
      const end = parseMedCloudDate(row.exe_e_date || row.cure_e_date, `${path}.exe_e_date`);
      adapterWarnings.push(...start.warnings, ...end.warnings);
      const code = row.cure_type?.trim() || "IMUE0080";
      const display = row.cure_path_name?.trim() || row.cure_type?.trim() || "\u5FA9\u5065\u91AB\u7642\u7D00\u9304";
      if (!row.cure_type && !row.cure_path_name && !row.cure_grade) {
        adapterWarnings.push(missingClinicalContentWarning(`${path}.cure_type`));
        continue;
      }
      const notes = [
        row.cure_grade ? `\u6CBB\u7642\u7B49\u7D1A\uFF1A${row.cure_grade}` : "",
        row.cure_path_name ? `\u7642\u7A0B\uFF1A${row.cure_path_name}` : ""
      ].filter(Boolean);
      const date = toMapperDate(start.date);
      const endDate = toMapperDate(end.date);
      const encounter = encounterClassFromSource(row.cure_path, row.cure_path_name, row.hosp);
      records.push({
        ...recordMetadata(
          context,
          IMUE0080_SOURCE_MODULE,
          IMUE0080_DATASET_SCOPE,
          row.hosp_id,
          start.date,
          [...source.warnings, ...start.warnings, ...end.warnings]
        ),
        ...date ? { date } : {},
        ...endDate ? { end_date: endDate } : {},
        code,
        display,
        display_zh: display,
        system: "LOCAL",
        status: "unknown",
        hospital: row.hosp,
        hospital_id: row.hosp_id,
        ...row.icd_code ? { reason_code: row.icd_code } : {},
        ...row.icd_cname ? { reason_zh: row.icd_cname } : {},
        ...typeof row.order_qty === "number" ? { quantity: row.order_qty } : {},
        ...notes.length > 0 ? { note: notes.join("\uFF1B") } : {},
        ...encounter ? { encounter_class: encounter.class, encounter_kind: encounter.kind } : {},
        source_record_key: sourceRecordKeys[parsedIndex]
      });
    }
    return moduleResult(parsed, context, records, adapterWarnings);
  }

  // ../packages/medcloud-adapter/src/imue0150.ts
  var SCREENINGS = {
    colorectal: "\u5927\u8178\u764C\u7BE9\u6AA2",
    oralMucosa: "\u53E3\u8154\u764C\u7BE9\u6AA2",
    mammography: "\u4E73\u764C\u7BE9\u6AA2",
    papSmears: "\u5B50\u5BAE\u9838\u62B9\u7247\u7BE9\u6AA2",
    lungCancer: "\u80BA\u764C\u7BE9\u6AA2",
    papillomavirus: "\u4EBA\u985E\u4E73\u7A81\u75C5\u6BD2\u7BE9\u6AA2",
    helicobacter: "\u5E7D\u9580\u687F\u83CC\u7BE9\u6AA2"
  };
  var SCREENING_CATEGORIES = {
    colorectal: "laboratory",
    oralMucosa: "exam",
    mammography: "imaging",
    papSmears: "laboratory",
    lungCancer: "imaging",
    papillomavirus: "laboratory",
    helicobacter: "laboratory"
  };
  function failed2(context, code, message) {
    const warningCode = code.startsWith("HTTP_") ? "http-error" : code === "INVALID_JSON" ? "invalid-json" : "invalid-response";
    return {
      sourceSystem: "nhi-medcloud",
      sourceModule: IMUE0150_SOURCE_MODULE,
      datasetScope: IMUE0150_DATASET_SCOPE,
      adapterVersion: adapterVersion(context),
      capturedAt: context.capturedAt,
      patientContextHash: context.patientContextHash,
      pageType: "observations",
      completeness: "failed",
      warnings: [{ code: warningCode, severity: "error", path: code.startsWith("HTTP_") ? "status" : "body", message }],
      records: [],
      error: { code, message }
    };
  }
  function adaptImue0150Response(response, context) {
    if (!Number.isInteger(response.status) || response.status < 200 || response.status >= 300) {
      return failed2(context, `HTTP_${Number.isInteger(response.status) ? response.status : "invalid"}`, "The screening endpoint did not return a successful response.");
    }
    let body = response.body;
    try {
      if (typeof body === "string") body = JSON.parse(body);
    } catch {
      return failed2(context, "INVALID_JSON", "The screening response could not be parsed.");
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return failed2(context, "INVALID_RESPONSE", "The screening response has an unsupported structure.");
    }
    const root = body.robject;
    if (Array.isArray(root) && root.length === 0) {
      return {
        sourceSystem: "nhi-medcloud",
        sourceModule: IMUE0150_SOURCE_MODULE,
        datasetScope: IMUE0150_DATASET_SCOPE,
        adapterVersion: adapterVersion(context),
        capturedAt: context.capturedAt,
        patientContextHash: context.patientContextHash,
        pageType: "observations",
        completeness: "empty",
        warnings: [],
        records: []
      };
    }
    if (!root || typeof root !== "object" || Array.isArray(root)) {
      return failed2(context, "INVALID_RESPONSE", "The screening response has an unsupported structure.");
    }
    const records = [];
    const warnings = [];
    let sourceRowCount = 0;
    for (const [screeningKey, display] of Object.entries(SCREENINGS)) {
      const section = root[screeningKey];
      if (!section || typeof section !== "object" || Array.isArray(section)) continue;
      const proposal = String(section.proposal ?? "").trim();
      if (proposal) {
        sourceRowCount += 1;
        records.push({
          ...recordMetadata(
            context,
            IMUE0150_SOURCE_MODULE,
            IMUE0150_DATASET_SCOPE,
            void 0,
            void 0,
            []
          ),
          order_code: `screening-${screeningKey}-proposal`,
          order_name: `${display}\u5EFA\u8B70`,
          code: `screening-${screeningKey}-proposal`,
          display: `${display}\u5EFA\u8B70`,
          item_name: `${display}\u5EFA\u8B70`,
          value: proposal,
          unit: "",
          reference_range: "",
          hospital: "",
          category: "survey",
          source_program: "cancer-screening",
          screening_proposal: proposal,
          nhi_source_channel: null,
          source_record_key: `${screeningKey}|proposal|${stableSourceRecordKeys([{ proposal }])[0]}`
        });
      }
      const rows = section.subData;
      if (!Array.isArray(rows)) continue;
      const sourceRecordKeys = stableSourceRecordKeys(
        rows.filter(
          (raw) => !!raw && typeof raw === "object" && !Array.isArray(raw)
        )
      );
      let validRowIndex = 0;
      rows.forEach((raw, rowIndex) => {
        sourceRowCount += 1;
        const path = `robject.${screeningKey}.subData[${rowIndex}]`;
        if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
          warnings.push({ code: "invalid-row", severity: "warning", path, message: "Screening history row is not an object." });
          return;
        }
        const row = raw;
        const sourceRecordKey = `${screeningKey}|${sourceRecordKeys[validRowIndex++]}`;
        const result = String(row.result ?? "").trim();
        if (!result) {
          warnings.push(missingClinicalContentWarning(`${path}.result`));
          return;
        }
        const date = parseMedCloudDate(row.func_date, `${path}.func_date`);
        warnings.push(...date.warnings);
        const mapperDate = toMapperDate(date.date);
        const hospital = String(row.hosp_abbr ?? "").trim();
        const cytopathicCode = String(row.cytopathic_code ?? "").trim();
        const code = `screening-${screeningKey}`;
        records.push({
          ...recordMetadata(context, IMUE0150_SOURCE_MODULE, IMUE0150_DATASET_SCOPE, void 0, date.date, date.warnings),
          ...mapperDate ? { date: mapperDate, nhi_visit_date: mapperDate } : {},
          order_code: code,
          order_name: display,
          code,
          display,
          item_name: display,
          value: result,
          unit: "",
          reference_range: "",
          hospital,
          category: SCREENING_CATEGORIES[screeningKey],
          source_program: "cancer-screening",
          ...cytopathicCode ? { cytopathic_code: cytopathicCode } : {},
          nhi_source_channel: null,
          source_record_key: sourceRecordKey
        });
      });
    }
    const completeness = sourceRowCount === 0 ? "empty" : warnings.length > 0 || records.length !== sourceRowCount ? "partial" : "complete";
    return {
      sourceSystem: "nhi-medcloud",
      sourceModule: IMUE0150_SOURCE_MODULE,
      datasetScope: IMUE0150_DATASET_SCOPE,
      adapterVersion: adapterVersion(context),
      capturedAt: context.capturedAt,
      patientContextHash: context.patientContextHash,
      pageType: "observations",
      completeness,
      warnings,
      records
    };
  }

  // ../packages/medcloud-adapter/src/mapper-input.ts
  function toNhiMapperInput(results) {
    const input = {
      observations: [],
      medications: [],
      diagnostic_reports: [],
      procedures: [],
      encounters: [],
      document_references: [],
      service_requests: []
    };
    for (const result of results) {
      if (result.completeness === "failed") continue;
      const records = result.records;
      for (const record of records) {
        const targetPageType = record.target_page_type ?? result.pageType;
        if (targetPageType === "observations") {
          input.observations.push(record);
        } else if (targetPageType === "medications") {
          input.medications.push(record);
        } else if (targetPageType === "diagnostic_reports") {
          input.diagnostic_reports.push(record);
        } else if (targetPageType === "procedures") {
          input.procedures.push(record);
        } else if (targetPageType === "encounters") {
          input.encounters.push(record);
        } else if (targetPageType === "document_references") {
          input.document_references.push(record);
        } else if (targetPageType === "service_requests") {
          input.service_requests.push(record);
        }
      }
      if (result.pageType === "procedures" || result.pageType === "service_requests") {
        for (const record of records) {
          const sourceRecordKey = "source_record_key" in record ? String(record.source_record_key ?? "") : "";
          const code = "code" in record ? String(record.code ?? "") : "";
          const encounterClass = "encounter_class" in record ? record.encounter_class : void 0;
          if (!encounterClass) continue;
          const encounterKind = "encounter_kind" in record && record.encounter_kind ? record.encounter_kind : encounterClass === "IMP" ? "\u4F4F\u9662" : encounterClass === "EMER" ? "\u6025\u8A3A" : "\u9580\u8A3A";
          const encounterSequence = "clinical_service_domain" in record && record.clinical_service_domain === "dental" ? "medcloud-dental-day" : sourceRecordKey;
          input.encounters.push({
            ...record,
            class: encounterClass,
            kind: encounterKind,
            channel: "\u96F2\u7AEF\u75C5\u6B77",
            func_seq_no: encounterSequence,
            ...code ? { lab_order_codes: [code] } : {}
          });
        }
      }
    }
    return input;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/helpers.ts
  var import_js_sha12 = __toESM(require_sha1(), 1);
  function stableId(patientId, ...parts) {
    return (0, import_js_sha12.sha1)([patientId, ...parts].join("|")).slice(0, 32);
  }
  var TWID_LETTER_CODE = {
    A: 10,
    B: 11,
    C: 12,
    D: 13,
    E: 14,
    F: 15,
    G: 16,
    H: 17,
    I: 34,
    J: 18,
    K: 19,
    L: 20,
    M: 21,
    N: 22,
    O: 35,
    P: 23,
    Q: 24,
    R: 25,
    S: 26,
    T: 27,
    U: 28,
    V: 29,
    W: 32,
    X: 30,
    Y: 31,
    Z: 33
  };
  function isValidTwid(id) {
    const m = /^([A-Z])([12])(\d{8})$/.exec(id);
    if (!m) return false;
    const code = TWID_LETTER_CODE[m[1]];
    if (code === void 0) return false;
    const digits = (m[2] + m[3]).split("").map(Number);
    let sum = Math.floor(code / 10) + code % 10 * 9;
    const weights = [8, 7, 6, 5, 4, 3, 2, 1];
    for (let i = 0; i < 8; i++) sum += digits[i] * weights[i];
    sum += digits[8];
    return sum % 10 === 0;
  }
  var TAIWAN_CITY_COUNTY = "(?:\u57FA\u9686\u5E02|\u81FA\u5317\u5E02|\u53F0\u5317\u5E02|\u65B0\u5317\u5E02|\u6843\u5712\u5E02|\u81FA\u4E2D\u5E02|\u53F0\u4E2D\u5E02|\u81FA\u5357\u5E02|\u53F0\u5357\u5E02|\u9AD8\u96C4\u5E02|\u65B0\u7AF9\u5E02|\u5609\u7FA9\u5E02|\u65B0\u7AF9\u7E23|\u82D7\u6817\u7E23|\u5F70\u5316\u7E23|\u5357\u6295\u7E23|\u96F2\u6797\u7E23|\u5609\u7FA9\u7E23|\u5C4F\u6771\u7E23|\u5B9C\u862D\u7E23|\u82B1\u84EE\u7E23|\u81FA\u6771\u7E23|\u53F0\u6771\u7E23|\u6F8E\u6E56\u7E23|\u91D1\u9580\u7E23|\u9023\u6C5F\u7E23)";
  var DETAILED_TAIWAN_ADDRESS_RE = new RegExp(
    `${TAIWAN_CITY_COUNTY}[^\\s<\uFF0C\u3002\uFF1B;\u3001,()\uFF08\uFF09]{0,90}(?:\u5927\u9053|\u8DEF|\u8857|\u5DF7|\u5F04|\u865F|\u91CC|\u6751|\u9130)[^\\s<\uFF0C\u3002\uFF1B;\u3001,()\uFF08\uFF09]{0,90}`,
    "g"
  );
  var ADDRESS_REDACTION = "[\u5DF2\u53BB\u8B58\u5225\u5730\u5740]";
  var PHONE_REDACTION = "[\u5DF2\u53BB\u8B58\u5225\u96FB\u8A71]";
  var PHONE_LABEL_PATTERN = "(?:\u806F\u7D61\u96FB\u8A71|\u9023\u7D61\u96FB\u8A71|\u884C\u52D5\u96FB\u8A71(?:\u865F\u78BC)?|\u624B\u6A5F(?:\u865F\u78BC)?|\u96FB\u8A71(?:\u865F\u78BC)?|\\b(?:phone\\s*(?:number|no\\.?|#)?|telephone\\s*(?:number|no\\.?|#)?|mobile(?:\\s+phone)?\\s*(?:number|no\\.?|#)?)(?![A-Za-z]))";
  var PHONE_VALUE_PATTERN = "[+\uFF0B]?[ \\t\\u3000]*(?:[\uFF08(][ \\t\\u3000]*)?[0-9\uFF10-\uFF19](?:[0-9\uFF10-\uFF19 \\t\\u3000().\uFF08\uFF09\uFF0E\\-\uFF0D\u2013\u2014/\uFF0F]{0,40}[0-9\uFF10-\uFF19])?(?:[ \\t\\u3000]*(?:#|\uFF03|\u5206\u6A5F|ext\\.?)[ \\t\\u3000]*[0-9\uFF10-\uFF19]{1,8})?";
  var PHONE_INLINE_LAYOUT_PATTERN = "(?:[ \\t\\u3000]|&nbsp;|&#160;|&#x0*a0;|<\\/?(?:b|strong|span|font|em|i)\\b[^>]*>)*";
  var PHONE_LABEL_SEPARATOR_PATTERN = "(?:\\s*[:\uFF1A]\\s*|[ \\t\\u3000]+)?";
  var LABELED_PHONE_VALUE_RE = new RegExp(
    `(${PHONE_LABEL_PATTERN}${PHONE_LABEL_SEPARATOR_PATTERN}${PHONE_INLINE_LAYOUT_PATTERN}(?:<\\/td>\\s*<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN})?)(${PHONE_VALUE_PATTERN})`,
    "gi"
  );
  var BARE_PHONE_CELL_VALUE_RE = new RegExp(
    `(<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN}${PHONE_LABEL_PATTERN}${PHONE_INLINE_LAYOUT_PATTERN}<\\/td>\\s*<td[^>]*>${PHONE_INLINE_LAYOUT_PATTERN})(${PHONE_VALUE_PATTERN})`,
    "gi"
  );
  function redactPhoneValue(match, labelAndLayout, value) {
    const trailingDate = value.match(
      /^(.*?[0-9０-９])([ \t\u3000]+[12１２][09０９][0-9０-９]{2}[/.．／\-－][0-9０-９]{1,2}[/.．／\-－][0-9０-９]{1,2}.*)$/
    );
    const phone = trailingDate?.[1] ?? value;
    const suffix = trailingDate?.[2] ?? "";
    const digitCount = phone.match(/[0-9０-９]/g)?.length ?? 0;
    return digitCount >= 7 ? `${labelAndLayout}${PHONE_REDACTION}${suffix}` : match;
  }
  var LABELED_ADDRESS_VALUE_RE = new RegExp(
    `((?:\u6236\u7C4D\u5730\u5740|\u901A\u8A0A\u5730\u5740|\u806F\u7D61\u5730\u5740|\u73FE\u4F4F\u5730\u5740|\u4F4F\u5740|\u5730\u5740)\\s*[:\uFF1A]\\s*(?:<\\/b>\\s*)?(?:<\\/td>\\s*<td[^>]*>\\s*(?:<b>\\s*<\\/b>\\s*)?)?)([^<\\n\\r]+?)(?=<|\\n|\\r|\\s*(?:[-_=]{8,}|(?:SNOMED|DX|GROSS(?:\\s+(?:D|FINDING))?|MICRO(?:SCOPIC\\s+FINDING|\\s+D)?|PATHOLOGICAL\\s+DIAGNOSIS|DIAGNOSIS|\u81E8\u5E8A\u8A3A\u65B7|\u75C5\u7406\u8A3A\u65B7|\u6253\u5B57\u54E1|\u75C5\u7406\u91AB\u5E2B|\u5C1A\u6709\u5831\u544A|\u75C5\u89E3\u5C08\u91AB\u5B57|\u5165\u9662\u79D1\u5225|\u51FA\u9662\u79D1\u5225|\u4F4F\u9662\u5929\u6578|ISS\u5206\u6578|\u91AB\u7642\u6A5F\u69CB\u540D\u7A31|\u91AB\u7642\u6A5F\u69CB\u4EE3\u78BC|${PHONE_LABEL_PATTERN})\\s*[:\uFF1A])|$)`,
    "gi"
  );
  function redactDemographicsInText(text) {
    if (!text || typeof text !== "string") return text;
    return text.replace(
      /((?:出生日期|出生年月日|生日)\s*[:：]\s*(?:<\/b>\s*)?(?:<\/td>\s*<td[^>]*>\s*)?)(\d{4})(\s*[/.\-／]\s*)\d{1,2}(\s*[/.\-／]\s*)\d{1,2}/g,
      (_m, label, year, sep1, sep2) => `${label}${year}${sep1}XX${sep2}XX`
    ).replace(
      /((?:出生日期|出生年月日|生日)\s*[:：]\s*(?:<\/b>\s*)?(?:<\/td>\s*<td[^>]*>\s*)?)(?:民國\s*)?\d{1,3}\s*[年/.\-／]\s*\d{1,2}\s*[月/.\-／]\s*\d{1,2}\s*日?/g,
      (_m, label) => `${label}[\u5DF2\u53BB\u8B58\u5225]`
    ).replace(
      /(^|[\r\n>])(\s*)(?!(?:送檢|主治|會診|病理|臨床|醫師|醫事|報告|診斷))([一-鿿]{2,15})(\s+)(?=(?:病歷號碼|病歷號數|病歷號|病歷編號)\s*[:：]\s*(?:<\/b>\s*)?[A-Za-z0-9\-]+\s+性別\s*[:：]\s*(?:男性|女性|男|女))/g,
      (_m, boundary, leading, name, gap) => `${boundary}${leading}${maskName(name)}${gap}`
    ).replace(
      /(^|[\r\n>])(\s*)([A-Za-z][A-Za-z .'\-]{1,38}?)(\s+)(?=(?:病歷號碼|病歷號數|病歷號|病歷編號)\s*[:：]\s*(?:<\/b>\s*)?[A-Za-z0-9\-]+\s+性別\s*[:：]\s*(?:男性|女性|男|女))/g,
      (_m, boundary, leading, name, gap) => `${boundary}${leading}${maskName(name)}${gap}`
    ).replace(
      /((?:病歷號碼|病歷號數|病歷號|病歷編號)\s*[:：]\s*(?:<\/b>\s*)?(?:<\/td>\s*<td[^>]*>\s*)?)[A-Za-z0-9\-]+/g,
      (_m, label) => `${label}[\u5DF2\u53BB\u8B58\u5225]`
    ).replace(
      /((?:國民身分證統一編號|身分證統一編號|身分證字號|身份證字號|身分證號|身份證號|身分證|身份證)\s*[:：]\s*(?:<\/b>\s*)?(?:<\/td>\s*<td[^>]*>\s*)?)[A-Za-z0-9*\-]+/g,
      (_m, label) => `${label}[\u5DF2\u53BB\u8B58\u5225]`
    ).replace(LABELED_PHONE_VALUE_RE, redactPhoneValue).replace(BARE_PHONE_CELL_VALUE_RE, redactPhoneValue).replace(LABELED_ADDRESS_VALUE_RE, (_m, label) => `${label}${ADDRESS_REDACTION}`).replace(
      /(<td[^>]*>\s*(?:<b>\s*)?(?:戶籍地址|通訊地址|聯絡地址|現住地址|住址|地址)\s*(?:<\/b>\s*)?<\/td>\s*<td[^>]*>\s*)([^<\n\r]+)/g,
      (_m, label) => `${label}${ADDRESS_REDACTION}`
    ).replace(DETAILED_TAIWAN_ADDRESS_RE, ADDRESS_REDACTION).replace(
      /((?:病患姓名|病人姓名|患者姓名|姓名)\s*[:：]\s*(?:<\/b>\s*)?(?:<\/td>\s*<td[^>]*>\s*)?)([一-鿿]{2,15})/g,
      (_m, label, name) => `${label}${maskName(name)}`
    ).replace(
      /((?:病患姓名|病人姓名|患者姓名|姓名)\s*[:：]\s*(?:<\/b>\s*)?(?:<\/td>\s*<td[^>]*>\s*)?)([A-Za-z][A-Za-z .'\-]{1,38})/g,
      (_m, label, name) => `${label}${maskName(name)}`
    ).replace(
      /(病患資訊\s*[:：]\s*(?:[門急住]\s*[診院])?\s*)([^<\n\r]+?)(\s*(?:男性|女性|男|女)\s*[\d０-９]{1,3}\s*歲)/g,
      (_m, label, _mid, marker) => `${label}[\u5DF2\u53BB\u8B58\u5225]${marker}`
    ).replace(
      /(?<![0-9A-Za-z\-])(?=[0-9A-Za-z\-]*\d)[0-9A-Za-z][0-9A-Za-z\-]*(\s*(?:男性|女性|男|女)\s*[\d０-９]{1,3}\s*歲)/g,
      (_m, marker) => `[\u5DF2\u53BB\u8B58\u5225]${marker}`
    ).replace(
      /(?<![A-Za-z0-9])[A-Z][12]\d{8}(?![0-9])/g,
      (m) => isValidTwid(m) ? "[\u5DF2\u53BB\u8B58\u5225]" : m
    );
  }
  function normalizeNarrativeForDedup(s) {
    return (s ?? "").normalize("NFKC").replace(/\s+/g, "").toLowerCase();
  }
  function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function cjkChars(s) {
    if (!s) return 0;
    let n = 0;
    for (const ch of s) {
      const cp = ch.codePointAt(0) ?? 0;
      if (cp >= 19968 && cp <= 40959) n++;
    }
    return n;
  }
  var TRANSLATION_EXT = "http://hl7.org/fhir/StructureDefinition/translation";
  function bilingualCoding(system, code, nativeDisplay, other) {
    const coding = { system, code };
    const nd = (nativeDisplay ?? "").trim();
    if (nd) coding.display = nd;
    const oc = (other?.content ?? "").trim();
    if (oc && oc !== nd) {
      coding._display = {
        extension: [
          {
            url: TRANSLATION_EXT,
            extension: [
              { url: "lang", valueCode: other.lang },
              { url: "content", valueString: oc }
            ]
          }
        ]
      };
    }
    return coding;
  }
  function maskName(name) {
    const trimmed = (name ?? "").trim();
    if (!trimmed || trimmed === "Unknown") return trimmed;
    if (/\s/.test(trimmed)) {
      const parts = trimmed.split(/\s+/);
      if (parts.length === 1) return parts[0];
      const first = parts[0];
      const last = parts[parts.length - 1];
      if (parts.length === 2) {
        const lastMasked = last.length <= 1 ? last : `${last[0]}***`;
        return `${first} ${lastMasked}`;
      }
      const middles = parts.slice(1, -1).map(() => "***");
      return [first, ...middles, last].join(" ");
    }
    const chars = Array.from(trimmed);
    if (chars.length <= 1) return trimmed;
    if (chars.length === 2) return `${chars[0]}O`;
    return chars[0] + "O".repeat(chars.length - 2) + chars[chars.length - 1];
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/systems.ts
  var NHI_MEDICAL_ORDER_CODE = "https://twcore.mohw.gov.tw/ig/twcore/CodeSystem/medical-service-payment-tw";
  var NHI_DRUG_CODE = "https://twcore.mohw.gov.tw/ig/twcore/CodeSystem/medication-nhi-tw";
  var HIS_LOCAL_LAB_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-lab";
  var HIS_LOCAL_MEDICATION_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-medication";
  var HIS_LOCAL_REPORT_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-report";
  var HIS_LOCAL_CONDITION_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-condition";
  var HIS_LOCAL_PROCEDURE_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-procedure";
  var HIS_LOCAL_ALLERGEN_CODE = "https://nhi-fhir-bridge.local/CodeSystem/his-local-allergen";
  var ENCOUNTER_KIND_SYSTEM = "https://nhi-fhir-bridge.github.io/CodeSystem/encounter-kind";
  var ENCOUNTER_CHANNEL_SYSTEM = "https://nhi-fhir-bridge.github.io/CodeSystem/encounter-channel";
  var FHIR_SERVICE_TYPE = "http://terminology.hl7.org/CodeSystem/service-type";
  var TW_CORE_MEDICAL_CONSULTATION_DEPARTMENT = "https://twcore.mohw.gov.tw/ig/twcore/CodeSystem/medical-consultation-department-nhi-tw";
  var NHI_CARE_PLAN_PROGRAM = "https://nhi-fhir-bridge.github.io/CodeSystem/nhi-care-plan-program";
  var CANCER_SCREENING_CODE = "https://nhi-fhir-bridge.github.io/CodeSystem/cancer-screening";
  var CANCER_SCREENING_RESULT = "https://nhi-fhir-bridge.github.io/CodeSystem/cancer-screening-result";
  var OBSERVATION_VALUE = "https://nhi-fhir-bridge.github.io/CodeSystem/observation-value";
  var NHI_SOURCE_ORDER_CODE = "http://nhi-fhir-bridge/nhi-source-order-code";
  var DEDUP_PROVENANCE = "http://nhi-fhir-bridge/dedup-provenance";
  var LOINC = "http://loinc.org";
  var SNOMED_CT = "http://snomed.info/sct";
  var ICD_10_CM = "http://hl7.org/fhir/sid/icd-10-cm";
  var ICD_10_PCS = "http://hl7.org/fhir/sid/icd-10-pcs";

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/allergy.ts
  var ALLOWED_CATEGORIES = /* @__PURE__ */ new Set(["medication", "food", "environment", "biologic"]);
  var ALLOWED_CRITICALITY = /* @__PURE__ */ new Set(["high", "low", "unable-to-assess"]);
  function mapSystem(systemHint) {
    const s = typeof systemHint === "string" ? systemHint.toLowerCase() : "";
    if (s.includes("snomed")) return SNOMED_CT;
    if (s.includes("rxnorm")) return "http://www.nlm.nih.gov/research/umls/rxnorm";
    return HIS_LOCAL_ALLERGEN_CODE;
  }
  function mapAllergyIntolerance(raw, patientId) {
    const display = raw.display ?? "Unknown Allergen";
    const code = raw.code;
    const system = mapSystem(raw.system ?? "");
    const resource = {
      resourceType: "AllergyIntolerance",
      id: stableId(patientId, code || display, raw.recorded_date ?? ""),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      patient: { reference: `Patient/${patientId}` },
      clinicalStatus: {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
            code: "active"
          }
        ]
      },
      verificationStatus: {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
            code: "confirmed"
          }
        ]
      },
      code: {
        coding: [{ system, code: code || display, display }],
        text: display
      }
    };
    const category = raw.category ?? "";
    if (ALLOWED_CATEGORIES.has(category)) {
      resource.category = [category];
    }
    const criticality = raw.criticality ?? "";
    if (ALLOWED_CRITICALITY.has(criticality)) {
      resource.criticality = criticality;
    }
    if (raw.recorded_date) {
      resource.recordedDate = `${raw.recorded_date}T00:00:00+08:00`;
    }
    const reactionNote = raw.reaction ?? "";
    if (reactionNote) {
      resource.reaction = [{ description: reactionNote }];
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/cancer-screening.ts
  var INTERP_SYS = "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
  var OBS_CATEGORY_SYS = "http://terminology.hl7.org/CodeSystem/observation-category";
  var CANCER_SCREENING_NAMES = {
    \u5927\u8178\u764C\u7BE9\u6AA2: "Colorectal Cancer Screening (FOBT)",
    \u53E3\u8154\u764C\u7BE9\u6AA2: "Oral Cancer Screening",
    \u4E73\u764C\u7BE9\u6AA2: "Breast Cancer Screening (Mammography)",
    \u5B50\u5BAE\u9838\u764C\u7BE9\u6AA2: "Cervical Cancer Screening (Pap Smear)",
    \u80BA\u764C\u7BE9\u6AA2: "Lung Cancer Screening (LDCT)",
    \u5A66\u5973HPV\u6AA2\u6E2C: "Cervical HPV Test",
    \u80C3\u5E7D\u9580\u687F\u83CC\u7BE9\u6AA2: "H. pylori Stool Antigen Test (HPSA)"
  };
  var CANCER_RESULT_VOCAB = {
    \u7121\u7570\u5E38: { en: "No abnormality detected", interp: "N" },
    \u6B63\u5E38: { en: "Normal", interp: "N" },
    \u7570\u5E38: { en: "Abnormal", interp: "A" },
    \u7591\u4F3C\u7570\u5E38: { en: "Suspected abnormality", interp: "A" },
    \u967D\u6027: { en: "Positive", interp: "POS" },
    \u9670\u6027: { en: "Negative", interp: "NEG" },
    \u826F\u6027\u767C\u73FE: { en: "Benign finding", interp: "N" },
    \u5EFA\u8B70\u8FFD\u8E64: { en: "Follow-up recommended", interp: null },
    \u5EFA\u8B70\u8907\u6AA2: { en: "Follow-up recommended", interp: null }
  };
  var INTERP_DISPLAY = {
    N: "Normal",
    A: "Abnormal",
    POS: "Positive",
    NEG: "Negative"
  };
  function mapCancerScreening(raw, patientId) {
    const date = String(raw.date ?? "").trim();
    const label = String(raw.screening_label ?? "").trim();
    const resultText = String(raw.result_text ?? "").trim();
    if (!date || !label || !resultText) return null;
    const hospital = String(raw.hospital ?? "").trim();
    const nameEn = CANCER_SCREENING_NAMES[label];
    const vocab = CANCER_RESULT_VOCAB[resultText];
    const resource = {
      resourceType: "Observation",
      id: stableId(patientId, "cancer-screen", label, date, hospital, resultText),
      meta: {
        versionId: "1",
        source: "nhi-fhir-bridge/scraper",
        // Programme tag so SMART apps can isolate the 癌症篩檢 section.
        tag: [{ system: "http://nhi-fhir-bridge/source-program", code: "cancer-screening" }]
      },
      status: "final",
      category: [
        { coding: [{ system: OBS_CATEGORY_SYS, code: "laboratory", display: "Laboratory" }] }
      ],
      code: {
        // Chinese label as the code; English display from the bilingual
        // table (falls back to the Chinese label when unmapped). code.text
        // always carries the Chinese name (patient-facing).
        coding: [{ system: CANCER_SCREENING_CODE, code: label, display: nameEn || label }],
        text: label
      },
      subject: { reference: `Patient/${patientId}` },
      effectiveDateTime: `${date}T00:00:00+08:00`
    };
    if (vocab) {
      resource.valueCodeableConcept = {
        coding: [{ system: CANCER_SCREENING_RESULT, code: resultText, display: vocab.en }],
        text: resultText
      };
      if (vocab.interp) {
        resource.interpretation = [
          {
            coding: [
              { system: INTERP_SYS, code: vocab.interp, display: INTERP_DISPLAY[vocab.interp] }
            ]
          }
        ];
      }
    } else {
      resource.valueString = resultText;
    }
    if (hospital) resource.performer = [{ display: hospital }];
    const detail = String(raw.detail ?? "").trim();
    if (detail) {
      resource.note = [{ text: detail }];
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/careplan.ts
  function mapCarePlan(raw, patientId) {
    const title = (raw.title ?? "").trim();
    if (!title) return null;
    const status = raw.status === "completed" ? "completed" : "active";
    const start = (raw.period_start ?? "").trim();
    const end = (raw.period_end ?? "").trim();
    const resource = {
      resourceType: "CarePlan",
      // Stable id keys on patient + title + start. Re-enrolment in the same
      // programme on a different 收案日 is a distinct CarePlan; a re-sync of
      // the same enrolment collapses to one resource (deterministic hash).
      id: stableId(patientId, title, start),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      // CarePlan.status (1..1, request-status ValueSet) + intent (1..1) are
      // both required by FHIR R4.
      status,
      intent: "plan",
      title,
      subject: { reference: `Patient/${patientId}` }
    };
    const description = (raw.description ?? "").trim();
    if (description) {
      resource.description = description;
    }
    if (start || end) {
      const period = {};
      if (start) period.start = `${start}T00:00:00+08:00`;
      if (end) period.end = `${end}T00:00:00+08:00`;
      resource.period = period;
    }
    const category = { text: "NHI \u7167\u8B77\u8A08\u756B" };
    const programCode = (raw.program_code ?? "").trim();
    if (programCode) {
      category.coding = [{ system: NHI_CARE_PLAN_PROGRAM, code: programCode }];
    }
    resource.category = [category];
    const hospital = (raw.hospital ?? "").trim();
    if (hospital) {
      resource.author = { display: hospital };
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/condition.ts
  var ICD10_CATEGORY_RE = /^[A-Z][0-9A-Z]{2}$/;
  function normalizeIcd10Cm(code) {
    if (!code || code.includes(".")) return code ?? "";
    const s = code.trim().toUpperCase();
    if (s.length <= 3) return s;
    const head = s.slice(0, 3);
    const tail = s.slice(3);
    if (ICD10_CATEGORY_RE.test(head)) {
      return `${head}.${tail}`;
    }
    return s;
  }
  function mapSystem2(systemHint) {
    const s = typeof systemHint === "string" ? systemHint.toLowerCase() : "";
    if (s.includes("snomed")) return SNOMED_CT;
    if (s.includes("icd-10") || s.includes("icd10")) {
      return ICD_10_CM;
    }
    return HIS_LOCAL_CONDITION_CODE;
  }
  function mapCondition(raw, patientId) {
    const display = raw.display ?? "Unknown Condition";
    let code = raw.code;
    const system = mapSystem2(raw.system ?? "");
    if (system === ICD_10_CM && code) {
      code = normalizeIcd10Cm(code);
    }
    const resource = {
      resourceType: "Condition",
      // Stable id falls back to display when no code is present (catastrophic
      // illness rows from IHKE3209 carry the Chinese narrative only). Mirrors
      // the same `code || display` pattern in diagnostic-report.ts and
      // allergy.ts — avoids hash collisions between two same-day code-less
      // conditions.
      id: stableId(patientId, code || display, raw.onset_date ?? ""),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      subject: { reference: `Patient/${patientId}` },
      clinicalStatus: {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/condition-clinical",
            code: raw.clinical_status ?? "active"
          }
        ]
      },
      verificationStatus: {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/condition-ver-status",
            code: "confirmed"
          }
        ]
      }
    };
    if (raw.category) {
      resource.category = [
        {
          coding: [
            {
              system: "http://terminology.hl7.org/CodeSystem/condition-category",
              code: raw.category
            }
          ]
        }
      ];
    }
    resource.code = {
      // coding[0].display = English-preferred (technical); code.text = 中文 when
      // available so the patient-facing label is consistently Chinese instead of
      // whatever language NHI happened to ship (was display-language-unpredictable).
      coding: [{ system, code: code || display, display }],
      text: (raw.display_zh ?? "").trim() || display
    };
    const severity = raw.severity ?? "";
    if (severity) {
      resource.severity = { text: severity };
    }
    if (raw.onset_date) {
      resource.onsetDateTime = `${raw.onset_date}T00:00:00+08:00`;
    }
    if (raw.recorded_date) {
      resource.recordedDate = `${raw.recorded_date}T00:00:00+08:00`;
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/base64.ts
  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }
  function bytesToBase64(bytes) {
    let binary = "";
    const chunkSize = 32768;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }
  function utf8ToBytes(value) {
    return new TextEncoder().encode(value);
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/jpeg-deid.ts
  function detectImageFormat(bytes) {
    if (bytes.length >= 2 && bytes[0] === 255 && bytes[1] === 216) return "jpeg";
    if (bytes.length >= 6 && bytes[0] === 71 && // G
    bytes[1] === 73 && // I
    bytes[2] === 70 && // F
    bytes[3] === 56 && // 8
    (bytes[4] === 55 || bytes[4] === 57) && // 7 | 9
    bytes[5] === 97) {
      return "gif";
    }
    return "unknown";
  }
  function imageMimeFromBase64(b64) {
    try {
      const head = base64ToBytes(b64.slice(0, 16));
      const fmt = detectImageFormat(head);
      if (fmt === "gif") return "image/gif";
      if (fmt === "jpeg") return "image/jpeg";
    } catch {
    }
    return "image/jpeg";
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/diagnostic-report.ts
  var V2_0074 = "http://terminology.hl7.org/CodeSystem/v2-0074";
  function fhirDateTime(value) {
    const source = String(value ?? "").trim();
    return source.includes("T") ? source : `${source}T00:00:00+08:00`;
  }
  var CATEGORY_MAP = {
    LAB: [V2_0074, "LAB", "Laboratory"],
    RAD: [V2_0074, "RAD", "Radiology"],
    EC: [V2_0074, "EC", "Electrocardiac"],
    CUS: [V2_0074, "CUS", "Cardiac Ultrasound"],
    CTH: [V2_0074, "CTH", "Cardiac Catheterization"],
    PATH: [V2_0074, "PAT", "Pathology"]
  };
  var LAB_VALUE_ONLY_RE = /^(?:[\p{L}\p{N}._%/+-]{1,40}\s+)?[<>≤≥]?\s*[+-]?\d+(?:\.\d+)?\s*(?:%|mg\/dL|g\/dL|mmol\/L|U\/L|IU\/L|mIU\/L|ng\/mL|μg\/dL|ug\/dL|pg\/mL|fL|\/uL|10\^?\d+\/uL|x10\^?\d+\/uL|sec|秒|copies\/mL)(?:\s*\([^)]{1,80}\))?$/iu;
  function looksLikeLabValueOnly(conclusion) {
    if (!conclusion) return true;
    const text = conclusion.trim();
    if (text.length > 100) return false;
    if (LAB_VALUE_ONLY_RE.test(text)) return true;
    return false;
  }
  function _conclusionFingerprint(s) {
    const norm = normalizeNarrativeForDedup(s);
    let h = 5381;
    const cap = Math.min(norm.length, 16384);
    for (let i = 0; i < cap; i++) {
      h = (h << 5) + h + norm.charCodeAt(i) | 0;
    }
    return `${h >>> 0}:${norm.length}`;
  }
  function mapDiagnosticReport(raw, patientId) {
    const conclusion = (raw.conclusion ?? "").trim();
    const rawJpgs = Array.isArray(raw.jpgBase64s) ? raw.jpgBase64s.filter((s) => typeof s === "string" && s.length > 0) : typeof raw.jpgBase64 === "string" && raw.jpgBase64.length > 0 ? [raw.jpgBase64] : [];
    if (!conclusion && rawJpgs.length === 0) return null;
    const catKeyRaw = String(raw.category ?? "").toUpperCase();
    if (catKeyRaw === "LAB" && conclusion && looksLikeLabValueOnly(conclusion)) {
      return null;
    }
    const display = raw.display ?? "Unknown Report";
    const code = raw.code;
    const systemHint = typeof raw.system === "string" ? raw.system.toUpperCase() : "";
    const system = systemHint === "LOINC" ? LOINC : systemHint === "NHI" && code ? NHI_MEDICAL_ORDER_CODE : HIS_LOCAL_REPORT_CODE;
    let idDiscriminator;
    if (raw.iplCaseSeqNo) {
      idDiscriminator = `${code || display}|${raw.iplCaseSeqNo}`;
    } else if (conclusion) {
      idDiscriminator = `${code || display}|${_conclusionFingerprint(conclusion)}`;
    } else {
      idDiscriminator = code || display;
    }
    const hospital = (raw.hospital ?? "").trim();
    const resource = {
      resourceType: "DiagnosticReport",
      id: stableId(patientId, idDiscriminator, raw.date ?? "", hospital),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      status: raw.status ?? "final",
      subject: { reference: `Patient/${patientId}` },
      code: {
        // coding[0].display = English-preferred; code.text = 中文 when available
        // so the report label is consistently Chinese (was language-unpredictable).
        coding: [{ system, code: code || display, display }],
        text: (raw.display_zh ?? "").trim() || display
      }
    };
    if (conclusion) resource.conclusion = conclusion;
    const catEntry = CATEGORY_MAP[catKeyRaw];
    if (catEntry) {
      const [catSys, catCode, catDisplay] = catEntry;
      resource.category = [{ coding: [{ system: catSys, code: catCode, display: catDisplay }] }];
    }
    if (raw.date) {
      resource.effectiveDateTime = fhirDateTime(raw.date);
    }
    if (raw.issued) {
      resource.issued = fhirDateTime(raw.issued);
    } else if (raw.date) {
      resource.issued = fhirDateTime(raw.date);
    }
    if (hospital) {
      resource.performer = [{ display: hospital }];
    }
    if (raw.rid && raw.ctype) {
      resource.meta.tag = [
        {
          system: "http://nhi-fhir-bridge/nhi-imaging-row",
          code: `${raw.rid}|${raw.ctype}`
        }
      ];
    }
    if (rawJpgs.length > 0) {
      resource.presentedForm = rawJpgs.map((b64, i) => {
        const size = Math.floor(b64.length * 3 / 4);
        const title = rawJpgs.length > 1 ? `${display} (frame ${i + 1}/${rawJpgs.length})` : display;
        return {
          // NHI labels these "JPG" but in practice ships GIF89a — sniff the magic
          // number per frame so the Attachment's contentType is honest (a consumer
          // that trusts the label and decodes as JPEG would otherwise fail).
          contentType: imageMimeFromBase64(b64),
          data: b64,
          size,
          title
        };
      });
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/document-reference.ts
  var import_js_sha13 = __toESM(require_sha1(), 1);

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/encounter.ts
  var KIND_CODE_MAP = {
    \u9580\u8A3A: "outpatient",
    \u6025\u8A3A: "emergency",
    \u4F4F\u9662: "inpatient",
    \u85E5\u5C40: "pharmacy"
  };
  var CHANNEL_CODE_MAP = {
    \u7533\u5831\u8CC7\u6599: "claims",
    IC\u5361\u8CC7\u6599: "ic-card",
    \u96F2\u7AEF\u75C5\u6B77: "medcloud"
  };
  function buildTypeEntry(text, system, codeMap) {
    const coding = { system, display: text };
    const code = codeMap[text];
    if (code) coding.code = code;
    return { text, coding: [coding] };
  }
  var ACTCODE_SYSTEM = "http://terminology.hl7.org/CodeSystem/v3-ActCode";
  var CLASS_MAP = {
    AMB: [ACTCODE_SYSTEM, "AMB", "ambulatory"],
    IMP: [ACTCODE_SYSTEM, "IMP", "inpatient encounter"],
    EMER: [ACTCODE_SYSTEM, "EMER", "emergency"]
  };
  var CLINICAL_SERVICE_TYPE_MAP = {
    dental: {
      coding: [
        { system: SNOMED_CT, code: "722163006" },
        { system: FHIR_SERVICE_TYPE, code: "88" }
      ]
    },
    "traditional-chinese-medicine": {
      coding: [{
        system: TW_CORE_MEDICAL_CONSULTATION_DEPARTMENT,
        version: "2024-05-27",
        code: "60"
      }]
    }
  };
  function encounterServiceTypeFromClinicalDomain(value) {
    const domain = String(value ?? "").trim().toLowerCase();
    const serviceType = CLINICAL_SERVICE_TYPE_MAP[domain];
    if (!serviceType) return void 0;
    return {
      ...serviceType,
      coding: serviceType.coding.map((coding) => ({ ...coding }))
    };
  }
  function shouldUseFuncSeqKey(raw, funcSeq) {
    const channel = String(raw.channel ?? "").trim();
    if (/^\d+$/.test(funcSeq)) return channel !== "IC\u5361\u8CC7\u6599";
    if (channel !== "IC\u5361\u8CC7\u6599") return false;
    return /^[A-Z]\d{3}$/.test(funcSeq);
  }
  function encounterStableId(patientId, encClass, raw) {
    const date = String(raw.date ?? "");
    const hospital = String(raw.hospital ?? "").trim();
    if (encClass === "IMP") {
      const sourceStayKey = String(
        raw.func_seq_no ?? raw.source_record_key ?? raw.row_id ?? ""
      ).trim();
      return stableId(
        patientId,
        date,
        "IMP",
        hospital,
        sourceStayKey ? `stay:${sourceStayKey}` : String(raw.end_date ?? "").trim()
      );
    }
    if (raw.channel === "\u96F2\u7AEF\u75C5\u6B77" && raw.clinical_service_domain === "dental" && raw.func_seq_no === "medcloud-dental-day") {
      return stableId(patientId, date, hospital, "medcloud-dental-day");
    }
    const primary = raw.reason_code ? normalizeIcd10Cm(String(raw.reason_code)) : "";
    const secondaries = (Array.isArray(raw.secondary_diagnoses) ? raw.secondary_diagnoses : []).map((s) => s?.code ? normalizeIcd10Cm(String(s.code)) : "").filter(Boolean).sort();
    const dxKey = [primary, ...secondaries].join(",");
    const funcSeq = String(raw.func_seq_no ?? "").trim();
    if (shouldUseFuncSeqKey(raw, funcSeq)) {
      return stableId(patientId, date, hospital, dxKey, `fseq:${funcSeq}`);
    }
    const partAmt = String(raw.part_amt ?? "").trim();
    const applDot = String(raw.appl_dot ?? "").trim();
    return stableId(patientId, date, hospital, dxKey, partAmt, applDot);
  }
  var ENC_CLASS_RANK = { EMER: 3, IMP: 2, AMB: 1 };
  function encClassRank(enc) {
    return ENC_CLASS_RANK[String(enc?.class?.code ?? "").toUpperCase()] ?? 0;
  }
  function dedupEncountersPreferClass(resources) {
    const winner = /* @__PURE__ */ new Map();
    const labUnion = /* @__PURE__ */ new Map();
    const rxUnion = /* @__PURE__ */ new Map();
    const reasonUnion = /* @__PURE__ */ new Map();
    const collectUnion = (id, arr, into) => {
      if (!Array.isArray(arr) || arr.length === 0) return;
      const set = into.get(id) ?? /* @__PURE__ */ new Set();
      for (const c of arr) if (c) set.add(String(c));
      into.set(id, set);
    };
    for (const r of resources) {
      if (r?.resourceType !== "Encounter") continue;
      collectUnion(r.id, r.__labOrderCodes, labUnion);
      collectUnion(r.id, r.__rxOrderCodes, rxUnion);
      if (Array.isArray(r.reasonCode)) {
        const reasons = reasonUnion.get(r.id) ?? /* @__PURE__ */ new Map();
        for (const reason of r.reasonCode) {
          const coding = reason?.coding?.[0];
          const key = coding?.system && coding?.code ? `${coding.system}|${coding.code}` : JSON.stringify(reason);
          if (!reasons.has(key)) reasons.set(key, reason);
        }
        reasonUnion.set(r.id, reasons);
      }
      const prev = winner.get(r.id);
      if (!prev || encClassRank(r) > encClassRank(prev)) winner.set(r.id, r);
    }
    const emitted = /* @__PURE__ */ new Set();
    const out = [];
    for (const r of resources) {
      if (r?.resourceType !== "Encounter") {
        out.push(r);
        continue;
      }
      if (emitted.has(r.id)) continue;
      emitted.add(r.id);
      const w = winner.get(r.id) ?? r;
      const lab = labUnion.get(w.id);
      if (lab && lab.size > 0) w.__labOrderCodes = [...lab];
      const rx = rxUnion.get(w.id);
      if (rx && rx.size > 0) w.__rxOrderCodes = [...rx];
      const reasons = reasonUnion.get(w.id);
      if (reasons && reasons.size > 0) w.reasonCode = [...reasons.values()];
      out.push(w);
    }
    return out;
  }
  function mapEncounter(raw, patientId) {
    const encClass = String(raw.class ?? "AMB").toUpperCase();
    const classEntry = CLASS_MAP[encClass] ?? CLASS_MAP.AMB;
    const resource = {
      resourceType: "Encounter",
      id: encounterStableId(patientId, encClass, raw),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      // 住院(IMP)沒有出院日 → status "unknown". IC卡資料 的住院常只記到住院日,
      // 出院日未寫回卡片,所以「沒有 out_DATE」並不代表還在住院(in-progress),也
      // 不能斷定已結束(finished). 忠實搬運:無法判定就標 unknown,不杜撰狀態. 申報
      // 住院 / 門診 / 急診照舊 finished(門診本就是單日、無 period.end 屬正常).
      status: encClass === "IMP" && !raw.end_date ? "unknown" : "finished",
      class: {
        system: classEntry[0],
        code: classEntry[1],
        display: classEntry[2]
      },
      subject: { reference: `Patient/${patientId}` }
    };
    const kind = (raw.kind ?? "").trim();
    const channel = (raw.channel ?? "").trim();
    const types = [];
    if (kind) types.push(buildTypeEntry(kind, ENCOUNTER_KIND_SYSTEM, KIND_CODE_MAP));
    if (channel) {
      types.push(buildTypeEntry(channel, ENCOUNTER_CHANNEL_SYSTEM, CHANNEL_CODE_MAP));
    }
    if (types.length === 0) {
      const typeDisplay = (raw.type_display ?? "").trim();
      if (typeDisplay) types.push({ text: typeDisplay });
    }
    if (types.length > 0) {
      resource.type = types;
    }
    const period = {};
    if (raw.date) period.start = String(raw.date);
    if (raw.end_date) period.end = String(raw.end_date);
    if (Object.keys(period).length > 0) {
      resource.period = period;
    }
    const department = raw.department ?? "";
    const provider = raw.provider ?? "";
    if (provider) {
      resource.participant = [{ individual: { display: provider } }];
    }
    const clinicalServiceType = encounterServiceTypeFromClinicalDomain(
      raw.clinical_service_domain
    );
    if (clinicalServiceType) {
      resource.serviceType = clinicalServiceType;
    } else if (department) {
      resource.serviceType = { text: department };
    }
    const hospital = (raw.hospital ?? "").trim();
    if (hospital) {
      resource.serviceProvider = { display: hospital };
    }
    const reasonCodes = [];
    const reason = (raw.reason ?? "").trim();
    const reasonZh = (raw.reason_zh ?? "").trim();
    const reasonCode = (raw.reason_code ?? "").trim();
    if (reason || reasonZh || reasonCode) {
      const rc = {};
      if (reasonCode) {
        const displayPlain = reason.replace(new RegExp(`^${reasonCode}\\s+`), "").trim();
        rc.coding = [
          {
            system: "http://hl7.org/fhir/sid/icd-10-cm",
            // NHI ships ICD-10-CM WITHOUT the dot ("E079"); the canonical
            // system form is dotted ("E07.9"). Normalising here keeps the
            // same diagnosis from appearing as two distinct codes across
            // encounters (the medication mapper already normalises) — a
            // problem-list grouping bug in consuming SMART apps.
            code: normalizeIcd10Cm(reasonCode),
            display: displayPlain || reason || reasonZh
          }
        ];
      }
      rc.text = reasonZh || reason;
      reasonCodes.push(rc);
    }
    const secondaries = Array.isArray(raw.secondary_diagnoses) ? raw.secondary_diagnoses : [];
    for (const sec of secondaries) {
      const code = (sec?.code ?? "").trim();
      const nameEn = (sec?.name_en ?? "").trim();
      const nameZh = (sec?.name_zh ?? "").trim();
      if (!code && !nameEn && !nameZh) continue;
      const entry = {};
      if (code) {
        entry.coding = [
          {
            system: "http://hl7.org/fhir/sid/icd-10-cm",
            code: normalizeIcd10Cm(code),
            display: nameEn || nameZh
          }
        ];
      }
      entry.text = code ? `${code} ${nameZh || nameEn}`.trim() : nameZh || nameEn;
      reasonCodes.push(entry);
    }
    if (reasonCodes.length > 0) {
      resource.reasonCode = reasonCodes;
    }
    const discharge = raw.discharge_disposition ?? "";
    if (discharge) {
      resource.hospitalization = { dischargeDisposition: { text: discharge } };
    }
    const clinicalNote = (raw.clinical_note ?? "").trim();
    if (clinicalNote) {
      resource.note = [{ text: clinicalNote }];
    }
    const rxCodes = Array.isArray(raw.rx_order_codes) ? raw.rx_order_codes : [];
    if (rxCodes.length > 0) resource.__rxOrderCodes = rxCodes;
    const labCodes = Array.isArray(raw.lab_order_codes) ? raw.lab_order_codes : [];
    if (labCodes.length > 0) resource.__labOrderCodes = labCodes;
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/document-reference.ts
  var LOINC2 = "http://loinc.org";
  var LOINC_DISCHARGE_SUMMARY = "18842-5";
  var LOINC_DISCHARGE_SUMMARY_DISPLAY = "Discharge summary";
  var DOC_CATEGORY_SYSTEM = "http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category";
  function sha1Base64(bytes) {
    return bytesToBase64(Uint8Array.from(import_js_sha13.sha1.array(bytes)));
  }
  function buildAttachment(html, title) {
    const bytes = utf8ToBytes(html);
    return {
      contentType: "text/html",
      language: "zh-TW",
      data: bytesToBase64(bytes),
      title,
      // FHIR R4 Attachment.size: "Number of bytes of content (if url
      // provided)" — the binary length, NOT the base64-string length.
      // For UTF-8 HTML this is the encoded byte count.
      size: bytes.byteLength,
      hash: sha1Base64(bytes)
    };
  }
  function mapDischargeSummaryDocRef(raw, patientId) {
    const html = String(raw?.html ?? "");
    if (!html || html.length < 10) return null;
    const admissionDate = String(raw?.admission_date ?? "");
    const dischargeDate = String(raw?.discharge_date ?? "");
    if (!admissionDate) return null;
    const hospital = String(raw?.hospital ?? "").trim();
    const rowId = String(raw?.row_id ?? "").trim();
    const encounterId = encounterStableId(patientId, "IMP", {
      date: admissionDate,
      hospital,
      func_seq_no: rowId,
      end_date: dischargeDate
    });
    const id = stableId(
      patientId,
      "discharge-summary",
      rowId || `${hospital}|${admissionDate}|${dischargeDate}`
    );
    const periodLabel = admissionDate && dischargeDate ? `${admissionDate}~${dischargeDate}` : admissionDate;
    const title = hospital ? `\u51FA\u9662\u75C5\u6458 \u2014 ${hospital} ${periodLabel}` : `\u51FA\u9662\u75C5\u6458 ${periodLabel}`;
    const resource = {
      resourceType: "DocumentReference",
      id,
      meta: {
        versionId: "1",
        source: "nhi-fhir-bridge/scraper",
        // bridge-namespaced tag mirrors v0.12.3 nhi-source-channel and
        // v0.15 nhi-imaging-row patterns. Informational; FHIR R4 spec
        // says applications not aware of the tag system MUST ignore it.
        tag: [
          {
            system: "http://nhi-fhir-bridge/nhi-source",
            code: "ihke3309-getxml"
          }
        ]
      },
      status: "current",
      type: {
        coding: [
          {
            system: LOINC2,
            code: LOINC_DISCHARGE_SUMMARY,
            display: LOINC_DISCHARGE_SUMMARY_DISPLAY
          }
        ],
        text: "\u51FA\u9662\u75C5\u6458"
      },
      category: [
        {
          coding: [
            {
              system: DOC_CATEGORY_SYSTEM,
              code: "clinical-note",
              display: "Clinical Note"
            }
          ]
        }
      ],
      subject: { reference: `Patient/${patientId}` },
      content: [
        {
          attachment: buildAttachment(html, title)
        }
      ],
      context: {
        encounter: [{ reference: `Encounter/${encounterId}` }],
        period: {
          start: admissionDate,
          ...dischargeDate ? { end: dischargeDate } : {}
        }
      }
    };
    if (hospital) {
      resource.custodian = { display: hospital };
    }
    if (rowId) {
      resource.identifier = [{ system: "http://nhi-fhir-bridge/nhi-inpatient-row", value: rowId }];
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/immunization.ts
  function mapImmunization(raw, patientId) {
    const vaccineName = (raw.vaccine_name ?? "").trim();
    const date = (raw.date ?? "").trim();
    if (!vaccineName || !date) return null;
    const resource = {
      resourceType: "Immunization",
      // Stable id uses date + vaccine name + lot — same vaccine same day
      // with the same lot collapses (NHI rare edge case); different lots
      // would be distinct Immunizations.
      id: stableId(patientId, vaccineName, date, raw.lot_number ?? ""),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      status: "completed",
      vaccineCode: {
        // No terminology coding — NHI gives Chinese name only. SMART
        // apps render .text for both patient and clinical views (the
        // v0.8.0 bilingual fallback contract: if English absent, text
        // is the only display).
        text: vaccineName
      },
      patient: { reference: `Patient/${patientId}` },
      occurrenceDateTime: `${date}T00:00:00+08:00`
    };
    const lotNumber = (raw.lot_number ?? "").trim();
    if (lotNumber) {
      resource.lotNumber = lotNumber;
    }
    const hospital = (raw.hospital ?? "").trim();
    if (hospital) {
      resource.performer = [{ actor: { display: hospital } }];
    }
    const source = (raw.source ?? "").trim();
    if (source) {
      resource.note = [{ text: `\u4F86\u6E90: ${source}` }];
    }
    return resource;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/medication.ts
  var EN_CHUNK_G = /[A-Z][A-Z0-9.%/\-"'\s]{3,}/g;
  function canonicalDrugKey(name) {
    const s = (name ?? "").toUpperCase();
    const chunks = [...s.matchAll(EN_CHUNK_G)].map((m) => m[0]);
    if (chunks.length === 0) {
      return (name ?? "").trim().toLowerCase();
    }
    let longest = chunks.reduce((a, b) => b.length > a.length ? b : a).trim();
    for (const sep of [" - ", " \u2013 ", " / "]) {
      if (longest.includes(sep)) {
        longest = longest.split(sep)[0];
      }
    }
    return longest.replace(/\s+/g, " ").trim().toLowerCase();
  }
  function medStatus(authoredIso, durationDays) {
    if (!authoredIso) return "completed";
    const datePart = String(authoredIso).slice(0, 10);
    const parsed = /* @__PURE__ */ new Date(`${datePart}T00:00:00Z`);
    if (Number.isNaN(parsed.getTime())) return "completed";
    let days;
    if (durationDays === null || durationDays === void 0 || durationDays === "") {
      days = null;
    } else {
      const n = Number.parseInt(String(durationDays), 10);
      days = Number.isFinite(n) ? n : null;
    }
    if (days === null) days = 90;
    const end = new Date(parsed.getTime());
    end.setUTCDate(end.getUTCDate() + days);
    const today = /* @__PURE__ */ new Date();
    today.setUTCHours(0, 0, 0, 0);
    return end >= today ? "active" : "completed";
  }
  function mapMedicationRequest(raw, patientId) {
    const drugName = (raw.drug_name ?? "").trim();
    if (!drugName) return null;
    const idParts = [canonicalDrugKey(drugName), String(raw.date ?? "")];
    const hospKey = String(raw.hospital ?? "").trim();
    const qtyKey = String(raw.quantity ?? "").trim();
    const dxKey = String(raw.indication_code ?? "").trim();
    if (hospKey) idParts.push(`h:${hospKey}`);
    if (qtyKey) idParts.push(`q:${qtyKey}`);
    if (dxKey) idParts.push(`d:${dxKey}`);
    const medId = stableId(patientId, ...idParts);
    const drugCode = (raw.code ?? "").trim();
    const coding = {
      system: drugCode ? NHI_DRUG_CODE : HIS_LOCAL_MEDICATION_CODE,
      code: drugCode || drugName,
      display: drugName
    };
    const drugNameZh = (raw.drug_name_zh ?? "").trim() || drugName;
    const resource = {
      resourceType: "MedicationRequest",
      id: medId,
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      status: medStatus(raw.date ?? "", raw.duration_days),
      intent: "order",
      medicationCodeableConcept: {
        coding: [coding],
        text: drugNameZh
      },
      subject: { reference: `Patient/${patientId}` }
    };
    if (raw.date) {
      resource.authoredOn = `${raw.date}T00:00:00+08:00`;
    }
    const courseOfTherapy = (raw.course_of_therapy ?? "").trim();
    if (courseOfTherapy === "continuous") {
      resource.courseOfTherapyType = {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/medicationrequest-course-of-therapy",
            code: "continuous",
            display: "Continuous long term therapy"
          }
        ],
        text: "Continuous long term therapy"
      };
    }
    const drugClass = (raw.drug_class ?? "").trim();
    const drugClassZh = (raw.drug_class_zh ?? "").trim();
    if (drugClass || drugClassZh) {
      const cat = {};
      if (drugClass) cat.coding = [{ display: drugClass }];
      cat.text = drugClassZh || drugClass;
      resource.category = [cat];
    }
    const hospital = (raw.hospital ?? "").trim();
    if (hospital) {
      resource.requester = { display: hospital };
    }
    const dosage = {};
    const parts = [];
    for (const k of ["dose", "unit", "frequency"]) {
      if (raw[k]) parts.push(String(raw[k]));
    }
    if (parts.length > 0) {
      dosage.text = parts.join(" ");
    } else if (raw.dosage_text) {
      const t = String(raw.dosage_text).trim();
      if (t) dosage.text = t;
    } else {
      const qtyRaw2 = raw.quantity;
      const qtyNum = qtyRaw2 !== null && qtyRaw2 !== void 0 && qtyRaw2 !== "" ? Number.parseFloat(String(qtyRaw2).replace(/,/g, "")) : Number.NaN;
      const daysNum = Number.parseInt(String(raw.duration_days ?? 0), 10);
      if (Number.isFinite(qtyNum) && qtyNum > 0 && Number.isFinite(daysNum) && daysNum > 0) {
        const qtyStr = Number.isInteger(qtyNum) ? String(qtyNum) : String(qtyNum);
        const perDay = qtyNum / daysNum;
        const perDayStr = Number.isInteger(perDay) ? String(perDay) : Number.parseFloat(perDay.toFixed(2)).toString();
        dosage.text = `\u7D66\u85E5\u7E3D\u91CF ${qtyStr}\uFF0C\u7D66\u85E5\u65E5\u6578 ${daysNum} \u5929\uFF08\u5E73\u5747\u6BCF\u65E5 ${perDayStr}\uFF09`;
      }
    }
    if (raw.route) {
      dosage.route = {
        coding: [{ system: "http://snomed.info/sct", display: raw.route }]
      };
    }
    if (Object.keys(dosage).length > 0) {
      resource.dosageInstruction = [dosage];
    }
    const dr = {};
    const qtyRaw = raw.quantity;
    if (qtyRaw !== null && qtyRaw !== void 0 && qtyRaw !== "") {
      const qtyNum = Number.parseFloat(String(qtyRaw).replace(/,/g, ""));
      if (Number.isFinite(qtyNum)) {
        dr.quantity = { value: qtyNum };
      }
    }
    if (raw.duration_days) {
      const days = Number.parseInt(String(raw.duration_days), 10);
      if (Number.isFinite(days)) {
        dr.expectedSupplyDuration = {
          value: days,
          unit: "days",
          system: "http://unitsofmeasure.org",
          code: "d"
        };
      }
    }
    const endDate = (raw.end_date ?? "").trim();
    if (raw.date && endDate && endDate !== raw.date) {
      dr.validityPeriod = {
        start: `${raw.date}T00:00:00+08:00`,
        end: `${endDate}T23:59:59+08:00`
      };
    }
    if (Object.keys(dr).length > 0) {
      resource.dispenseRequest = dr;
    }
    const indication = (raw.indication ?? "").trim();
    const indicationZh = (raw.indication_zh ?? "").trim();
    const indicationCode = (raw.indication_code ?? "").trim();
    if (indication || indicationZh || indicationCode) {
      const rc = {};
      if (indicationCode) {
        rc.coding = [
          {
            system: ICD_10_CM,
            code: normalizeIcd10Cm(indicationCode),
            display: indication || indicationZh || indicationCode
          }
        ];
      }
      const nameZh = indicationZh || indication;
      if (nameZh) {
        rc.text = indicationCode ? `${indicationCode} ${nameZh}`.trim() : nameZh;
      }
      resource.reasonCode = [rc];
    }
    const encounterClass = (raw.encounter_class ?? "").trim();
    if (encounterClass) resource.__nhiVisitClass = encounterClass;
    return resource;
  }
  function mapMedicationsDedup(rawItems, patientId) {
    const byKey = /* @__PURE__ */ new Map();
    for (const item of rawItems) {
      if (!item || typeof item !== "object") continue;
      const drugName = (item.drug_name ?? "").trim();
      if (!drugName) continue;
      const datePart = (item.date ?? "").slice(0, 10);
      const hospKey = String(item.hospital ?? "").trim();
      const qtyKey = String(item.quantity ?? "").trim();
      const dxKey = String(item.indication_code ?? "").trim();
      const key = `${datePart}|${canonicalDrugKey(drugName)}|${hospKey}|${qtyKey}|${dxKey}`;
      const existing = byKey.get(key);
      if (existing === void 0) {
        byKey.set(key, item);
      } else {
        if (cjkChars(drugName) < cjkChars(existing.drug_name ?? "")) {
          byKey.set(key, item);
        }
      }
    }
    const out = [];
    for (const item of byKey.values()) {
      const m = mapMedicationRequest(item, patientId);
      if (m !== null) out.push(m);
    }
    return out;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/analyte-aliases.ts
  var CELL_ALIASES = {
    NEUTROPHIL: {
      common: [
        "neutrophilic segment",
        "neutrophil",
        "neutrophils",
        "segmented",
        "segment",
        "segments",
        "seg",
        "seg.",
        "neut",
        "neut.",
        "neut. seg",
        "neut seg",
        "\u55DC\u4E2D\u6027\u767D\u8840\u7403",
        "\u55DC\u4E2D\u6027\u7403",
        "\u4E2D\u6027\u7403",
        "\u591A\u6838\u7403",
        "\u591A\u5F62\u6838\u7403",
        "neutrophilic segment(\u55DC\u4E2D\u6027\u767D\u8840\u7403)",
        "neutrophil(\u55DC\u4E2D\u6027\u767D\u8840\u7403)",
        "neutrophils(\u55DC\u4E2D\u6027\u767D\u8840\u7403)",
        "segment(\u55DC\u4E2D\u6027\u767D\u8840\u7403)"
      ],
      scoped: { "16003C": ["neu", "neu-pleural", "sediment-neu"] }
    },
    LYMPHOCYTE: {
      common: [
        "lymphocyte",
        "lymphocytes",
        "lymph cell",
        "lymph",
        "lymph.",
        "lym",
        "lym.",
        "\u6DCB\u5DF4\u767D\u8840\u7403",
        "\u6DCB\u5DF4\u7403",
        "\u6DCB\u5DF4\u7D30\u80DE",
        "\u6DCB\u5DF4",
        "lymphocytes(\u6DCB\u5DF4\u767D\u8840\u7403)",
        "lymphocyte(\u6DCB\u5DF4\u767D\u8840\u7403)"
      ],
      scoped: { "16008C": ["lymohocyte"] }
      // known LIS typo (missing 'p'), real 北榮 P20105
    },
    MONOCYTE: {
      common: [
        "monocyte",
        "monocytes",
        "mono",
        "mono.",
        "\u55AE\u6838\u767D\u8840\u7403",
        "\u55AE\u6838\u7403",
        "monocytes(\u55AE\u6838\u767D\u8840\u7403)",
        "monocyte(\u55AE\u6838\u767D\u8840\u7403)"
      ]
    },
    EOSINOPHIL: {
      common: [
        "eosinophil",
        "eosinophils",
        "eos",
        "eos.",
        "\u55DC\u9178\u6027\u767D\u8840\u7403",
        "\u55DC\u9178",
        "\u55DC\u4F0A\u7D05\u6027\u767D\u8840\u7403",
        "\u55DC\u4F0A\u7D05",
        "eosinophils(\u55DC\u9178\u6027\u767D\u8840\u7403)",
        "eosinophil(\u55DC\u9178\u6027\u767D\u8840\u7403)"
      ],
      scoped: { "16003C": ["eosin", "sediment-eosin"] }
    },
    BASOPHIL: {
      common: [
        "basophil",
        "basophils",
        "baso",
        "baso.",
        "\u55DC\u9E7C\u6027\u767D\u8840\u7403",
        "\u55DC\u9E7C",
        "basophils(\u55DC\u9E7C\u6027\u767D\u8840\u7403)",
        "basophil(\u55DC\u9E7C\u6027\u767D\u8840\u7403)"
      ]
    },
    // Macrophage & histiocyte — in serous-fluid differentials LOINC MERGES
    // monocytes+macrophages into one code (e.g. Pleural 35021-5), so a fluid panel
    // routes BOTH the MONOCYTE and MACROPHAGE tokens to that same code.
    MACROPHAGE: {
      common: ["macrophage", "macrophages", "\u5DE8\u566C\u7D30\u80DE", "histiocyte", "\u7D44\u7E54\u7403"],
      scoped: { "16003C": ["m&h", "sediment-m&h", "m & h"] }
    },
    // Reactive / variant / atypical lymphocyte — distinct from plain lymphocyte
    // (own LOINC, e.g. Pleural 33370-8 Variant lymphocytes/Leukocytes).
    REACTIVE_LYMPHOCYTE: {
      common: [
        "reactive lymphocyte",
        "reactive lymphocytes",
        "variant lymphocyte",
        "variant lymphocytes",
        "atypical lymphocyte",
        "atypical lymphocytes",
        // 台大癌醫 CBC differential shorthand. Separator-insensitive matching
        // also covers Aty.Lym.(STAT), Aty-Lym and Aty_Lym from this one alias.
        // Keep it on the central analyte token so Blood/Pleural contexts choose
        // their own System-specific LOINC without duplicating private regexes.
        "aty lym",
        "atyp lym",
        "atypical lympho",
        "\u53CD\u61C9\u6027\u6DCB\u5DF4\u7403",
        "\u7570\u578B\u6DCB\u5DF4\u7403",
        "\u975E\u5178\u578B\u6DCB\u5DF4\u7403"
      ],
      scoped: { "16003C": ["react lympho", "react. lympho"] }
    },
    // ── Cell counts (cross-specimen: Blood / Synovial / Pleural / … each own LOINC) ──
    LEUKOCYTE_COUNT: {
      common: ["leukocyte count", "\u767D\u8840\u7403\u8A08\u6578"],
      scoped: { "16003C": ["wbc", "wbc-pleural", "leukocyte", "leukocytes", "\u767D\u8840\u7403"] }
    },
    ERYTHROCYTE_COUNT: {
      common: ["erythrocyte count", "\u7D05\u8840\u7403\u8A08\u6578"],
      scoped: {
        "16003C": ["rbc", "rbc count", "rbc-pleural", "erythrocyte", "erythrocytes", "\u7D05\u8840\u7403"]
      }
    },
    // Total nucleated cells — serous fluids (pleural/ascites/pericardial) report
    // TNC instead of a WBC count (NHI/lab convention).
    NUCLEATED_CELL_COUNT: {
      common: [
        "nucleated cell count",
        "total nucleated cell count",
        "total nuclear cell count",
        "total nuclear cell c",
        "tnc",
        "\u6709\u6838\u7D30\u80DE\u8A08\u6578"
      ]
    },
    // ── Physical characteristics (cross-specimen: Urine / Synovial / Pleural …) ──
    COLOR: { common: ["color", "colour", "\u8272", "\u984F\u8272"] },
    APPEARANCE: { common: ["appearance", "\u5916\u89C0", "turbidity", "\u6FC1\u5EA6", "clarity"] },
    PH: { common: ["ph", "\u9178\u9E7C\u5EA6", "\u9178\u9E7C\u503C"] },
    SPECIFIC_GRAVITY: {
      common: ["specific gravity", "sp.gravity", "sp gravity", "sp.gr", "\u6BD4\u91CD"]
    }
  };
  function buildRoutes(tokenToLoinc, opts = {}) {
    const out = {};
    for (const [token, loinc] of Object.entries(tokenToLoinc)) {
      const entry = CELL_ALIASES[token];
      if (!entry) throw new Error(`buildRoutes: unknown analyte token "${token}"`);
      if (opts.validLoinc && !opts.validLoinc(loinc)) {
        throw new Error(`buildRoutes: LOINC "${loinc}" for ${token} is not in LOINC_DISPLAY`);
      }
      const variants = [...entry.common, ...opts.scope ? entry.scoped?.[opts.scope] ?? [] : []];
      for (const v of variants) {
        const key = v.toLowerCase();
        if (key in out && out[key] !== loinc) {
          throw new Error(`buildRoutes: alias "${key}" maps to both ${out[key]} and ${loinc}`);
        }
        out[key] = loinc;
      }
    }
    return out;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/loinc-tables.ts
  var NHI_TO_LOINC = {
    // ── Haematology ────────────────────────────────────
    "08002C": "6690-2",
    // 白血球計數 — Leukocytes #/vol Blood Auto
    "08003C": "718-7",
    // 血色素檢查 — Hemoglobin Mass/vol Blood
    "08006C": "777-3",
    // 血小板計數 — Platelets #/vol Blood Auto
    // 08013C 白血球分類計數 is a standalone differential order, not a
    // complete CBC-with-differential panel: real exports contain only the 5–6
    // differential members and omit the CBC members required by 57021-8. Keep
    // the members in PANEL_LOINC_MAP, but leave the ordinary DR NHI-code-only.
    // The independently verified exact 08011C+08013C merge still assigns
    // 57021-8 in observation.ts when every required CBC+diff member is present.
    "08128B": "47286-0",
    // 骨髓細胞形態判讀合併細胞分類計數 — panel; members route by display
    // ── Chemistry ─────────────────────────────────────
    "09011C": "17861-6",
    // 鈣 — Calcium Mass/vol S/P
    "09015C": "2160-0",
    // 肌酸酐、血 — Creatinine Mass/vol S/P
    "09016C": "2161-8",
    // 肌酐、尿 — Creatinine Mass/vol Urine
    "09025C": "1920-8",
    // AST/GOT — Aspartate aminotransferase Act S/P
    "09026C": "1742-6",
    // ALT/GPT — Alanine aminotransferase Act S/P
    "09029C": "1975-2",
    // 膽紅素總量 — Bilirubin total Mass/vol S/P
    "09030C": "1968-7",
    // 直接膽紅素 — Bilirubin direct Mass/vol S/P
    "09033C": "2532-0",
    // 乳酸脫氫脢 — LDH Activity S/P
    "09038C": "1751-7",
    // 白蛋白 — Albumin Mass/vol S/P
    "09138C": "35672-5",
    // 直接/總膽紅素比值
    // 12112B 白蛋白(免疫比濁法/nephelometry) → method-specific 101198-0 "Albumin
    // [Mass/volume] in Serum or Plasma by Nephelometry" (loinc.org-verified ACTIVE;
    // official NHI ConceptMap also maps 12112B→101198-0). Method axis now preserved
    // vs the old methodless 1751-7. Non-serum rows still reroute: 101198-0 is a
    // SERUM_TO_FLUID_CHEM key (→ CSF 1746-7 / pleural / peritoneal / body-fluid) and
    // albuminUrineLoincFix handles urine (2026-07-13 Finding 3).
    "12112B": "101198-0",
    // 白蛋白(免疫比濁法) — Albumin Mass/vol S/P by Nephelometry
    "24007B": "1995-0",
    // 血漿游離鈣 — Calcium ionized Moles/vol S/P
    // ── Hormones ──────────────────────────────────────
    "09121C": "2986-8",
    // 睪丸酯醇免疫分析 — Testosterone Mass/vol S/P
    // 2026-06-14 audit: NHI name "睪固酮/睪丸脂醇" carries no "free/游離" →
    // unqualified testosterone = TOTAL. Was 2991-8 (Testosterone *Free*).
    "27021B": "2986-8",
    // 睪丸脂醇放射免疫分析 — Testosterone total [Mass/vol] S/P
    // 09125C / 09127C corrected after dual-reviewer audit — the earlier
    // values (3016-3 was TSH, 10501-5 was LH) were just wrong copy-
    // pastes. Source for the new values: TWNHIFHIR PAS ConceptMap.
    "09125C": "83098-4",
    // 濾泡刺激素免疫分析 — Follitropin (FSH) Immunoassay S/P
    "09127C": "83096-8",
    // 二氫基春情素免疫分析 — Estradiol Immunoassay S/P
    // ── Tumor markers ─────────────────────────────────
    "12007C": "1834-1",
    // α-胎兒蛋白 (AFP) — Mass/vol S/P
    "27049C": "1834-1",
    // 甲-胎兒蛋白 (AFP, RIA)
    "12081C": "83112-3",
    // PSA (EIA/LIA) — Mass/vol S/P Immunoassay
    "12198C": "83113-1",
    // Free PSA — Mass/vol S/P Immunoassay
    "27052C": "2857-1",
    // 攝護腺特異抗原 (PSA) — Mass/vol S/P
    "27083B": "10886-0",
    // 游離PSA (RIA)
    // CA-family + CEA tumor markers (H12113 audit 2026-07-08). Each NHI code
    // carried EXACTLY ONE marker display with U/mL (ng/mL for CEA) in the bundle —
    // single-analyte tumor-marker codes (not panels), same shape as the 12007C/
    // 27049C AFP pair above (chapter-27 = alternate billing of the chapter-12
    // marker). LOINCs WebFetch-verified loinc.org 2026-07-08 (all ACnc, Ser/Plas):
    "12077C": "10334-1",
    // CA-125 — Cancer Ag 125 [U/vol] S/P
    "27053C": "10334-1",
    // CA-125 (alt billing code)
    "12078C": "6875-9",
    // CA 15-3 — Cancer Ag 15-3 [U/vol] S/P
    "27055C": "24108-3",
    // CA 19-9 — Cancer Ag 19-9 [U/vol] S/P
    "27050C": "2039-6",
    // CEA (alt billing of 12021C) — Mass/vol S/P
    // 12052B β2-微球蛋白 — previously mapped to 10873-8 which is actually
    // 'Beta-2-Microglobulin [Mass/time] in 24 hour Urine' (timed urine
    // collection, verified loinc.org/10873-8/). Taiwan 12052B billing is
    // typically a serum order; 1952-1 is the verified serum-or-plasma LOINC
    // (Component=Beta-2-Microglobulin, Property=MCnc) — loinc.org/1952-1/.
    "12052B": "1952-1",
    // β2-microglobulin — Mass/vol S/P
    // ── Immunology / proteins ─────────────────────────
    // 90991-1 additionally requires M-protein isotype by MALDI-TOF and is not the
    // ordinary SPE panel. 24351-9 is the generic serum/plasma electrophoresis panel;
    // urine/CSF reports reroute to 34539-7/24352-7 in observation.ts.
    "09065B": "24351-9",
    // 蛋白電泳分析 — Protein electrophoresis panel, serum/plasma
    // 12028B (免疫擴散法) / 12029B (免疫比濁法) IgM — previously both mapped to
    // LOINC 14002-0 which is actually 'IgM [Units/volume] in Cord blood'
    // (neonatal specimen, verified loinc.org/14002-0/); that was removed in
    // the 2026-05-19 audit. v0.13.5 (SMART app dev report 2026-06-03, Bug B):
    // now mapped to 2472-9, verified as 'IgM [Mass/volume] in Serum or Plasma'
    // (Component=IgM, Property=MCnc, System=Ser/Plas, Method NULL → method-
    // independent, covers both immunodiffusion + nephelometry) — loinc.org/
    // 2472-9/ 2026-06-03. Symmetric with IgG 12025B→2465-3, IgA 12027B→2458-8.
    "12028B": "2472-9",
    // IgM 免疫擴散法 — Mass/vol S/P
    "12029B": "2472-9",
    // IgM 免疫比濁法 — Mass/vol S/P
    // 2026-06-14 audit: was 95801-7 = "Ig light chains.free and IFE panel -
    // *Urine*" (wrong specimen + free-LC panel). Serum immunofixation →
    // 25700-6 Immunofixation for Serum or Plasma (Nom, loinc.org-verified).
    "12103B": "25700-6",
    // 免疫電泳分析 — Immunofixation for Serum/Plasma
    "12160B": "15189-4",
    // IgG κ/λ
    "12171B": "17351-8",
    // 抗嗜中性球細胞質抗體 (ANCA)
    "12204B": "80721-4",
    // 白血球表面標記 — T/B/NK lymphocyte subsets panel, Blood
    // (sub-rows routed via DISPLAY_FIRST_CODES + PANEL_LOINC_MAP since
    // v0.10.0; this entry is fallback for empty display)
    "25013B": "44596-5",
    // 螢光切片檢查
    // ── Hepatitis ─────────────────────────────────────
    "14030C": "5195-3",
    // HBsAg
    "14031C": "5195-3",
    // HBsAg
    "14032C": "5196-1",
    // HBsAg qualitative IA
    // 2026-07-08 BC肝 cumulative-report gap: 14033C/14037C were emitted with
    // only NHI coding, so LOINC-pivoted apps could not classify them. LOINCs
    // verified at loinc.org 2026-07-08:
    //   5193-8   Anti-HBs, ACnc, Ser/Plas, Qn, IA; example unit mIU/mL (= IU/L)
    //   13952-7  Anti-HBc, PrThr, Ser/Plas, Ord, IA; Positive/Negative answers
    //   22316-4  Anti-HBc, ACnc, Ser, Qn; arbitrary units / COI-like numeric
    //            results. 14037C defaults to qualitative; observation.ts
    //            antiHbcLoincFix() promotes numeric/COI rows to 22316-4.
    "14033C": "5193-8",
    // Anti-HBs — Units/vol S/P by Immunoassay
    "14035C": "13954-3",
    // HBeAg — qualitative S/P by Immunoassay
    "14036C": "13953-5",
    // Anti-HBe — qualitative S/P by Immunoassay
    "14037C": "13952-7",
    // Anti-HBc — qualitative default; COI/numeric → 22316-4
    "14051C": "13955-0",
    // HCV Ab
    "27033C": "5197-9",
    // HBsAg RIA
    // ── Pathology / cytology / IHC ────────────────────
    // 12195B Her-2/neu — LEFT UNMAPPED (2026-06-14). Prior 18474-7 is HER2
    // *IHC* (protein, Immune stain); the catalog comment claimed *ISH* (gene
    // amplification) — a different LOINC. Cannot confirm which NHI 12195B
    // bills (no row in the probe patient). Per "uncertain → no LOINC" rule,
    // falls through to NHI-code-only + raw display rather than risk a
    // method-wrong code. Re-add once the NHI item name (ISH vs IHC) is known.
    "27061B": "14130-9",
    // 動情激素接受體 (ER)
    "27062B": "10861-3",
    // 黃體激素接受體 (PR)
    // 30103B is a coarse PD-L1 IHC billing code. It does NOT identify clone
    // (22C3/SP263/28-8/...) or result scale (Presence/TPS/CPS/%). The old 83052-1
    // mapping falsely asserted clone 22C3 + Presence for every row. Keep it
    // NHI-code-only until both clone and score/scale can be resolved from the row.
    // ── Audiology / pulmonary ─────────────────────────
    // 2026-06-13 LOINC audit: was 24341-0 (an arterial-blood-gas PANEL, wrong).
    // 19911-7 = Diffusion capacity.carbon monoxide — the panel's primary
    // analyte (DLCO); used only as the panel-level DR LOINC / Step-C fallback.
    "17009B": "19911-7",
    // 一氧化碳肺瀰散量 — DLCO panel (sub-rows routed via
    // DISPLAY_FIRST_CODES + PANEL_LOINC_MAP since v0.10.0)
    // 22001C 純音聽力檢查 — previously mapped to LOINC 45498-3 which is
    // actually 'Hearing [Minimum Data Set]' (an MDS long-term-care survey
    // item, NOT a pure-tone audiometry measurement; verified loinc.org/
    // 45498-3/ 2026-05-29). Wrong analyte type entirely. Leaving unmapped;
    // falls through to NHI-code-only coding. v0.12.0 audit.
    // 22015B 詐聾聽力檢查 — same wrong 45498-3 mapping. Removed.
    // 22025B 自記聽力檢查 — previously mapped to LOINC 46530-2 which is
    // actually 'Sensory status - hearing and ability to understand spoken
    // language [OASIS]' (an OASIS home-health survey item, verified
    // loinc.org/46530-2/ 2026-05-29). Wrong type. Leaving unmapped.
    // ═════════════════════════════════════════════════════════════════
    // SUPPLEMENTAL (not in PAS ConceptMap — hand-curated from common
    // NHI codes seen in 健康存摺. LOINC verified against loinc.org
    // canonical names. Method-specific codes (e.g. hs-CRP) pick the
    // specific LOINC; general-method codes pick the most common form.
    // If 健保署 publishes an authoritative broader ConceptMap later,
    // replace this section in one pass.
    // ═════════════════════════════════════════════════════════════════
    // ── Glucose / HbA1c ───────────────────────────────
    "09005C": "1558-6",
    // 空腹血糖 (Glu-AC) — Fasting glucose Mass/vol S/P
    "09140C": "2345-7",
    // 血糖-餐後/隨機 — Glucose Mass/vol S/P (general)
    "09006C": "4548-4",
    // 醣化血紅素 (HbA1c) — Hemoglobin A1c/Hgb.total Blood
    // ── Renal / electrolytes ─────────────────────────
    "09002C": "3094-0",
    // BUN — Urea nitrogen Mass/vol S/P
    "09013C": "3084-1",
    // Uric Acid — Urate Mass/vol S/P
    "09021C": "2951-2",
    // Na — Sodium Moles/vol S/P (dual-specimen; urine → 2955-3 via urineElectrolyteLoincFix)
    "09022C": "2823-3",
    // K  — Potassium Moles/vol S/P (dual-specimen; urine → 2828-2)
    "09023C": "2075-0",
    // Cl — Chloride Moles/vol S/P (dual-specimen; urine → 2078-4)
    "09024C": "2028-9",
    // CO2 — Carbon dioxide Moles/vol S/P
    "09012C": "2777-1",
    // Inorganic P — Phosphate Mass/vol S/P
    "09046B": "19123-9",
    // Mg — Magnesium Mass/vol S/P
    // ── Lipid panel ───────────────────────────────────
    "09001C": "2093-3",
    // T-Cholesterol — Cholesterol Mass/vol S/P
    "09004C": "2571-8",
    // TG — Triglyceride Mass/vol S/P
    "09043C": "2085-9",
    // HDL — HDL cholesterol Mass/vol S/P
    // 09044C is used for both direct and calculated LDL. Methodless is the safe
    // default; observation.ts promotes explicit direct/calculated rows.
    "09044C": "2089-1",
    // LDL — LDL cholesterol Mass/vol S/P, method unspecified
    // ── Liver function ────────────────────────────────
    "09027C": "6768-6",
    // ALK-P — Alkaline phosphatase Activity S/P
    "09031C": "2324-2",
    // γ-GT — Gamma glutamyl transferase Activity S/P
    "09035C": "50190-8",
    // Iron/Fe + TIBC/UIBC/saturation panel — members route by display
    // 09037C 血氨 (Ammonia) — previously mapped to LOINC 1827-5 which is
    // actually 'Alpha 1 antitrypsin MS [Mass/volume] in Serum or Plasma'
    // (verified loinc.org/1827-5/); that was removed in the 2026-05-19 audit.
    // v0.13.5 (SMART app dev report 2026-06-03, Bug B): now mapped. NOTE the
    // bug report's suggested 1827-1 does NOT exist in LOINC (verified
    // loinc.org/1827-1/ → "code does not exist"; likely a typo off the old
    // 1827-5). Ammonia is ALWAYS plasma (never serum — NH3 analytic
    // stability), so System=Plas is settled; mass-vs-molar depends on the
    // lab's reported unit:
    //   22763-7  Ammonia [Mass/volume] in Plasma  (MCnc, µg/dL — default)
    //   16362-6  Ammonia [Moles/volume] in Plasma (SCnc, µmol/L)
    // Both verified at loinc.org 2026-06-03. Default is the µg/dL mass form
    // (台灣傳統 / 台北榮總 慣用單位); observation.ts ammoniaLoincFix() switches
    // to the molar LOINC when the row's unit is µmol/L, so the LOINC's
    // property class always matches the shipped unit (avoids the v0.12.0
    // Free T4 LOINC↔unit-mismatch class).
    "09037C": "22763-7",
    // 血氨 (Ammonia) — Mass/vol Plasma; molar unit → 16362-6 via ammoniaLoincFix
    "09064C": "3040-3",
    // Lipase — Activity S/P
    // Taiwan hospital catalogs commonly report mmol/L; 09059B is also reused for
    // CSF. Molar serum/plasma is the default, with unit/specimen rerouting in
    // lactateLoincFix(). Mass-unit rows return to 14118-4.
    "09059B": "2524-7",
    // Lactate — Moles/vol S/P; mass/CSF variants resolved post-lookup
    // ── Hematology extras ─────────────────────────────
    "08004C": "4544-3",
    // HCT — Hematocrit volume fraction Blood
    // Reticulocyte 網狀紅血球計數. 4679-7 = "Reticulocytes/Erythrocytes in
    // Blood" (NFr, %, methodless) — matches this "/100 RBC" intent. Was
    // 14196-0 (#/vol, ABSOLUTE), which contradicted the comment; corrected
    // v1.2.9 (WebFetch loinc.org 2026-07-06). NHI 08008C is reported as %;
    // absolute ARC is rare and would surface as a unit/scale outlier.
    "08008C": "4679-7",
    "08010C": "711-2",
    // Eosinophil count — #/vol Blood
    // 2026-06-13: was 24317-0 (DISCOURAGED by loinc.org). 58410-2 is the
    // active replacement — "CBC panel - Blood by Automated count" (CBC WO
    // differential, same semantics; WebFetch-verified). Used as the 08011C
    // panel-level DR LOINC / Step-C fallback.
    "08011C": "58410-2",
    // 全套血液檢查I(八項)— CBC panel (no diff), auto count
    "08026C": "6301-6",
    // PT/INR — INR Platelet poor plasma
    "08036C": "14979-9",
    // APTT — Platelet poor plasma
    // v0.12.0 audit fix: 2692-7 typo; LOINC 2692-7 does NOT exist in the
    // LOINC database (verified loinc.org/2692-7/ → not found, suggests
    // 2692-2). Correct LOINC for serum/plasma osmolality is 2692-2,
    // "Osmolality of Serum or Plasma" (verified loinc.org/2692-2/).
    "08075C": "2692-2",
    // Osmolality — Serum or Plasma
    "08079B": "30240-6",
    // D-dimer — Plt poor plasma
    // ── Coag panel members (kept here as fallback) ────────
    // 08026C PT/INR is a 2-row panel (PT in seconds + INR). Promoted to
    // DISPLAY_FIRST_CODES so per-item displays route via PANEL_LOINC_MAP;
    // this entry is only consumed when the display is empty/unrecognised,
    // in which case INR is the safer default (more clinically tracked).
    // ── Thyroid ───────────────────────────────────────
    // Free T4 has TWO valid LOINCs that differ only in unit-system:
    //   3024-7  Component=Thyroxine.free, Property=MCnc (Mass conc, ng/dL)
    //   14920-3 Component=Thyroxine.free, Property=SCnc (Molar conc, pmol/L)
    // Both are Free T4 — neither is Total T4. Earlier history:
    //   - Original mapping was 3024-7 (correct: matches Taiwan ng/dL labs).
    //   - Commit 9da5e5b changed it to 14920-3 on the premise that 3024-7
    //     was Total T4. That premise was inverted (verified loinc.org/3024-7/
    //     — Component is "Thyroxine.free"); the change introduced a LOINC↔unit
    //     mismatch (molar LOINC paired with a ng/dL value).
    //   - Restoring 3024-7 here so the LOINC's property class (MCnc) matches
    //     the unit field (ng/dL) Taiwan labs ship. See docs/LOINC_AUDIT_2026_05_19.md
    //     section F for full evidence.
    "09106C": "3024-7",
    // Free T4 — Thyroxine (T4) free [Mass/volume] S/P
    "09112C": "3016-3",
    // TSH — Thyrotropin S/P
    "09107C": "3051-0",
    // Free T3 — Triiodothyronine (T3) Free Mass/vol S/P
    // ── Cardiac markers ───────────────────────────────
    // 09099C is a SINGLE NHI code shared by BOTH conventional Troponin I AND
    // high-sensitivity Troponin I (官方品項名「心肌旋轉蛋白I」, 450 點 — web-
    // verified 2026-07-03; no separate hs- code exists). Path A default =
    // 10839-9 (conventional); rows whose display carries an hs marker are
    // promoted to 89579-7 by hsTroponinFix() in observation.ts (rule #7 dual-
    // signal — the code can't distinguish the two, only the display can).
    "09099C": "10839-9",
    // Troponin I (conventional default; hs → 89579-7 via hsTroponinFix)
    "12192C": "33959-8",
    // Procalcitonin — S/P
    // 12193C is shared by BNP and NT-proBNP at Taiwan hospitals. No safe single
    // default: display aliases route BNP→30934-4 and NT-/proBNP→33762-6; a bare or
    // unrecognised row remains NHI-code-only.
    // ── Vitamins / cofactors ──────────────────────────
    "09129C": "2132-9",
    // Vit B12 — Cobalamin Mass/vol S/P
    "09130C": "2284-8",
    // Folate — Mass/vol S/P
    "09113C": "2143-6",
    // Cortisol — Mass/vol S/P
    "12116C": "2276-4",
    // Ferritin — Mass/vol S/P
    // ── Medical-calculator gap fills (2026-07-03) ─────
    // Each NHI code confirmed via web search against hospital lab-code pages
    // (rule #10 — content/scope check) before mapping; no conflict with any
    // existing NHI_TO_LOINC key (grep-verified). All single-analyte codes.
    "09017C": "1798-8",
    // Amylase (血液) — Enzymatic activity/volume S/P
    "09103C": "20448-7",
    // Insulin (Serum) — Units/volume S/P
    "09020C": "2498-4",
    // Serum Iron (Fe) — Mass/volume S/P (distinct from 09035C TIBC)
    "10807B": "5643-2",
    // Ethanol (血中酒精濃度) — Mass/volume S/P
    "10817B": "5643-2",
    // Ethanol (乙醇) — alt NHI code seen at some院所 (tsmh); same analyte
    // 2026-07-03 wave 2 (MDCalc gaps; NHI codes web-verified against hospital
    // lab-code pages, LOINC WebFetch-verified loinc.org — rule #5 + #10):
    "09032C": "2157-6",
    // CK / CPK 肌酸激酶 — Creatine kinase Activity S/P (rhabdo)
    "09071C": "13969-1",
    // CK-MB mass 肌酸激酶MB — Creatine kinase.MB Mass/vol S/P
    "08005C": "30341-2",
    // ESR 紅血球沉降速率 — Erythrocyte Sedimentation Rate Blood
    "09122B": "2731-8",
    // iPTH 副甲狀腺素(RIA) — Parathyrin.intact Mass/vol S/P
    "09122C": "2731-8",
    // iPTH 副甲狀腺素(EIA/LIA) — Parathyrin.intact Mass/vol S/P
    "09010C": "3026-2",
    // Total T4 四碘甲狀腺素(生化法) — Thyroxine (T4) Mass/vol S/P
    // ── Acute phase / inflammation ───────────────────
    // 12015C is the generic NHI CRP order — most clinical contexts in 健保
    // send a regular (not hs-) CRP, so map to 1988-5. If a 院所 specifically
    // bills hs-CRP it will land on a different code (e.g. 12189C).
    "12015C": "1988-5",
    // CRP — C reactive protein Mass/vol S/P
    "12053C": "5048-4",
    // ANA — Antinuclear Ab Titer S/P
    // 12056B 抗粒線體抗體 (AMA) — previously mapped to LOINC 16124-0 which is
    // actually 'Cryptococcus sp Ab [Titer] in Serum' (隱球菌抗體, a fungal
    // serology — verified loinc.org/16124-0/ 2026-06-03). Completely wrong
    // analyte: AMA is the key marker for primary biliary cholangitis (PBC),
    // NOT an infection marker. Bug reported by SMART app dev 2026-06-03
    // (嘉基 12056B, value '1:20(-)' → wrongly classified as 黴菌血清學).
    // 20483-4 verified as the canonical AMA titer LOINC (Component=
    // Mitochondria Ab, Property=Titr, System=Ser, Scale=SemiQn, Method NULL
    // → method-independent, fits the titer value) — loinc.org/20483-4/.
    "12056B": "20483-4",
    // 抗粒線體抗體 (AMA) — Mitochondria Ab [Titer] Serum
    // ── Urinalysis ────────────────────────────────────
    // v0.18.2 (2026-06-09, rule #10): 06012C 尿液一般檢查 is a FULL routine
    // urinalysis PANEL (18 sub-analytes: dipstick + sediment microscopy),
    // NOT a single "Color" test. The old 5778-6 value, combined with 06012C
    // missing from DISPLAY_FIRST_CODES, short-circuited via findLoincDetailed
    // Step A and silently collapsed all 18 sub-rows to 5778-6 "Color of
    // Urine". Now a panel: 06012C ∈ DISPLAY_FIRST_CODES + PANEL_LOINC_MAP
    // (URINALYSIS_ANALYTE_KEYS), so this value is only the Step-C best-effort
    // panel fallback (cleanMatch=false → mis-tag canary stays visible).
    "06009C": "24365-9",
    // 尿沉渣 panel — Urinalysis microscopic panel - Urine sediment
    "06012C": "24356-8",
    // 尿液一般檢查 panel — Urinalysis Macro Panel (fallback)
    // 06013C 尿生化 exports can mix dipstick/macroscopic members with UACR
    // (MALB/CREA/ACR), without the microscopy child required by the complete-UA
    // panel 24356-8. Per strict parent/member semantics, retain the NHI grouping
    // but do not stamp a code-level parent LOINC. Per-member routing below stays.
    // 06001C = 「酸鹼度反應 / PH」standalone pH. INTENTIONALLY NOT MAPPED
    // (see SPECIMEN_AMBIGUOUS_NO_LOINC_CODES below). Being a 06-chapter code
    // does NOT make it urine pH: the SAME code carries body-fluid pH with no
    // specimen marker on the display (real H12113 case: value 8, ref range
    // [7.24][7.4] — a blood/body-fluid pH range, NOT urine ~4.6–8.0). With no
    // per-row specimen evidence we cannot know Urine vs body fluid, so shipping
    // "pH of Urine" (5803-2) would silently mis-specimen the body-fluid rows.
    // Left LOINC-less; downstream can judge from the reference range.
    "07001C": "14563-1",
    // Stool occult blood
    "09134C": "58453-2",
    // iFOBT quantitative — Hemoglobin Mass/vol Stool by IA
    // 12111C 官方 = 微白蛋白 Microalbumin(檢體 Urine,免疫比濁法;彰基/三總規格表 +
    // 健保 275 點,web 查證 2026-07-13)。碼層級 fallback 從尿肌酸酐 2161-8 → 微白蛋白
    // 14957-5「Microalbumin [Mass/volume] in Urine」(loinc.org 查證)。之前誤設 2161-8:
    // 空/未知 display 的 12111C 列會靜默變成尿肌酸酐(語意錯,FHIR validator 抓不到)。
    // 有 display 的列不受影響 —— 12111C ∈ DISPLAY_FIRST_CODES,實際 microalbumin/UACR/
    // creatinine 子列仍由 URINE_BIOCHEM_KEYS(PANEL_LOINC_MAP)按顯示名各自正確路由;
    // 這裡只是「無顯示線索時退回該碼的定義分析物 = 微白蛋白」。09016C(肌酐尿)fallback
    // 維持 2161-8(那才是它的定義分析物)。
    "12111C": "14957-5",
    // Microalbumin Mass/vol Urine（碼定義分析物）
    // ── Serology / immunology ────────────────────────
    "12001C": "5292-8",
    // RPR — Serum/Plasma
    "12021C": "2039-6",
    // CEA — Mass/vol S/P
    "12025B": "2465-3",
    // IgG — Mass/vol S/P
    "12027B": "2458-8",
    // IgA — Mass/vol S/P
    "12031C": "19113-0",
    // IgE — Mass/vol S/P
    "12068C": "8098-6",
    // Thyroglobulin Ab — methodless Units/vol S/P
    // 12069B Cryptococcus Ag — previously mapped to LOINC 5132-6 which is
    // actually 'DNA single strand Ab [Units/volume] in Serum' (anti-ssDNA,
    // lupus serology — verified loinc.org/5132-6/). Completely wrong
    // analyte. Leaving unmapped; falls through to NHI-code-only coding.
    // See docs/LOINC_AUDIT_2026_05_19.md.
    "12079C": "24108-3",
    // CA 19-9 — Mass/vol S/P
    // ── Blood type ────────────────────────────────────
    // v0.11.11 (SMART app dev bug 4 2026-05-29 + loinc.org audit):
    // 882-1 is the COMBINED "ABO and Rh group [Type] in Blood" — its
    // answer list is "O Pos / O Neg / A Pos…AB Neg", not appropriate
    // for ABO-only OR Rh-only rows. Splitting per loinc.org audit:
    //   883-9   ABO group [Type] in Blood              — 11001C ABO
    //   10331-7 Rh [Type] in Blood                     — 11003C Rh(D)
    //   890-4   Antibody screen [Presence] in Blood    — 11004C unchanged
    // Each LOINC verified at loinc.org 2026-05-29 (Component / Property /
    // System / Method confirmed appropriate for standalone analyte).
    "11001C": "883-9",
    // ABO group [Type] in Blood (BLDBK)
    "11003C": "10331-7",
    // Rh [Type] in Blood (BLDBK)
    "11004C": "890-4",
    // 抗體反應 — Antibody screen
    // ── Microbiology cultures ────────────────────────
    // 13007C 細菌培養 — previously mapped to LOINC 14219-0 which is
    // actually 'HTLV I p26 Ab in Serum' (verified at loinc.org). The
    // right family is 6463-4 / 11268-0 (Bacteria identified by aerobe
    // culture) but the source row doesn't tell us specimen — leaving
    // unmapped so we don't lie. Falls through to NHI-code-only coding.
    // 13013C TB Culture — previously mapped to LOINC 31952-5 which is
    // actually 'Rinderpest virus Ag [Presence] in Exudate' (cattle
    // morbillivirus, verified loinc.org/31952-5/). Wrong organism entirely.
    // Leaving unmapped; falls through to NHI-code-only coding. See
    // docs/LOINC_AUDIT_2026_05_19.md.
    "13016B": "600-7",
    // Blood Culture — Bacteria identified in Blood
    // ── Virology ──────────────────────────────────────
    // 14004B CMV IgG — previously mapped to LOINC 7849-3 which is actually
    // 'Taenia solium larva IgM Ab [Presence] in Serum' (pork tapeworm,
    // verified loinc.org/7849-3/). It remains absent from the code-level map
    // because Taiwan hospitals also reuse 14004B for CSF. Explicit serum CMV-IgG
    // rows route to 5124-3 through PANEL_LOINC_MAP; explicit CSF rows are vetoed
    // rather than mislabeled serum.
    "14048B": "7853-5",
    // CMV IgM — Cytomegalovirus IgM Ab [Units/volume] S/P
    //   restored after audit: 14048B previously mapped to 7850-1 which is
    //   'Taenia solium larva Ab' (verified loinc.org/7850-1/). 7853-5
    //   verified as the canonical CMV IgM LOINC (Component=Cytomegalovirus
    //   Ab.IgM, Property=ACnc) — loinc.org/7853-5/.
    // Official NHI naming and hospital catalogs distinguish the two billing
    // codes: 14065C=A and 14066C=B. The previous 14066C→A mapping was an A/B
    // swap. Both are rapid upper-respiratory antigen tests.
    "14065C": "80382-5",
    // 流行性感冒 A 型病毒抗原
    "14066C": "80383-3",
    // 流行性感冒 B 型病毒抗原
    "14084C": "94558-4",
    // SARS-CoV-2 Ag — Respiratory
    // Chapter 12 is NOT a blood-only family. These two billing codes are
    // definitionally urine rapid-antigen tests at Taiwan hospitals.
    "12172C": "77949-6",
    // Streptococcus pneumoniae Ag, urine, rapid IA
    "12191C": "77684-9",
    // Legionella pneumophila serogroup 1 Ag, urine, rapid IA
    // 12184C CMV DNA quant PCR — previously mapped to LOINC 88157-3 which
    // is actually 'Microscopic observation [Identifier] in Semen by Acid
    // fast stain' (semen AFB, verified loinc.org/88157-3/ 2026-05-29).
    // Completely wrong analyte + specimen. The generic billing code remains
    // unmapped, while explicit serum/plasma CMV-DNA rows route to 72493-0 through
    // PANEL_LOINC_MAP. Other organisms/specimens stay NHI-code-only. v1.3.25.
    // ── Mycobacterium / acid-fast ─
    // 13025C 抗酸性濃縮抹片染色檢查 — previously mapped to LOINC 29260-7
    // which is actually 'Monocytes Abnormal [#/volume] in Blood by Manual
    // count' (verified loinc.org/29260-7/ 2026-05-29). That wrong mapping was
    // removed in v0.12.0. v1.4.5 now uses the verified generic-specimen AFB
    // stain member from active LOINC panel 94540-2.
    "13025C": "11545-1",
    // Microscopic observation in Specimen by Acid fast stain
    // 13026C 抗酸菌培養 — previously mapped to LOINC 29553-5 which is
    // actually 'Age calculated' (verified loinc.org/29553-5/ 2026-05-29).
    // That wrong mapping was removed in v0.12.0. v1.4.5 uses the culture member
    // declared by 94540-2. Cross-carried rows are rerouted by the shared
    // row-label/result resolver in observation.ts rather than trusting code alone.
    "13026C": "50941-4"
    // Mycobacterium sp Presence by organism-specific culture
    // ── ABG panel (09041B) ────────────────────────────
    // Intentionally NOT mapped here — 09041B is a panel order that
    // unfolds into many items (pH / pCO2 / pO2 / HCO3 / TCO2 / SBE /
    // ABE / SBC / SAT). Mapping the panel code to "pH" would mis-label
    // every non-pH row that shares this NHI code. Each item is
    // resolved via _LOINC_MAP display-keyword fallback below; 09041B
    // also appears in _DISPLAY_FIRST_CODES so display always wins.
    // ── Body fluid / synovial fluid panel (16008C unfolds; the
    // member items rely on display keywords for specimen-aware
    // LOINCs). Parent code maps to synovial fluid analysis panel. ──
    // 16008C 滑液檢查 — previously mapped to LOINC 33903-6 which is
    // actually 'Ketones [Presence] in Urine' (verified loinc.org).
    // Leaving unmapped; the panel falls through to NHI-coding only
    // and the per-item displays in _LOINC_MAP carry their own LOINCs
    // where known.
  };
  var SPECIMEN_AMBIGUOUS_NO_LOINC_CODES = /* @__PURE__ */ new Set(["06001C"]);
  var DISPLAY_FIRST_CODES = /* @__PURE__ */ new Set([
    "08011C",
    // CBC panel
    "08013C",
    // CBC w/ auto diff panel
    "06009C",
    // 尿沉渣鏡檢 panel — member analyte comes from the row display
    "06012C",
    // 尿液一般檢查 — full routine UA panel (dipstick + microscopy).
    // v0.18.2 (2026-06-09): promoted to fix the silent mis-tag where all 18
    // sub-analytes collapsed to 5778-6 "Color of Urine". Shares the
    // URINALYSIS_ANALYTE_KEYS table with 06013C (see PANEL_LOINC_MAP).
    "06013C",
    // Urinalysis macroscopic panel
    "07009C",
    // Stool routine panel — appearance/ova/occult blood/form/color/RBC/WBC/mucus
    "09015C",
    // Serum creatinine — Taiwan labs report eGFR as a piggyback
    // sub-row on the same Crea billing code. Without panel-mode handling,
    // every row under 09015C (incl. the eGFR one) got LOINC 2160-0
    // (Creatinine), causing SMART apps to display eGFR=33 as CREA=33 mg/dL
    // — an instant fatal-looking false reading (real CREA ~1.94, real eGFR
    // is CKD stage 3a). Bug report 2026-05-27 (Part 2).
    "09041B",
    // ABG panel
    "08128B",
    // Bone-marrow morphology + differential panel
    "09035C",
    // Iron/TIBC workup — Fe/TIBC/UIBC/saturation sub-rows
    "12020C",
    // Generic Mycoplasma Ab code — only explicit IgM rows are mapped
    "12193C",
    // Shared BNP/NT-proBNP billing code — analyte comes from row display
    "12184C",
    // Generic quantitative DNA amplification — organism comes from row display
    "14004B",
    // CMV IgG can be serum or CSF — serum mapping requires row evidence
    "14065C",
    // Influenza A order can contain separate A/B kit result rows
    "14066C",
    // Influenza B order can contain separate A/B kit result rows
    "16003C",
    // Pleural fluid routine analysis panel
    "16008C",
    // Synovial / body-fluid panel
    "08026C",
    // PT/INR — Taiwan labs bill PT (seconds) AND INR under the
    // same 08026C code as two sub-rows. Without panel-mode handling, both
    // collapsed to LOINC 6301-6 (INR). For warfarin monitoring this is
    // patient-safety-adjacent: a trend chart would plot PT seconds (~12)
    // and INR (~2.5) on the same series, or label a PT=12 row as "INR=12"
    // (instantly looks like critical anticoagulation overdose). v0.9.10.
    "08036C",
    // APTT — Taiwan labs bill BOTH "APTT" (seconds, normal ~25-35)
    // AND "Heparin治療範圍參考倍數" / "APTT data/mean" (ratio, normal ~1.0)
    // under the same 08036C code. Without panel-mode handling, both
    // collapsed to LOINC 14979-9 (APTT time, seconds) — the ratio row's
    // value of 1.08 displayed under an APTT-time trend column would read
    // as a fatally low APTT, or scientifically nonsensical seconds unit
    // for a ratio. SMART app dev report 2026-05-29. LOINC verified at
    // loinc.org: 14979-9 Property=Time (seconds), 63561-5 Property=RelTime
    // (actual/normal ratio). v0.11.9.
    // ── CBC component billing codes (v0.9.10, bug report Part 5) ─────
    // These are SINGLE-analyte billing codes (one analyte per code, NOT
    // panels). Why are they here? Hospital LIS labelling errors swap
    // displays across CBC siblings: 嘉基's bundle billed 08004C (HCT)
    // but the row's display text was "HGB" with value 13 g/dL — clearly
    // a hemoglobin measurement mis-billed as HCT, or a label/display
    // swap inside the LIS. Trusting the NHI code returned LOINC 4544-3
    // (HCT) for a hemoglobin row → SMART app's HCT trend column showed
    // 13 (impossible for HCT, normal 30-50%). Promoting these to
    // display-first lets unambiguous display text ("HGB", "HCT", "Hb",
    // "Ht") override the LIS billing-swap. SCOPED to CBC family ONLY —
    // we don't generalize to other single-test codes because outside
    // CBC the display strings are less standardized and the risk of
    // wrong over-ride is higher. v0.9.10 Part 5.
    "08002C",
    // WBC count (Leukocytes)
    "08003C",
    // Hemoglobin
    "08004C",
    // Hematocrit
    "08006C",
    // Platelets
    // ── UACR-workup / microalbumin codes (v0.9.10 Part 6 N2; corrected 2026-07-13) ──
    // 09016C = 肌酐、尿 (urine creatinine); 12111C = 微白蛋白 Microalbumin. Both are
    // DISPLAY_FIRST because a UACR workup bills BOTH legs (microalbumin + urine
    // creatinine, sometimes the ratio) under one code, distinguished only by display
    // text. Without display routing a microalbumin row would inherit the code's
    // fallback LOINC. The two codes' fallbacks differ by their DEFINITIONAL analyte:
    // 09016C → 2161-8 (urine creatinine), 12111C → 14957-5 (urine microalbumin) —
    // NOT 2161-8 (that was the audit bug). See URINE_BIOCHEM_KEYS for the shared
    // analyte map; a CSF-marked 12111C reroutes to CSF albumin 1746-7 in observation.ts.
    "09016C",
    // 肌酐、尿 — urine creatinine billing
    "12111C",
    // 微白蛋白 Microalbumin (shares the UACR display-routing table)
    // ── Specialised panels (v0.10.0 — completing the v0.9.10 TODO list)
    // Same reasoning as CBC umbrella + urine: each billing code unfolds
    // into multiple sub-rows with distinct LOINCs. Previously deferred
    // under TODO(panel) comments in NHI_TO_LOINC; now activated with
    // verified LOINCs.
    "09065B",
    // SPE — albumin/α1/α2/β/γ globulin fractions + A/G ratio
    "12204B",
    // Flow cytometry CD markers — CD3/CD4/CD8/CD19/CD56/ratio
    "17009B"
    // DLCO — DLCO + VA + DLCO/VA
  ]);
  var CBC_COMPONENT_KEYS = {
    // Hemoglobin — variant CJK 血色素 / 血紅蛋白 added v0.11.4 audit
    // (Taiwan medical texts use all three interchangeably).
    hemoglobin: "718-7",
    \u8840\u7D05\u7D20: "718-7",
    \u8840\u8272\u7D20: "718-7",
    \u8840\u7D05\u86CB\u767D: "718-7",
    hgb: "718-7",
    hb: "718-7",
    "hb.": "718-7",
    // Hematocrit (HCT) — Taiwan LIS shortens to "Ht" / "H.t.". The
    // ".ascii" period-separated forms (e.g. "M.C.V.") added v0.11.4 —
    // they bypass \bMCV\b matching because intra-word periods break
    // the word boundary. Key WITHOUT trailing period covers both
    // "M.C.V" and "M.C.V." inputs (trailing period creates a \b on
    // the closing letter, key's regex `\bm\.c\.v\b` matches the "M.C.V"
    // prefix of "M.C.V." just fine).
    hematocrit: "4544-3",
    \u8840\u7403\u5BB9\u7A4D\u6BD4: "4544-3",
    // v0.11.11 (SMART app dev bug 2 + 5 2026-05-29): variants observed
    // in user's v0.11.9 bundle. "血球容積比值測定" was previously
    // matching the global LOINC_MAP fallback to a panel LOINC; "血球比容值"
    // is a sibling phrasing.
    \u8840\u7403\u5BB9\u7A4D\u6BD4\u503C: "4544-3",
    \u8840\u7403\u5BB9\u7A4D\u6BD4\u503C\u6E2C\u5B9A: "4544-3",
    \u8840\u7403\u6BD4\u5BB9\u503C: "4544-3",
    \u8840\u7403\u6BD4\u5BB9\u503C\u6E2C\u5B9A: "4544-3",
    \u8840\u7403\u6BD4\u5BB9: "4544-3",
    \u8840\u6BD4\u5BB9: "4544-3",
    \u7D05\u8840\u7403\u5BB9\u7A4D: "4544-3",
    // alt phrasing — RBC volume = hematocrit
    hct: "4544-3",
    ht: "4544-3",
    "h.t.": "4544-3",
    "h.t": "4544-3",
    "%ht": "4544-3",
    // RBC — period-separated abbrev added
    \u7D05\u8840\u7403: "789-8",
    rbc: "789-8",
    "r.b.c": "789-8",
    // WBC — period-separated abbrev added
    \u767D\u8840\u7403: "6690-2",
    wbc: "6690-2",
    "w.b.c": "6690-2",
    // Platelet — include the plural "Platelets" (v1.2.9). Some 林口長庚 CBC
    // rows ship the full word "Platelets"; the both-side `\b…\b` matcher won't
    // let the singular key match the plural, so the row degraded to the
    // (stripped) CBC panel default → no LOINC → the PLT column went blank in
    // the cumulative-report pivot even though the value was in the bundle.
    // Mirrors the sing/plural pairs already in CBC_DIFF_KEYS (neutrophils …).
    platelet: "777-3",
    platelets: "777-3",
    "platelet count": "777-3",
    \u8840\u5C0F\u677F: "777-3",
    plt: "777-3",
    // Reticulocyte (v1.2.9) — % form: 4679-7 "Reticulocytes/Erythrocytes in
    // Blood" (Property NFr, System Bld, methodless; WebFetch-verified
    // loinc.org 2026-07-06). Sing + plural + short "Retic" so a reticulocyte
    // row billed under a general CBC code resolves instead of falling to the
    // stripped CBC panel default. (Bare "retic" only matches standalone via
    // `\bretic\b`, so it never fires inside diuretic/natriuretic.)
    reticulocyte: "4679-7",
    reticulocytes: "4679-7",
    retic: "4679-7",
    "retic.": "4679-7",
    \u7DB2\u72C0\u7D05\u8840\u7403: "4679-7",
    \u7DB2\u7E54\u7D05\u8840\u7403: "4679-7",
    // CBC indices — period-separated abbrev forms added v0.11.4.
    // Order matters: longer "m.c.h.c" must register before "m.c.h"
    // is even considered (_findLongestMatch picks longest match
    // regardless of insertion order, so insertion order here is for
    // readability only).
    "m.c.v": "787-2",
    "m.c.h.c": "786-4",
    "m.c.h": "785-6",
    // ── v0.12.1 (SMART app dev bug 5'/6'/7' 2026-05-29): explicit
    // "EN(中文)" parenthetical variants from the 2024-01-22 hospital's
    // CBC display format. Same rationale as the CBC_DIFF_KEYS additions
    // above: guarantee longest-match wins over panel-default fallback.
    "mcv(\u5E73\u5747\u7D05\u8840\u7403\u5BB9\u7A4D)": "787-2",
    "mch(\u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20)": "785-6",
    "mchc(\u5E73\u5747\u7D05\u8840\u7403\u6FC3\u5EA6)": "786-4",
    "mchc(\u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20\u6FC3\u5EA6)": "786-4",
    "rdw(\u7D05\u8840\u7403\u5206\u5E03\u5BEC\u5EA6)": "788-0",
    "rdw(\u5E73\u5747\u7D05\u8840\u7403\u5BEC\u5EA6)": "788-0",
    // observed variant in user's bundle
    "rdw(\u7D05\u8840\u7403\u5206\u4F48\u5BEC\u5EA6)": "788-0",
    "wbc(\u767D\u8840\u7403\u8A08\u6578)": "6690-2",
    "rbc(\u7D05\u8840\u7403\u8A08\u6578)": "789-8",
    "hb(\u8840\u7D05\u7D20)": "718-7",
    "hb(\u8840\u8272\u7D20)": "718-7",
    "hgb(\u8840\u7D05\u7D20)": "718-7",
    "hgb(\u8840\u8272\u7D20)": "718-7",
    "hct(\u8840\u7403\u5BB9\u7A4D\u6BD4)": "4544-3",
    "ht(\u8840\u7403\u5BB9\u7A4D\u6BD4)": "4544-3",
    "platelet(\u8840\u5C0F\u677F)": "777-3",
    "platelets(\u8840\u5C0F\u677F)": "777-3",
    "plt(\u8840\u5C0F\u677F)": "777-3",
    // ── v0.11.11 (SMART app dev bug 5 2026-05-29): variants observed
    // in user's v0.11.9 bundle that previously fell through to global
    // LOINC_MAP "紅血球" → 789-8 (RBC count) — 5 distinct CBC indices
    // all wrongly tagged as RBC count (48 records).
    //
    // 紅血球分**佈**變異數 (LIS variant of 紅血球分**布**寬度) → RDW.
    //   LOINC 788-0 already verified v0.11.4.
    // 紅血球**平均**容積 (word order variant of **平均**紅血球容積) → MCV.
    //   LOINC 787-2 already verified.
    // 紅血球色素 → MCH (mean corpuscular hemoglobin).
    //   LOINC 785-6 already verified.
    // 紅血球色素濃度 → MCHC. LOINC 786-4 already verified.
    // Add 變異 + 體積 cross variants for robustness against future LIS
    // quirks; longest-match semantics keep RBC ("紅血球") from winning
    // over the longer compound keys.
    \u7D05\u8840\u7403\u5206\u4F48\u8B8A\u7570\u6578: "788-0",
    \u7D05\u8840\u7403\u5206\u5E03\u8B8A\u7570\u6578: "788-0",
    // 布 variant
    \u7D05\u8840\u7403\u5206\u5E03\u8B8A\u7570: "788-0",
    \u7D05\u8840\u7403\u5206\u4F48\u8B8A\u7570: "788-0",
    \u7D05\u8840\u7403\u9AD4\u7A4D\u5206\u4F48: "788-0",
    \u7D05\u8840\u7403\u9AD4\u7A4D\u5206\u5E03: "788-0",
    \u7D05\u8840\u7403\u5E73\u5747\u5BB9\u7A4D: "787-2",
    \u7D05\u8840\u7403\u5E73\u5747\u9AD4\u7A4D: "787-2",
    \u7D05\u8840\u7403\u8272\u7D20\u6FC3\u5EA6: "786-4",
    // MCHC (must precede 紅血球色素 for longest-match clarity)
    \u7D05\u8840\u7403\u8272\u7D20: "785-6",
    // MCH
    \u7D05\u8840\u7403\u5E73\u5747\u8840\u8272\u7D20\u6FC3\u5EA6: "786-4",
    \u7D05\u8840\u7403\u5E73\u5747\u8840\u8272\u7D20: "785-6"
  };
  var CBC_DIFF_KEYS = {
    // Cell differential (neut/lym/mono/eos/baso, incl. Taiwan CJK synonyms, bare
    // abbreviations, and "EN(中文)" parenthetical forms). Variants live ONCE in
    // CELL_ALIASES (analyte-aliases.ts); buildRoutes reproduces the prior hand-
    // written blood table byte-for-byte (pinned by loinc-alias-matrix.test.ts +
    // the registry-equivalence test). Same tokens route to Synovial-fluid LOINCs
    // under 16008C via buildRoutes there — no more per-specimen re-listing/drift.
    ...buildRoutes({
      NEUTROPHIL: "770-8",
      // Neutrophils/100 leukocytes
      LYMPHOCYTE: "736-9",
      // Lymphocytes/100 leukocytes
      // Method is absent from the NHI row, so use the method-unspecified blood
      // term rather than guessing manual-only 735-1. LOINC explicitly treats
      // variant, atypical and reactive lymphocytes as the same component.
      // Verified: https://loinc.org/13046-8 and https://loinc.org/735-1
      REACTIVE_LYMPHOCYTE: "13046-8",
      MONOCYTE: "5905-5",
      // Monocytes/100 leukocytes
      EOSINOPHIL: "713-8",
      // Eosinophils/100 leukocytes
      BASOPHIL: "706-2"
      // Basophils/100 leukocytes
    }),
    // Nucleated erythrocytes are reported per 100 leukocytes and are NOT the
    // ordinary RBC count. These longer aliases must live in the CBC-scoped table
    // so they win before the shorter CBC_COMPONENT_KEYS "rbc" / "紅血球"
    // aliases. Do not infer Normobl. here: that LIS abbreviation has no explicit
    // ratio/unit evidence in the captured rows and deliberately remains code-only.
    "nucleated rbc": "19048-8",
    "nucleated erythrocyte": "19048-8",
    "nucleated erythrocytes": "19048-8",
    nrbc: "19048-8",
    "n.r.b.c": "19048-8",
    \u6709\u6838\u7D05\u8840\u7403: "19048-8",
    \u6709\u6838\u7D05\u7D30\u80DE: "19048-8",
    // ── Maturation-stage neutrophils (v0.11.11) ────────────────────
    // SMART app dev bug 2 + 6 2026-05-29: Metamyelocyte ("後骨髓球") and
    // Band ("帶狀嗜中性白血球") rows were falling to the panel LOINC
    // 57021-8 (CBC W Diff panel) or 770-8 (Segment neutrophils). Both
    // are immature neutrophil maturation stages distinct from total /
    // segmented neutrophils; each has its own LOINC verified at
    // loinc.org 2026-05-29:
    //   740-1  Metamyelocytes/Leukocytes in Blood by Manual count (NFr)
    //   764-1  Band form neutrophils/Leukocytes in Blood by Manual count (NFr)
    // Adding to CBC_DIFF_KEYS so they're available under every CBC
    // sibling code (08002C/08003C/08004C/08006C/08011C/08013C).
    metamyelocyte: "740-1",
    metamyelocytes: "740-1",
    "meta-myelocyte": "740-1",
    "meta myelocyte": "740-1",
    meta: "740-1",
    // abbrev "Meta" / "Meta(STAT)" — `\bmeta\b` never matches the
    // full "metamyelocyte" (no word boundary), so this only catches the standalone
    // abbreviation; the "(STAT)" suffix is collapsed to a separate token.
    \u5F8C\u9AA8\u9AD3\u7403: "740-1",
    band: "764-1",
    bands: "764-1",
    "band form": "764-1",
    "band cell": "764-1",
    \u5E36\u72C0\u55DC\u4E2D\u6027\u767D\u8840\u7403: "764-1",
    \u5E36\u72C0: "764-1",
    \u687F\u72C0\u6838: "764-1",
    // alt name 桿狀核細胞
    // ── Earlier maturation stages (v1.3.3, H12113 audit 2026-07-08) ──────
    // 中國北港醫's manual diff (08013C) reports the full left-shift series as
    // abbreviations (Myelo. / Promyl. / Blast) that matched no key → panel-default
    // → suppressed → no-LOINC. Each is a distinct blood maturation stage with its
    // own NFr%/Manual LOINC, WebFetch-verified loinc.org 2026-07-08:
    //   749-2  Myelocytes/Leukocytes in Blood by Manual count (NFr)
    //   783-1  Promyelocytes/Leukocytes in Blood by Manual count (NFr)
    //   709-6  Blasts/Leukocytes in Blood by Manual count (NFr)
    // Abbrev keys are separator-collapse safe (Myelo.(STAT) → "myelo stat"); the
    // `\bmyelo\b` guard never matches "metamyelocyte"/"myelocyte" (no word
    // boundary), so it only catches the standalone abbreviation. 骨髓球 (myelocyte)
    // added too, but longest-match keeps 後骨髓球 → 740-1 (4 chars > 3).
    // NOT mapped (no verifiable manual-NFr% Blood LOINC found — left as no-LOINC
    // per rule #5 rather than shipping a guess): PlasmaCell, Normobl. (nucleated
    // RBC), PS (= peripheral-smear narrative, no unit).
    myelocyte: "749-2",
    myelocytes: "749-2",
    myelo: "749-2",
    "myelo.": "749-2",
    \u9AA8\u9AD3\u7403: "749-2",
    promyelocyte: "783-1",
    promyelocytes: "783-1",
    promyel: "783-1",
    "promyel.": "783-1",
    promyl: "783-1",
    // 北港醫 abbreviates "Promyl." (no e)
    "promyl.": "783-1",
    \u524D\u9AA8\u9AD3\u7403: "783-1",
    blast: "709-6",
    blasts: "709-6",
    \u82BD\u7D30\u80DE: "709-6",
    \u6BCD\u7D30\u80DE: "709-6"
  };
  var URINE_BIOCHEM_KEYS = {
    // Microalbumin variants (specimen + analyte)
    "micro-albumin": "14957-5",
    // Microalbumin Mass/vol Urine
    microalbumin: "14957-5",
    microalb: "14957-5",
    // 長庚嘉義 "MicroALB(U)"; (U) is folded as a separator
    "micro albumin": "14957-5",
    "u-malb": "14957-5",
    "malb(u)": "14957-5",
    "malb.": "14957-5",
    malb: "14957-5",
    \u5FAE\u5C0F\u767D\u86CB\u767D: "14957-5",
    \u5FAE\u767D\u86CB\u767D: "14957-5",
    // 官方 12111C 中文名（免疫比濁法版是「微白蛋白（免疫比濁法）」）
    \u5FAE\u91CF\u767D\u86CB\u767D: "14957-5",
    // 通用寫法（"尿微量白蛋白" 亦含此子字串）
    \u5C3F\u5FAE\u91CF\u767D\u86CB\u767D: "14957-5",
    \u5C3F\u767D\u86CB\u767D: "14957-5",
    // UACR (Microalbumin/Creatinine ratio Urine)
    uacr: "14959-1",
    "u-acr": "14959-1",
    acr: "14959-1",
    // bare "ACR" (P10109 audit 2026-07-08) — safe: URINE_BIOCHEM_KEYS
    // is consulted ONLY under 09016C/12111C (urine-creatinine codes), so "acr" can't
    // hijack a non-urine row.
    "alb/cre": "14959-1",
    "albumin/creatinine": "14959-1",
    // Urine creatinine variants
    "urine creatinine": "2161-8",
    "creatinine urine": "2161-8",
    "creatinine(u)": "2161-8",
    "u-cre": "2161-8",
    "u-crea": "2161-8",
    \u5C3F\u6DB2\u808C\u9178\u9150: "2161-8",
    \u5C3F\u808C\u9178\u9150: "2161-8",
    creatinine: "2161-8",
    // bare — within 09016C/12111C scope, default to urine
    crea: "2161-8",
    \u808C\u9178\u9150: "2161-8"
  };
  var STOOL_ROUTINE_ANALYTE_KEYS = {
    color: "9397-1",
    // Color of Stool (Nom)
    colour: "9397-1",
    \u984F\u8272: "9397-1",
    form: "11029-6",
    // Consistency of Stool (Nom); real value "Formed"
    consistency: "11029-6",
    \u786C\u5EA6: "11029-6",
    \u6027\u72C0: "11029-6",
    appearance: "29636-8",
    // Appearance of Stool (Nom)
    \u5916\u89C0: "29636-8",
    mucus: "42524-9",
    // Mucus [Presence] in Stool by Light microscopy
    mucous: "42524-9",
    \u7C98\u6DB2: "42524-9",
    \u9ECF\u6DB2: "42524-9",
    "o.b.(chem)": "2335-8",
    // real LIS spelling; punctuation is separator-folded
    "ob chem": "2335-8",
    "occult blood": "2335-8",
    \u6F5B\u8840: "2335-8",
    "ova(dir)": "10704-5",
    // Ova and parasites identified in Stool by LM
    "ova direct": "10704-5",
    ova: "10704-5",
    parasite: "10704-5",
    \u87F2\u5375: "10704-5",
    \u5BC4\u751F\u87F2: "10704-5",
    pus: "13655-6",
    // pus cells = stool leukocytes; real result is Ord Negative
    wbc: "13655-6",
    leukocyte: "13655-6",
    leukocytes: "13655-6",
    \u767D\u8840\u7403: "13655-6",
    rbc: "33668-5",
    erythrocyte: "33668-5",
    erythrocytes: "33668-5",
    \u7D05\u8840\u7403: "33668-5"
  };
  var URINALYSIS_ANALYTE_KEYS = {
    // Order matters: longer/more-specific keys before generic ones
    // (matches _LOINC_MAP iteration semantics — first hit wins).
    "specific gravity": "5811-5",
    // Specific gravity Urine
    "sp.gravity": "5811-5",
    "sp gravity": "5811-5",
    \u6BD4\u91CD: "5811-5",
    "micro-albumin": "14957-5",
    // Microalbumin Mass/vol Urine
    microalbumin: "14957-5",
    "malb(u)": "14957-5",
    malb: "14957-5",
    \u5FAE\u5C0F\u767D\u86CB\u767D: "14957-5",
    // v0.12.1 (caught during v0.11.7 test re-run after LOINC_SHORT_TEXT
    // for 20454-5 was added — both 微白蛋白 displays were silently
    // routing to bare "蛋白" → 20454-5 (urine protein) instead of
    // their correct microalbumin/UACR LOINCs). Longer specific keys
    // ensure correct routing via _findLongestMatch.
    \u5FAE\u767D\u86CB\u767D: "14957-5",
    "\u5FAE\u767D\u86CB\u767D(\u5C3F)": "14957-5",
    "\u5FAE\u767D\u86CB\u767D(\u5C3F)(\u534A\u5B9A\u91CF)": "14957-5",
    "\u5FAE\u767D\u86CB\u767D(\u5C3F\u6DB2)": "14957-5",
    \u5C3F\u5FAE\u91CF\u767D\u86CB\u767D: "14957-5",
    \u5C3F\u767D\u86CB\u767D: "14957-5",
    "u-malb": "14957-5",
    uacr: "14959-1",
    // Microalbumin/Creatinine ratio Urine
    "\u5FAE\u767D\u86CB\u767D/\u808C\u9150\u9178\u6BD4\u503C": "14959-1",
    "\u5FAE\u767D\u86CB\u767D/\u808C\u9150\u9178\u6BD4\u503C(\u534A\u5B9A\u91CF)": "14959-1",
    \u808C\u9150\u9178\u6BD4\u503C: "14959-1",
    \u808C\u9178\u9150\u6BD4\u503C: "14959-1",
    "alb/cre": "14959-1",
    "albumin/creatinine": "14959-1",
    "u-acr": "14959-1",
    "urine glucose": "5792-7",
    sugar: "5792-7",
    // NHI '尿糖' / 'Sugar' under 06013C
    \u5C3F\u7CD6: "5792-7",
    \u7CD6: "5792-7",
    // panel-scoped bare Chinese alias (real 06012C row)
    urobilinogen: "5818-0",
    // Urobilinogen Urine Ql
    \u5C3F\u81BD\u7D20\u539F: "5818-0",
    \u5C3F\u81BD\u5143: "5818-0",
    // Taiwan LIS shorthand; unit fix may select 19161-9
    bilirubin: "5770-3",
    // Bilirubin Urine Ql
    \u5C3F\u81BD\u7D05\u7D20: "5770-3",
    // v0.13.1 (LOINC-based dedup migration audit 2026-05-30): bare
    // "膽紅素" was missing — only the 尿- prefixed form was registered.
    // PANEL_LOINC_MAP is code-scoped to 06013C urinalysis context, so
    // adding the bare term here doesn't cross-pollute serum 膽紅素 (which
    // routes via 09029C → NHI_TO_LOINC = 1975-2).
    // WebFetch loinc.org/5770-3 verified 2026-06-02: Long Common Name
    // "Bilirubin.total [Presence] in Urine by Test strip" — Component
    // Bilirubin / Property PrThr / System Urine / Scale Ord / Method
    // Test strip → correct urine-dipstick context for 06013C. ✅
    \u81BD\u7D05\u7D20: "5770-3",
    nitrite: "5802-4",
    // Nitrite Urine
    \u4E9E\u785D\u9178: "5802-4",
    ketones: "5797-6",
    // Ketones Urine
    ketone: "5797-6",
    \u916E\u9AD4: "5797-6",
    protein: "20454-5",
    // Protein Mass/vol Urine
    \u5C3F\u86CB\u767D: "20454-5",
    \u86CB\u767D: "20454-5",
    leukocyte: "5799-2",
    // Leukocytes Urine
    leu: "5799-2",
    \u767D\u8840\u7403\u916F\u9176: "5799-2",
    // v0.11.11 (SMART app dev bug 7 2026-05-29): variant character 脢
    // (not 酶) observed under 06013C in user's v0.11.9 bundle. Without
    // this entry path-B missed and fell to global LOINC_MAP "白血球" →
    // 6690-2 (blood WBC count) — wrong specimen + wrong analyte (4
    // records affected).
    \u767D\u8840\u7403\u916F\u8122: "5799-2",
    \u767D\u8840\u7403\u8102\u9176: "5799-2",
    // also seen — 脂 vs 酯
    \u767D\u8840\u7403\u8102\u8122: "5799-2",
    \u767D\u8840\u7403\u916F\u985E: "5799-2",
    // observed in some HIS as descriptive name
    "\u767D\u8840\u7403\u916F\uE002": "5799-2",
    // hospital private-use glyph for the final 脂/酶 character
    blood: "5794-3",
    // Hemoglobin Urine Ql
    \u6F5B\u8840: "5794-3",
    \u8272: "5778-6",
    // Color of Urine (CJK substring)
    color: "5778-6",
    turbidity: "5767-9",
    // Appearance of Urine
    appearance: "5767-9",
    \u5916\u89C0: "5767-9",
    // v0.13.1 (app dev urinalysis A/B audit 2026-06-02): NHI B-channel
    // ships "濁度" where A-channel ships "Turbidity". Without this key
    // 濁度 fell to path-C panel default 24356-8 (Urinalysis complete
    // panel) → diverged from Turbidity's 5767-9 → looked like a dup pair
    // AND carried the wrong LOINC. WebFetch loinc.org/5767-9 verified
    // 2026-06-02: Long Common Name "Appearance of Urine" — System Urine,
    // Property Aper, Scale Nom. Taiwan urinalysis 濁度/Turbidity is the
    // standard urine appearance/clarity test. ✅
    \u6FC1\u5EA6: "5767-9",
    ph: "5803-2",
    // pH of Urine (urine-specific, NOT
    // the arterial 11558-4 that the
    // global map points to)
    \u9178\u9E7C\u5EA6: "5803-2",
    // v0.13.1 (same audit): B-channel "酸鹼值" vs A-channel "pH". Note
    // 酸鹼值 (值) ≠ 酸鹼度 (度) — only the latter was registered, so 酸鹼值
    // fell to panel default 24356-8. Code-scoped to 06013C so no clash
    // with 09041B ABG's "酸鹼值" → 11558-4 (arterial pH). WebFetch
    // loinc.org/5803-2 verified 2026-06-02: "pH of Urine by Test strip"
    // — Component pH, System Urine. ✅
    \u9178\u9E7C\u503C: "5803-2",
    glucose: "5792-7",
    // Last in this block so 'urine
    // ── v0.11.4 audit — Taiwan dipstick abbrev variants ──
    // Without these the abbreviated displays ("Bili" / "KET" / "OB" /
    // "NIT" / "UBG" / "URO" / "SG" / "Colour" / "WBC esterase") fell
    // to path-C and got LOINC 24356-8 (Urinalysis panel). Some also
    // shadowed by global LOINC_MAP keys (e.g. "WBC esterase" matched
    // global "wbc" → 6690-2 BLOOD WBC, wrong specimen).
    "u-bili": "5770-3",
    bili: "5770-3",
    ket: "5797-6",
    ob: "5794-3",
    "ob.": "5794-3",
    "occult blood": "5794-3",
    nit: "5802-4",
    ubg: "5818-0",
    uro: "5818-0",
    sg: "5811-5",
    "s.g": "5811-5",
    colour: "5778-6",
    // UK spelling
    "wbc esterase": "5799-2",
    // blocks global "wbc" → 6690-2 shadow
    // v0.12.2 (SMART app dev v0.12.1 audit 2026-05-29): hospital
    // 長庚嘉義 ships urine creatinine rows under NHI 06013C (尿生化
    // panel) — NOT under 09015C as the v0.12.1 fix targeted. Without
    // explicit urine variants here, "肌酸酐(尿液)(半定量)" routed via
    // LOINC_MAP global "肌酸酐" → 2160-0 serum LOINC under 06013C
    // billing (4 rows affected in user's v0.12.1 bundle). Mirror the
    // same urine creatinine variants from PANEL_LOINC_MAP["09015C"]
    // — longest-match guarantees urine LOINC 2161-8 wins over generic.
    "\u808C\u9178\u9150(\u5C3F\u6DB2)(\u534A\u5B9A\u91CF)": "2161-8",
    "\u808C\u9178\u9150(\u5C3F\u6DB2)": "2161-8",
    "\u808C\u9178\u9150(\u5C3F)": "2161-8",
    "\u808C\u9178\u9150(u)": "2161-8",
    // ASCII keys ending in ")" fail \b regex boundary at end of match
    // (same \b-non-word-char-no-boundary issue documented in v0.11.13
    // APTT ratio fix). Use opening-paren-only form so \b at end fires
    // on the word char preceding ")" — "creatinine(u" matches inside
    // "creatinine(u)" with \b after "u".
    "creatinine(u": "2161-8",
    "creatinine(urine": "2161-8",
    // v0.13.1 (app dev urinalysis A/B audit 2026-06-02): A-channel ships
    // the abbreviation "CREA(U)(半定量)" — "creatinine(u" did NOT match
    // (no "creatinine" substring in "crea(u)"), so it fell to global
    // LOINC_MAP "crea" → 2160-0 SERUM creatinine while the B-channel
    // "肌酸酐(尿液)" correctly got urine 2161-8. Add the abbreviated
    // opening-paren form. Same verified LOINC 2161-8 "Creatinine
    // [Mass/volume] in Urine" — WebFetch loinc.org/2161-8 confirmed
    // 2026-06-02 (System Urine). ✅
    "crea(u": "2161-8",
    "crea(urine": "2161-8",
    "u-creatinine": "2161-8",
    "urine creatinine": "2161-8",
    "creatinine, urine": "2161-8",
    // ── Sediment microscopy sub-analytes (v0.18.2, 2026-06-09) ──
    // 06012C 尿液一般檢查 also ships URINE SEDIMENT MICROSCOPY items the
    // dipstick-only 06013C bundles never carried. Each LOINC WebFetch-
    // verified at loinc.org 2026-06-09 (rule #5):
    //   5787-7  Epithelial cells [#/area] Urine sed Microscopy HPF (Qn)
    //   5821-4  Leukocytes [#/area] Urine sed Microscopy HPF (Qn)
    //   5808-1  Erythrocytes [#/volume] Urine sed Microscopy HPF (Qn)
    //   25145-4 Bacteria [Presence] Urine sed Light microscopy (Ord)
    //   5783-6  Unidentified crystals [Presence] Urine sed (Ord)
    // Count-form keys (白血球計數/紅血球計數) outrank the dipstick
    // leukocyte-esterase key (白血球酯脢→5799-2) by longest-match.
    //
    // v1.0.11 (2026-06-29, real P10109 06012C bundle): some HIS ship the
    // sediment items as BARE ENGLISH "WBC" / "RBC" / "Epith Cell" (value e.g.
    // "0-2" /HPF). The earlier "deliberately NO bare wbc/rbc" stance backfired:
    // with no panel key they fell through to the BLOOD CBC LOINCs in the global
    // map (6690-2 / 789-8) — the very wrong-specimen it tried to avoid (and
    // after the v1.0.10 blood-LOINC veto they degraded to uncoded). Adding them
    // HERE (Path B1, resolves BEFORE the global map) is what actually prevents
    // the blood fall-through. Shadow-safety: the dipstick keys are DISTINCT
    // strings (leukocyte / leu / 白血球酯酶 / "wbc esterase" / blood / 潛血 / ob)
    // and "wbc esterase" (11) beats bare "wbc" (3) via longest-match — so the
    // dipstick esterase / occult-blood rows still route correctly; only a row
    // whose display IS bare "WBC"/"RBC" (the microscopy count) lands on the
    // sediment LOINC. Re-verified 5821-4 / 5808-1 / 5787-7 on loinc.org
    // 2026-06-29 (all Qn, Urine sed, Microscopy.light.HPF). CI: bundle-quality
    // "CI v1.0.11 — urine sediment 英文 WBC/RBC/Epith".
    \u4E0A\u76AE\u7D30\u80DE: "5787-7",
    "epi cell": "5787-7",
    "epith cell": "5787-7",
    // "Epith Cell" — the trailing "th" breaks epi/epithelial
    "ep.cell": "5787-7",
    // real urine-sediment abbreviation
    epith: "5787-7",
    epithelial: "5787-7",
    \u767D\u8840\u7403\u8A08\u6578: "5821-4",
    \u7D05\u8840\u7403\u8A08\u6578: "5808-1",
    wbc: "5821-4",
    // bare English sediment WBC count (esterase = "wbc esterase"/leukocyte/leu, longer/distinct → still wins)
    rbc: "5808-1",
    // bare English sediment RBC count (occult blood = blood/潛血/ob, distinct → unaffected)
    \u7D30\u83CC: "25145-4",
    bacteria: "25145-4",
    \u7D50\u6676: "5783-6",
    crystal: "5783-6",
    crystals: "5783-6",
    crystal1: "5783-6",
    // hospital compact suffix without a separator
    "crystal 1": "5783-6",
    cast: "24124-0",
    // generic qualitative Cast / Cast(1)
    // 尿膽素元 — real-world 元/原 spelling variant of urobilinogen (the
    // dipstick key above is 尿膽素原). English "Urobilinogen" already routes
    // it; cover the CJK-only 元 form too.
    \u5C3F\u81BD\u7D20\u5143: "5818-0",
    \u81BD\u7D20\u5143: "5818-0",
    // 黏液/Mucus → 8247-9 (2026-06-13, SMART app dev report + WebFetch).
    // CORRECTION: the prior comment claimed "no clean generic urine-mucus
    // LOINC" and left 黏液 unmapped → it fell to the Step-C panel default
    // 24356-8, which is the "Urinalysis complete PANEL" code, NOT a mucus
    // analyte. The app dev correctly flagged that as a panel-on-analyte
    // mis-tag. loinc.org/8247-9 (rule #5, WebFetch-verified): Component
    // "Mucus", Property "PrThr", System "Urine sed", Scale "Ord", Method
    // "Microscopy.light" — a single-observation urine-sediment mucus code
    // matching the qualitative (Negative/Present) result NHI ships. ✅
    \u9ECF\u6DB2: "8247-9",
    mucus: "8247-9"
  };
  var URINE_SEDIMENT_MEMBER_LOINCS = /* @__PURE__ */ new Set([
    "5787-7",
    // epithelial cells
    "5821-4",
    // leukocytes
    "5808-1",
    // erythrocytes
    "25145-4",
    // bacteria
    "5783-6",
    // crystals
    "24124-0",
    // casts
    "8247-9"
    // mucus
  ]);
  var URINE_SEDIMENT_ANALYTE_KEYS = Object.fromEntries(
    Object.entries(URINALYSIS_ANALYTE_KEYS).filter(
      ([, loinc]) => URINE_SEDIMENT_MEMBER_LOINCS.has(loinc)
    )
  );
  var PANEL_LOINC_MAP = {
    // ── Urinalysis: 06012C + 06013C share ONE analyte table ──────
    // v0.18.2 (2026-06-09): both urinalysis panel codes route display-first
    // through URINALYSIS_ANALYTE_KEYS. 06012C was previously NOT registered
    // as a panel and short-circuited (NHI_TO_LOINC Step A) to 5778-6 "Color
    // of Urine", collapsing all 18 sub-analytes. See rule #10.
    "06009C": URINE_SEDIMENT_ANALYTE_KEYS,
    "06012C": URINALYSIS_ANALYTE_KEYS,
    "06013C": URINALYSIS_ANALYTE_KEYS,
    // 09040C (全蛋白) is specimen-agnostic, so it must never receive a
    // code-wide urine default. This exact LIS spelling carries positive urine
    // evidence in the suffix: 長庚「T-Protein(U)」. Separator folding makes the
    // single key cover T-Protein(U), T Protein (U), and fullwidth punctuation;
    // the trailing U is required, so a bare/serum T-Protein cannot be poached.
    "09040C": {
      "t-protein(u": "2888-6",
      "t protein urine": "2888-6"
    },
    // 13007C is a broad microbiology billing container, not a single culture.
    // Map only rows that explicitly name an AEROBIC culture. LOINC 634-6 has
    // System=XXX (generic Specimen), so an absent specimen marker is not a reason
    // to discard this otherwise exact analyte+method match. Other 13007C rows
    // (fungal/anaerobic/protozoal/etc.) deliberately remain NHI-code-only.
    "13007C": {
      "aerobic culture": "634-6",
      \u55DC\u6C27\u57F9\u990A: "634-6"
    },
    // ── ABG panel (09041B) ───────────────────────────────
    // 09041B has DISPLAY_FIRST_CODES but no PANEL_LOINC_MAP entry until
    // v0.11.4 — relied on global LOINC_MAP for routing, which works for
    // the canonical abbreviations (pH/pCO2/pO2/HCO3/TCO2/SaO2) but
    // missed period-separated forms (P.CO2 / T.CO2 / p.H.) + Chinese
    // descriptive names (酸鹼值 / 二氧化碳分壓 / 氧分壓 / 血氧飽和度).
    // Panel-scoped table now covers Taiwan LIS variants. Global entries
    // kept for backward compat (Mode A bundles older than v0.11.4 may
    // still rely on global path).
    // 2026-07-06 (v1.2.10 — REVERTED the 2026-07-03 arterial mapping):
    // 09041B 的健保目錄名稱實際是「血液氣體分析」(Blood gas analysis) — 實際 NHI
    // 資料帶的 order_name 亦為「血液氣體分析」，**未指定動脈或靜脈**。先前 2026-07-03
    // 誤以為是「動脈血液氣體分析」而改用動脈專屬 LOINC，屬 over-claim（實測案例：
    // SAT 值 37.3%、參考範圍 70-75% 明顯是靜脈血氧區間 → 動脈 LOINC 與靜脈範圍
    // 自相矛盾）。忠實搬運：來源沒說動/靜脈，就用**泛用「in Blood」LOINC**，檢體標
    // 泛用「Blood」(見 SPECIMEN_SPECIFIC_CODE["09041B"])，交給臨床判讀。**不由參考
    // 範圍反推靜脈**(間接、脆弱、非每筆都有範圍 → 也是猜)。全部 loinc.org 查證
    // 2026-07-06：
    //   pH   2744-1(Arterial) → 11558-4「pH of Blood」
    //   pCO2 2019-8(Arterial) → 11557-6「Carbon dioxide [PPres] in Blood」
    //   pO2  2703-7(Arterial) → 11556-8「Oxygen [PPres] in Blood」
    //   HCO3 1960-4(Arterial) → 1959-6「Bicarbonate [Moles/vol] in Blood」
    //   SaO2 2708-6(Arterial) → 20564-1「Oxygen saturation in Blood」(method-less;
    //        不用 2713-6「Calculated from pO2」— NHI 未給 assay 方向，選 calculated
    //        會捏造來源沒有的方法)
    // 這些也正是全域 LOINC_MAP 的泛用值 → 面板與全域一致。
    // Table lookup temporarily uses the ordinary generic code for SBE/SBC so
    // aliases remain analyte-identifiable. The final mapper never emits that
    // borrowed code for a standard row: explicit/proven venous evidence yields
    // 19237-7/19232-8; otherwise the row is NHI-code-only. ABE/HCO3 may retain
    // their true vessel-neutral Blood terms.
    "09041B": {
      // pH → generic 11558-4
      ph: "11558-4",
      "p.h.": "11558-4",
      "p.h": "11558-4",
      \u9178\u9E7C\u503C: "11558-4",
      // pCO2 / pO2 → generic in Blood
      pco2: "11557-6",
      "p.co2": "11557-6",
      \u4E8C\u6C27\u5316\u78B3\u5206\u58D3: "11557-6",
      po2: "11556-8",
      \u6C27\u5206\u58D3: "11556-8",
      // HCO3 → generic 1959-6 (distinct from total CO2)
      hco3: "1959-6",
      "hco3-": "1959-6",
      bicarbonate: "1959-6",
      sbc: "1959-6",
      // Standard bicarbonate; do not confuse with base excess
      \u78B3\u9178\u6C2B\u6839: "1959-6",
      \u91CD\u78B3\u9178: "1959-6",
      // 09041B is a whole-blood gas order. Use the specimen-correct generic
      // Blood total-CO2 term; a proven venous group is promoted to 2027-1.
      // Keep global codeless `tco2` on 2028-9 because without the NHI context it
      // may genuinely be the serum/plasma chemistry analyte.
      tco2: "20565-8",
      "t.co2": "20565-8",
      "total co2": "20565-8",
      "total carbon dioxide": "20565-8",
      // SaO2 → generic 20564-1「Oxygen saturation in Blood」(method-less; measured
      // or pulse-ox, NOT the calculated 2713-6). NHI ships bare "SAT" / "O2SAT".
      sao2: "20564-1",
      sat: "20564-1",
      o2sat: "20564-1",
      saturat: "20564-1",
      "o2 saturation": "20564-1",
      "o2 sat": "20564-1",
      saturation: "20564-1",
      \u8840\u6C27\u98FD\u548C\u5EA6: "20564-1",
      // 11555-0 is the true generic-Blood term for actual base excess (ABE).
      // SBE aliases temporarily share it only inside lookup; the final mapper
      // removes that candidate unless venous evidence selects 19237-7.
      "base excess": "11555-0",
      abe: "11555-0",
      temp: "8310-5",
      // patient temperature recorded with blood-gas analysis
      temperature: "8310-5",
      \u6EAB\u5EA6: "8310-5"
    },
    // ── CBC basic panel (08011C) ─────────────────────────
    // NHI 08011C bills the basic CBC items (RBC + indices, HGB, HCT,
    // PLT, WBC). Without per-item LOINCs under the panel, MCV / MCHC /
    // RDW were being shadowed:
    //   • MCV "平均紅血球容積" → matched global "紅血球" → 789-8 (RBC) ✗
    //   • MCHC "MCHC" → no key matched → fell back to panel 58410-2 ✗
    //   • RDW → no key matched → fell back to panel 58410-2 ✗
    //   • Basophil / Lymphocyte / Monocyte → fell to "白血球" → 6690-2 ✗
    // Panel-scoped table runs BEFORE the global one so the longer,
    // specific CJK / ASCII keys win. All LOINCs verified at loinc.org
    // (Long Common Name documented inline). Bug report 2026-05-27.
    "08011C": {
      // RBC indices — longer CJK keys first so they beat the bare
      // "紅血球" key in the global LOINC_MAP path. (longest-key-wins
      // semantics in _findLongestMatch make insertion order irrelevant
      // within this dict but readability still benefits.)
      \u5E73\u5747\u7D05\u8840\u7403\u5BB9\u7A4D: "787-2",
      // MCV — Erythrocyte mean corpuscular volume
      \u5E73\u5747\u7D05\u8840\u7403\u9AD4\u7A4D: "787-2",
      mcv: "787-2",
      \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20\u6FC3\u5EA6: "786-4",
      // MCHC — Erythrocytes mean corpuscular HGB concentration
      mchc: "786-4",
      \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20: "785-6",
      // MCH — Erythrocyte mean corpuscular hemoglobin
      mch: "785-6",
      \u7D05\u8840\u7403\u5206\u5E03\u5BEC\u5EA6: "788-0",
      // RDW — Erythrocyte distribution width
      \u7D05\u8840\u7403\u9AD4\u7A4D\u5206\u4F48\u5BEC\u5EA6: "788-0",
      rdw: "788-0",
      // CBC basic counts — shared with the single-analyte billing codes
      // (08002C / 08003C / 08004C / 08006C) below; see
      // CBC_COMPONENT_KEYS const below for the source of truth.
      ...CBC_COMPONENT_KEYS,
      // v0.12.2 (SMART app dev v0.12.1 audit 2026-05-29): hospital
      // 中國北港醫 ships CBC differential rows under BOTH 08013C (CBC W
      // diff billing) AND 08011C (CBC-8項 umbrella billing) for the
      // same draw. v0.11.11 spread CBC_DIFF_KEYS into 08013C but NOT
      // into 08011C — so the 08011C-billed diff rows still fell back
      // to panel-default 6690-2 (WBC count) for all diff cells. Mirror
      // the spread so per-analyte LOINCs (706-2 Basophils / 713-8
      // Eosinophils / 736-9 Lymphocytes / 770-8 Neutrophils / 5905-5
      // Monocytes / 740-1 Metamyelocyte / 764-1 Band) win regardless
      // of which CBC NHI code the hospital bills under.
      ...CBC_DIFF_KEYS
    },
    // ── CBC sibling billing codes (v0.9.10 Part 5 + Part 6) ──
    // Single-analyte billing codes promoted to display-first so when a
    // hospital LIS swaps display vs code (e.g. row billed 08004C HCT
    // but display text reads "HGB"), the unambiguous display wins. Each
    // sibling spreads BOTH CBC_COMPONENT_KEYS (basic counts) AND
    // CBC_DIFF_KEYS (differential percentages) — hospitals bill the
    // diff rows under whatever CBC code their LIS uses (中國北港醫
    // observed billing diff under 08002C WBC count; bug report Part 6
    // bug N3). Fallback path C still hits NHI_TO_LOINC entry for empty/
    // unrecognised displays.
    "08002C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // WBC count billing
    "08003C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // Hemoglobin billing
    "08004C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // Hematocrit billing
    "08006C": { ...CBC_COMPONENT_KEYS, ...CBC_DIFF_KEYS },
    // Platelet count billing
    // ── Urine creatinine sibling codes (v0.9.10 Part 6 N2) ──
    // See URINE_BIOCHEM_KEYS const docstring. When hospital bills UACR
    // workup under 09016C / 12111C, the actual analyte (microalbumin
    // vs creatinine vs UACR ratio) is distinguished only by display.
    "09016C": URINE_BIOCHEM_KEYS,
    "12111C": URINE_BIOCHEM_KEYS,
    // 糞便一般檢查 — true multi-member panel, no invented parent LOINC.
    "07009C": STOOL_ROUTINE_ANALYTE_KEYS,
    // ── Bone-marrow morphology/differential (08128B) ───────────────
    // 08128B is a real multi-row panel, not one Observation. Member LOINCs are
    // taken from the active 47286-0 bone-marrow differential panel. Keeping the
    // aliases panel-scoped prevents bone-marrow cells from inheriting the blood
    // differential LOINCs with the same display names.
    "08128B": {
      myeloblast: "11113-8",
      myeloblasts: "11113-8",
      \u539F\u59CB\u9AA8\u9AD3\u7403: "11113-8",
      myelocyte: "11114-6",
      myelocytes: "11114-6",
      \u9AA8\u9AD3\u7403: "11114-6",
      metamyelocyte: "11111-2",
      metamyelocytes: "11111-2",
      \u5F8C\u9AA8\u9AD3\u7403: "11111-2",
      promyelocyte: "11120-3",
      promyelocytes: "11120-3",
      \u524D\u9AA8\u9AD3\u7403: "11120-3",
      blast: "11150-0",
      blasts: "11150-0",
      \u82BD\u7D30\u80DE: "11150-0",
      lymphocyte: "11108-8",
      lymphocytes: "11108-8",
      \u6DCB\u5DF4\u7403: "11108-8",
      \u6DCB\u5DF4\u7D30\u80DE: "11108-8",
      "plasma cell": "11118-7",
      "plasma cells": "11118-7",
      \u6F3F\u7D30\u80DE: "11118-7",
      basophil: "11105-4",
      basophils: "11105-4",
      \u55DC\u9E7C\u6027\u7403: "11105-4",
      eosinophil: "11152-6",
      eosinophils: "11152-6",
      \u55DC\u9178\u6027\u7403: "11152-6",
      monocyte: "11112-0",
      monocytes: "11112-0",
      \u55AE\u6838\u7403: "11112-0",
      neutrophil: "11115-3",
      neutrophils: "11115-3",
      \u55DC\u4E2D\u6027\u7403: "11115-3",
      "band neutrophil": "11103-9",
      "band form": "11103-9",
      \u5E36\u72C0\u55DC\u4E2D\u6027\u7403: "11103-9",
      "segmented neutrophil": "11128-6",
      "segmented neutrophils": "11128-6",
      \u5206\u8449\u55DC\u4E2D\u6027\u7403: "11128-6",
      megakaryocyte: "11110-4",
      megakaryocytes: "11110-4",
      \u5DE8\u6838\u7D30\u80DE: "11110-4",
      "erythroid cell": "40689-2",
      "erythroid cells": "40689-2",
      \u7D05\u8840\u7403\u7CFB\u7D30\u80DE: "40689-2",
      "m:e ratio": "11138-5",
      "m/e ratio": "11138-5",
      "myeloid erythroid ratio": "11138-5",
      \u7C92\u7D05\u6BD4: "11138-5"
    },
    // ── Iron/TIBC workup (09035C) ──────────────────────────────────
    // Taiwan hospitals can emit Fe, TIBC, UIBC and transferrin saturation as
    // sibling rows under 09035C. Unknown rows fall back to the 50190-8 panel and
    // are suppressed on Observation by isPanelDefaultFallback().
    "09035C": {
      "transferrin saturation": "2502-3",
      "iron saturation": "2502-3",
      "fe saturation": "2502-3",
      "sat fe": "2502-3",
      \u9435\u98FD\u548C\u5EA6: "2502-3",
      \u8F49\u9435\u86CB\u767D\u98FD\u548C\u5EA6: "2502-3",
      uibc: "2501-5",
      "unsaturated iron binding capacity": "2501-5",
      \u672A\u98FD\u548C\u9435\u7D50\u5408\u80FD: "2501-5",
      tibc: "2500-7",
      "total iron binding capacity": "2500-7",
      "iron binding capacity": "2500-7",
      \u7E3D\u9435\u7D50\u5408\u80FD: "2500-7",
      \u7E3D\u9435\u7D50\u5408\u529B: "2500-7",
      \u7E3D\u9435\u7D50\u5408\u80FD\u529B: "2500-7",
      \u7E3D\u9435\u7D50\u5408\u5BB9\u91CF: "2500-7",
      "serum iron": "2498-4",
      iron: "2498-4",
      fe: "2498-4",
      \u8840\u6E05\u9435: "2498-4"
    },
    // ── BNP / NT-proBNP shared billing code (12193C) ──────────────
    // The NHI code alone cannot distinguish the two analytes. Route only when
    // the row label is explicit; mojibake seen in hospital exports can replace
    // the final peptide character, so the highly specific N端前B型 prefix is the
    // safe Chinese discriminator for NT-proBNP.
    "12193C": {
      "nt-probnp": "33762-6",
      "pro-bnp": "33762-6",
      probnp: "33762-6",
      "pro bnp": "33762-6",
      n\u7AEF\u524Db\u578B: "33762-6",
      bnp: "30934-4"
    },
    // NHI 12020C names a generic M. pneumoniae antibody test. Hospitals may
    // expose IgM specifically; only that explicit qualitative immunoassay row is
    // safe to map to 5257-1. A bare/generic antibody row remains uncoded.
    "12020C": {
      "mycoplasma pneumoniae igm": "5257-1",
      "mycoplasma igm": "5257-1",
      \u80BA\u708E\u9EF4\u6F3F\u83CCigm: "5257-1",
      \u80BA\u708E\u9709\u6F3F\u83CCigm: "5257-1"
    },
    // 14004B is shared by serum and CSF at Taiwan hospitals. These aliases name
    // the serum/plasma quantitative immunoassay; an explicit CSF marker triggers
    // the specimen veto in observation.ts and therefore never emits 5124-3.
    "14004B": {
      "cmv igg": "5124-3",
      "cytomegalovirus igg": "5124-3",
      \u5DE8\u7D30\u80DE\u75C5\u6BD2igg: "5124-3",
      \u5DE8\u5927\u7D30\u80DE\u75C5\u6BD2igg: "5124-3"
    },
    // 12184C is organism-generic. Only an explicit CMV-DNA quantitative row is
    // mapped; 72493-0 is the IU/mL serum/plasma viral-load term used by the
    // reviewed hospital exports.
    "12184C": {
      "cmv dna": "72493-0",
      "cytomegalovirus dna": "72493-0",
      \u5DE8\u7D30\u80DE\u75C5\u6BD2dna: "72493-0",
      \u5DE8\u5927\u7D30\u80DE\u75C5\u6BD2dna: "72493-0"
    },
    // Combined rapid-flu kits often emit both A and B result rows under either
    // billing code. The order code remains the path-C fallback, while explicit
    // sub-row labels must select the matching virus type.
    "14065C": {
      "influenza a": "80382-5",
      "inf a": "80382-5",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2a\u578B: "80382-5",
      \u6D41\u884C\u6027\u611F\u5192a\u578B: "80382-5",
      "influenza b": "80383-3",
      "inf b": "80383-3",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2b\u578B: "80383-3",
      \u6D41\u884C\u6027\u611F\u5192b\u578B: "80383-3"
    },
    "14066C": {
      "influenza a": "80382-5",
      "inf a": "80382-5",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2a\u578B: "80382-5",
      \u6D41\u884C\u6027\u611F\u5192a\u578B: "80382-5",
      "influenza b": "80383-3",
      "inf b": "80383-3",
      \u6D41\u884C\u6027\u611F\u5192\u75C5\u6BD2b\u578B: "80383-3",
      \u6D41\u884C\u6027\u611F\u5192b\u578B: "80383-3"
    },
    // ── Serum protein electrophoresis (09065B; v0.10.0) ─────
    // SPE reports 5 fractions (Albumin / α1 / α2 / β / γ globulins) plus
    // A/G ratio. Each fraction has its own LOINC verified at loinc.org.
    // Previously all 6 sub-rows collapsed to 90991-1 (SPE panel LOINC) —
    // SMART app pivot-by-LOINC merged everything into one column.
    "09065B": {
      // Specific fractions — long names first (longest-match wins)
      "alpha-1 globulin": "2865-4",
      "alpha 1 globulin": "2865-4",
      "\u03B11-globulin": "2865-4",
      \u03B11: "2865-4",
      "alpha-2 globulin": "2868-8",
      "alpha 2 globulin": "2868-8",
      "\u03B12-globulin": "2868-8",
      \u03B12: "2868-8",
      "beta globulin": "2871-2",
      "\u03B2-globulin": "2871-2",
      \u03B2: "2871-2",
      "gamma globulin": "2874-6",
      "\u03B3-globulin": "2874-6",
      \u03B3: "2874-6",
      "a/g ratio": "1759-0",
      // Albumin/Globulin ratio
      "a/g": "1759-0",
      "alb/glb": "1759-0",
      // v0.11.11 (SMART app dev bug 3a 2026-05-29): Total Protein (T.P)
      // row was inheriting the SPE panel LOINC 90991-1. T.P is the total
      // serum protein measurement, distinct LOINC.
      // 2885-2 verified at loinc.org 2026-05-29:
      //   Component=Protein, Property=MCnc, System=Ser/Plas (Class=CHEM)
      "total protein": "2885-2",
      "t.p": "2885-2",
      "t. p": "2885-2",
      "t p": "2885-2",
      tp: "2885-2",
      \u7E3D\u86CB\u767D: "2885-2",
      \u8840\u6E05\u7E3D\u86CB\u767D: "2885-2",
      \u7E3D\u86CB\u767D\u8CEA: "2885-2",
      // 2026-07-03 audit: 2865-7 was an INVALID LOINC (check-digit fail; loinc.org
      // confirms "2865-7 does not exist" — 2865-4 is alpha-1 globulin). Correct
      // SPE-albumin code is 2862-1 (WebFetch loinc.org: Albumin, MCnc, Ser/Plas,
      // Electrophoresis), fitting the fraction series 2862/2865/2868/2871/2874.
      albumin: "2862-1",
      // Albumin in SPE context (was invalid 2865-7)
      \u767D\u86CB\u767D: "2862-1",
      alb: "2862-1"
    },
    // ── Flow cytometry CD markers (12204B; v0.10.0) ─────────
    // Lymphocyte surface markers — each CD subtype has its own LOINC.
    // Previously all CD3/CD4/CD8/CD19/CD56/ratio rows collapsed to
    // 20584-9 (Lymphocyte subset panel). Critical for HIV monitoring
    // (CD4 absolute count is the actionable indicator).
    "12204B": {
      // v0.11.4 audit fix: trailing "+" in keys breaks \b regex boundary
      // (+ is non-word, end-of-string after non-word has no \b). Keys
      // dropped trailing + so "CD3+/CD4+" display still matches via the
      // "cd3+/cd4" prefix substring. Keys with leading + and bare CD#
      // also need careful ordering — _findLongestMatch picks longest
      // match, so combined ratio keys must outrank bare cd3/cd4/cd8 by
      // length to avoid CD3 winning over the CD3+/CD4+ ratio entry.
      "cd3+/cd4": "8123-2",
      // CD3+CD4+ (T4 helper) cells/cells
      "cd3+/cd8": "8101-8",
      // CD3+CD8+ (T8 suppressor) cells/cells (was deprecated/wrong 8128-1)
      "cd4/cd8 ratio": "54218-3",
      "cd4/cd8": "54218-3",
      "cd8/cd4": "54218-3",
      "cd16+cd56": "8112-5",
      "cd16/cd56": "8112-5",
      // Percentage defaults; flowMarkerUnitFix() promotes cells/µL rows to the
      // absolute-count twins. Bare CD16/CD56 are deliberately absent: CD16 alone
      // and CD56 alone do not prove the CD3-CD16+CD56+ NK-cell phenotype.
      cd3: "8124-0",
      // CD3 cells/cells in Blood (%)
      cd4: "8123-2",
      // CD3+CD4+ cells/cells in Blood (%)
      cd8: "8101-8",
      // CD3+CD8+ cells/cells in Blood (%)
      cd19: "8117-4"
      // CD19 cells/cells in Blood (%)
    },
    // ── DLCO (17009B; v0.10.0) ──────────────────────────────
    // Carbon monoxide diffusing capacity test — reports DLCO + alveolar
    // volume (VA) + DLCO/VA ratio as 3 sub-rows. LOINCs verified at
    // loinc.org. Pulmonary function rarely surfaces in 健康存摺 but the
    // panel exists for completeness.
    "17009B": {
      // 2026-06-13 LOINC audit: all three sub-rows were WRONG and scrambled —
      // DLCO→24341-0 (an arterial-blood-gas PANEL), KCO→19911-7 (plain DLCO),
      // VA→19850-7 (inspiratory capacity). Corrected (WebFetch loinc.org, rule
      // #5): DLCO=19911-7, DLCO/VA(KCO)=19914-1. VA (肺泡容積) has no clean
      // single-analyte LOINC found → left UNMAPPED per rule #7 (NHI-code-only
      // beats a wrong code), longest-match keys ordered so the ratio wins.
      "dlco/va": "19914-1",
      // DLCO/VA = transfer coefficient (KCO)
      "dlco/alveolar volume": "19914-1",
      kco: "19914-1",
      dlco: "19911-7",
      // Diffusion capacity.carbon monoxide
      "dlco sb": "19911-7",
      // single-breath DLCO
      \u4E00\u6C27\u5316\u78B3\u80BA\u7030\u6563\u91CF: "19911-7"
    },
    // ── Serum creatinine + eGFR piggyback (09015C) ──────
    // NHI bills creatinine under 09015C; Taiwan labs auto-calculate eGFR
    // (CKD-EPI / MDRD) and append it as a separate sub-row using the
    // SAME 09015C billing code, distinguished only by display text.
    // Without this panel-scoped table, every 09015C row inherited LOINC
    // 2160-0 (serum creatinine) and SMART apps routed eGFR values into
    // the creatinine column — patient-safety issue (eGFR=33 displayed as
    // CREA=33 mg/dL is instantly mistaken for acute kidney failure).
    //
    // Formula-unlabelled eGFR ("eGFR" / "Estimated GFR" with no MDRD/
    // CKD-EPI qualifier) defaults to MDRD 77147-7 — Taiwan LIS convention
    // (健保 CKD program historically reports 四變數 MDRD). We deliberately
    // do NOT back-calculate which formula was used (would violate the
    // v1.0.18 "bridge does no self-compute" rule and rests on fragile
    // age/sex/race assumptions); the raw display is preserved in code.text
    // so consumers see the formula was unspecified. When the display DOES
    // name CKD-EPI, the "ckd-epi" key above routes it to 62238-1 instead.
    //
    // 77147-7 (MDRD, Ser/Plas/Bld) replaces the older 33914-3 (MDRD,
    // Ser/Plas) which LOINC marks DISCOURAGED and maps forward to 77147-7.
    // WebFetch-verified loinc.org 2026-07-07 (both Active-status checked).
    // The explicit creatinine entries are duplicated from the global
    // LOINC_MAP so the panel is self-contained.
    "09015C": {
      // CKD-EPI formula variant — Taiwan LIS ships it as a SEPARATE sub-row
      // under the same 09015C code, display "eGFR (CKD-EPI)", alongside the
      // MDRD row "eGFR (MDRD)". Both used to hit the bare "egfr" key → both
      // got MDRD 33914-3, so a LOINC-keyed SMART app (MediPrisma) collapsed
      // them to one label ("EGFR(M)") — the CKD-EPI 76.92 and MDRD 69.69
      // readings became indistinguishable. Longest-match makes "ckd-epi"
      // (7) win over "egfr" (4). 62238-1 WebFetch-verified loinc.org 2026-07-07:
      // "Glomerular filtration rate [Volume Rate/Area] in Serum, Plasma or
      // Blood by Creatinine-based formula (CKD-EPI)/1.73 sq M" (Component GFR,
      // Property ArVRat, Method CKD-EPI, Scale Qn). Separator normalization
      // covers "CKD-EPI" / "CKD EPI"; "ckdepi" catches the no-separator form.
      "ckd-epi": "62238-1",
      ckdepi: "62238-1",
      egfr: "77147-7",
      // eGFR — Glomerular filtration rate (MDRD default)
      "estimated gfr": "77147-7",
      "estimated glomerular filtration rate": "77147-7",
      "glomerular filtration rate": "77147-7",
      "gfr-est": "77147-7",
      // v0.11.4 audit
      "gfr est": "77147-7",
      \u814E\u7D72\u7403\u904E\u6FFE\u7387: "77147-7",
      \u4F30\u7B97\u814E\u7D72\u7403\u904E\u6FFE\u7387: "77147-7",
      creatinine: "2160-0",
      crea: "2160-0",
      // Some hospitals ship serum creatinine as "CRE" / "CRE(STAT)" (no
      // trailing 'a'), so the longer "crea" key never substring-matches
      // "cre(stat)" and the row fell through with NO LOINC (H fixture: 30×
      // 09015C | CRE(STAT) | mg/dL | Blood unmapped). Panel-scoped bare
      // "cre" is safe: longest-match still routes true "creatinine"/"crea"
      // rows first, and every 09015C row is creatinine/eGFR so there is no
      // collateral (eGFR displays carry no "cre" token). Also covers "cre.".
      cre: "2160-0",
      \u808C\u9178\u9150: "2160-0",
      \u808C\u9150\u9178: "2160-0",
      \u8840\u4E2D\u808C\u9178\u9150: "2160-0",
      // v0.12.1 (SMART app dev bug 10 2026-05-29): some hospitals bill
      // urine creatinine under serum-billing code 09015C with the
      // display annotating "(尿液)". Without explicit urine variants
      // here, longest-match returns the bare "肌酸酐" key → 2160-0
      // serum LOINC even though the row is urine. Longer urine-
      // annotated keys win. 2161-8 = "Creatinine [Mass/volume] in
      // Urine" (verified at loinc.org/2161-8/ earlier).
      "\u808C\u9178\u9150(\u5C3F\u6DB2)(\u534A\u5B9A\u91CF)": "2161-8",
      "\u808C\u9178\u9150(\u5C3F\u6DB2)": "2161-8",
      "\u808C\u9178\u9150(\u5C3F)": "2161-8",
      "\u808C\u9178\u9150(u)": "2161-8",
      // ASCII keys ending in ")" fail \b regex boundary at end of match
      // (same \b-non-word-char-no-boundary issue documented in v0.11.13
      // APTT ratio fix). Use opening-paren-only form so \b at end fires
      // on the word char preceding ")" — "creatinine(u" matches inside
      // "creatinine(u)" with \b after "u".
      "creatinine(u": "2161-8",
      "creatinine(urine": "2161-8",
      // v0.13.1 (app dev urinalysis A/B audit 2026-06-02): A-channel ships
      // the abbreviation "CREA(U)(半定量)" — "creatinine(u" did NOT match
      // (no "creatinine" substring in "crea(u)"), so it fell to global
      // LOINC_MAP "crea" → 2160-0 SERUM creatinine while the B-channel
      // "肌酸酐(尿液)" correctly got urine 2161-8. Add the abbreviated
      // opening-paren form. Same verified LOINC 2161-8 "Creatinine
      // [Mass/volume] in Urine" — WebFetch loinc.org/2161-8 confirmed
      // 2026-06-02 (System Urine). ✅
      "crea(u": "2161-8",
      "crea(urine": "2161-8",
      "u-creatinine": "2161-8",
      "urine creatinine": "2161-8",
      "creatinine, urine": "2161-8"
    },
    // ── PT/INR panel (08026C) ────────────────────────────
    // Taiwan labs bill PT (seconds) and INR (ratio) under the SAME 08026C
    // code, distinguished only by display string. Without this panel
    // table both rows mapped to LOINC 6301-6 (INR); a warfarin trend
    // view would plot a PT=12 sec point as INR=12 (instant overdose
    // alarm) or merge PT and INR into one series. Each LOINC verified
    // at loinc.org:
    //   5902-2  Prothrombin time (PT) in Platelet poor plasma by
    //           Coagulation assay
    //   6301-6  INR in Platelet poor plasma by Coagulation assay
    //   5894-1  Prothrombin time (PT) Control in Platelet poor plasma
    //           by Coagulation assay
    // Order is longest-key-wins inside _findLongestMatch so insertion
    // order doesn't matter, but readability benefits from
    // longest-specific first.
    "08026C": {
      "international normalized ratio": "6301-6",
      // v0.11.9 (SMART app dev report 2026-05-29 + loinc.org audit):
      // 5894-1's canonical name is "Prothrombin time (PT) actual/Normal"
      // — Component=Prothrombin time actual/Normal, Property=RelTime
      // (a RATIO, not a control reading). Earlier v0.9.10 mapping of
      // "PT control" / "對照" / "對照組" / "prothrombin time control"
      // → 5894-1 was based on the misread that 5894-1 was a "control"
      // LOINC. It is NOT — these displays describe lab QC control plasma
      // readings, which have no clinical LOINC fit and are already
      // candidates for the QC filter (looksLikeQcControl). Removing the
      // wrong LOINC mapping so any "Control PT" rows that slip past the
      // QC filter fall back to NHI-coding-only, rather than being
      // mis-labelled as a PT-ratio analyte.
      "prothrombin time": "5902-2",
      "pt (sec)": "5902-2",
      "pt sec": "5902-2",
      "pt-sec": "5902-2",
      \u51DD\u8840\u9176\u539F\u6642\u9593: "5902-2",
      // 脢 (U+8122) is a glyph variant of 酶 (U+9176) that 長庚嘉義 LIS ships
      // on the B (定期上傳) channel: assaY_ITEM_NAME="凝血脢原時間" while the A
      // channel ships "P.T". Without this alias the B row missed 5902-2, fell
      // to the panel default (stripped → no LOINC), and so carried a DIFFERENT
      // cross-channel dedup key than the A row → the A+B PT pair never collapsed
      // and TWO PT (11.9 sec) survived (user report 2026-06-16, 5/18 急診).
      \u51DD\u8840\u8122\u539F\u6642\u9593: "5902-2",
      \u51DD\u8840\u6642\u9593: "5902-2",
      // Bug report 2026-05-27 v0.11.1: 長庚嘉義 LIS prints "P.T" (dot-
      // separated initials). `_keywordMatches` uses \b...\b regex on
      // ASCII keys, and the period in "p.t" breaks the implicit word
      // boundary that "pt" relied on — so `pt` key never matched and
      // path-C fallback returned NHI_TO_LOINC = 6301-6 (INR) for a
      // 11.9 sec PT measurement. Patient-safety-adjacent: SMART app
      // would plot 11.9 in the INR column (looks like fatal INR=11.9
      // → emergency reversal). Adding period-separated variants.
      "p.t": "5902-2",
      "p . t": "5902-2",
      "p t": "5902-2",
      inr: "6301-6",
      pt: "5902-2"
    },
    // ── APTT panel (08036C) ──────────────────────────────
    // Taiwan labs bill TWO sub-rows under 08036C:
    //   1. "APTT" / "活化部份凝血活酶時間" — value in seconds (~25-35 sec
    //      normal). LOINC 14979-9 (aPTT in PPP, Property=Time).
    //   2. "Heparin治療範圍參考倍數" / "APTT data/mean" / "APTT actual/normal"
    //      — ratio (patient APTT / lab normal mean), value ~1.0 ± dimensionless.
    //      LOINC 63561-5 (aPTT actual/normal in PPP, Property=RelTime).
    // Before v0.11.9 BOTH rows mapped to 14979-9 — a ratio value of 1.08
    // displayed under APTT-time column would read as fatally low APTT
    // (normal lower bound ~25 sec), or render seconds units on a unitless
    // ratio. SMART app dev report 2026-05-29.
    //
    // LOINC verified at loinc.org (2026-05-29):
    //   14979-9 Component=aPTT, Property=Time, System=PPP (seconds)
    //   63561-5 Component=aPTT actual/normal, Property=RelTime, System=PPP (ratio)
    //
    // Longest-key-wins via _findLongestMatch — so the longer ratio
    // synonyms get priority over the bare "APTT" → time fallback when
    // a row's display contains both substrings.
    "08036C": {
      // Ratio variants — Taiwan LIS shows "Heparin治療範圍參考倍數"
      // (Heparin therapeutic range reference multiplier) when reporting
      // the APTT ratio for heparin monitoring. Also "APTT data/mean"
      // (denominator-explicit form) and "actual/normal" verbiage.
      heparin\u6CBB\u7642\u7BC4\u570D\u53C3\u8003\u500D\u6578: "63561-5",
      heparin\u6CBB\u7642\u7BC4\u570D: "63561-5",
      \u6CBB\u7642\u7BC4\u570D\u53C3\u8003\u500D\u6578: "63561-5",
      \u53C3\u8003\u500D\u6578: "63561-5",
      "aptt data/mean": "63561-5",
      "aptt actual/normal": "63561-5",
      "aptt ratio": "63561-5",
      "aptt mean": "63561-5",
      // v0.11.13: parenthesised variant ("APTT (ratio)" with space + paren)
      // observed in v0.11.10 lockdown test. \b-bounded "aptt (ratio)" key
      // doesn't match at the trailing ")" (non-word char has no \b before
      // end of string). Workaround: add bare "ratio" key — \b around the
      // ASCII word "ratio" matches even inside parens, longest-match wins
      // over bare "aptt" (5 chars > 4). Combined with "{ratio}" unit
      // pre-canonicalisation, this routes the ratio analyte cleanly.
      ratio: "63561-5",
      "aptt-ratio": "63561-5",
      // Bare time variants — fall through to seconds LOINC.
      aptt: "14979-9",
      "a.p.t.t": "14979-9",
      \u6D3B\u5316\u90E8\u4EFD\u51DD\u8840\u6D3B\u9176\u6642\u9593: "14979-9",
      \u90E8\u4EFD\u51DD\u8840\u6D3B\u9176\u6642\u9593: "14979-9",
      \u51DD\u8840\u6D3B\u9176\u6642\u9593: "14979-9"
    },
    // ── Synovial / body-fluid panel (16008C) ─────────────
    // 16008C bills the full body-fluid analysis: appearance / color /
    // WBC count / differential. Each sub-item has its own specimen-
    // aware LOINC. Panel-scoped table runs before the global one so
    // shorter generic keys (e.g. global "wbc" → 6690-2 blood WBC)
    // can't shadow the body-fluid specific LOINCs. Each LOINC verified
    // at loinc.org:
    // 2026-07-12 — 16008C is SYNOVIAL-fluid-specific (NHI 項目名「關節液常規檢查分析
    // / Synovial Fluid Routine」, 檢體=關節液; web-confirmed 屏基 檢驗手冊), so the
    // sub-items use Synovial-fluid LOINCs (rule #5 有專屬用專屬), replacing the
    // earlier generic "Body fluid" codes. All loinc.org-verified 2026-07-12 (Active,
    // System = Synv fld, property matches the old generic twin):
    //   14664-7 Color of Synovial fluid            (was 6824-7  Body fluid)
    //   26469-7 Leukocytes [#/volume] in Synv fld  (was 26466-3 Body fluid; drops the
    //           "by Manual count" method — method-less is safer when method unknown)
    //   17836-8 Neutrophils/Leukocytes in Synv fld, NFr (was 26513-2 Body fluid; LOINC
    //           v2.79 renamed the component from "…/100 leukocytes" → "…/Leukocytes")
    //   26483-8 Lymphocytes/Leukocytes in Synv fld, NFr (was 11031-2 Body fluid)
    // Diff stays % (NFr). If a real 16008C row reports the diff as absolute #/volume,
    // revisit to the Synovial [#/volume] variants. "sf.*" = Taiwan LIS "SF" (Synovial
    // Fluid) prefix in raw display text.
    // ── Pleural fluid routine analysis (16003C = 胸水常規分析) ──────────────
    // Pleural-fluid-specific LOINCs for the full panel (differential / counts /
    // physical / chemistry), all loinc.org-verified 2026-07-13 (LOINC 2.82) from
    // the "Cell count and Differential panel - Pleural fluid" (34562-9). Differential
    // + counts + physical come from CELL_ALIASES via buildRoutes (same variant lists
    // as blood/synovial — no per-specimen drift). Serous fluids report TOTAL
    // NUCLEATED CELLS (58904-4), and LOINC MERGES monocytes+macrophages into one
    // code (35021-5), so both MONOCYTE and MACROPHAGE route there. Chemistry is
    // listed directly (panel-scoped) so the pleural glucose/LDH/protein rows resolve
    // to their pleural LOINCs without the serum-veto stripping them first.
    "16003C": {
      ...buildRoutes(
        {
          NEUTROPHIL: "30455-0",
          LYMPHOCYTE: "26481-2",
          MONOCYTE: "35021-5",
          MACROPHAGE: "35021-5",
          EOSINOPHIL: "30379-2",
          BASOPHIL: "35070-2",
          REACTIVE_LYMPHOCYTE: "33370-8",
          LEUKOCYTE_COUNT: "26467-1",
          ERYTHROCYTE_COUNT: "26456-4",
          NUCLEATED_CELL_COUNT: "58904-4",
          COLOR: "14662-1",
          APPEARANCE: "14620-9",
          PH: "2750-8",
          SPECIFIC_GRAVITY: "14349-5"
        },
        { scope: "16003C" }
      ),
      // Chemistry — panel-scoped pleural (16003C IS pleural, so bypass serum veto).
      glucose: "2346-5",
      "glucose ac": "2346-5",
      \u8461\u8404\u7CD6: "2346-5",
      ldh: "2530-4",
      "l.d.h.": "2530-4",
      "l d h": "2530-4",
      protein: "2882-9",
      "total protein": "2882-9",
      \u5168\u86CB\u767D: "2882-9",
      "abnormal cell": "34983-7",
      // unidentified cells/leukocytes fraction, %
      "abnormal cells": "34983-7"
    },
    "16008C": {
      // Cell differential — SAME variants as blood CBC (CELL_ALIASES), routed to
      // Synovial-fluid LOINCs. Via buildRoutes the synovial panel now gets the FULL
      // variant set (lym / 淋巴 / neut / 嗜中性球 / mono …) the hand-copied list was
      // missing — the drift this refactor fixes — plus the 16008C-scoped LIS typo
      // "lymohocyte" (missing 'p', real P20105). The bare "neutrophil"/"lym" keys
      // also match the Taiwan "SF." prefix ("sf neutrophil" ⊃ \bneutrophil\b), so
      // the old redundant "sf.*" keys are gone. Monocyte %: the ONLY Synovial NFr
      // differential code is the mono+macro merge 21395-9 "Monocytes+Macrophages/
      // Leukocytes:NFr:Pt:Synv fld:Qn:Manual count" (loinc.org 2026-07-13) — there
      // is NO monocyte-only NFr for synovial, same mono+macro merge convention as
      // the pleural 35021-5. Per rule #5「有專屬用專屬」use the Synovial-specific
      // 21395-9 over the generic body-fluid 26487-9; the Manual-count method axis
      // (siblings 17836-8/26483-8 are method-less) is the only synovial option and
      // is accurate for a manual-microscopy differential. MACROPHAGE routes here
      // too (the code IS mono+macro). System=Synovial → specimen resolves cleanly.
      ...buildRoutes(
        {
          NEUTROPHIL: "17836-8",
          LYMPHOCYTE: "26483-8",
          MONOCYTE: "21395-9",
          MACROPHAGE: "21395-9"
        },
        { scope: "16008C" }
      ),
      "sf.wbc": "26469-7",
      "sf wbc": "26469-7",
      wbc: "26469-7",
      leukocyte: "26469-7",
      leukocytes: "26469-7",
      "sf.rbc": "26458-0",
      // Erythrocytes [#/volume] in Synovial fluid
      "sf rbc": "26458-0",
      rbc: "26458-0",
      erythrocyte: "26458-0",
      erythrocytes: "26458-0",
      "sf.color": "14664-7",
      "sf color": "14664-7",
      color: "14664-7",
      \u984F\u8272: "14664-7",
      "sf.appearance": "29605-3",
      // Appearance of Synovial fluid
      "sf appearance": "29605-3",
      appearance: "29605-3",
      \u5916\u89C0: "29605-3",
      "sf.viscosity": "14950-0",
      // Viscosity of Synovial fluid, Qualitative
      "sf viscosity": "14950-0",
      viscosity: "14950-0",
      \u9ECF\u7A20\u5EA6: "14950-0",
      \u9ECF\u5EA6: "14950-0",
      glucose: "2348-1",
      // Glucose [Mass/volume] in Synovial fluid
      glucosc: "2348-1",
      // LIS typo (missing 'e') — real P20105 "Glucosc"
      \u8461\u8404\u7CD6: "2348-1",
      protein: "2886-0",
      // Protein [Mass/volume] in Synovial fluid
      \u86CB\u767D: "2886-0",
      \u86CB\u767D\u8CEA: "2886-0"
    },
    // ── CBC with auto diff (08013C) ──────────────────────
    // 08013C reports each cell type as a PERCENT of leukocytes (per 100),
    // distinct LOINCs from the absolute-count series (08010C Eosinophil
    // count → 711-2 is a different billing code with the count semantics).
    // Adding these here so under 08013C the diff entries route to the
    // /100 leukocytes LOINCs instead of falling to global eosinophil
    // count or "白血球" → WBC.
    "08013C": {
      // Differential percentages — shared with the CBC sibling billing
      // codes (08002C / 08003C / 08004C / 08006C) above; see
      // CBC_DIFF_KEYS const for the source of truth (includes singular
      // "Segment" Part 4 fix + 淋巴白血球 / 單核白血球 / 嗜中性白血球
      // wider CJK variants added v0.9.10 Part 6 N3).
      ...CBC_DIFF_KEYS,
      // v0.11.11 (SMART app dev bug 2 2026-05-29): basic CBC component
      // displays (Hct, Hb, RBC indices) also appear under 08013C diff
      // panel printout in some Taiwan LIS. Without these mappings, e.g.
      // "Hct(血球容積比)" rows previously fell to panel LOINC 57021-8
      // (CBC W Auto Diff panel). Adding the shared component keys here
      // routes basic CBC entries to their canonical LOINCs.
      ...CBC_COMPONENT_KEYS,
      // WBC absolute count can also appear on the diff panel printout.
      \u767D\u8840\u7403: "6690-2",
      wbc: "6690-2"
    }
  };
  var LOINC_MAP = {
    // ── Glucose ───────────────────────────────────────
    // Display-keyword fallback only kicks in when NO NHI code is
    // present (dashboard rows, LLM-extracted text). When the NHI code
    // IS present, 09005C → 1558-6 (Fasting) and 09140C → 2345-7
    // (generic) wins directly via _NHI_TO_LOINC.
    //
    // Faithful-transport principle: the bridge does NOT re-interpret
    // display strings like "FINGER SUGAR" as a different LOINC — it
    // preserves the raw display in `code.text` and the original NHI
    // code in `code.coding`. The SMART app does specimen/method-aware
    // grouping on the consumer side (see SMART app handoff doc).
    "fasting glucose": "1558-6",
    \u7A7A\u8179\u8840\u7CD6: "1558-6",
    "glu-ac": "1558-6",
    "glucose ac": "1558-6",
    glucose: "2345-7",
    \u8840\u7CD6: "2345-7",
    glu: "2345-7",
    // HbA1c MUST appear before generic "hb" entries so the longest-prefix
    // match wins for the "HbA1c" display string. Other A1c synonyms…
    hba1c: "4548-4",
    \u91A3\u5316\u8840\u7D05\u7D20: "4548-4",
    a1c: "4548-4",
    hemoglobin: "718-7",
    \u8840\u7D05\u7D20: "718-7",
    hgb: "718-7",
    hb: "718-7",
    // CBC diff — eosinophil count must precede the bare 'wbc'/'白血球'
    // keys (which would otherwise win as substrings).
    // 711-2 verified at loinc.org: 'Eosinophils [#/volume] in Blood
    // by Automated count'.
    \u55DC\u9178\u6027\u767D\u8840\u7403: "711-2",
    \u55DC\u4F0A\u7D05\u6027\u767D\u8840\u7403: "711-2",
    eosinophil: "711-2",
    eosinophils: "711-2",
    // Other diff cells — added v0.9.10 Part 6 N7 (long庚嘉義 row had
    // display="Neutrophil" with EMPTY coding array, ie. no NHI code
    // context for panel routing to kick in). When no NHI code, fall
    // back to /100 leukocytes form since that's the dominant diff
    // context in Taiwan LIS. Absolute-count form has its own dedicated
    // billing codes (08010C eosinophil count etc.) that resolve via
    // NHI_TO_LOINC path A before this global table is consulted.
    "neutrophilic segment": "770-8",
    neutrophil: "770-8",
    neutrophils: "770-8",
    segmented: "770-8",
    segment: "770-8",
    segments: "770-8",
    \u55DC\u4E2D\u6027\u767D\u8840\u7403: "770-8",
    \u55DC\u4E2D\u6027\u7403: "770-8",
    \u4E2D\u6027\u7403: "770-8",
    lymphocyte: "736-9",
    lymphocytes: "736-9",
    \u6DCB\u5DF4\u767D\u8840\u7403: "736-9",
    \u6DCB\u5DF4\u7403: "736-9",
    \u6DCB\u5DF4\u7D30\u80DE: "736-9",
    monocyte: "5905-5",
    monocytes: "5905-5",
    \u55AE\u6838\u767D\u8840\u7403: "5905-5",
    \u55AE\u6838\u7403: "5905-5",
    basophil: "706-2",
    basophils: "706-2",
    \u55DC\u9E7C\u6027\u767D\u8840\u7403: "706-2",
    \u55DC\u9E7C: "706-2",
    // Microalbumin (urine) — same Part 6 N7 reasoning: when no NHI
    // code arrives, "Micro Albumin" / "MALB" display should still
    // route to the right LOINC instead of falling to null.
    "micro-albumin": "14957-5",
    microalbumin: "14957-5",
    "micro albumin": "14957-5",
    malb: "14957-5",
    \u5FAE\u5C0F\u767D\u86CB\u767D: "14957-5",
    wbc: "6690-2",
    \u767D\u8840\u7403: "6690-2",
    platelet: "777-3",
    platelets: "777-3",
    // v1.2.9 plural (see CBC_COMPONENT_KEYS note)
    \u8840\u5C0F\u677F: "777-3",
    plt: "777-3",
    reticulocyte: "4679-7",
    // v1.2.9 — Retic % (NFr), WebFetch-verified 2026-07-06
    reticulocytes: "4679-7",
    \u7DB2\u72C0\u7D05\u8840\u7403: "4679-7",
    \u7DB2\u7E54\u7D05\u8840\u7403: "4679-7",
    // RBC + RBC indices — verified LOINCs (loinc.org):
    // 789-8  Erythrocytes #/vol Blood Auto              → RBC
    // 785-6  Erythrocyte mean corpuscular hemoglobin    → MCH
    // Long CJK forms first (LDL/cholesterol pattern) so '平均紅血球
    // 血色素' wins over 紅血球.
    \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20: "785-6",
    rbc: "789-8",
    \u7D05\u8840\u7403: "789-8",
    mch: "785-6",
    // Urine creatinine — MUST appear before generic 'creatinine' so
    // rows like 'U-CRE 尿液肌酸酐' or 'Creatinine(U)' resolve to the
    // urine LOINC (2161-8) instead of being shadowed by the serum
    // default (2160-0). Same longest-specific-first ordering as
    // the fasting-vs-random glucose block.
    "urine creatinine": "2161-8",
    "creatinine urine": "2161-8",
    "creatinine(u)": "2161-8",
    "u-cre": "2161-8",
    "u-crea": "2161-8",
    \u5C3F\u6DB2\u808C\u9178\u9150: "2161-8",
    creatinine: "2160-0",
    \u808C\u9178\u9150: "2160-0",
    \u808C\u9150\u9178: "2160-0",
    // Taiwan variant spelling
    crea: "2160-0",
    bun: "3094-0",
    \u5C3F\u7D20\u6C2E: "3094-0",
    ast: "1920-8",
    alt: "1742-6",
    ferritin: "2276-4",
    \u8840\u6E05\u9435\u86CB\u767D: "2276-4",
    ferr: "2276-4",
    // Vital-signs from 成人預防保健 (IHKE3402) — separate code namespace
    // but the lookup is by display-name substring, same as for labs.
    "body height": "8302-2",
    "body weight": "29463-7",
    bmi: "39156-5",
    // Waist circumference — measurement LOINC (8280-0). 56086-2 is
    // the 'Adult Waist Circumference Protocol' code, which is a
    // survey/protocol descriptor, NOT a numeric measurement
    // (verified at loinc.org). NHI 健保 reports a single waistline
    // number per visit, so the measurement code is correct.
    "waist circumference": "8280-0",
    "systolic blood pressure": "8480-6",
    "diastolic blood pressure": "8462-4",
    // Lipid panel — method-qualified LDL aliases precede generic LDL; all LDL/
    // HDL aliases precede bare cholesterol. Bare LDL does not establish direct
    // assay versus Friedewald calculation, so it uses methodless 2089-1.
    "direct ldl cholesterol": "18262-6",
    "ldl cholesterol direct": "18262-6",
    "ldl-c direct": "18262-6",
    "ldl direct": "18262-6",
    \u76F4\u63A5\u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "18262-6",
    "calculated ldl cholesterol": "13457-7",
    "ldl cholesterol calculated": "13457-7",
    "ldl-c calculated": "13457-7",
    "ldl calculated": "13457-7",
    "ldl friedewald": "13457-7",
    \u8A08\u7B97\u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "13457-7",
    "ldl cholesterol": "2089-1",
    "ldl-cholesterol": "2089-1",
    \u4F4E\u5BC6\u5EA6\u81BD\u56FA\u9187: "2089-1",
    \u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "2089-1",
    "ldl-c": "2089-1",
    ldl: "2089-1",
    "hdl cholesterol": "2085-9",
    "hdl-cholesterol": "2085-9",
    \u9AD8\u5BC6\u5EA6\u81BD\u56FA\u9187: "2085-9",
    \u9AD8\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "2085-9",
    "hdl-c": "2085-9",
    hdl: "2085-9",
    // Total cholesterol — bare 'cholesterol' only fires AFTER the
    // LDL/HDL-prefixed variants above have been checked.
    "total cholesterol": "2093-3",
    "t-cholesterol": "2093-3",
    \u8840\u6E05\u7E3D\u81BD\u56FA\u9187: "2093-3",
    \u7E3D\u81BD\u56FA\u9187: "2093-3",
    cholesterol: "2093-3",
    triglyceride: "2571-8",
    \u4E09\u9178\u7518\u6CB9\u916F: "2571-8",
    "uric acid": "3084-1",
    "ckd-epi": "62238-1",
    // CKD-EPI eGFR variant (longest-match wins over "egfr")
    ckdepi: "62238-1",
    egfr: "77147-7",
    // MDRD default (77147-7 replaces discouraged 33914-3)
    hbsag: "5196-1",
    "anti-hcv": "16128-1",
    // ── Standalone urine dipstick tests (v0.18.2, 2026-06-09) ──────
    // Scenario D: some patients have a SINGLE urine analyte billed under an
    // unrecognized / batch code (e.g. 成人預防保健 code "21", or a hospital
    // custom code) — NOT under the 06012C/06013C urinalysis panels. Those
    // rows never reach PANEL_LOINC_MAP, so without specimen-qualified GLOBAL
    // keys they'd fall to the panel default or a serum LOINC. Every key here
    // MUST carry the 尿/urine qualifier — NEVER bare 蛋白/糖/protein/glucose
    // (would shadow serum tests) and NEVER bare 尿 (v0.12.6 尿酸 mis-tag
    // lesson, rule #7). Known serum codes short-circuit at findLoincDetailed
    // Step A before this map is consulted, so these can't poach them.
    // LOINCs reuse the urine-dipstick set already verified for 06013C.
    "urine protein": "20454-5",
    // Protein [Presence] in Urine by Test strip
    "u-pro": "20454-5",
    \u5C3F\u86CB\u767D: "20454-5",
    "urine glucose": "5792-7",
    \u5C3F\u7CD6: "5792-7",
    "urine ketone": "5797-6",
    \u5C3F\u916E\u9AD4: "5797-6",
    "urine bilirubin": "5770-3",
    \u5C3F\u81BD\u7D05\u7D20: "5770-3",
    "urine urobilinogen": "5818-0",
    \u5C3F\u81BD\u7D20\u539F: "5818-0",
    \u5C3F\u81BD\u7D20\u5143: "5818-0",
    // 元/原 spelling variant
    "urine nitrite": "5802-4",
    \u5C3F\u4E9E\u785D\u9178\u9E7D: "5802-4",
    "urine occult blood": "5794-3",
    \u5C3F\u6F5B\u8840: "5794-3",
    "urine leukocyte esterase": "5799-2",
    \u5C3F\u767D\u8840\u7403\u916F\u8122: "5799-2",
    \u5C3F\u767D\u8840\u7403\u916F\u9176: "5799-2",
    // 脢/酶 variant
    "urine specific gravity": "5811-5",
    \u5C3F\u6BD4\u91CD: "5811-5",
    "urine ph": "5803-2",
    \u5C3F\u9178\u9E7C\u503C: "5803-2",
    // Global blood-gas fallbacks for codeless rows with independent blood/vessel
    // evidence. Keep these vessel- and method-neutral; 09041B itself routes first
    // through its panel-scoped table, and observation.ts promotes a proven venous
    // group to the corresponding BldV members.
    ph: "11558-4",
    // pH of Blood
    pco2: "11557-6",
    // Carbon dioxide partial pressure in Blood
    po2: "11556-8",
    // Oxygen partial pressure in Blood
    hco3: "1959-6",
    // Bicarbonate Moles/volume in Blood
    bicarbonate: "1959-6",
    tco2: "2028-9",
    // Total CO2 Moles/volume in Serum or Plasma
    // Base excess → generic 11555-0 (v1.2.10, user 2026-07-06). 2026-05-27 had
    // split ABE→1925-7(art) / SBE→1927-3(ven) to stop LOINC-pivot collapse, but
    // those are vessel over-claims for 「血液氣體分析」(unspecified vessel). LOINC
    // has no generic-blood *standard* base-excess code (only vessel-coded
    // 19235-1/19237-7). SBE therefore shares 11555-0 only as an internal lookup
    // candidate: final mapping emits 19237-7 for venous evidence or no LOINC.
    abe: "11555-0",
    // ABE — Base excess in Blood by calculation
    "a.b.e": "11555-0",
    "actual base excess": "11555-0",
    sbe: "11555-0",
    // provisional lookup only; final mapper requires venous
    "s.b.e": "11555-0",
    "standard base excess": "11555-0",
    sbc: "1959-6",
    // provisional lookup only; final mapper requires venous
    saturat: "20564-1",
    // Oxygen saturation in Blood, method unspecified
    sao2: "20564-1",
    sat: "20564-1",
    // NHI display shows just "SAT"
    // Synovial / body-fluid components (16008C parent above).
    "sf.color": "14664-7",
    // Color of Synovial fluid (16008C=關節液常規, synovial-specific 2026-07-12; was generic 6824-7)
    // NOTE: 8255-2 / 13948-5 previously listed here both turned out
    // to be unrelated LOINCs (verified loinc.org — 8255-2 is
    // 'Service comment 13', 13948-5 is 'Coccidioides immitis IgM
    // Ab'). Fluid Appearance / RBC DO have specimen-specific LOINCs and
    // are now mapped per fluid (2026-07-13): pleural Appearance 14620-9,
    // pleural RBC 26456-4 (see the 16003C panel + CELL_ALIASES). Global
    // sf.* stay minimal; the fluid panels carry the full set.
    "sf.wbc": "26469-7",
    // Leukocytes [#/volume] in Synovial fluid (was generic body fluid 26466-3)
    "sf.neutrophil": "17836-8",
    // Neutrophils/Leukocytes in Synovial fluid, NFr (was generic 26513-2)
    "sf.lympho": "26483-8",
    // Lymphocytes/Leukocytes in Synovial fluid, NFr (was generic 11031-2)
    // ══════════════════════════════════════════════════════════════════
    // Medical-calculator LOINC gaps (2026-07-03, SMART app calculator
    // feature — MDCalc-style). Every LOINC WebFetch-verified at loinc.org
    // per rule #5 (Component/Property/System/Scale documented inline).
    // These are display-keyword fallbacks (Path B in findLoincDetailed):
    // reached only when the analyte's NHI 醫令碼 is NOT in NHI_TO_LOINC, so
    // they never shadow an existing single-analyte NHI code (Path A wins
    // first). Urine analytes use SPECIMEN-QUALIFIED keys ONLY (rule #7 —
    // never bare 鈉/sodium/滲透壓 that would poach the serum electrolytes).
    // ── Priority 1: ABG — FiO2 (unlocks A-a gradient, oxygenation index,
    //    full SOFA). Other ABG members (pH/pCO2/pO2/HCO3/BE/SaO2) already
    //    routed in the 09041B block above. 3150-0 = Oxygen/Gas.total, VFr,
    //    Inhl gas, Qn — loinc.org states "percent of oxygen inhaled (FIO2)".
    fio2: "3150-0",
    "fi o2": "3150-0",
    "inhaled oxygen": "3150-0",
    "inspired oxygen": "3150-0",
    \u5438\u5165\u6C27\u6FC3\u5EA6: "3150-0",
    // ── Priority 2: urine electrolytes / chemistry (unlock FENa, FEUrea,
    //    urine anion gap, TTKG). All in-Urine LOINCs verified 2026-07-03.
    //    Urine creatinine (2161-8) already distinguishable above — the
    //    serum form is 2160-0, so the two specimens carry different LOINCs.
    "urine sodium": "2955-3",
    // Sodium [Moles/volume] in Urine (SCnc/Qn)
    "urine na": "2955-3",
    "u-na": "2955-3",
    \u5C3F\u9209: "2955-3",
    \u5C3F\u6DB2\u9209: "2955-3",
    "urine potassium": "2828-2",
    // Potassium [Moles/volume] in Urine (SCnc/Qn)
    "urine k": "2828-2",
    "u-k": "2828-2",
    \u5C3F\u9240: "2828-2",
    \u5C3F\u6DB2\u9240: "2828-2",
    "urine chloride": "2078-4",
    // Chloride [Moles/volume] in Urine (SCnc/Qn)
    "urine cl": "2078-4",
    "u-cl": "2078-4",
    \u5C3F\u6C2F: "2078-4",
    \u5C3F\u6DB2\u6C2F: "2078-4",
    "urine urea nitrogen": "3095-7",
    // Urea nitrogen [Mass/volume] in Urine (MCnc/Qn)
    "urine bun": "3095-7",
    "u-bun": "3095-7",
    \u5C3F\u6DB2\u5C3F\u7D20\u6C2E: "3095-7",
    // qualified — bare 尿素氮 above = serum BUN 3094-0
    "urine osmolality": "2695-5",
    // Osmolality of Urine (Osmol/Qn)
    "urine osm": "2695-5",
    \u5C3F\u6DB2\u6EF2\u900F\u58D3: "2695-5",
    \u5C3F\u6EF2\u900F\u58D3: "2695-5",
    // ── Priority 3: osmolar-gap & toxicology ──────────────────────────
    // Serum osmolality already routes via NHI 08075C → 2692-2 (Path A);
    // these are display fallbacks. Bare "osmolality"/滲透壓 default to
    // SERUM (the dominant standalone form + what the osmolar-gap calc
    // needs); the urine variants above are longer keys → win when present.
    "serum osmolality": "2692-2",
    "plasma osmolality": "2692-2",
    osmolality: "2692-2",
    osmol: "2692-2",
    \u8840\u6E05\u6EF2\u900F\u58D3: "2692-2",
    \u8840\u6F3F\u6EF2\u900F\u58D3: "2692-2",
    \u6EF2\u900F\u58D3: "2692-2",
    ethanol: "5643-2",
    // Ethanol [Mass/volume] in Serum or Plasma (MCnc/Qn)
    etoh: "5643-2",
    \u4E59\u9187: "5643-2",
    \u9152\u7CBE\u6FC3\u5EA6: "5643-2",
    salicylate: "4024-6",
    // Salicylates [Mass/volume] in Serum or Plasma (MCnc/Qn)
    salicylates: "4024-6",
    \u6C34\u694A\u9178: "4024-6",
    // Acetaminophen — the QUANTITATIVE 3298-7 (MCnc/Qn) for the Rumack-
    // Matthew nomogram, NOT the presence-only 3297-9 (PrThr/Ord).
    acetaminophen: "3298-7",
    paracetamol: "3298-7",
    \u4E59\u91AF\u80FA\u915A: "3298-7",
    // ── Other gaps (single calculator each / panel completion) ─────────
    insulin: "20448-7",
    // Insulin [Units/volume] in Serum or Plasma (ACnc/Qn) — HOMA-IR
    \u80F0\u5CF6\u7D20: "20448-7",
    ammonia: "22763-7",
    // Ammonia [Mass/volume] in Plasma — also NHI 09037C; molar unit → 16362-6 via ammoniaLoincFix
    \u8840\u6C28: "22763-7",
    amylase: "1798-8",
    // Amylase [Enzymatic activity/volume] in Serum or Plasma (CCnc/Qn) — Ranson
    \u6FB1\u7C89\u9176: "1798-8",
    \u6FB1\u7C89\u9175\u7D20: "1798-8",
    // BNP vs NT-proBNP: distinct analytes. "bnp" \b-bounded does NOT match
    // "nt-probnp" (no left boundary after "pro"). The shared NHI 12193C code is
    // resolved by its panel-specific aliases above; longer probnp keys also let
    // codeless rows resolve when their display is explicit.
    bnp: "30934-4",
    // Natriuretic peptide B [Mass/volume] in Serum or Plasma (MCnc/Qn)
    "nt-probnp": "33762-6",
    probnp: "33762-6",
    // High-sensitivity troponin — plain Troponin I stays 10839-9 (NHI 09099C).
    "hs-troponin i": "89579-7",
    // Troponin I.cardiac ... by High sensitivity method
    "high sensitivity troponin i": "89579-7",
    "hs-tni": "89579-7",
    hstni: "89579-7",
    "hs-troponin t": "67151-1",
    // Troponin T.cardiac ... by High sensitivity method
    "high sensitivity troponin t": "67151-1",
    "hs-tnt": "67151-1",
    hstnt: "67151-1",
    // Free T3 (09107C via Path A when coded). Separator normalization now folds
    // "Free-T3"/"Free.T3"/"Free (T3)" → "free t3", so one key covers them; the
    // concatenated no-separator form "freet3" still needs its own key.
    "free t3": "3051-0",
    // Triiodothyronine (T3) Free [Mass/volume] in Serum or Plasma (MCnc/Qn)
    "free triiodothyronine": "3051-0",
    ft3: "3051-0",
    freet3: "3051-0",
    "f-t3": "3051-0",
    \u6E38\u96E2\u4E09\u7898\u7532\u72C0\u817A\u7D20: "3051-0",
    \u6E38\u96E2t3: "3051-0",
    // Free T4 (09106C via Path A when coded) — display keys for codeless rows,
    // symmetric with Free T3. 3024-7 = Thyroxine (T4) free, MCnc, Ser/Plas.
    "free t4": "3024-7",
    "free thyroxine": "3024-7",
    ft4: "3024-7",
    freet4: "3024-7",
    "f-t4": "3024-7",
    \u6E38\u96E2\u7532\u72C0\u817A\u7D20: "3024-7",
    \u6E38\u96E2t4: "3024-7",
    // ── Wave 2 MDCalc gaps (2026-07-03) — LOINC WebFetch-verified loinc.org.
    // CK / CK-MB / ESR / PTH / Total T4 also have NHI codes (Path A); these
    // display keys catch codeless / unknown-code rows. Fibrinogen / Haptoglobin
    // / Total T3 are display-routed only (NHI code not confidently confirmed).
    ck: "2157-6",
    // Creatine kinase [Enzymatic activity/volume] S/P — rhabdomyolysis
    cpk: "2157-6",
    "creatine kinase": "2157-6",
    \u808C\u9178\u6FC0\u9176: "2157-6",
    \u808C\u9178\u78F7\u5316\u9176: "2157-6",
    // CK-MB — longer keys win over bare "ck" via longest-match.
    "ck-mb": "13969-1",
    // Creatine kinase.MB [Mass/volume] S/P (→ "ck mb" after sep-normalize)
    ckmb: "13969-1",
    "cpk-mb": "13969-1",
    "creatine kinase mb": "13969-1",
    fibrinogen: "3255-7",
    // Fibrinogen [Mass/volume] in Platelet poor plasma by Coagulation assay — DIC/ISTH
    \u7E96\u7DAD\u86CB\u767D\u539F: "3255-7",
    // FDP (纖維蛋白（原）降解產物) — DIC marker, single-specimen plasma. NHI 08038B
    // (600pt, 2.0mL plasma — web-confirmed 支付標準 + 臺中榮總/祐健 檢驗手冊 2026-07-12);
    // 北榮 CCU 大數據院內名 "FDP" (research-data PFKEY join). LOINC 30226-5
    // "Fibrin+Fibrinogen fragments [Mass/volume] in Platelet poor plasma" — Qn MCnc,
    // matches TW FDP ref range <5 μg/mL (loinc.org/30226-5, WebFetch-verified). Display-
    // routed (suffix-agnostic): catches both historical 08038B and any C-era sibling.
    fdp: "30226-5",
    \u7E96\u7DAD\u86CB\u767D\u964D\u89E3\u7522\u7269: "30226-5",
    \u7E96\u7DAD\u86CB\u767D\u539F\u964D\u89E3\u7522\u7269: "30226-5",
    \u7E96\u7DAD\u5143\u86CB\u767D\u5206\u5316\u7269: "30226-5",
    haptoglobin: "4542-7",
    // Haptoglobin [Mass/volume] S/P — hemolysis workup
    hapto: "4542-7",
    \u8840\u7D05\u7D20\u7D50\u5408\u86CB\u767D: "4542-7",
    \u7D50\u5408\u86CB\u767D: "4542-7",
    esr: "30341-2",
    // Erythrocyte [Sedimentation Rate] in Blood
    "erythrocyte sedimentation": "30341-2",
    \u7D05\u8840\u7403\u6C89\u964D: "30341-2",
    \u8840\u6C89: "30341-2",
    // PTH — intact form. Avoid bare "pth" colliding? no other pth key exists.
    pth: "2731-8",
    // Parathyrin.intact [Mass/volume] S/P — CKD-MBD / hypercalcemia
    ipth: "2731-8",
    "intact pth": "2731-8",
    "parathyroid hormone": "2731-8",
    parathyrin: "2731-8",
    \u526F\u7532\u72C0\u817A\u7D20: "2731-8",
    // Total T4 / Total T3 — QUALIFIED keys only. Never bare "thyroxine"/"t4"/
    // "t3"/四碘甲狀腺素/三碘甲狀腺素 (would poach the Free T4/T3 rows). Free
    // forms have their own NHI codes (09106C / 09107C) + "free …" keys above.
    "total t4": "3026-2",
    // Thyroxine (T4) [Mass/volume] S/P — thyroid storm (Burch-Wartofsky)
    "total thyroxine": "3026-2",
    \u7532\u72C0\u817A\u7D20\u7E3D\u91CF: "3026-2",
    \u56DB\u7898\u7532\u72C0\u817A\u7D20\u7E3D\u91CF: "3026-2",
    "total t3": "3053-6",
    // Triiodothyronine (T3) [Mass/volume] S/P
    "total triiodothyronine": "3053-6",
    \u4E09\u7898\u7532\u72C0\u817A\u7D20\u7E3D\u91CF: "3053-6",
    // ── 院所命名補充 (2026-07-03, web-surveyed hospital lab pages) ─────
    // Real display strings collected from 榮總/慈濟/長庚/祐健/奇美/彰基 lab
    // catalogs — separator-insensitive matcher already folds punctuation, so
    // these cover the ORDER-reversed and CHARACTER-variant forms it can't.
    // Urine electrolytes: "Na (urine)" (ion-first order), "24小時尿中鈉" (尿中≠尿).
    "na urine": "2955-3",
    \u5C3F\u4E2D\u9209: "2955-3",
    "k urine": "2828-2",
    \u5C3F\u4E2D\u9240: "2828-2",
    "cl urine": "2078-4",
    \u5C3F\u4E2D\u6C2F: "2078-4",
    \u5C3F\u4E2D\u5C3F\u7D20\u6C2E: "3095-7",
    \u5C3F\u4E2D\u6EF2\u900F\u58D3: "2695-5",
    // Osmolality: "Osmolarity" spelling; "血液滲透力" (力 vs 壓 char variant).
    osmolarity: "2692-2",
    \u8840\u6DB2\u6EF2\u900F\u529B: "2692-2",
    \u8840\u6E05\u6EF2\u900F\u529B: "2692-2",
    // Ethanol: "Ethyl Alcohol" longhand + 10817B (some院所 bill this vs 10807B).
    "ethyl alcohol": "5643-2",
    // Acetaminophen: "APAP" abbr + 乙醯氨酚 (氨 vs 胺) + 乙醯對氨基酚 longhand.
    apap: "3298-7",
    \u4E59\u91AF\u6C28\u915A: "3298-7",
    \u4E59\u91AF\u5C0D\u6C28\u57FA\u915A: "3298-7",
    // CK/CK-MB extra Chinese longhand.
    \u808C\u9178\u78F7\u9178\u6FC0\u9176: "2157-6",
    \u808C\u9178\u6FC0\u9176mb: "13969-1",
    // Haptoglobin "HAPT" abbr (VGHKS).
    hapt: "4542-7",
    // "Pro-BNP" / "proBNP" (no NT- prefix) is the precursor = NT-proBNP in TW
    // practice — route to 33762-6, NOT bare BNP 30934-4. Longer key wins over
    // the "bnp" token that separator-normalized "pro bnp" would otherwise hit.
    "pro bnp": "33762-6",
    // Iron — TIBC (2500-7) is a longer key → wins for "total iron binding
    // capacity"; bare 鐵 deliberately NOT used (would poach 鐵蛋白/ferritin).
    "serum iron": "2498-4",
    // Iron [Mass/volume] in Serum or Plasma (MCnc/Qn)
    iron: "2498-4",
    fe: "2498-4",
    \u8840\u6E05\u9435: "2498-4",
    tibc: "2500-7",
    // Iron binding capacity [Mass/volume] in Serum or Plasma — also NHI 09035C
    "iron binding capacity": "2500-7",
    "total iron binding capacity": "2500-7",
    \u7E3D\u9435\u7D50\u5408\u80FD: "2500-7",
    \u7E3D\u9435\u7D50\u5408\u529B: "2500-7",
    \u7E3D\u9435\u7D50\u5408\u80FD\u529B: "2500-7",
    \u7E3D\u9435\u7D50\u5408\u5BB9\u91CF: "2500-7",
    uibc: "2501-5",
    "unsaturated iron binding capacity": "2501-5",
    \u672A\u98FD\u548C\u9435\u7D50\u5408\u80FD: "2501-5",
    "transferrin saturation": "2502-3",
    "iron saturation": "2502-3",
    \u9435\u98FD\u548C\u5EA6: "2502-3",
    \u8F49\u9435\u86CB\u767D\u98FD\u548C\u5EA6: "2502-3"
  };
  var LOINC_DISPLAY = {
    // ── Urinalysis (06013C panel sub-items) ──────────
    // Most critical block — NHI's "Color 尿 顏  ..." style labels are
    // what triggers downstream Chinese-substring labelling bugs.
    "5803-2": "pH of Urine",
    "5811-5": "Specific gravity of Urine",
    "5770-3": "Bilirubin Urine Ql",
    "5802-4": "Nitrite Urine Ql",
    "5778-6": "Color of Urine",
    "5767-9": "Appearance of Urine",
    "5818-0": "Urobilinogen Urine Ql",
    "19161-9": "Urobilinogen [Units/volume] in Urine by Test strip",
    // Canonical Long Common Name per loinc.org/20454-5/ (verified 2026-06-08):
    // Component=Protein, Property=PrThr (Presence/Threshold), Scale=Ord,
    // System=Urine, Method=Test strip. The earlier "Protein Mass/Vol in Urine"
    // display was wrong (Mass/Vol implies the Qn 2888-6 form) and contradicted
    // the Ord/PrThr scale this code actually carries — rule #1 violation.
    "20454-5": "Protein [Presence] in Urine by Test strip",
    // v0.12.2 (SMART app dev v0.12.1 audit 2026-05-29): quantitative
    // urine protein LOINC. Verified at loinc.org/2888-6/ —
    //   Component=Protein, Property=MCnc (Mass concentration),
    //   System=Urine, Scale=Qn (Quantitative), Class=UA.
    // Distinct from 20454-5 which is Property=PrThr (Presence) /
    // Scale=Ord (Ordinal) — dipstick presence test. Bridge routes
    // numeric mg/dL values to 2888-6 and qualitative dipstick values
    // (Negative / Trace / 1+ / "4+ (2000)" combined) to 20454-5 — see
    // classifyUrineProteinValue() in observation.ts.
    "2888-6": "Protein [Mass/volume] in Urine",
    "2889-4": "Protein [Mass/time] in 24 hour Urine",
    // Total-protein per-specimen codes (2026-07-04, WebFetch-verified loinc.org).
    "2881-1": "Protein [Mass/volume] in Body fluid",
    "2880-3": "Protein [Mass/volume] in Cerebral spinal fluid",
    "14957-5": "Microalbumin Mass/Vol in Urine",
    // Canonical Long Common Name (LOINC 2.82). This is also the official
    // Map-To for discouraged random-urine panel 34535-5.
    "14959-1": "Microalbumin/Creatinine [Mass Ratio] in Urine",
    "5792-7": "Glucose Urine Ql",
    "5797-6": "Ketones Urine Ql",
    "5794-3": "Hemoglobin Urine Ql",
    "5799-2": "Leukocytes Urine Ql",
    // 24356-8 official Long Common Name is "Urinalysis complete panel -
    // Urine" (WebFetch loinc.org/24356-8 2026-06-13) — corrected from the
    // earlier "Urinalysis Macro Panel" (that name belongs to 24357-6, the
    // dipstick-only panel). 06012C 尿液一般檢查 = dipstick + sediment
    // microscopy = the COMPLETE panel, so the code 24356-8 is right; only
    // its display string was wrong.
    "24356-8": "Urinalysis complete panel - Urine",
    "24365-9": "Urinalysis microscopic panel - Urine sediment",
    // ── Urine sediment microscopy (06012C, v0.18.2 2026-06-09) ──────
    // Canonical Long Common Names per loinc.org (WebFetch-verified
    // 2026-06-09, rule #5). Component / Property / System / Scale / Method
    // documented at the URINALYSIS_ANALYTE_KEYS microscopy block.
    "5787-7": "Epithelial cells [#/area] in Urine sediment by Microscopy high power field",
    "5821-4": "Leukocytes [#/area] in Urine sediment by Microscopy high power field",
    "5808-1": "Erythrocytes [#/volume] in Urine sediment by Microscopy high power field",
    "25145-4": "Bacteria [Presence] in Urine sediment by Light microscopy",
    "5783-6": "Unidentified crystals [Presence] in Urine sediment by Light microscopy",
    "24124-0": "Casts [Presence] in Urine sediment by Light microscopy",
    // 黏液/Mucus (2026-06-13, WebFetch loinc.org/8247-9, rule #5).
    "8247-9": "Mucus [Presence] in Urine sediment by Light microscopy",
    // ── Stool routine members (07009C, audit 2026-07-13) ───────────
    // Canonical Long Common Names from active LOINC 2.82 terms. 07009C
    // intentionally has no parent LOINC because no exact panel represents the
    // Taiwanese NHI member set.
    "9397-1": "Color of Stool",
    "11029-6": "Consistency of Stool",
    "29636-8": "Appearance of Stool",
    "42524-9": "Mucus [Presence] in Stool by Light microscopy",
    "2335-8": "Hemoglobin [Presence] in Stool from gastrointestinal",
    "10704-5": "Ova and parasites identified in Stool by Light microscopy",
    "13655-6": "Leukocytes [Presence] in Stool by Light microscopy",
    "33668-5": "Erythrocytes [Presence] in Stool",
    // ALL entries below use the LOINC canonical 'Long Common Name'
    // as accepted by the TWNHIFHIR validator. Source: loinc.org for
    // each code, cross-checked against the validator's reported
    // 'Valid display is one of N choices' for displays we previously
    // got wrong (45 LOINCs found in the P333333333 validation run).
    // When updating, copy the exact en-US long name from loinc.org —
    // the validator is sensitive to spelling / punctuation.
    //
    // ── Urinalysis (06013C panel sub-items) ──────────
    // ── ABG (09041B panel) — not in validator output; loinc.org sourced
    // ABG display strings CORRECTED 2026-07-03 (loinc.org re-verification —
    // three were mislabelled "Arterial" when the code is generic "Blood", and
    // 1925-7 was mislabelled as bicarbonate when it is Base excess). The
    // 09041B emits generic-Blood members unless explicit vessel evidence promotes
    // them in observation.ts; the generic-Blood codes are also the global
    // fallback for codeless rows with independent blood evidence.
    "11558-4": "pH of Blood",
    // generic Blood (was wrongly "pH of Arterial blood")
    "8310-5": "Body temperature",
    // Generic "in Blood" ABG twins used by the v1.2.10 09041B neutralisation.
    // WebFetch-verified loinc.org 2026-07-06.
    "11557-6": "Carbon dioxide [Partial pressure] in Blood",
    "11556-8": "Oxygen [Partial pressure] in Blood",
    "20564-1": "Oxygen saturation in Blood",
    "2744-1": "pH of Arterial blood",
    // 09041B ABG
    "2019-8": "Carbon dioxide [Partial pressure] in Arterial blood",
    "2703-7": "Oxygen [Partial pressure] in Arterial blood",
    "1959-6": "Bicarbonate [Moles/volume] in Blood",
    // generic (was wrongly "Arterial")
    "1960-4": "Bicarbonate [Moles/volume] in Arterial blood",
    // 09041B ABG
    "2028-9": "Carbon dioxide [Moles/volume] in Serum or Plasma",
    "20565-8": "Carbon dioxide, total [Moles/volume] in Blood",
    "11555-0": "Base excess in Blood by calculation",
    // generic (WebFetch loinc.org 2026-07-06; was wrongly "Arterial blood")
    "1925-7": "Base excess in Arterial blood by calculation",
    // was WRONGLY "Bicarbonate ... --standard"
    "2713-6": "Oxygen saturation Calculated from oxygen partial pressure in Blood",
    // generic (was wrongly "Arterial")
    "2708-6": "Oxygen saturation in Arterial blood",
    // 09041B ABG
    // Venous-blood-gas counterparts. These are selected only when the row/report
    // carries explicit venous evidence; the ordinary 09041B aliases above remain
    // vessel-neutral because the NHI billing code itself says only "Blood gas".
    "2746-6": "pH of Venous blood",
    "2021-4": "Carbon dioxide [Partial pressure] in Venous blood",
    "2705-2": "Oxygen [Partial pressure] in Venous blood",
    "2027-1": "Carbon dioxide [Moles/volume] in Venous blood",
    "14627-4": "Bicarbonate [Moles/volume] in Venous blood",
    "19232-8": "Bicarbonate [Moles/volume] standard in Venous blood",
    "19237-7": "Base excess standard in Venous blood by calculation",
    "2711-0": "Oxygen saturation in Venous blood",
    "24339-4": "Gas panel - Venous blood",
    // ── Glucose ──────────────────────────────────────
    "1558-6": "Fasting glucose [Mass/volume] in Serum or Plasma",
    "2345-7": "Glucose [Mass/volume] in Serum or Plasma",
    // Explicit finger-stick / glucometer siblings (Q12133 audit 2026-07-13).
    "41604-0": "Fasting glucose [Mass/volume] in Capillary blood by Glucometer",
    "41653-7": "Glucose [Mass/volume] in Capillary blood by Glucometer",
    "14770-2": "Fasting glucose [Moles/volume] in Capillary blood by Glucometer",
    "14743-9": "Glucose [Moles/volume] in Capillary blood by Glucometer",
    // Body-fluid / CSF twins for the dual-specimen glucose & LDH codes
    // (09005C / 09033C) — see fluidChemistryLoincFix(). WebFetch-verified
    // loinc.org 2026-07-05.
    "2344-0": "Glucose [Mass/volume] in Body fluid",
    "2342-4": "Glucose [Mass/volume] in Cerebral spinal fluid",
    "2529-6": "Lactate dehydrogenase [Enzymatic activity/volume] in Body fluid",
    "2528-8": "Lactate dehydrogenase [Enzymatic activity/volume] in Cerebral spinal fluid",
    // Pleural / peritoneal specimen-specific fluid-chemistry twins (loinc.org-
    // verified 2026-07-12; rule #5 有專屬用專屬 — fluidChemistryLoincFix / totalProteinLoincFix)
    "2346-5": "Glucose [Mass/volume] in Pleural fluid",
    "2347-3": "Glucose [Mass/volume] in Peritoneal fluid",
    "2530-4": "Lactate dehydrogenase [Enzymatic activity/volume] in Pleural fluid",
    "2531-2": "Lactate dehydrogenase [Enzymatic activity/volume] in Peritoneal fluid",
    "1748-3": "Albumin [Mass/volume] in Pleural fluid",
    "1749-1": "Albumin [Mass/volume] in Peritoneal fluid",
    "1796-2": "Amylase [Enzymatic activity/volume] in Pleural fluid",
    "1797-0": "Amylase [Enzymatic activity/volume] in Peritoneal fluid",
    "14389-1": "Amylase [Enzymatic activity/volume] in Cerebral spinal fluid",
    "1918-2": "Aspartate aminotransferase [Enzymatic activity/volume] in Cerebral spinal fluid",
    "14439-4": "Cholesterol [Mass/volume] in Cerebral spinal fluid",
    "9619-8": "Triglyceride [Mass/volume] in Pleural fluid",
    "14446-9": "Triglyceride [Mass/volume] in Cerebral spinal fluid",
    "14447-7": "Triglyceride [Mass/volume] in Peritoneal fluid",
    "14441-0": "Cholesterol [Mass/volume] in Peritoneal fluid",
    "14409-7": "Aspartate aminotransferase [Enzymatic activity/volume] in Pleural fluid",
    "14410-5": "Aspartate aminotransferase [Enzymatic activity/volume] in Peritoneal fluid",
    "54492-4": "Alanine aminotransferase [Enzymatic activity/volume] in Pleural fluid",
    "54491-6": "Alanine aminotransferase [Enzymatic activity/volume] in Peritoneal fluid",
    "9618-0": "Cholesterol [Mass/volume] in Pleural fluid",
    "2882-9": "Protein [Mass/volume] in Pleural fluid",
    "2883-7": "Protein [Mass/volume] in Peritoneal fluid",
    // ── Hematology ───────────────────────────────────
    "718-7": "Hemoglobin [Mass/volume] in Blood",
    "4548-4": "Hemoglobin A1c/Hemoglobin.total in Blood",
    "6690-2": "Leukocytes [#/volume] in Blood by Automated count",
    "777-3": "Platelets [#/volume] in Blood by Automated count",
    "789-8": "Erythrocytes [#/volume] in Blood by Automated count",
    "785-6": "MCH [Entitic mass] by Automated count",
    "711-2": "Eosinophils [#/volume] in Blood by Automated count",
    // v0.11.12 FHIR R4 audit (2026-05-29): coverage sweep — LOINCs
    // routed to by mapper but missing from LOINC_DISPLAY. Without
    // entries here, Coding.display falls back to the raw row display
    // ("Meta-Myelocyte" / "紅血球分佈變異數" / etc) which violates the
    // FHIR R4 rule that Coding.display "follows the rules of the system"
    // (= LOINC Long Common Name). All entries below are the Long Common
    // Name fetched verbatim from loinc.org 2026-05-29.
    "740-1": "Metamyelocytes/Leukocytes in Blood by Manual count",
    "764-1": "Band form neutrophils/Leukocytes in Blood by Manual count",
    // Earlier maturation stages (v1.3.3, WebFetch-verified loinc.org 2026-07-08)
    "749-2": "Myelocytes/Leukocytes in Blood by Manual count",
    "783-1": "Promyelocytes/Leukocytes in Blood by Manual count",
    "709-6": "Blasts/Leukocytes in Blood by Manual count",
    // CBC indices (v0.11.11 expanded variant routing → these LOINCs)
    "786-4": "MCHC [Entitic Mass/volume] in Red Blood Cells by Automated count",
    "787-2": "MCV [Entitic mean volume] in Red Blood Cells by Automated count",
    "788-0": "Erythrocyte [DistWidth] in Blood by Automated count",
    // v0.11.10 LOINC_SHORT_TEXT entries that lacked LOINC_DISPLAY twins
    "2143-6": "Cortisol [Mass/volume] in Serum or Plasma",
    "2132-9": "Cobalamin (Vitamin B12) [Mass/volume] in Serum or Plasma",
    "2284-8": "Folate [Mass/volume] in Serum or Plasma",
    "83112-3": "Prostate specific Ag [Mass/volume] in Serum or Plasma by Immunoassay",
    "4544-3": "Hematocrit [Volume Fraction] of Blood by Automated count",
    "24360-0": "Hemoglobin and Hematocrit panel - Blood",
    "57021-8": "CBC W Auto Differential panel - Blood",
    "58410-2": "CBC panel - Blood by Automated count",
    // Mycobacterial stain/culture members and exact parent (v1.4.5).
    // Canonical Long Common Names copied from active LOINC 94540-2 and its
    // official panel member list on 2026-07-14.
    "11545-1": "Microscopic observation [Identifier] in Specimen by Acid fast stain",
    "50941-4": "Mycobacterium sp [Presence] in Specimen by Organism specific culture",
    "94540-2": "Mycobacterial stain and culture panel - Specimen",
    // ── Clinical Documents ───────────────────────────
    // v0.16+ (2026-06-05): discharge summary DocumentReference.type.
    // Verified at loinc.org/18842-5/ — Component=Discharge summary note,
    // Class=DOC.ONTOLOGY, Scale=Doc, Status=Active. Long Common Name is
    // simply "Discharge summary" (no setting/role qualifier — code is
    // the universal document-type entry across all care settings).
    "18842-5": "Discharge summary",
    // ── Chemistry / liver / renal ────────────────────
    "1920-8": "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma",
    "1742-6": "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma",
    "2160-0": "Creatinine [Mass/volume] in Serum or Plasma",
    "2161-8": "Creatinine [Mass/volume] in Urine",
    "33914-3": "Glomerular filtration rate [Volume Rate/Area] in Serum or Plasma by Creatinine-based formula (MDRD)/1.73 sq M",
    "77147-7": "Glomerular filtration rate [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)/1.73 sq M",
    "62238-1": "Glomerular filtration rate [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (CKD-EPI)/1.73 sq M",
    "3094-0": "Urea nitrogen [Mass/volume] in Serum or Plasma",
    "3084-1": "Urate [Mass/volume] in Serum or Plasma",
    "2951-2": "Sodium [Moles/volume] in Serum or Plasma",
    "2823-3": "Potassium [Moles/volume] in Serum or Plasma",
    "2075-0": "Chloride [Moles/volume] in Serum or Plasma",
    "1975-2": "Bilirubin.total [Mass/volume] in Serum or Plasma",
    "1968-7": "Bilirubin.direct [Mass/volume] in Serum or Plasma",
    "1751-7": "Albumin [Mass/volume] in Serum or Plasma",
    "101198-0": "Albumin [Mass/volume] in Serum or Plasma by Nephelometry",
    // 12112B (Finding 3)
    // Body-fluid / CSF albumin twins for the 09038C reroute (v1.2.9) — see
    // SERUM_TO_FLUID_CHEM. WebFetch-verified loinc.org 2026-07-06.
    "1747-5": "Albumin [Mass/volume] in Body fluid",
    "1746-7": "Albumin [Mass/volume] in Cerebral spinal fluid",
    // Urine albumin twins for the 09038C reroute (Finding 2, 2026-07-13) — loinc.org
    // verified ACTIVE. spot Mass/vol / 24h Mass/time / 24h Mass/vol.
    "1754-1": "Albumin [Mass/volume] in Urine",
    "1755-8": "Albumin [Mass/time] in 24 hour Urine",
    "21059-1": "Albumin [Mass/volume] in 24 hour Urine",
    "2885-2": "Protein [Mass/volume] in Serum or Plasma",
    // v0.11.11 — Total Protein
    "2532-0": "Lactate dehydrogenase [Enzymatic activity/volume] in Serum or Plasma",
    "6768-6": "Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma",
    "2324-2": "Gamma glutamyl transferase [Enzymatic activity/volume] in Serum or Plasma",
    "17861-6": "Calcium [Mass/volume] in Serum or Plasma",
    // ── Lipid panel ──────────────────────────────────
    "2093-3": "Cholesterol [Mass/volume] in Serum or Plasma",
    "2571-8": "Triglyceride [Mass/volume] in Serum or Plasma",
    // Body-fluid twins for the v1.2.9 (2nd pass) AST/ALT/cholesterol/triglyceride
    // reroute — see SERUM_TO_FLUID_CHEM. All WebFetch-verified loinc.org 2026-07-06.
    "1919-0": "Aspartate aminotransferase [Enzymatic activity/volume] in Body fluid",
    "25302-1": "Alanine aminotransferase [Enzymatic activity/volume] in Body fluid",
    "12183-0": "Cholesterol [Mass/volume] in Body fluid",
    "12228-3": "Triglyceride [Mass/volume] in Body fluid",
    "2085-9": "Cholesterol in HDL [Mass/volume] in Serum or Plasma",
    "9830-1": "Cholesterol.total/Cholesterol in HDL [Mass Ratio] in Serum or Plasma",
    "2089-1": "Cholesterol in LDL [Mass/volume] in Serum or Plasma",
    "13457-7": "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation",
    "18262-6": "Cholesterol in LDL [Mass/volume] in Serum or Plasma by Direct assay",
    // ── Thyroid / hormones ───────────────────────────
    "3016-3": "Thyrotropin [Units/volume] in Serum or Plasma",
    "3024-7": "Thyroxine (T4) free [Mass/volume] in Serum or Plasma",
    "14920-3": "Thyroxine (T4) free [Moles/volume] in Serum or Plasma",
    "2986-8": "Testosterone [Mass/volume] in Serum or Plasma",
    "83098-4": "Follitropin [Units/volume] in Serum or Plasma by Immunoassay",
    "83096-8": "Estradiol (E2) [Mass/volume] in Serum or Plasma by Immunoassay",
    // ── Cardiac / inflammation ───────────────────────
    "10839-9": "Troponin I.cardiac [Mass/volume] in Serum or Plasma",
    "33762-6": "Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma",
    "1988-5": "C reactive protein [Mass/volume] in Serum or Plasma",
    "30522-7": "C reactive protein [Mass/volume] in Serum or Plasma by High sensitivity method",
    "33959-8": "Procalcitonin [Mass/volume] in Serum or Plasma",
    // ── Hepatitis / serology ─────────────────────────
    "5195-3": "Hepatitis B virus surface Ag [Presence] in Serum",
    "5196-1": "Hepatitis B virus surface Ag [Presence] in Serum or Plasma by Immunoassay",
    "5193-8": "Hepatitis B virus surface Ab [Units/volume] in Serum or Plasma by Immunoassay",
    "13952-7": "Hepatitis B virus core Ab [Presence] in Serum or Plasma by Immunoassay",
    "22316-4": "Hepatitis B virus core Ab [Units/volume] in Serum",
    "16128-1": "Hepatitis C virus Ab [Presence] in Serum",
    "13955-0": "Hepatitis C virus Ab [Presence] in Serum or Plasma by Immunoassay",
    // ── Virology (audit 2026-05-19) ──────────────────
    "7853-5": "Cytomegalovirus IgM Ab [Units/volume] in Serum or Plasma",
    // ── Tumor markers / proteins (audit 2026-05-19) ──
    "1952-1": "Beta-2-Microglobulin [Mass/volume] in Serum or Plasma",
    // ── Blood type (v0.11.11 — ABO/Rh split from combined 882-1) ──
    "883-9": "ABO group [Type] in Blood",
    "10331-7": "Rh [Type] in Blood",
    "890-4": "Blood group antibody screen [Presence] in Serum or Plasma",
    // ── Coagulation ──────────────────────────────────
    "5902-2": "Prothrombin time (PT) in Platelet poor plasma by Coagulation assay",
    // v0.11.9 audit: previously labelled "Prothrombin time (PT) Control...".
    // loinc.org canonical is actually "Prothrombin time (PT) actual/Normal..."
    // (Component=Prothrombin time actual/Normal, Property=RelTime — a RATIO,
    // not a control reading). See PANEL_LOINC_MAP['08026C'] comment.
    "5894-1": "Prothrombin time (PT) actual/Normal in Platelet poor plasma by Coagulation assay",
    "6301-6": "INR in Platelet poor plasma by Coagulation assay",
    "14979-9": "aPTT in Platelet poor plasma by Coagulation assay",
    // v0.11.9 (SMART app dev report 2026-05-29): added APTT ratio LOINC.
    // 08036C bills both APTT (seconds, 14979-9) AND APTT ratio (63561-5) as
    // sub-rows; without per-LOINC display, the ratio row inherited APTT
    // time's display and looked like a fatal coagulation reading.
    "63561-5": "aPTT in Platelet poor plasma by Coagulation assay --actual/normal",
    "30240-6": "Fibrin D-dimer [Mass/volume] in Platelet poor plasma",
    // ── Body fluid (16008C panel members; v0.9.10) ───
    "26469-7": "Leukocytes [#/volume] in Synovial fluid",
    "17836-8": "Neutrophils/Leukocytes in Synovial fluid",
    "26483-8": "Lymphocytes/Leukocytes in Synovial fluid",
    "26487-9": "Monocytes/Leukocytes in Body fluid",
    // Synovial mono %: only synovial NFr differential code is the mono+macro merge,
    // and it carries Method=Manual count (loinc.org 2026-07-13; no method-less
    // synovial variant exists). Replaces generic body-fluid 26487-9 per rule #5.
    "21395-9": "Monocytes+Macrophages/100 leukocytes in Synovial fluid by Manual count",
    "26458-0": "Erythrocytes [#/volume] in Synovial fluid",
    "14664-7": "Color of Synovial fluid",
    "29605-3": "Appearance of Synovial fluid",
    "14950-0": "Viscosity of Synovial fluid Qualitative",
    "2348-1": "Glucose [Mass/volume] in Synovial fluid",
    "2886-0": "Protein [Mass/volume] in Synovial fluid",
    // ── Pleural fluid panel 16003C (loinc.org-verified 2026-07-13, LOINC 2.82) ──
    "30455-0": "Neutrophils/Leukocytes in Pleural fluid",
    "26481-2": "Lymphocytes/Leukocytes in Pleural fluid",
    "35021-5": "Monocytes+Macrophages/Leukocytes in Pleural fluid",
    "30379-2": "Eosinophils/Leukocytes in Pleural fluid",
    "35070-2": "Basophils/Leukocytes in Pleural fluid",
    "33370-8": "Variant lymphocytes/Leukocytes in Pleural fluid",
    "26467-1": "Leukocytes [#/volume] in Pleural fluid",
    "26456-4": "Erythrocytes [#/volume] in Pleural fluid",
    "58904-4": "Nucleated cells [#/volume] in Pleural fluid by Manual count",
    "14662-1": "Color of Pleural fluid",
    "14620-9": "Appearance of Pleural fluid",
    "2750-8": "pH of Pleural fluid",
    "2751-6": "pH of Peritoneal fluid",
    "2755-7": "pH of Stool",
    "2748-2": "pH of Body fluid",
    "14349-5": "Specific gravity of Pleural fluid by Refractometry",
    "34983-7": "Unidentified cells/Leukocytes in Pleural fluid",
    // ── SPE fractions (09065B; v0.10.0) ──────────────
    "2862-1": "Albumin [Mass/volume] in Serum or Plasma by Electrophoresis",
    // was invalid 2865-7 (2026-07-03 audit)
    // 2026-06-13 LOINC audit: prior codes 2867-3/2868-1/2869-9/2871-5 were
    // INVALID (bad check digits, non-existent on loinc.org). Corrected to the
    // verified serum-EP globulin fraction codes (WebFetch loinc.org, rule #5).
    "2865-4": "Alpha 1 globulin [Mass/volume] in Serum or Plasma by Electrophoresis",
    "2868-8": "Alpha 2 globulin [Mass/volume] in Serum or Plasma by Electrophoresis",
    "2871-2": "Beta globulin [Mass/volume] in Serum or Plasma by Electrophoresis",
    "2874-6": "Gamma globulin [Mass/volume] in Serum or Plasma by Electrophoresis",
    "1759-0": "Albumin/Globulin [Mass Ratio] in Serum or Plasma",
    // ── Flow cytometry CD (12204B; v0.10.0) ──────────
    "8124-0": "CD3 cells/cells in Blood",
    "8122-4": "CD3 cells [#/volume] in Blood",
    "8123-2": "CD3+CD4+ (T4 helper) cells/cells in Blood",
    "24467-3": "CD3+CD4+ (T4 helper) cells [#/volume] in Blood",
    "8101-8": "CD3+CD8+ (T8 suppressor) cells/cells in Blood",
    "14135-8": "CD3+CD8+ (T8 suppressor) cells [#/volume] in Blood",
    "8117-4": "CD19 cells/cells in Blood",
    "8116-6": "CD19 cells [#/volume] in Blood",
    "8112-5": "CD3-CD16+CD56+ (Natural killer) cells/cells in Blood",
    "20402-4": "CD16+CD56+ cells [#/volume] in Blood",
    "54218-3": "CD3+CD4+ (T4 helper) cells/CD3+CD8+ (T8 suppressor cells) cells [# Ratio] in Blood",
    // ── DLCO (17009B; v0.10.0; codes corrected 2026-06-13 LOINC audit) ──
    // Was scrambled: 19850-7 (mislabeled "alveolar volume"; really Inspiratory
    // capacity) and 19911-7 (mislabeled as the DLCO/VA ratio; really plain
    // DLCO). 19850-7 + 24341-0 are now unused (removed). Verified LCNs:
    "19911-7": "Diffusion capacity.carbon monoxide",
    "19914-1": "Diffusion capacity/Alveolar volume by Single breath.carbon monoxide+Helium",
    // ── Vital signs (IHKE3402) ───────────────────────
    "8302-2": "Body height",
    "29463-7": "Body weight",
    "39156-5": "Body mass index (BMI) [Ratio]",
    "8280-0": "Waist Circumference at umbilicus by Tape measure",
    "8480-6": "Systolic blood pressure",
    "8462-4": "Diastolic blood pressure",
    "85354-9": "Blood pressure panel with all children optional",
    // ── v0.12.0 legacy sweep (46 entries) ─────────────
    // All Long Common Names below WebFetch-verified at loinc.org
    // 2026-05-29 for the LOINCs already routed to by the bridge but
    // missing LOINC_DISPLAY entries. Without these, Coding.display fell
    // back to raw row display — FHIR R4 violation ("follow rules of the
    // system"). Audit during this sweep also found 6 incorrect mappings
    // + 1 invalid LOINC (2692-7) which were corrected in NHI_TO_LOINC
    // above (12184C / 22001C / 22015B / 22025B unmapped; 13025C / 13026C
    // remained unmapped until the verified 94540-2 panel was added in v1.4.5;
    // 08075C 2692-7 → 2692-2 typo fix).
    // CBC differential percentages
    "706-2": "Basophils/Leukocytes in Blood by Automated count",
    "713-8": "Eosinophils/Leukocytes in Blood by Automated count",
    "736-9": "Lymphocytes/Leukocytes in Blood by Automated count",
    "770-8": "Neutrophils/Leukocytes in Blood by Automated count",
    "5905-5": "Monocytes/Leukocytes in Blood by Automated count",
    "13046-8": "Variant lymphocytes/Leukocytes in Blood",
    "26477-0": "Variant lymphocytes [#/volume] in Blood",
    "19048-8": "Nucleated erythrocytes/Leukocytes [Ratio] in Blood",
    "30392-5": "Nucleated erythrocytes [#/volume] in Blood",
    // Tumor markers
    "1834-1": "Alpha-1-Fetoprotein [Mass/volume] in Serum or Plasma",
    "19176-7": "Alpha-1-Fetoprotein [Units/volume] in Serum or Plasma",
    // AFP arbitrary-unit (IU/mL) guard target
    "2039-6": "Carcinoembryonic Ag [Mass/volume] in Serum or Plasma",
    "2857-1": "Prostate specific Ag [Mass/volume] in Serum or Plasma",
    "10861-3": "Progesterone receptor [Mass/mass] in Tissue",
    "10886-0": "Prostate Specific Ag Free [Mass/volume] in Serum or Plasma",
    "24108-3": "Cancer Ag 19-9 [Units/volume] in Serum or Plasma",
    "10334-1": "Cancer Ag 125 [Units/volume] in Serum or Plasma",
    "6875-9": "Cancer Ag 15-3 [Units/volume] in Serum or Plasma",
    "83113-1": "Prostate Specific Ag Free [Mass/volume] in Serum or Plasma by Immunoassay",
    // Hepatitis / virology
    "5197-9": "Hepatitis B virus surface Ag [Presence] in Serum by Radioimmunoassay (RIA)",
    "14118-4": "Lactate [Mass/volume] in Serum or Plasma",
    "2524-7": "Lactate [Moles/volume] in Serum or Plasma",
    "2520-5": "Lactate [Moles/volume] in Cerebral spinal fluid",
    "27941-4": "Lactate [Mass/volume] in Cerebral spinal fluid",
    "80382-5": "Influenza virus A Ag [Presence] in Upper respiratory specimen by Rapid immunoassay",
    "80383-3": "Influenza virus B Ag [Presence] in Upper respiratory specimen by Rapid immunoassay",
    "80381-7": "Influenza virus A and B Ag panel - Upper respiratory specimen by Rapid immunoassay",
    "94558-4": "SARS-CoV-2 (COVID-19) Ag [Presence] in Respiratory system specimen by Rapid immunoassay",
    // Immunology / autoimmune
    "5048-4": "Nuclear Ab [Titer] in Serum by Immunofluorescence",
    // 5292-8 is canonically the VDRL LOINC; bridge maps NHI 12001C (RPR
    // billing) here because RPR + VDRL are clinically interchangeable
    // serology methods for the same anti-cardiolipin antibody. Display
    // follows the LOINC's own canonical name (VDRL) per FHIR R4.
    "5292-8": "Reagin Ab [Presence] in Serum by VDRL",
    "8098-6": "Thyroglobulin Ab [Units/volume] in Serum or Plasma",
    "5257-1": "Mycoplasma pneumoniae IgM Ab [Presence] in Serum by Immunoassay",
    "5124-3": "Cytomegalovirus IgG Ab [Units/volume] in Serum or Plasma by Immunoassay",
    "72493-0": "Cytomegalovirus DNA [Units/volume] (viral load) in Serum or Plasma by NAA with probe detection",
    "13953-5": "Hepatitis B virus e Ab [Presence] in Serum or Plasma by Immunoassay",
    "13954-3": "Hepatitis B virus e Ag [Presence] in Serum or Plasma by Immunoassay",
    "15189-4": "Kappa light chains/Lambda light chains [Mass Ratio] in Serum",
    "36916-5": "Kappa light chains.free [Mass/volume] in Serum",
    "33944-0": "Lambda light chains.free [Mass/volume] in Serum or Plasma",
    "48378-4": "Kappa light chains.free/Lambda light chains.free [Mass Ratio] in Serum",
    "57778-3": "Kappa and Lambda light chains.free panel - Serum or Plasma",
    // 16124-0 (Cryptococcus sp Ab) removed — it was only referenced by the
    // buggy 12056B mapping (see NHI_TO_LOINC); no NHI code legitimately maps
    // to it (12069B Cryptococcus Ag is left unmapped). 20483-4 is its
    // replacement: the correct AMA titer LOINC now used by 12056B.
    "20483-4": "Mitochondria Ab [Titer] in Serum",
    "17351-8": "Neutrophil cytoplasmic Ab [Presence] in Serum",
    "47286-0": "Differential panel - Bone marrow",
    "11105-4": "Basophils/cells in Bone marrow by Manual count",
    "11150-0": "Blasts/cells in Bone marrow",
    "11152-6": "Eosinophils/cells in Bone marrow",
    "40689-2": "Erythroid cells/cells in Bone marrow by Manual count",
    "11108-8": "Lymphocytes/cells in Bone marrow by Manual count",
    "11110-4": "Megakaryocytes/cells in Bone marrow by Manual count",
    "11111-2": "Metamyelocytes/cells in Bone marrow by Manual count",
    "11112-0": "Monocytes/cells in Bone marrow by Manual count",
    "11113-8": "Myeloblasts/cells in Bone marrow by Manual count",
    "11114-6": "Myelocytes/cells in Bone marrow by Manual count",
    "11115-3": "Neutrophils/cells in Bone marrow by Manual count",
    "11118-7": "Plasma cells/cells in Bone marrow by Manual count",
    "11120-3": "Promyelocytes/cells in Bone marrow by Manual count",
    "11103-9": "Band form neutrophils/cells in Bone marrow by Manual count",
    "11128-6": "Segmented neutrophils/cells in Bone marrow",
    "11138-5": "Myeloid cells/Erythroid cells [# Ratio] in Bone marrow",
    "80721-4": "Lymphocyte T-cell and B-cell and Natural killer subsets panel - Blood",
    "24351-9": "Protein electrophoresis panel - Serum or Plasma",
    "34539-7": "Protein electrophoresis panel - Urine",
    "24352-7": "Protein electrophoresis panel - Cerebral spinal fluid",
    "50190-8": "Iron and Iron binding capacity panel - Serum or Plasma",
    "25700-6": "Immunofixation for Serum or Plasma",
    // Pathology / IHC
    "14130-9": "Estrogen receptor [Moles/mass] in Tissue",
    "4679-7": "Reticulocytes/Erythrocytes in Blood",
    "14196-0": "Reticulocytes [#/volume] in Blood",
    // absolute ARC form (not the 08008C default; kept for completeness)
    "35672-5": "Bilirubin.direct/Bilirubin.total in Serum or Plasma",
    // ABG / Pulmonary
    "44596-5": "IgG Ag [Presence] in Skin by Immunofluorescence",
    // Chemistry (general)
    "1927-3": "Base excess in Venous blood by calculation",
    "1995-0": "Calcium.ionized [Moles/volume] in Serum or Plasma",
    // Ammonia (NHI 09037C) — both forms carried so LOINC_DISPLAY stays in
    // sync whichever ammoniaLoincFix() selects based on the row's unit.
    "22763-7": "Ammonia [Mass/volume] in Plasma",
    "16362-6": "Ammonia [Moles/volume] in Plasma",
    "14563-1": "Hemoglobin [Presence] in Stool from gastrointestinal --1st specimen",
    "2276-4": "Ferritin [Mass/volume] in Serum or Plasma",
    "2458-8": "IgA [Mass/volume] in Serum or Plasma",
    "2465-3": "IgG [Mass/volume] in Serum or Plasma",
    "2472-9": "IgM [Mass/volume] in Serum or Plasma",
    "2500-7": "Iron binding capacity [Mass/volume] in Serum or Plasma",
    "2501-5": "Iron binding capacity.unsaturated [Mass/volume] in Serum or Plasma",
    "2502-3": "Iron saturation [Mass Fraction] in Serum or Plasma",
    "2692-2": "Osmolality of Serum or Plasma",
    // typo fix from 2692-7
    "2777-1": "Phosphate [Mass/volume] in Serum or Plasma",
    "3040-3": "Lipase [Enzymatic activity/volume] in Serum or Plasma",
    "19113-0": "IgE [Units/volume] in Serum or Plasma",
    "19123-9": "Magnesium [Mass/volume] in Serum or Plasma",
    "2601-3": "Magnesium [Moles/volume] in Serum or Plasma",
    "19124-7": "Magnesium [Mass/volume] in Urine",
    "2598-1": "Magnesium [Moles/volume] in Urine",
    "24447-5": "Magnesium [Mass/time] in 24 hour Urine",
    "2599-9": "Magnesium [Moles/time] in 24 hour Urine",
    // Stool / GI
    "58453-2": "Hemoglobin [Mass/volume] in Stool from gastrointestinal lower by Immunoassay",
    "29771-3": "Hemoglobin [Presence] in Stool from gastrointestinal lower by Immunoassay",
    // Microbiology
    "600-7": "Bacteria identified in Blood by Culture",
    "634-6": "Bacteria identified in Specimen by Aerobe culture",
    "77949-6": "Streptococcus pneumoniae Ag [Presence] in Urine by Rapid immunoassay",
    "77684-9": "Legionella pneumophila 1 Ag [Presence] in Urine by Rapid immunoassay",
    // ── Medical-calculator LOINC gaps (2026-07-03) ───────────────────
    // Long Common Names WebFetch-verified at loinc.org 2026-07-03 (rule
    // #5). Twins of the LOINC_MAP display-keyword block above so emitted
    // Coding.display follows the rules of the system (FHIR R4 rule #1).
    "3150-0": "Inhaled oxygen concentration",
    "2955-3": "Sodium [Moles/volume] in Urine",
    "2828-2": "Potassium [Moles/volume] in Urine",
    "2078-4": "Chloride [Moles/volume] in Urine",
    "3095-7": "Urea nitrogen [Mass/volume] in Urine",
    "2695-5": "Osmolality of Urine",
    "5643-2": "Ethanol [Mass/volume] in Serum or Plasma",
    "4024-6": "Salicylates [Mass/volume] in Serum or Plasma",
    "3298-7": "Acetaminophen [Mass/volume] in Serum or Plasma",
    "20448-7": "Insulin [Units/volume] in Serum or Plasma",
    "1798-8": "Amylase [Enzymatic activity/volume] in Serum or Plasma",
    // Body-fluid amylase twin for the 09017C reroute (v1.2.9) — see
    // SERUM_TO_FLUID_CHEM. No CSF-specific amylase LOINC exists (amylase-in-CSF
    // is not a standard test), so the CSF slot also uses this generic body-fluid
    // code. WebFetch-verified loinc.org 2026-07-06.
    "1795-4": "Amylase [Enzymatic activity/volume] in Body fluid",
    "1521-4": "Glucose [Mass/volume] in Serum or Plasma --2 hours post meal",
    "30934-4": "Natriuretic peptide B [Mass/volume] in Serum or Plasma",
    "89579-7": "Troponin I.cardiac [Mass/volume] in Serum or Plasma by High sensitivity method",
    "67151-1": "Troponin T.cardiac [Mass/volume] in Serum or Plasma by High sensitivity method",
    "3051-0": "Triiodothyronine (T3) Free [Mass/volume] in Serum or Plasma",
    "2498-4": "Iron [Mass/volume] in Serum or Plasma",
    // ── Wave 2 (2026-07-03) — WebFetch-verified loinc.org ────────────
    "2157-6": "Creatine kinase [Enzymatic activity/volume] in Serum or Plasma",
    "13969-1": "Creatine kinase.MB [Mass/volume] in Serum or Plasma",
    "3255-7": "Fibrinogen [Mass/volume] in Platelet poor plasma by Coagulation assay",
    "30226-5": "Fibrin+Fibrinogen fragments [Mass/volume] in Platelet poor plasma",
    "2639-3": "Myoglobin [Mass/volume] in Serum or Plasma",
    "2641-9": "Myoglobin [Mass/volume] in Urine",
    "47826-3": "Adenosine deaminase [Enzymatic activity/volume] in Serum or Plasma",
    "35704-6": "Adenosine deaminase [Enzymatic activity/volume] in Pleural fluid",
    "49759-4": "Adenosine deaminase [Enzymatic activity/volume] in Peritoneal fluid",
    "35703-8": "Adenosine deaminase [Enzymatic activity/volume] in Cerebral spinal fluid",
    "9404-5": "Adenosine deaminase [Enzymatic activity/volume] in Body fluid",
    "4542-7": "Haptoglobin [Mass/volume] in Serum or Plasma",
    "30341-2": "Erythrocyte [Sedimentation Rate] in Blood",
    "2731-8": "Parathyrin.intact [Mass/volume] in Serum or Plasma",
    "3026-2": "Thyroxine (T4) [Mass/volume] in Serum or Plasma",
    "3053-6": "Triiodothyronine (T3) [Mass/volume] in Serum or Plasma"
  };
  var LOINC_SHORT_TEXT = {
    // ── Coagulation panel (08036C / 08026C) ──────────
    "14979-9": "APTT",
    "63561-5": "APTT (ratio)",
    "5902-2": "PT",
    "6301-6": "INR",
    "5894-1": "PT (ratio)",
    // v0.11.9: 5894-1 is PT actual/normal RATIO
    // (Property=RelTime), NOT PT Control as previously (incorrectly) labelled.
    // See LOINC_DISPLAY comment for full audit trail.
    //
    // ── Single-analyte panels (v0.11.10) ─────────────
    // SMART app dev report 2026-05-29 Category B + C: bridge previously
    // shipped DR title and obs.text from two different sources for
    // these single-analyte panels — DR title from order_name (with NHI-
    // catalog method suffix like 「免疫分析」), obs.text from row display
    // (lab-shorthand or alternate Chinese). Unifying via LOINC_SHORT_TEXT
    // means both DR title and obs.text resolve to the same clean
    // clinical short name when the row's NHI code maps to one of these
    // LOINCs (via NHI_TO_LOINC path A).
    //
    // Each LOINC below verified via WebFetch loinc.org 2026-05-29 —
    // Component / Property / System / Method all confirmed appropriate
    // for the Taiwan NHI billing context:
    //   4548-4   Hemoglobin A1c/Hemoglobin.total, MFr, Blood (NGSP %; Taiwan default)
    //   1975-2   Bilirubin total, MCnc, Ser/Plas
    //   10839-9  Troponin I.cardiac, MCnc, Ser/Plas
    //   13457-7  Cholesterol in LDL (calculated), MCnc, Ser/Plas
    //   3016-3   Thyrotropin (TSH), ACnc, Ser/Plas
    //   2143-6   Cortisol, MCnc, Ser/Plas
    //   2132-9   Cobalamin (Vitamin B12), MCnc, Ser/Plas
    //   2284-8   Folate, MCnc, Ser/Plas
    //   83112-3  Prostate specific Ag, MCnc, Ser/Plas, IA (covers EIA/LIA both)
    "4548-4": "HbA1c",
    // NHI 09006C (was: DR "醣化血紅素" / obs "Hb-A1c")
    "1975-2": "Total Bilirubin",
    // NHI 09029C (was: DR "膽紅素總量" / obs "全膽紅素")
    "10839-9": "Troponin I",
    // NHI 09099C conventional (was: DR "心肌旋轉蛋白Ｉ" fullwidth)
    "89579-7": "hs-Troponin I",
    // NHI 09099C high-sensitivity variant (display-routed via hsTroponinFix)
    "2089-1": "LDL-C",
    "13457-7": "LDL-C (calculated)",
    "18262-6": "LDL-C (direct)",
    "3016-3": "TSH",
    // NHI 09112C (was: DR "甲狀腺刺激素免疫分析" / obs "甲狀腺刺激素")
    "2143-6": "Cortisol",
    // NHI 09113C (was: DR "皮質素免疫分析")
    "2132-9": "Vitamin B12",
    // NHI 09129C (was: DR "維生素B12免疫分析")
    "2284-8": "Folate",
    // NHI 09130C (was: DR "葉酸免疫分析")
    "83112-3": "PSA",
    // NHI 12081C (was: DR "攝護腺特異抗原(EIA/LIA法)")
    "5193-8": "Anti-HBs",
    // NHI 14033C
    "13952-7": "Anti-HBc",
    // NHI 14037C qualitative
    "22316-4": "Anti-HBc",
    // NHI 14037C quantitative / COI
    "8098-6": "Thyroglobulin Ab",
    "5257-1": "Mycoplasma pneumoniae IgM",
    "5124-3": "CMV IgG",
    "72493-0": "CMV DNA viral load",
    "13953-5": "Anti-HBe",
    "13954-3": "HBeAg",
    "80381-7": "Influenza A/B Ag panel",
    "24360-0": "Hemoglobin and Hematocrit",
    "11545-1": "Acid-fast Stain",
    "50941-4": "Mycobacterial Culture",
    "94540-2": "Mycobacterial Stain and Culture",
    "634-6": "Aerobic Culture",
    "8310-5": "Body temperature",
    "20565-8": "TCO2 (blood)",
    "2746-6": "pH (venous)",
    "2021-4": "pCO2 (venous)",
    "2705-2": "pO2 (venous)",
    "2027-1": "TCO2 (venous)",
    "14627-4": "HCO3 (venous)",
    "1927-3": "Base excess (venous)",
    "19232-8": "Standard bicarbonate (venous)",
    "19237-7": "Standard base excess (venous)",
    "2711-0": "O2 saturation (venous)",
    "24339-4": "Venous blood gas panel",
    // v0.12.1 (SMART app dev bug 8' 2026-05-29): urine total protein
    // observations had DR title "全蛋白" (ambiguous NHI catalog name —
    // can mean serum or urine total protein) while the obs itself was
    // correctly LOINC 20454-5 (the Ord/PrThr test-strip qualitative form).
    // Clinicians reading the DR header assumed serum TP. Clean short text
    // resolves both DR title and obs.code.text to "Urine Protein" —
    // disambiguating the specimen explicitly. This is the free-form
    // CodeableConcept.text; the catalog-faithful Coding.display lives in
    // LOINC_DISPLAY[20454-5] = "Protein [Presence] in Urine by Test strip"
    // (canonical Long Common Name, corrected 2026-06-08 — was wrongly the
    // Qn 2888-6 "Mass/Vol" wording, see loinc-tables.ts note above).
    "20454-5": "Urine Protein",
    // v0.12.2: quantitative urine protein. Same clean label as the
    // qualitative twin so SMART app per-LOINC pivot shows both under
    // the same column header "Urine Protein"; the LOINC code itself
    // disambiguates which scale (Ord vs Qn) downstream consumers see.
    "2888-6": "Urine Protein",
    "2889-4": "24-hour Urine Protein",
    // v0.13 — CBC sub-analytes (08011C / 08013C) ─────────
    // App dev (MediPrisma) soft request 2026-05-30: bridge ships these
    // CBC LOINCs but `obs.code.text` varies (Hb / 血色素 / Hemoglobin /
    // HGB depending on hospital LIS). SMART apps doing cross-hospital
    // trend display need to maintain an alias table to merge them. With
    // SHORT_TEXT entries here PLUS the clean-match gate in
    // mapObservation / buildObservation (CBC_CANONICAL_TEXT_LOINCS check
    // → only canonicalize when findLoincDetailed.cleanMatch === true),
    // app-side alias table can retire.
    //
    // Mis-tag canary preservation: when a CBC panel sub-row's display
    // doesn't match any PANEL_LOINC_MAP["08011C"] key explicitly, the
    // row falls to the panel-default LOINC via findLoinc path C
    // (cleanMatch=false). In that case the raw display is preserved as
    // obs.code.text — letting downstream reviewers spot the mis-tag.
    // This is the lesson from v0.11.9 Bug 6 (帶狀嗜中性白血球 silently
    // routed to 770-8 panel default before the variant key was added).
    //
    // Short labels chosen to match clinical convention (Taiwan EHR
    // standard column headers). NOT LOINC's verbose long name — that
    // already lives in coding[loinc].display per LOINC_DISPLAY.
    "770-8": "Neutrophils %",
    "736-9": "Lymphocytes %",
    "5905-5": "Monocytes %",
    "13046-8": "Variant Lymphocytes %",
    "26477-0": "Variant Lymphocytes #",
    "19048-8": "Nucleated RBC /100 WBC",
    "30392-5": "Nucleated RBC #",
    "713-8": "Eosinophils %",
    "706-2": "Basophils %",
    "6690-2": "WBC",
    "4544-3": "HCT",
    "718-7": "Hb",
    "777-3": "Platelet",
    "787-2": "MCV",
    "785-6": "MCH",
    "786-4": "MCHC",
    "788-0": "RDW",
    "789-8": "RBC",
    "9830-1": "Total Cholesterol/HDL-C Ratio",
    "30522-7": "hs-CRP",
    "67151-1": "hs-Troponin T",
    "36916-5": "Free Kappa Light Chain",
    "33944-0": "Free Lambda Light Chain",
    "48378-4": "Free Kappa/Lambda Ratio",
    "57778-3": "Free Light Chains Panel",
    "1521-4": "2-h Postprandial Glucose"
  };
  var CBC_CANONICAL_TEXT_LOINCS = /* @__PURE__ */ new Set([
    "770-8",
    "736-9",
    "5905-5",
    "13046-8",
    "26477-0",
    "19048-8",
    "30392-5",
    "713-8",
    "706-2",
    "6690-2",
    "4544-3",
    "718-7",
    "777-3",
    "787-2",
    "785-6",
    "786-4",
    "788-0",
    "789-8"
  ]);
  var NHI_CODE_PANEL_NAME = {
    // v0.11.10 FHIR R4 compliance audit (2026-05-29): values must match
    // the NHI catalog's authoritative panel name verbatim — this map is
    // also consulted by `buildCodings` as the fallback for
    // `Observation.code.coding[nhi].display` when `raw.order_name` is
    // missing, and Coding.display per FHIR R4 must "follow the rules of
    // the system". Treating my paraphrase ("ABO 血型測定") as the NHI
    // catalog name would be wrong on both counts (FHIR semantic + faithful
    // transport). NHI 健保 catalog formal names confirmed via the SMART
    // app dev's bug report enumeration of observed DR titles.
    "11001C": "ABO\u8840\u578B\u6E2C\u5B9A\u6AA2\u9A57",
    "11003C": "RH\uFF08D\uFF09\u578B\u6AA2\u9A57",
    "11004C": "\u6297\u9AD4\u53CD\u61C9 (\u4E0D\u898F\u5247\u6297\u9AD4)"
  };

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/parsers.ts
  var UCUM_SYSTEM = "http://unitsofmeasure.org";
  var FULLWIDTH_RESULT_TOKENS = [
    ["\uFF1E", ">"],
    ["\uFF1C", "<"],
    ["\u2267", ">="],
    ["\u2266", "<="],
    ["\u2265", ">="],
    ["\u2264", "<="],
    ["\uFF08", "("],
    ["\uFF09", ")"],
    ["\uFF0B", "+"],
    ["\uFF0D", "-"]
  ];
  function translateFullwidth(s) {
    let out = s;
    for (const [from, to] of FULLWIDTH_RESULT_TOKENS) {
      if (out.includes(from)) {
        out = out.split(from).join(to);
      }
    }
    if (/[０-９．]/.test(out)) {
      out = out.replace(/[０-９]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 65248)).replace(/．/g, ".");
    }
    return out;
  }
  var HTML_ENTITIES = [
    ["&lt;", "<"],
    ["&gt;", ">"],
    ["&le;", "<="],
    ["&ge;", ">="],
    ["&#60;", "<"],
    ["&#62;", ">"],
    ["&amp;", "&"]
  ];
  function decodeHtmlEntities(s) {
    if (!s.includes("&")) return s;
    let out = s;
    for (const [from, to] of HTML_ENTITIES) {
      if (out.includes(from)) {
        out = out.split(from).join(to);
      }
    }
    return out;
  }
  var COMPARATOR_RE = /^\s*(<=|>=|<|>)\s*(.+)$/;
  var FLAGGED_COMPARATOR_RE = /^\s*\(\s*(?:\+|positive|pos)\s*\)\s*(<=|>=|<|>)\s*(.+)$/i;
  var QUALITATIVE_LAB_RESULT_RE = /^(?:(?:negative|positive|reactive|non[ -]?reactive)|(?:陰性|陽性|未檢出|檢出))(?:\s*\([^)]*\))?\s*$|^[1-4]?\+(?:\s*\([^)]*\))?\s*$/i;
  function isQualitativeLabResultValue(rawValue) {
    if (rawValue === null || rawValue === void 0) return false;
    return QUALITATIVE_LAB_RESULT_RE.test(translateFullwidth(String(rawValue).trim()));
  }
  function stripThousandsCommas(s) {
    return s.replace(/(?<=\d),(?=\d{3}(?!\d))/g, "");
  }
  var UCUM_OVERRIDES = {
    // Fullwidth → ASCII
    "\uFF05": "%",
    // Case-sensitive UCUM (Eq is 'eq', not 'Eq')
    "mEq/L": "meq/L",
    "meq/l": "meq/L",
    // Cell counts — UCUM scales with the 10*N factor (verified: NLM v1.4 +
    // HL7 ucum-common). thousand = 10*3, ten-thousand = 10*4, million = 10*6.
    // NHI/LIS ship many notations for the same magnitude.
    "K/uL": "10*3/uL",
    "k/uL": "10*3/uL",
    "*1000/uL": "10*3/uL",
    "1000/uL": "10*3/uL",
    "x10^3 /uL": "10*3/uL",
    "x10^3/uL": "10*3/uL",
    "10^3/uL": "10*3/uL",
    "x10^4 /uL": "10*4/uL",
    "x10^4/uL": "10*4/uL",
    "10^4/uL": "10*4/uL",
    "M/uL": "10*6/uL",
    "mil/cumm": "10*6/uL",
    // million cells per cubic mm = million cells/uL
    "*10^6/uL": "10*6/uL",
    "x10^6 /uL": "10*6/uL",
    "x10^6/uL": "10*6/uL",
    "10^6/uL": "10*6/uL",
    "million/uL": "10*6/uL",
    // Absolute counts per cubic millimetre. 1 mm3 = 1 uL, so the patient value
    // is unchanged; only the machine-readable unit spelling is normalised.
    "/cumm": "/uL",
    // Picogram is 'pg' (HL7); 'Pg' is petagram (10^15 g) — a case error. MCH's
    // descriptive '/Cell' suffix isn't UCUM (a cell is a dimensionless count).
    Pg: "pg",
    "pg/Cell": "pg",
    "pg/cell": "pg",
    // MCHC (LOINC 786-4) is g/dL; 'gHb' isn't a UCUM unit (Hb is descriptive).
    "gHb/dL": "g/dL",
    // Degree Celsius is 'Cel' (HL7 ucum-common).
    "\xB0C": "Cel",
    // UCUM is case-sensitive; hospital all-caps display text is not canonical.
    "MG/DL": "mg/dL",
    // Analyte/method annotations must use UCUM curly-brace syntax. The LIS
    // spellings below are printable ASCII, but are not valid UCUM and must not
    // fall through the permissive ASCII path (NLM isValidUCUM, 2026-07-14).
    "%RBC": "%{RBC}",
    "mg/L FEU": "mg/L{FEU}",
    // mmHg → mm[Hg]; cover mixed-case LIS variants.
    mmHg: "mm[Hg]",
    MMHG: "mm[Hg]",
    mmHG: "mm[Hg]",
    // eGFR / BSA-normalised. The BSA divisor is an annotation in canonical
    // UCUM, not multiplication by the non-UCUM token "1.73.m2".
    "mL/min/1.73m2": "mL/min/{1.73_m2}",
    "ml/min/1.73m2": "mL/min/{1.73_m2}",
    "mL/min/1.73M2": "mL/min/{1.73_m2}",
    "mL/min/1.73.m2": "mL/min/{1.73_m2}",
    "mL/min/1.73 m^2": "mL/min/{1.73_m2}",
    "mL/min/1.73 m2": "mL/min/{1.73_m2}",
    "ml/min/1.73 m2": "mL/min/{1.73_m2}",
    "mL/min/1.73m\xB2": "mL/min/{1.73_m2}",
    "mL/min/1.73M^2": "mL/min/{1.73_m2}",
    // Osmolality (2026-07-03): UCUM osmole is 'osm' (lowercase, case-sensitive;
    // web-verified ucum.org — 'osm'/'OSM' are the c/s and c/i forms), so milli
    // = 'mosm'. The LIS/print form 'mOsm/kg' has an invalid capital 'O' → would
    // be mislabelled as UCUM by the ASCII passthrough. Map to the valid 'mosm/kg'
    // (raw label still on Quantity.unit). 'mosm/kg' itself already passes through.
    "mOsm/kg": "mosm/kg",
    "mOsm/Kg": "mosm/kg",
    "mOsmol/kg": "mosm/kg",
    "mosmol/kg": "mosm/kg",
    "mOsm/kg H2O": "mosm/kg",
    "mOsm/kgH2O": "mosm/kg",
    "mosm/KgH2O": "mosm/kg",
    // Coagulation LIS spelling. UCUM uses the SI second symbol "s"; "sec" is
    // not a valid UCUM code (NLM isValidUCUM, verified 2026-07-13).
    sec: "s",
    // Urine albumin/creatinine ratio. The analyte annotation is valid UCUM and
    // avoids falsely passing the LIS prose "Creatinine" through as a unit token.
    "ug/mg Creatinine": "ug/mg{creat}",
    // International Unit (2026-07-03): UCUM code is '[iU]' (brackets; '[iU]' and
    // '[IU]' are equivalent — web-verified ucum.org). Bare 'IU' is NOT valid
    // UCUM. Insulin ships µIU/mL → micro-normalised to 'uIU/mL' upstream, so
    // key on that. Covers the common per-mL/per-L IU notations.
    "uIU/mL": "u[iU]/mL",
    "uIU/ml": "u[iU]/mL",
    "uIU/L": "u[iU]/L",
    "mIU/mL": "m[iU]/mL",
    "mIU/L": "m[iU]/L",
    "IU/mL": "[iU]/mL",
    "IU/L": "[iU]/L",
    // Arbitrary indices / placeholders we can't faithfully map to UCUM → omit
    // the code (raw label still on Quantity.unit). '.' = differential-count
    // placeholder (Normobl/PlasmaCell); OPF = Gram-stain organisms per
    // oil-power-field (semi-quant); COI = immunoassay cut-off index
    // (dimensionless ratio); E.U/dL = Ehrlich units (urobilinogen, no UCUM unit).
    ".": null,
    OPF: null,
    COI: null,
    "E.U/dL": null,
    // Common Chinese 'no unit' placeholders → drop UCUM code
    \u7121: null,
    \u7121\u55AE\u4F4D: null,
    "": null,
    "\u2014": null,
    "-": null
  };
  function toUcum(unit) {
    if (!unit) return null;
    let u = unit.normalize("NFKC").replace(/〈/g, "^").replace(/[µμ]/g, "u");
    if (/^(?:#\s*)?\/\s*100\s*(?:wbc|wbcs|leukocytes?)$/i.test(u.trim())) {
      u = "/100{WBCs}";
    }
    if (/^(?:#|cells?)\s*\/\s*u[lL]$/i.test(u.trim())) {
      u = "/uL";
    }
    const scaledCellCount = u.match(/^[x*]?\s*10\s*\^\s*([346])\s*\/\s*u[lL]$/i);
    if (scaledCellCount) {
      u = `10*${scaledCellCount[1]}/uL`;
    } else {
      u = u.replace(/\/u[lL]\b/g, "/uL");
    }
    u = u.replace(/\/(m|d)?l\b/g, (_match, prefix) => `/${prefix ?? ""}L`);
    u = u.replace(/\s*\/\s*24\s*(?:h|hr|hrs|hour|hours)\s*$/i, "/(24.h)");
    u = u.replace(/\s*\/\s*day\s*$/i, "/d");
    if (Object.prototype.hasOwnProperty.call(UCUM_OVERRIDES, u)) {
      return UCUM_OVERRIDES[u] ?? null;
    }
    if (/[^\x20-\x7E]/.test(u)) return null;
    return u;
  }
  function tryParseFloat(s) {
    if (s === "" || s == null) return null;
    const trimmed = s.trim();
    if (trimmed === "") return null;
    const n = Number(trimmed);
    if (!Number.isFinite(n)) return null;
    return n;
  }
  function readBracketGroup(s, start) {
    if (s[start] !== "[") return null;
    let depth = 0;
    for (let i = start; i < s.length; i++) {
      const ch = s[i];
      if (ch === "[") depth++;
      else if (ch === "]") {
        depth--;
        if (depth === 0) {
          return { content: s.slice(start + 1, i), end: i + 1 };
        }
      }
    }
    return null;
  }
  function skipSpaces(s, pos) {
    let i = pos;
    while (i < s.length && /\s/.test(s[i])) i++;
    return i;
  }
  function splitTopLevelBracketPair(s) {
    const trimmed = s.trim();
    const first = readBracketGroup(trimmed, 0);
    if (!first) return null;
    const secondStart = skipSpaces(trimmed, first.end);
    const second = readBracketGroup(trimmed, secondStart);
    if (!second) return null;
    if (skipSpaces(trimmed, second.end) !== trimmed.length) return null;
    return [first.content, second.content];
  }
  function normalizedRangePart(s) {
    return translateFullwidth(s).replace(/\s+/g, " ").trim();
  }
  function dedupeDuplicatedBracketPair(decoded, parsed) {
    const parsedPair = splitTopLevelBracketPair(parsed);
    if (!parsedPair) return null;
    if (normalizedRangePart(parsedPair[0]) !== normalizedRangePart(parsedPair[1])) return null;
    const decodedPair = splitTopLevelBracketPair(decoded);
    if (!decodedPair) return null;
    const decodedInner = decodedPair[0].trim();
    const parsedInner = parsedPair[0].trim();
    if (!decodedInner || !parsedInner) return null;
    return { decoded: decodedInner, parsed: parsedInner };
  }
  function parseRangeMulti(rawRange, unit) {
    const one = parseRange(rawRange, unit);
    return one ? [one] : [];
  }
  function parseRange(rawRange, _unit) {
    return parseRangeInner(rawRange);
  }
  function parseRangeInner(rawRange) {
    let decoded = decodeHtmlEntities((rawRange || "").trim());
    let s = translateFullwidth(decoded);
    if (!s) return null;
    if (_looksLikeInterpretationText(s)) {
      return { text: decoded, interpretationText: s };
    }
    const deduped = dedupeDuplicatedBracketPair(decoded, s);
    if (deduped) {
      decoded = deduped.decoded;
      s = deduped.parsed;
      if (_looksLikeInterpretationText(s)) {
        return { text: decoded, interpretationText: s };
      }
    }
    return { text: decoded };
  }
  function tryParseQuantity(rawValue, unit) {
    if (rawValue === null || rawValue === void 0) return null;
    let s = translateFullwidth(String(rawValue).trim());
    if (isQualitativeLabResultValue(s)) return null;
    let comparator = null;
    const cm = s.match(FLAGGED_COMPARATOR_RE) ?? s.match(COMPARATOR_RE);
    if (cm) {
      comparator = cm[1] ?? null;
      s = (cm[2] ?? "").trim();
    }
    let v = tryParseFloat(stripThousandsCommas(s));
    if (v === null) {
      const parenIdx = s.indexOf("(");
      if (parenIdx > 0) {
        const leading = stripThousandsCommas(s.slice(0, parenIdx).trim());
        v = tryParseFloat(leading);
        if (v === null && /^(?:[\d.]+\+|trace)/i.test(leading)) {
          return null;
        }
      }
      if (v === null) {
        const m = s.match(/\(\s*([+\-\d.,]+)\s*\)/);
        if (m && m[1]) {
          v = tryParseFloat(stripThousandsCommas(m[1]));
        }
      }
    }
    if (v === null) return null;
    const ucumCode = toUcum(unit);
    const qty = { value: v };
    if (unit) {
      qty.unit = unit;
    }
    if (ucumCode !== null) {
      qty.system = UCUM_SYSTEM;
      qty.code = ucumCode;
    }
    if (comparator) {
      qty.comparator = comparator;
    }
    return qty;
  }
  function _looksLikeInterpretationText(s) {
    const t = s.trim();
    if (!t) return false;
    if (t === "\u6B63\u5E38" || t === "\u7570\u5E38") return true;
    if (t.startsWith("[")) return false;
    if (t.includes("-") || t.includes("~") || /[<>≦≧≤≥]/.test(t)) return false;
    return t.includes("\u5EFA\u8B70") || t.includes("\u8ACB\u6D3D\u8A62") || t.includes("\u8ACB\u806F\u7D61") || t.includes("\u898B\u5099\u8A3B");
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/observation.ts
  function fhirDateTime2(value) {
    const source = String(value ?? "").trim();
    return source.includes("T") ? source : `${source}T00:00:00+08:00`;
  }
  var QC_CONTROL_PATTERNS = [
    /\bnor\.?\s*plasma\b/i,
    // Nor.plasma / Nor plasma / Norplasma
    /\bnormal\s+plasma\b/i,
    /\babn\.?\s*plasma\b/i,
    // Abn.plasma
    /\babnormal\s+plasma\b/i,
    /\bcontrol\s+(mean|plasma)\b/i,
    // "Control mean" / "Control plasma"
    /\bqc\s+(mean|control|plasma)\b/i,
    /對照血漿/,
    /控制血漿/,
    // v0.11.9 (SMART app dev report 2026-05-29): broaden from /正常血漿平均/
    // → /正常血漿.*平均/ so we catch '正常血漿APTT平均值' / '正常血漿PT平均值'
    // variants where the analyte name is wedged between '正常血漿' prefix
    // and '平均' suffix. Original literal pattern only matched bare
    // '正常血漿平均' (no analyte token in the middle).
    /正常血漿.*平均/
  ];
  function looksLikeQcControl(display) {
    if (!display) return false;
    return QC_CONTROL_PATTERNS.some((re) => re.test(display));
  }
  var QUALITY_FLAG_PATTERNS = [
    /^溶血\s*$/,
    // 溶血 (hemolysis)
    /^脂血\s*$/,
    // 脂血 (lipemia)
    /^黃疸\s*$/,
    // 黃疸 (icterus)
    /^hemoly[sz]is\s*$/i,
    /^lipemia\s*$/i,
    /^icteric?\s*$/i,
    /^icterus\s*$/i
  ];
  var NARRATIVE_ROW_PATTERNS = [
    /^[\s:：;；,，.。\-—－]+$/,
    // pure punctuation (incl. fullwidth)
    /comment\b/i,
    /\bnote\b/i,
    /^備註/,
    // 備註 (note)
    /^註\s*[:：]/
  ];
  function looksLikeQualityFlag(display) {
    if (!display) return false;
    return QUALITY_FLAG_PATTERNS.some((re) => re.test(display));
  }
  function looksLikeNarrativeRow(display) {
    if (!display) return false;
    return NARRATIVE_ROW_PATTERNS.some((re) => re.test(display));
  }
  function normalizeFullwidth(s) {
    if (!s) return "";
    return String(s).replace(/[！-～]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 65248));
  }
  var SIMPLE_VALUE_CONCEPTS = {
    negative: { code: "negative", display: "Negative" },
    neg: { code: "negative", display: "Negative" },
    "not detected": { code: "not-detected", display: "Not detected" },
    "not found": { code: "not-found", display: "Not found" },
    absent: { code: "absent", display: "Absent" },
    none: { code: "absent", display: "Absent" },
    \u9670\u6027: { code: "negative", display: "Negative" },
    \u672A\u6AA2\u51FA: { code: "not-detected", display: "Not detected" },
    \u672A\u5075\u6E2C: { code: "not-detected", display: "Not detected" },
    \u672A\u767C\u73FE: { code: "not-found", display: "Not found" },
    positive: { code: "positive", display: "Positive" },
    pos: { code: "positive", display: "Positive" },
    detected: { code: "detected", display: "Detected" },
    present: { code: "present", display: "Present" },
    reactive: { code: "reactive", display: "Reactive" },
    \u967D\u6027: { code: "positive", display: "Positive" },
    \u6AA2\u51FA: { code: "detected", display: "Detected" },
    \u5075\u6E2C\u5230: { code: "detected", display: "Detected" },
    normal: { code: "normal", display: "Normal" },
    \u6B63\u5E38: { code: "normal", display: "Normal" },
    abnormal: { code: "abnormal", display: "Abnormal" },
    \u7570\u5E38: { code: "abnormal", display: "Abnormal" },
    "non reactive": { code: "non-reactive", display: "Non-reactive" },
    nonreactive: { code: "non-reactive", display: "Non-reactive" },
    "non detected": { code: "not-detected", display: "Not detected" },
    trace: { code: "trace", display: "Trace" },
    "+/-": { code: "trace", display: "Trace" },
    "+-": { code: "trace", display: "Trace" },
    "\xB1": { code: "trace", display: "Trace" },
    clear: { code: "clear", display: "Clear" },
    yellow: { code: "yellow", display: "Yellow" },
    straw: { code: "straw", display: "Straw" },
    amber: { code: "amber", display: "Amber" },
    cloudy: { code: "cloudy", display: "Cloudy" },
    turbid: { code: "turbid", display: "Turbid" },
    \u900F\u660E: { code: "clear", display: "Clear" },
    \u6E05\u6F88: { code: "clear", display: "Clear" },
    \u9EC3\u8272: { code: "yellow", display: "Yellow" }
  };
  function valueContext(raw, display, code) {
    return {
      code: String(code ?? ""),
      display: String(display ?? ""),
      orderName: raw.order_name,
      itemName: raw.item_name,
      sourceProgram: raw.source_program
    };
  }
  function normalizeValueConceptKey(rawText) {
    let s = normalizeFullwidth(rawText.trim());
    if (s.startsWith("[") && s.endsWith("]")) {
      s = s.slice(1, -1).trim();
    }
    return s.toLowerCase().replace(/[‐‑‒–—－]/g, "-").replace(/[-_\s]+/g, " ").trim();
  }
  function concept(def, rawText) {
    return {
      coding: [
        {
          system: OBSERVATION_VALUE,
          code: def.code,
          display: def.display
        }
      ],
      text: rawText
    };
  }
  function contextHaystack(ctx) {
    return normalizeFullwidth(
      `${ctx.code} ${ctx.display} ${String(ctx.orderName ?? "")} ${String(ctx.itemName ?? "")}`
    );
  }
  function bloodTypeValueConcept(rawText, ctx) {
    const codeUpper = ctx.code.toUpperCase();
    const haystack = contextHaystack(ctx);
    const valueUpper = normalizeFullwidth(rawText).trim().toUpperCase();
    if (codeUpper === "11003C" || /\brh\b|rh\s*\(?d\)?|RH（D）/i.test(haystack)) {
      if (valueUpper === "+" || valueUpper === "POSITIVE" || rawText.trim() === "\u967D\u6027") {
        return concept({ code: "rh-positive", display: "Rh positive" }, rawText);
      }
      if (valueUpper === "-" || valueUpper === "NEGATIVE" || rawText.trim() === "\u9670\u6027") {
        return concept({ code: "rh-negative", display: "Rh negative" }, rawText);
      }
    }
    if (codeUpper === "11001C" || /\babo\b/i.test(haystack)) {
      const aboCodes = {
        A: { code: "abo-a", display: "A" },
        B: { code: "abo-b", display: "B" },
        AB: { code: "abo-ab", display: "AB" },
        O: { code: "abo-o", display: "O" }
      };
      const def = aboCodes[valueUpper];
      if (def) return concept(def, rawText);
    }
    return null;
  }
  function isDashNegativeContext(ctx) {
    if (String(ctx.sourceProgram ?? "") === "adult-preventive") return true;
    return /尿|urine|protein|dipstick|rh|hbsag|anti\s*hcv|anti-hcv|血型/i.test(contextHaystack(ctx));
  }
  function valueCodeableConceptFor(value, ctx) {
    if (value === null || value === void 0) return null;
    const rawText = String(value).trim();
    if (!rawText) return null;
    if (/^(?:n\/a|n\.a\.?|null)$/i.test(rawText)) return null;
    if (/^[—–－]+$/.test(rawText)) return null;
    const bloodType = bloodTypeValueConcept(rawText, ctx);
    if (bloodType) return bloodType;
    if (/^\+\/?-?$/.test(rawText) && rawText !== "+") {
      return concept({ code: "trace", display: "Trace" }, rawText);
    }
    if (normalizeFullwidth(rawText).trim() === "-") {
      return isDashNegativeContext(ctx) ? concept({ code: "negative", display: "Negative" }, rawText) : null;
    }
    const normalized = normalizeValueConceptKey(rawText);
    if (normalized === "+") return concept({ code: "positive", display: "Positive" }, rawText);
    const grade = normalized.match(/^([1-4])\+$/);
    if (grade) {
      return concept({ code: `grade-${grade[1]}-plus`, display: `${grade[1]}+` }, rawText);
    }
    if (/^異常[，,、\s]/.test(rawText)) {
      return concept({ code: "abnormal", display: "Abnormal" }, rawText);
    }
    const def = SIMPLE_VALUE_CONCEPTS[normalized];
    return def ? concept(def, rawText) : null;
  }
  function hasObservationValue(raw, display, code) {
    if (isMeaningfulValue(raw.value)) return true;
    return valueCodeableConceptFor(raw.value, valueContext(raw, display, code)) !== null;
  }
  function applyObservationValue(resource, raw, display, code, loinc) {
    const value = raw.value;
    if (!hasObservationValue(raw, display, code)) return;
    const unit = _canonicalizeUnit(display, code, raw.unit ?? "");
    const qty = tryParseQuantity(String(value), unit);
    if (qty) {
      resource.valueQuantity = qty;
      if (loinc === "9830-1" && qty.code && qty.code !== "1" && qty.code !== "{ratio}") {
        delete qty.system;
        delete qty.code;
      }
      if (String(code).trim() === "09134C" && /^\s*\(\s*(?:\+|positive|pos)\s*\)\s*(?:[<>]=?|[≧≦≥≤])/i.test(
        normalizeFullwidth(String(value))
      )) {
        resource.note = [{ text: `NHI source result: ${String(value)}` }];
      }
      return;
    }
    const valueConcept = valueCodeableConceptFor(value, valueContext(raw, display, code));
    if (valueConcept) resource.valueCodeableConcept = valueConcept;
    else resource.valueString = String(value);
  }
  var NHI_LAB_CODE_RE = /^\d{4,6}[A-Z]$/;
  function isAsciiOnly(s) {
    for (let i = 0; i < s.length; i++) {
      if (s.charCodeAt(i) > 127) return false;
    }
    return true;
  }
  var _KEYWORD_SEP_RE = /[\s._\-(),]+/g;
  function _keywordMatches(key, combined) {
    const k = key.toLowerCase();
    if (isAsciiOnly(key)) {
      const nk = k.replace(_KEYWORD_SEP_RE, " ").trim();
      const nc = combined.replace(_KEYWORD_SEP_RE, " ");
      return new RegExp(`\\b${escapeRegex(nk)}\\b`).test(nc);
    }
    return combined.includes(k);
  }
  function _findLongestMatch(combined, table) {
    let bestLoinc = null;
    let bestKeyLen = 0;
    for (const [key, loinc] of Object.entries(table)) {
      if (key.length > bestKeyLen && _keywordMatches(key, combined)) {
        bestLoinc = loinc;
        bestKeyLen = key.length;
      }
    }
    return bestLoinc;
  }
  function _loincRequiresBlood(loinc) {
    if (CBC_CANONICAL_TEXT_LOINCS.has(loinc)) return true;
    return /\b(?:in|of)\s+(?:arterial |venous |capillary |mixed venous )?blood\b/i.test(
      LOINC_DISPLAY[loinc] ?? ""
    );
  }
  function _loincIsSerumPlasma(loinc) {
    return /\bin Serum or Plasma\b/i.test(LOINC_DISPLAY[loinc] ?? "");
  }
  function _codeFamilyPositivelyNonBlood(code, display = "", orderName = "", itemName = "") {
    if (!/^\d{5}[A-Za-z]$/.test(String(code ?? "").trim())) return false;
    const spec = inferSpecimen(orderName, display, code, itemName);
    return spec != null && spec !== "Blood";
  }
  function _explicitNonBloodMarker(display = "", orderName = "", itemName = "") {
    const spec = inferSpecimen(orderName, display, "", itemName);
    return spec != null && spec !== "Blood";
  }
  function _codeFamilyNotConfirmedBlood(code, display = "", orderName = "", itemName = "") {
    if (!/^\d{5}[A-Za-z]$/.test(String(code ?? "").trim())) return false;
    return inferSpecimen(orderName, display, code, itemName) !== "Blood";
  }
  var EXPLICIT_BLOOD_MARKER_RE = /血清|血漿|血液|\bserum\b|\bplasma\b|\bblood\b|\(b\)/i;
  var MYO_ROW_RE = /\bmyoglobin\b|\bmyo\b|肌球蛋白|肌紅蛋白/i;
  function resolveMyoglobinSpecimen(code, display, orderName = "", itemName = "") {
    const isMyo = /^12061/.test(String(code ?? "").trim()) || MYO_ROW_RE.test(`${display} ${orderName} ${itemName}`);
    if (!isMyo) return void 0;
    if (inferSpecimen(orderName, display, "", itemName) === "Urine") return "2641-9";
    if (EXPLICIT_BLOOD_MARKER_RE.test(`${display} ${orderName} ${itemName}`)) return "2639-3";
    return null;
  }
  var ADA_ROW_RE = /\bada\b|adenosine\s*deaminase|腺[苷核甘]+去[胺氨]酶?|去胺酶/i;
  function resolveAdaSpecimen(code, display, orderName = "", itemName = "") {
    const isAda = /^09102/.test(String(code ?? "").trim()) || ADA_ROW_RE.test(`${display} ${orderName} ${itemName}`);
    if (!isAda) return void 0;
    const spec = inferSpecimen(orderName, display, "", itemName);
    if (spec === "Pleural fluid") return "35704-6";
    if (spec === "Peritoneal fluid") return "49759-4";
    if (spec === "Cerebrospinal fluid") return "35703-8";
    if (spec === "Synovial fluid") return "9404-5";
    if (EXPLICIT_BLOOD_MARKER_RE.test(`${display} ${orderName} ${itemName}`)) return "47826-3";
    return null;
  }
  var PH_LOINC_BY_SPECIMEN = {
    "Pleural fluid": "2750-8",
    "Peritoneal fluid": "2751-6",
    Stool: "2755-7",
    "Body fluid": "2748-2"
  };
  function resolveMultiSpecimenPh(code, display, orderName = "", itemName = "") {
    if (String(code ?? "").trim() !== "07007C") return void 0;
    const spec = inferSpecimen(orderName, display, "", itemName);
    return spec && PH_LOINC_BY_SPECIMEN[spec] || null;
  }
  function resolveMicroalbuminLoinc(code, display, orderName = "", itemName = "") {
    if (String(code ?? "").trim() !== "12111C") return void 0;
    const specimen = inferSpecimen(orderName, display, "", itemName);
    if (specimen === "Cerebrospinal fluid") return "1746-7";
    return void 0;
  }
  var AEROBIC_CULTURE_ROW_RE = /\baerobic\s+culture\b|嗜氧培養/i;
  var ANAEROBIC_CULTURE_ROW_RE = /\banaerobic\s+culture\b|厭氧培養/i;
  function resolveAerobicCultureLoinc(code, display, itemName = "") {
    if (String(code ?? "").trim() !== "13007C") return void 0;
    const rowText = normalizeFullwidth(`${display} ${itemName}`);
    const saysAerobic = AEROBIC_CULTURE_ROW_RE.test(rowText);
    const saysAnaerobic = ANAEROBIC_CULTURE_ROW_RE.test(rowText);
    if (saysAnaerobic) return null;
    if (saysAerobic) return "634-6";
    return void 0;
  }
  var MYCOBACTERIAL_CULTURE_LABEL_RE = /\btb\s*culture\b|\bafs\s*\+\s*culture\b|mycobacter(?:ium|ial)?\s*culture|分枝桿菌培養|抗酸菌培養/i;
  var ACID_FAST_STAIN_LABEL_RE = /\bafb\b|\baf\s*stain\b|\bsmear\b|acid[\s-]*fast(?:\s+bacilli)?(?:\s+stain)?|抗酸性?(?:濃縮)?(?:抹片)?染色|抗酸性?抹片/i;
  var EXPLICIT_ACID_FAST_STAIN_LABEL_RE = /\bafb(?:\s+stain)?\b|acid[\s-]*fast(?:\s+bacilli)?(?:\s+stain)?|抗酸性?(?:濃縮)?(?:抹片)?染色|抗酸性?抹片/i;
  var MYCOBACTERIAL_CULTURE_RESULT_RE = /no\s*growth(?:\s*for)?\s*mycobacter|no\s*growth\s*after\s*\d+\s*(?:days?|weeks?)|mycobacter(?:ium|ia|ial)?\s*(?:not\s*isolated|not\s*detected)|未培養出.*(?:分枝|抗酸)/i;
  var ACID_FAST_STAIN_RESULT_RE = /acid\s*fast\s*bacilli\s*[-:–—]?\s*(?:not\s*found|none\s*seen|negative)|\bafb\b.*(?:not\s*found|none\s*seen|negative)|未發現.*抗酸/i;
  function resolveMycobacterialStainCultureLoinc(code, display, orderName = "", itemName = "", value = "") {
    const normalizedCode = String(code ?? "").trim();
    if (!["13006C", "13013C", "13015C", "13025C", "13026C"].includes(normalizedCode)) {
      return void 0;
    }
    const resultText = String(value ?? "").trim();
    const rowText = `${display} ${itemName}`.trim() || String(orderName ?? "").trim();
    if (normalizedCode === "13006C") {
      const saysCulture2 = MYCOBACTERIAL_CULTURE_LABEL_RE.test(rowText);
      const saysAcidFast = EXPLICIT_ACID_FAST_STAIN_LABEL_RE.test(rowText);
      if (saysAcidFast && !saysCulture2) return "11545-1";
      if (saysAcidFast && saysCulture2) return null;
      return void 0;
    }
    if (normalizedCode === "13013C" || normalizedCode === "13015C") {
      const saysCulture2 = MYCOBACTERIAL_CULTURE_LABEL_RE.test(rowText);
      const saysStain2 = ACID_FAST_STAIN_LABEL_RE.test(rowText);
      if (saysCulture2 && MYCOBACTERIAL_CULTURE_RESULT_RE.test(resultText)) {
        return "50941-4";
      }
      if (saysStain2 && !saysCulture2 && ACID_FAST_STAIN_RESULT_RE.test(resultText)) return "11545-1";
      return void 0;
    }
    if (MYCOBACTERIAL_CULTURE_RESULT_RE.test(resultText)) return "50941-4";
    if (ACID_FAST_STAIN_RESULT_RE.test(resultText)) return "11545-1";
    const saysCulture = MYCOBACTERIAL_CULTURE_LABEL_RE.test(rowText);
    const saysStain = ACID_FAST_STAIN_LABEL_RE.test(rowText);
    if (saysCulture && !saysStain) return "50941-4";
    if (saysStain && !saysCulture) return "11545-1";
    if (saysCulture && saysStain) return null;
    return void 0;
  }
  var LOINC_MEMO_MAX_ENTRIES = 8192;
  var loincMemo = /* @__PURE__ */ new Map();
  function findLoincDetailed(code, display, orderName = "", itemName = "", value = "") {
    const memoKey = `${code}\0${display}\0${orderName}\0${itemName}\0${String(value)}`;
    const cached = loincMemo.get(memoKey);
    if (cached) return { ...cached };
    const resolved = computeLoincDetailed(code, display, orderName, itemName, value);
    if (loincMemo.size >= LOINC_MEMO_MAX_ENTRIES) loincMemo.clear();
    loincMemo.set(memoKey, resolved);
    return { ...resolved };
  }
  function computeLoincDetailed(code, display, orderName = "", itemName = "", value = "") {
    if (code && SPECIMEN_AMBIGUOUS_NO_LOINC_CODES.has(code)) {
      return { loinc: null, cleanMatch: false };
    }
    const myo = resolveMyoglobinSpecimen(code, display, orderName, itemName);
    if (myo !== void 0) return { loinc: myo, cleanMatch: myo !== null };
    const fluidPh = resolveMultiSpecimenPh(code, display, orderName, itemName);
    if (fluidPh !== void 0) return { loinc: fluidPh, cleanMatch: fluidPh !== null };
    const ada = resolveAdaSpecimen(code, display, orderName, itemName);
    if (ada !== void 0) return { loinc: ada, cleanMatch: ada !== null };
    const malb = resolveMicroalbuminLoinc(code, display, orderName, itemName);
    if (malb !== void 0) return { loinc: malb, cleanMatch: malb !== null };
    const aerobicCulture = resolveAerobicCultureLoinc(code, display, itemName);
    if (aerobicCulture !== void 0) {
      return { loinc: aerobicCulture, cleanMatch: aerobicCulture !== null };
    }
    const mycobacteria = resolveMycobacterialStainCultureLoinc(
      code,
      display,
      orderName,
      itemName,
      value
    );
    if (mycobacteria !== void 0) {
      return { loinc: mycobacteria, cleanMatch: mycobacteria !== null };
    }
    if (code && code in NHI_TO_LOINC && !DISPLAY_FIRST_CODES.has(code)) {
      return { loinc: NHI_TO_LOINC[code] ?? null, cleanMatch: true };
    }
    const combined = normalizeFullwidth(`${code} ${display}`).toLowerCase();
    if (code in PANEL_LOINC_MAP) {
      const hit2 = _findLongestMatch(combined, PANEL_LOINC_MAP[code]);
      if (hit2) {
        const guarded = loincSpecimenConsistencyGuard(hit2, orderName, display, code, itemName);
        return { loinc: guarded, cleanMatch: guarded !== null };
      }
    }
    const hit = _findLongestMatch(combined, LOINC_MAP);
    const markerNonBlood = _explicitNonBloodMarker(display, orderName, itemName);
    const vetoed = hit != null && // blood-family LOINC under a not-confirmed-blood code (incl. unknown) OR
    // an explicit non-blood marker
    (_loincRequiresBlood(hit) && (_codeFamilyNotConfirmedBlood(code, display, orderName, itemName) || markerNonBlood) || // 2026-07-04: serum/plasma LOINC under a POSITIVELY non-blood code
    // (Urine / Pleural / Stool …) — e.g. 16003C 胸水 "Glucose" → 1558-6
    // serum fasting glucose — OR an explicit non-blood marker. Degrade to
    // NHI-code-only, don't ship a serum label on a body-fluid measurement.
    _loincIsSerumPlasma(hit) && (_codeFamilyPositivelyNonBlood(code, display, orderName, itemName) || markerNonBlood));
    if (hit && !vetoed) {
      return { loinc: hit, cleanMatch: true };
    }
    if (code && code in NHI_TO_LOINC) {
      return { loinc: NHI_TO_LOINC[code] ?? null, cleanMatch: false };
    }
    return { loinc: null, cleanMatch: false };
  }
  function isPanelDefaultFallback(code, lookup) {
    return !lookup.cleanMatch && lookup.loinc != null && DISPLAY_FIRST_CODES.has(code) && lookup.loinc === NHI_TO_LOINC[code];
  }
  function buildCodings(code, display, loinc, nhiPanelName, itemName) {
    const codings = [];
    if (loinc) {
      codings.push({
        system: "http://loinc.org",
        code: loinc,
        display: LOINC_DISPLAY[loinc] ?? display
      });
    }
    const codeStr = (code ?? "").trim();
    if (codeStr && NHI_LAB_CODE_RE.test(codeStr)) {
      const nhiDisplay = nhiPanelName || display;
      codings.push({
        system: NHI_MEDICAL_ORDER_CODE,
        code: codeStr,
        display: nhiDisplay
      });
      const itemStr = (itemName ?? "").trim();
      if (itemStr && itemStr !== nhiDisplay) {
        codings.push({
          system: HIS_LOCAL_LAB_CODE,
          code: itemStr,
          display: itemStr
        });
      }
    } else {
      codings.push({
        system: HIS_LOCAL_LAB_CODE,
        code: codeStr || display,
        display
      });
    }
    return codings;
  }
  var INTERP_SYS2 = "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
  function interpCoding(code, display) {
    return { system: INTERP_SYS2, code, display };
  }
  var INTERP_TABLE = {
    high: ["H", "High"],
    low: ["L", "Low"],
    normal: ["N", "Normal"],
    critical: ["AA", "Critical abnormal"],
    abnormal: ["A", "Abnormal"],
    positive: ["POS", "Positive"],
    negative: ["NEG", "Negative"]
  };
  function mapInterpretation(interp) {
    let key = (interp ?? "").toLowerCase();
    if (interp) {
      if (interp.includes("\u7570\u5E38")) key = "abnormal";
      else if (interp.includes("\u6B63\u5E38")) key = "normal";
    }
    const entry = INTERP_TABLE[key];
    if (!entry) return null;
    return interpCoding(entry[0], entry[1]);
  }
  function applyNhiAbnormalFlag(resource, raw) {
    const flag = String(raw.abnormal_flag ?? "").trim();
    if (flag === "1") {
      resource.interpretation = [{ coding: [interpCoding("A", "Abnormal")] }];
    } else if (flag === "0") {
      resource.interpretation = [{ coding: [interpCoding("N", "Normal")] }];
    }
  }
  var LAB_SYNONYMS = {
    // Diabetes
    \u91A3\u5316\u8840\u7D05\u7D20: "HBA1C",
    \u7CD6\u5316\u8840\u8272\u7D20: "HBA1C",
    \u7CD6\u5316\u8840\u7D05\u7D20: "HBA1C",
    "GLYCATED HEMOGLOBIN": "HBA1C",
    HBA1C: "HBA1C",
    A1C: "HBA1C",
    \u7A7A\u8179\u8840\u7CD6: "GLUCOSE_FASTING",
    "FASTING GLUCOSE": "GLUCOSE_FASTING",
    \u8461\u8404\u7CD6: "GLUCOSE",
    \u8840\u7CD6: "GLUCOSE",
    GLUCOSE: "GLUCOSE",
    // CBC
    \u767D\u8840\u7403\u8A08\u6578: "WBC",
    \u767D\u8840\u7403: "WBC",
    WBC: "WBC",
    \u7D05\u8840\u7403\u8A08\u6578: "RBC",
    \u7D05\u8840\u7403: "RBC",
    RBC: "RBC",
    \u8840\u7D05\u7D20: "HEMOGLOBIN",
    \u8840\u8272\u7D20: "HEMOGLOBIN",
    HEMOGLOBIN: "HEMOGLOBIN",
    HGB: "HEMOGLOBIN",
    // v0.11.7 pre-existing gap (defensive): "Hb" was missing from
    // LAB_SYNONYMS so Hb display canonical → "hb" (fallback), not
    // HEMOGLOBIN → cross-language merge with "血紅素" never happened.
    HB: "HEMOGLOBIN",
    \u8840\u5BB9\u7A4D\u6BD4: "HEMATOCRIT",
    HEMATOCRIT: "HEMATOCRIT",
    HCT: "HEMATOCRIT",
    \u8840\u5C0F\u677F: "PLATELET",
    PLATELET: "PLATELET",
    PLT: "PLATELET",
    // CBC indices (10-char and 7-char CJK forms beat bare 紅血球)
    \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20\u6FC3\u5EA6: "MCHC",
    \u5E73\u5747\u7D05\u8840\u7403\u8840\u8272\u7D20: "MCH",
    \u5E73\u5747\u7D05\u8840\u7403\u6FC3\u5EA6: "MCHC",
    \u5E73\u5747\u7D05\u8840\u7403\u9AD4\u7A4D: "MCV",
    \u7D05\u8840\u7403\u5206\u5E03\u5BEC\u5EA6: "RDW",
    MCV: "MCV",
    MCH: "MCH",
    MCHC: "MCHC",
    RDW: "RDW",
    // CBC differential
    \u55DC\u4E2D\u6027\u767D\u8840\u7403: "NEUTROPHIL",
    \u55DC\u4F0A\u7D05\u6027\u767D\u8840\u7403: "EOSINOPHIL",
    \u55DC\u9178\u6027\u767D\u8840\u7403: "EOSINOPHIL",
    \u55DC\u9E7C\u6027\u767D\u8840\u7403: "BASOPHIL",
    \u6DCB\u5DF4\u7403: "LYMPHOCYTE",
    \u55AE\u6838\u7403: "MONOCYTE",
    EOSINOPHILS: "EOSINOPHIL",
    EOSINOPHIL: "EOSINOPHIL",
    NEUTROPHILS: "NEUTROPHIL",
    NEUTROPHIL: "NEUTROPHIL",
    BASOPHILS: "BASOPHIL",
    BASOPHIL: "BASOPHIL",
    LYMPHOCYTES: "LYMPHOCYTE",
    LYMPHOCYTE: "LYMPHOCYTE",
    MONOCYTES: "MONOCYTE",
    MONOCYTE: "MONOCYTE",
    // Lipid — LDL/HDL must precede bare CHOLESTEROL.
    "LDL CHOLESTEROL": "LDL_C",
    "LDL-CHOLESTEROL": "LDL_C",
    "HDL CHOLESTEROL": "HDL_C",
    "HDL-CHOLESTEROL": "HDL_C",
    \u4F4E\u5BC6\u5EA6\u81BD\u56FA\u9187: "LDL_C",
    \u9AD8\u5BC6\u5EA6\u81BD\u56FA\u9187: "HDL_C",
    \u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "LDL_C",
    \u9AD8\u5BC6\u5EA6\u8102\u86CB\u767D\u81BD\u56FA\u9187: "HDL_C",
    \u8840\u6E05\u7E3D\u81BD\u56FA\u9187: "TOTAL_CHOLESTEROL",
    \u7E3D\u81BD\u56FA\u9187: "TOTAL_CHOLESTEROL",
    "T-CHOLESTEROL": "TOTAL_CHOLESTEROL",
    "T-CHOL": "TOTAL_CHOLESTEROL",
    "TOTAL CHOLESTEROL": "TOTAL_CHOLESTEROL",
    CHOLESTEROL: "TOTAL_CHOLESTEROL",
    CHOL: "TOTAL_CHOLESTEROL",
    \u4E09\u9178\u7518\u6CB9\u916F: "TRIGLYCERIDE",
    TRIGLYCERIDE: "TRIGLYCERIDE",
    "HDL-C": "HDL_C",
    HDL: "HDL_C",
    \u9AD8\u5BC6\u5EA6\u8102\u86CB\u767D: "HDL_C",
    "LDL-C(DIRECT)": "LDL_C",
    "LDL-C": "LDL_C",
    LDL: "LDL_C",
    \u4F4E\u5BC6\u5EA6\u8102\u86CB\u767D: "LDL_C",
    // Renal — urine creatinine variants before serum.
    // v0.11.7 fix (bug 2026-05-28): added longer-keyed entries for
    // 肌酸酐(尿液) / 微白蛋白/肌酐酸比值 so urinalysis half-quantitative
    // rows don't collide with serum creatinine via shorter "肌酸酐" key.
    // Original short keys (肌酸酐 / 肌酐酸 → CREATININE) preserved for
    // serum rows; longer urinalysis-specific keys take priority via
    // longest-match in canonicalLabKey.
    "\u5FAE\u767D\u86CB\u767D/\u808C\u9150\u9178\u6BD4\u503C": "UACR",
    UACR: "UACR",
    "MALB/CRE": "UACR",
    "ALB/CRE": "UACR",
    "\u808C\u9178\u9150(\u5C3F\u6DB2)": "URINE_CREATININE",
    \u5C3F\u6DB2\u808C\u9178\u9150: "URINE_CREATININE",
    "URINE CREATININE": "URINE_CREATININE",
    "CREATININE(U)": "URINE_CREATININE",
    "CREATININE-U": "URINE_CREATININE",
    "CREA(U)": "URINE_CREATININE",
    "CREA-U": "URINE_CREATININE",
    "U-CRE": "URINE_CREATININE",
    "U-CREA": "URINE_CREATININE",
    \u808C\u9178\u9150: "CREATININE",
    \u808C\u9150\u9178: "CREATININE",
    "CREATININE(B)": "CREATININE",
    CREATININE: "CREATININE",
    CREA: "CREATININE",
    CRTN: "CREATININE",
    EGFR: "EGFR",
    \u5C3F\u7D20\u6C2E: "BUN",
    BUN: "BUN",
    \u5C3F\u9178\u9E7C\u5EA6: "URINE_PH",
    \u5C3F\u6DB2\u9178\u9E7C\u5EA6: "URINE_PH",
    \u9178\u9E7C\u5EA6: "PH",
    \u5C3F\u9178: "URIC_ACID",
    "URIC ACID": "URIC_ACID",
    URIC_ACID: "URIC_ACID",
    // Liver
    AST: "AST",
    ALT: "ALT",
    GOT: "AST",
    GPT: "ALT",
    \u81BD\u7D05\u7D20: "BILIRUBIN",
    BILIRUBIN: "BILIRUBIN",
    // v0.11.7 (bug 2026-05-28): longer keys for urinalysis to prevent
    // collision with serum analytes — 微白蛋白(尿) wasn't 白蛋白; 白血
    // 球酯脢 wasn't blood 白血球. Longer keys take priority via
    // longest-match sorting.
    "\u5FAE\u767D\u86CB\u767D(\u5C3F)": "URINE_MICROALBUMIN",
    \u5FAE\u767D\u86CB\u767D: "URINE_MICROALBUMIN",
    "MALB(U)": "URINE_MICROALBUMIN",
    MICROALBUMIN: "URINE_MICROALBUMIN",
    \u767D\u86CB\u767D: "ALBUMIN",
    ALBUMIN: "ALBUMIN",
    \u767D\u8840\u7403\u916F\u8122: "URINE_LEU_ESTERASE",
    \u767D\u8840\u7403\u916F\u9176: "URINE_LEU_ESTERASE",
    "WBC ESTERASE": "URINE_LEU_ESTERASE",
    "LEUKOCYTE ESTERASE": "URINE_LEU_ESTERASE",
    // Cardiac
    \u5FC3\u808C\u65CB\u8F49\u86CB\u767D: "TROPONIN",
    TROPONIN: "TROPONIN",
    BNP: "BNP",
    \u5FC3\u81DF: "TROPONIN",
    // Thyroid
    \u7532\u72C0\u817A\u523A\u6FC0\u7D20: "TSH",
    TSH: "TSH",
    \u6E38\u96E2\u7532\u72C0\u817A\u7D20: "FREE_T4",
    "FREE T4": "FREE_T4",
    FT4: "FREE_T4",
    // Misc
    C\u53CD\u61C9\u6027\u86CB\u767D: "CRP",
    "C-REACTIVE PROTEIN": "CRP",
    CRP: "CRP",
    "HS-CRP": "HS_CRP",
    \u651D\u8B77\u817A\u7279\u7570\u6297\u539F: "PSA",
    PSA: "PSA",
    \u9435\u86CB\u767D: "FERRITIN",
    FERRITIN: "FERRITIN",
    \u8449\u9178: "FOLATE",
    FOLATE: "FOLATE",
    \u7DAD\u751F\u7D20B12: "VITAMIN_B12",
    "VIT B12": "VITAMIN_B12",
    "VITAMIN B12": "VITAMIN_B12",
    \u76AE\u8CEA\u7D20: "CORTISOL",
    CORTISOL: "CORTISOL",
    \u6885\u6BD2: "RPR",
    RPR: "RPR",
    \u96B1\u7403\u83CC\u6297\u539F: "CRYPTOCOCCAL_AG",
    CRYPAG: "CRYPTOCOCCAL_AG",
    \u8840\u6C28: "AMMONIA",
    AMMONIA: "AMMONIA",
    \u51DD\u8840\u9176\u539F\u6642\u9593: "PT",
    APTT: "APTT",
    INR: "INR"
  };
  var LAB_SYNONYM_KEYS_SORTED = Object.keys(LAB_SYNONYMS).sort((a, b) => b.length - a.length);
  var URINALYSIS_PANEL_SYNONYMS = {
    // English / abbreviation variants
    GLUCOSE: "URINE_GLUCOSE",
    "U-SUGAR": "URINE_GLUCOSE",
    SUGAR: "URINE_GLUCOSE",
    "U-GLUCOSE": "URINE_GLUCOSE",
    COLOR: "URINE_COLOR",
    COLOUR: "URINE_COLOR",
    BLOOD: "URINE_OCCULT_BLOOD",
    "U-BLOOD": "URINE_OCCULT_BLOOD",
    OB: "URINE_OCCULT_BLOOD",
    "OCCULT BLOOD": "URINE_OCCULT_BLOOD",
    PROTEIN: "URINE_PROTEIN",
    "U-PRO": "URINE_PROTEIN",
    "U-PROTEIN": "URINE_PROTEIN",
    KETONE: "URINE_KETONES",
    KETONES: "URINE_KETONES",
    KET: "URINE_KETONES",
    NITRITE: "URINE_NITRITE",
    NIT: "URINE_NITRITE",
    TURBIDITY: "URINE_TURBIDITY",
    "SP.GRAVITY": "URINE_SG",
    SG: "URINE_SG",
    "S.G.": "URINE_SG",
    "S.G": "URINE_SG",
    "SPECIFIC GRAVITY": "URINE_SG",
    UROBILINOGEN: "URINE_UROBILINOGEN",
    UBG: "URINE_UROBILINOGEN",
    URO: "URINE_UROBILINOGEN",
    // pH variants — v0.11.7 missing in initial commit; user reported
    // pH (英) + 酸鹼值 (中) still as 2 rows in 06013C bundle.
    PH: "URINE_PH",
    "P.H.": "URINE_PH",
    "P.H": "URINE_PH",
    "U-PH": "URINE_PH",
    // Bilirubin variants — separate from serum BILIRUBIN so urine
    // bilirubin (06013C) doesn't cross-panel-collide with serum
    // total bilirubin (09029C). Within scope, English "Bilirubin" and
    // CJK 膽紅素 both → URINE_BILIRUBIN → merge as 1 row.
    BILIRUBIN: "URINE_BILIRUBIN",
    BILI: "URINE_BILIRUBIN",
    "U-BILI": "URINE_BILIRUBIN",
    // CJK variants — paired with English above so cross-language dedup works
    \u5C3F\u7CD6: "URINE_GLUCOSE",
    \u984F\u8272: "URINE_COLOR",
    \u5C3F\u6F5B\u8840: "URINE_OCCULT_BLOOD",
    \u5C3F\u86CB\u767D: "URINE_PROTEIN",
    \u916E\u9AD4: "URINE_KETONES",
    \u4E9E\u785D\u9178\u9E7D: "URINE_NITRITE",
    \u6FC1\u5EA6: "URINE_TURBIDITY",
    \u6BD4\u91CD: "URINE_SG",
    \u5C3F\u81BD\u7D20\u539F: "URINE_UROBILINOGEN",
    \u9178\u9E7C\u503C: "URINE_PH",
    \u9178\u9E7C\u5EA6: "URINE_PH",
    \u81BD\u7D05\u7D20: "URINE_BILIRUBIN"
  };
  var CODE_SCOPED_SYNONYMS = {
    "06013C": URINALYSIS_PANEL_SYNONYMS
  };
  var CODE_SCOPED_CJK_KEYS_SORTED = Object.fromEntries(
    Object.entries(CODE_SCOPED_SYNONYMS).map(([code, table]) => [
      code,
      Object.keys(table).filter((k) => !isAsciiOnly(k)).sort((a, b) => b.length - a.length)
    ])
  );
  function canonicalLabKey(display, code) {
    if (!display) return "";
    const s = display.trim();
    if (!s) return "";
    const sUpper = s.toUpperCase();
    if (code) {
      const codeUpper = code.toUpperCase();
      const scoped = CODE_SCOPED_SYNONYMS[codeUpper];
      if (scoped) {
        if (scoped[sUpper]) return scoped[sUpper];
        if (scoped[s]) return scoped[s];
        for (const key of CODE_SCOPED_CJK_KEYS_SORTED[codeUpper] ?? []) {
          if (s.includes(key)) return scoped[key];
        }
      }
    }
    for (const key of LAB_SYNONYM_KEYS_SORTED) {
      const ku = key.toUpperCase();
      if (isAsciiOnly(ku)) {
        if (new RegExp(`\\b${escapeRegex(ku)}`).test(sUpper)) {
          return LAB_SYNONYMS[key];
        }
      } else if (sUpper.includes(ku)) {
        return LAB_SYNONYMS[key];
      }
    }
    return s.toLowerCase().replace(/\s+/g, " ").trim();
  }
  function isEnglishDominant(s) {
    let latin = 0;
    for (const ch of s) {
      const cp = ch.charCodeAt(0);
      if (cp < 128 && /[A-Za-z]/.test(ch)) latin++;
    }
    return latin >= 2 && cjkChars(s) === 0;
  }
  function normalizeValueForDedup(v) {
    if (v === null || v === void 0) return "";
    let s = String(v).trim().toLowerCase();
    s = s.replace(/\([^)]*\)/g, "").trim();
    s = s.replace(/\s+/g, " ");
    return s;
  }
  function isMeaningfulValue(value) {
    if (value === null || value === void 0) return false;
    const s = String(value).normalize("NFKC").trim();
    const folded = s.toLocaleLowerCase("en-US");
    return s !== "" && !/^[\-‐‑‒–—―－]+$/u.test(s) && folded !== "n/a" && folded !== "na" && folded !== "null" && folded !== "none";
  }
  var PLACEHOLDER_UNIT_RE = /^(?:空白空白|空白|n\/a|n\.a\.?|nil|無|null|none|未|—|–|-{1,3})$/i;
  function _canonicalizeUnit(display, _code, rawUnit) {
    let u = (rawUnit ?? "").trim();
    if (PLACEHOLDER_UNIT_RE.test(u)) {
      u = "";
    }
    const isBogus = u === "" || u === "N" || u === "n";
    if (isBogus) {
      if (/egfr|estimated\s*gfr|estimated\s*glomerular|腎絲球過濾率/i.test(display)) {
        return "mL/min/1.73m2";
      }
      return u;
    }
    let normalized = u;
    normalized = normalized.replace(/㎡/g, "m2").replace(/㎝/g, "cm").replace(/㎠/g, "mm").replace(/㎢/g, "km");
    normalized = normalized.replace(/\bgm(\s*\/)/gi, "g$1");
    normalized = normalized.replace(/\/d[lL]\.?/g, "/dL");
    normalized = normalized.replace(/\/(\d*)l\b/g, "/$1L");
    if (normalized === "\u500D\u6578" || normalized === "\u500D") {
      return "{ratio}";
    }
    return normalized;
  }
  var MEANINGFUL_INTERPS = /* @__PURE__ */ new Set([
    "normal",
    "abnormal",
    "high",
    "low",
    "critical",
    "positive",
    "negative"
  ]);
  function dedupePanelItems(items) {
    const byKey = /* @__PURE__ */ new Map();
    for (const it of items) {
      const k = `${normalizeValueForDedup(it.value)}|${String(it.display ?? "").toLowerCase().trim()}`;
      const group = byKey.get(k);
      if (group) group.push(it);
      else byKey.set(k, [it]);
    }
    const out = [];
    for (const group of byKey.values()) {
      if (group.length === 1) {
        out.push(group[0]);
        continue;
      }
      const cjkItems = group.filter((g) => cjkChars(String(g.display ?? "")) >= 2);
      const enItems = group.filter((g) => isEnglishDominant(String(g.display ?? "")));
      if (cjkItems.length > 0 && enItems.length > 0) {
        out.push(enItems[0]);
      } else {
        out.push(...group);
      }
    }
    return out;
  }
  var PLACEHOLDER_METHOD_RE = /^(?:n\/?a|n\.a\.?|空白空白|空白|無|null|none|未|—|–|-{1,3})$/i;
  function clinicalDuplicateScore(item) {
    const method = String(item.assay_method ?? "").trim();
    const referenceRange = String(item.reference_range ?? "").trim();
    const rawUnit = String(item.unit ?? "").trim();
    let score = 0;
    if (method && !PLACEHOLDER_METHOD_RE.test(method)) score += 4;
    if (referenceRange && !/^\[?(?:無|-)?\]?(?:\[\])?$/.test(referenceRange)) score += 3;
    if (rawUnit && !PLACEHOLDER_UNIT_RE.test(rawUnit) && !/^x$/i.test(rawUnit)) score += 2;
    if (String(item.nhi_source_channel ?? "").trim().toUpperCase() === "A") score += 1;
    return score;
  }
  function normalizedDuplicateUnit(item, display, code) {
    const rawUnit = String(item.unit ?? "").trim();
    if (/^x$/i.test(rawUnit)) return "";
    const cleaned = _canonicalizeUnit(display, code, rawUnit);
    return (toUcum(cleaned) ?? cleaned).trim().toLowerCase();
  }
  function repeatedSourceRowTerm(item) {
    const match = /#(\d+)$/.exec(String(item.source_record_key ?? "").trim());
    if (!match) return "";
    const ordinal = Number.parseInt(match[1], 10);
    return Number.isFinite(ordinal) && ordinal > 1 ? `repeat${ordinal}` : "";
  }
  function dedupeSameClinicalMeasurements(items) {
    const byKey = /* @__PURE__ */ new Map();
    const passthrough = [];
    for (const item of items) {
      const code = String(item.order_code ?? item.code ?? "").trim().toUpperCase();
      const display = String(item.display ?? item.item_name ?? "").trim();
      const itemName = String(item.item_name ?? "").trim();
      const date = String(item.date ?? "").trim();
      const hospital = String(item.hospital ?? "").trim();
      const groupInstanceKey = String(item.group_instance_key ?? "").trim();
      const value = normalizeFullwidth(String(item.value ?? "")).trim().toLowerCase();
      if (!code || !display || !date || !hospital || !groupInstanceKey || !value) {
        passthrough.push(item);
        continue;
      }
      const lookup = findLoincDetailed(
        code,
        display,
        String(item.order_name ?? ""),
        itemName,
        item.value
      );
      const analyteKey = lookup.cleanMatch && lookup.loinc ? `loinc:${lookup.loinc}` : `canonical:${canonicalLabKey(display, code)}`;
      const unit = normalizedDuplicateUnit(item, display, code);
      const key = JSON.stringify([
        code,
        date,
        hospital,
        groupInstanceKey,
        analyteKey,
        value,
        unit,
        repeatedSourceRowTerm(item)
      ]);
      const existing = byKey.get(key);
      if (!existing) {
        byKey.set(key, item);
        continue;
      }
      const preferred = clinicalDuplicateScore(item) > clinicalDuplicateScore(existing) ? item : existing;
      const secondary = preferred === item ? existing : item;
      const merged = { ...preferred };
      merged.item_name = String(preferred.item_name ?? "").trim() || String(secondary.item_name ?? "").trim();
      for (const field of ["reference_range", "assay_method", "abnormal_flag"]) {
        if (!String(merged[field] ?? "").trim() && String(secondary[field] ?? "").trim()) {
          merged[field] = secondary[field];
        }
      }
      byKey.set(key, merged);
    }
    return [...byKey.values(), ...passthrough];
  }
  function filterLabRows(rawItems) {
    const out = [];
    for (const raw of rawItems) {
      if (!raw || typeof raw !== "object") continue;
      const display = raw.display || raw.code || "";
      if (looksLikeQcControl(String(display))) continue;
      if (looksLikeQualityFlag(String(display))) continue;
      if (looksLikeNarrativeRow(String(display))) continue;
      const value = raw.value;
      const interp = (raw.interpretation ?? "").toString().toLowerCase();
      const hasValue = hasObservationValue(
        raw,
        String(display),
        String(raw.order_code || raw.code || "")
      );
      const hasMeaningfulInterp = MEANINGFUL_INTERPS.has(interp);
      if (!hasValue && !hasMeaningfulInterp) continue;
      out.push(raw);
    }
    return out;
  }
  function pickFullerLabel(a, b) {
    const aa = (a ?? "").trim();
    const bb = (b ?? "").trim();
    if (!aa) return bb;
    if (!bb) return aa;
    const aCjk = cjkChars(aa);
    const bCjk = cjkChars(bb);
    if (aCjk > 0 && bCjk === 0) return aa;
    if (bCjk > 0 && aCjk === 0) return bb;
    return bb.length > aa.length ? bb : aa;
  }
  function pickFullerItemName(rows) {
    let best = "";
    for (const r of rows) best = pickFullerLabel(best, String(r.item_name ?? ""));
    return best;
  }
  function dedupNhiCrossChannelPairs(items) {
    const groups = /* @__PURE__ */ new Map();
    const order = [];
    for (const item of items) {
      const code = String(item.code ?? item.order_code ?? "").trim();
      const date = String(item.date ?? "").trim();
      const hospital = String(item.hospital ?? "").trim();
      const value = String(item.value ?? "").trim();
      const display = String(item.display ?? "").trim();
      const groupInstanceKey = String(item.group_instance_key ?? "").trim();
      const { loinc } = findLoincDetailed(
        code,
        display,
        String(item.order_name ?? ""),
        String(item.item_name ?? ""),
        item.value
      );
      const adjustmentAxis = bloodGasAdjustmentAxis(code, display, item.item_name);
      const key = `${code}|${loinc ?? "_"}|${adjustmentAxis}|${date}|${hospital}|${groupInstanceKey}|${value}`;
      if (!groups.has(key)) {
        groups.set(key, []);
        order.push(key);
      }
      groups.get(key).push(item);
    }
    const out = [];
    for (const key of order) {
      const group = groups.get(key);
      if (group.length < 2) {
        out.push(...group);
        continue;
      }
      const aRows = group.filter((r) => String(r.nhi_source_channel ?? "").toUpperCase() === "A");
      const bRows = group.filter((r) => String(r.nhi_source_channel ?? "").toUpperCase() === "B");
      if (aRows.length > 0 && bRows.length > 0) {
        const bItemName = pickFullerItemName(bRows);
        if (bItemName) {
          for (const a of aRows) {
            a.item_name = pickFullerLabel(String(a.item_name ?? ""), bItemName);
          }
        }
        out.push(...aRows);
      } else {
        out.push(...group);
      }
    }
    return out;
  }
  var MERGED_UACR_GROUP_CODE = "merged-uacr-workup";
  var UACR_MEMBER_LOINCS = ["14957-5", "2161-8", "14959-1"];
  var MERGED_HB_HCT_GROUP_CODE = "merged-hemoglobin-hematocrit-panel";
  var MERGED_CBC_DIFF_GROUP_CODE = "merged-cbc-with-differential-panel";
  var MERGED_INFLUENZA_AB_GROUP_CODE = "merged-influenza-a-b-antigen-panel";
  var MERGED_MYCOBACTERIAL_GROUP_CODE = "merged-mycobacterial-stain-culture-panel";
  var MERGED_FOUR_CODE_MYCOBACTERIAL_GROUP_CODE = "merged-four-code-mycobacterial-stain-culture-panel";
  var MERGED_MYCOBACTERIAL_CULTURE_STATUS_GROUP_CODE = "merged-mycobacterial-culture-status-workup";
  var EXACT_CROSS_CODE_WORKUP_RULES = [
    {
      groupCode: MERGED_UACR_GROUP_CODE,
      sourceCodes: ["09016C", "12111C"],
      memberLoincs: UACR_MEMBER_LOINCS,
      preferredSourceCode: {
        "14957-5": "12111C",
        // microalbumin result → microalbumin billing code
        "2161-8": "09016C",
        // urine creatinine result → urine creatinine billing code
        "14959-1": "12111C"
        // primary UACR result → microalbumin workup
      },
      reportLoinc: "14959-1",
      reportTitle: "Urine Albumin/Creatinine Ratio",
      dedupCode: "cross-code-uacr-exact-member-match",
      dedupDisplay: "Merged exact duplicate 09016C and 12111C UACR workups"
    },
    {
      groupCode: MERGED_HB_HCT_GROUP_CODE,
      sourceCodes: ["08003C", "08004C"],
      memberLoincs: ["718-7", "4544-3"],
      preferredSourceCode: {
        "718-7": "08003C",
        // Hb result → hemoglobin billing code
        "4544-3": "08004C"
        // Hct result → hematocrit billing code
      },
      reportLoinc: "24360-0",
      reportTitle: "Hemoglobin and Hematocrit",
      dedupCode: "cross-code-hb-hct-exact-member-match",
      dedupDisplay: "Merged exact duplicate 08003C and 08004C Hb/Hct workups"
    },
    {
      groupCode: MERGED_CBC_DIFF_GROUP_CODE,
      sourceCodes: ["08011C", "08013C"],
      memberLoincs: [
        "6690-2",
        "789-8",
        "718-7",
        "4544-3",
        "777-3",
        "787-2",
        "785-6",
        "786-4",
        "788-0",
        "770-8",
        "736-9",
        "5905-5",
        "713-8",
        "706-2"
      ],
      preferredSourceCode: {
        "6690-2": "08011C",
        "789-8": "08011C",
        "718-7": "08011C",
        "4544-3": "08011C",
        "777-3": "08011C",
        "787-2": "08011C",
        "785-6": "08011C",
        "786-4": "08011C",
        "788-0": "08011C",
        "770-8": "08013C",
        "736-9": "08013C",
        "5905-5": "08013C",
        "713-8": "08013C",
        "706-2": "08013C"
      },
      reportLoinc: "57021-8",
      reportTitle: "CBC with Automated Differential",
      dedupCode: "cross-code-cbc-diff-exact-member-match",
      dedupDisplay: "Merged exact duplicate 08011C and 08013C CBC/differential workups"
    },
    {
      groupCode: MERGED_INFLUENZA_AB_GROUP_CODE,
      sourceCodes: ["14065C", "14066C"],
      memberLoincs: ["80382-5", "80383-3"],
      preferredSourceCode: {
        "80382-5": "14065C",
        "80383-3": "14066C"
      },
      reportLoinc: "80381-7",
      reportTitle: "Influenza A/B Antigen Panel",
      dedupCode: "cross-code-influenza-a-b-exact-member-match",
      dedupDisplay: "Merged exact duplicate 14065C and 14066C influenza A/B workups"
    },
    {
      // Some hospitals attach the same complete stain+culture workup to the
      // identification and susceptibility orders as well as the nominal stain
      // and culture orders. Prefer this four-code exact rule; the two-code rule
      // immediately below remains the fallback for hospitals that only export
      // 13025C/13026C.
      groupCode: MERGED_FOUR_CODE_MYCOBACTERIAL_GROUP_CODE,
      sourceCodes: ["13013C", "13015C", "13025C", "13026C"],
      memberLoincs: ["11545-1", "50941-4"],
      preferredSourceCode: {
        "11545-1": "13025C",
        "50941-4": "13026C"
      },
      reportLoinc: "94540-2",
      reportTitle: "Mycobacterial Stain and Culture",
      dedupCode: "cross-code-four-order-mycobacterial-stain-culture-exact-match",
      dedupDisplay: "Merged exact duplicate stain/culture workup across 13013C, 13015C, 13025C and 13026C"
    },
    {
      groupCode: MERGED_MYCOBACTERIAL_GROUP_CODE,
      sourceCodes: ["13025C", "13026C"],
      memberLoincs: ["11545-1", "50941-4"],
      preferredSourceCode: {
        "11545-1": "13025C",
        "50941-4": "13026C"
      },
      reportLoinc: "94540-2",
      reportTitle: "Mycobacterial Stain and Culture",
      dedupCode: "cross-code-mycobacterial-stain-culture-exact-member-match",
      dedupDisplay: "Merged exact duplicate 13025C and 13026C stain/culture workups"
    },
    {
      groupCode: MERGED_MYCOBACTERIAL_CULTURE_STATUS_GROUP_CODE,
      sourceCodes: ["13013C", "13015C", "13025C", "13026C"],
      memberLoincs: ["50941-4"],
      preferredSourceCode: {
        "50941-4": "13026C"
        // culture result → mycobacterial culture billing code
      },
      reportLoinc: "50941-4",
      reportTitle: "Mycobacterial Culture",
      dedupCode: "cross-code-mycobacterial-culture-status-exact-match",
      dedupDisplay: "Merged exact duplicate culture status across 13013C, 13015C, 13025C and 13026C"
    }
  ];
  function exactCrossCodeRuleForGroup(groupCode) {
    return EXACT_CROSS_CODE_WORKUP_RULES.find((rule) => rule.groupCode === groupCode);
  }
  function exactCrossCodeMember(item, index, rule) {
    const code = String(item.order_code ?? item.code ?? "").trim();
    if (!rule.sourceCodes.includes(code)) return null;
    const display = String(item.display ?? "");
    const { loinc } = findLoincDetailed(
      code,
      display,
      String(item.order_name ?? ""),
      String(item.item_name ?? ""),
      item.value
    );
    if (!loinc || !rule.memberLoincs.includes(loinc)) return null;
    const fingerprint = JSON.stringify([
      loinc,
      String(item.value ?? "").trim(),
      String(item.unit ?? "").trim(),
      String(item.reference_range ?? "").trim(),
      String(item.interpretation ?? "").trim(),
      String(item.abnormal_flag ?? "").trim(),
      String(item.nhi_source_channel ?? "").trim().toUpperCase(),
      String(item.nhi_visit_date ?? "").trim(),
      String(item.source_program ?? "").trim()
    ]);
    return { index, item, loinc, fingerprint };
  }
  function mergeExactDuplicateWorkupsForRule(items, rule) {
    const contexts = /* @__PURE__ */ new Map();
    const sourceItemCounts = /* @__PURE__ */ new Map();
    for (let index = 0; index < items.length; index++) {
      const item = items[index];
      const code = String(item.order_code ?? item.code ?? "").trim();
      if (!rule.sourceCodes.includes(code)) continue;
      const date = String(item.date ?? "").trim();
      const hospital = String(item.hospital ?? "").trim();
      if (!date || !hospital) continue;
      const groupInstanceKey = String(item.group_instance_key ?? "").trim();
      const contextKey = `${date}|${hospital}|${groupInstanceKey}`;
      const sourceCountKey = `${contextKey}|${code}`;
      sourceItemCounts.set(sourceCountKey, (sourceItemCounts.get(sourceCountKey) ?? 0) + 1);
      const member = exactCrossCodeMember(item, index, rule);
      if (!member) continue;
      const byCode = contexts.get(contextKey) ?? /* @__PURE__ */ new Map();
      const members = byCode.get(code) ?? [];
      members.push(member);
      byCode.set(code, members);
      contexts.set(contextKey, byCode);
    }
    const consumedIndexes = /* @__PURE__ */ new Set();
    const inserts = /* @__PURE__ */ new Map();
    for (const [contextKey, byCode] of contexts) {
      const groups = rule.sourceCodes.map((code) => byCode.get(code) ?? []);
      if (rule.sourceCodes.some(
        (code) => sourceItemCounts.get(`${contextKey}|${code}`) !== rule.memberLoincs.length
      ) || groups.some((group) => group.length !== rule.memberLoincs.length))
        continue;
      const hasExactMemberSet = (group) => {
        const loinCs = new Set(group.map((member) => member.loinc));
        return loinCs.size === rule.memberLoincs.length && rule.memberLoincs.every((loinc) => loinCs.has(loinc));
      };
      if (!groups.every(hasExactMemberSet)) continue;
      const fingerprints = groups.map(
        (group) => JSON.stringify(group.map((member) => member.fingerprint).sort())
      );
      if (!fingerprints.every((fingerprint) => fingerprint === fingerprints[0])) continue;
      const allMembers = groups.flat();
      const sourceOrders = rule.sourceCodes.map((code) => {
        const member = byCode.get(code)[0];
        return {
          code,
          display: String(member.item.order_name ?? "").trim()
        };
      });
      const mergedMembers = rule.memberLoincs.map((loinc) => {
        const preferredCode = rule.preferredSourceCode[loinc];
        const source = byCode.get(preferredCode).find((member) => member.loinc === loinc);
        return {
          ...source.item,
          __report_group_code: rule.groupCode,
          __observation_panel_code: preferredCode,
          __merged_source_orders: sourceOrders
        };
      });
      const firstIndex = Math.min(...allMembers.map((member) => member.index));
      for (const member of allMembers) consumedIndexes.add(member.index);
      inserts.set(firstIndex, mergedMembers);
    }
    if (consumedIndexes.size === 0) return items;
    const out = [];
    for (let index = 0; index < items.length; index++) {
      const merged = inserts.get(index);
      if (merged) out.push(...merged);
      if (!consumedIndexes.has(index)) out.push(items[index]);
    }
    return out;
  }
  function mergeExactDuplicateCrossCodeWorkups(items) {
    return EXACT_CROSS_CODE_WORKUP_RULES.reduce(
      (working, rule) => mergeExactDuplicateWorkupsForRule(working, rule),
      items
    );
  }
  function dedupeCrossFormat(items) {
    const orderCode = (it) => (it.order_code ?? "").trim().toUpperCase();
    const byKey = /* @__PURE__ */ new Map();
    let idxCounter = 0;
    for (const item of items) {
      const v = String(item.value ?? "").trim();
      const rawUnit = (item.unit ?? "").trim();
      const unit = rawUnit;
      if (!v) {
        byKey.set(`__no_dedup__|${idxCounter++}`, item);
        continue;
      }
      const key = [
        item.date ?? "",
        v.toLowerCase(),
        unit.toLowerCase(),
        orderCode(item),
        String(item.display ?? "").toLowerCase().trim(),
        String(item.group_instance_key ?? "").trim(),
        String(item.assay_method ?? "").trim(),
        // A row the source uploaded twice byte-for-byte is two readings, not a
        // cross-format duplicate. See repeatedSourceRowTerm().
        repeatedSourceRowTerm(item)
      ].join("|");
      const existing = byKey.get(key);
      if (!existing) {
        byKey.set(key, item);
        continue;
      }
      let primary;
      let secondary;
      if (cjkChars(item.display ?? "") < cjkChars(existing.display ?? "")) {
        primary = item;
        secondary = existing;
      } else {
        primary = existing;
        secondary = item;
      }
      const merged = { ...primary };
      for (const f of ["order_code", "order_name", "hospital", "code"]) {
        if (!merged[f] && secondary[f]) merged[f] = secondary[f];
      }
      byKey.set(key, merged);
    }
    return Array.from(byKey.values());
  }
  function combineBpItems(items) {
    const byKey = /* @__PURE__ */ new Map();
    const passThrough = [];
    for (const it of items) {
      const disp = String(it.display ?? "").toLowerCase();
      const key = `${it.date ?? ""}|${it.hospital ?? ""}|${it.group_instance_key ?? ""}`;
      if (disp.includes("systolic blood pressure")) {
        const v = byKey.get(key) ?? { systolic: [], diastolic: [] };
        v.systolic.push(it);
        byKey.set(key, v);
      } else if (disp.includes("diastolic blood pressure")) {
        const v = byKey.get(key) ?? { systolic: [], diastolic: [] };
        v.diastolic.push(it);
        byKey.set(key, v);
      } else {
        passThrough.push(it);
      }
    }
    const tryAdd = (components, src, loinc, display) => {
      if (!src) return;
      const val = src.value;
      if (val === null || val === void 0 || val === "" || val === "-" || val === "\u2014") return;
      const num = Number.parseFloat(String(val).replace(/,/g, ""));
      if (!Number.isFinite(num)) return;
      components.push({
        loinc,
        display,
        value: num,
        unit: src.unit || "mmHg",
        interpretation_text: src.reference_range || ""
      });
    };
    for (const parts of byKey.values()) {
      const n = Math.max(parts.systolic.length, parts.diastolic.length);
      for (let i = 0; i < n; i++) {
        const s = parts.systolic[i];
        const d = parts.diastolic[i];
        const primary = s ?? d;
        if (!primary) continue;
        const components = [];
        tryAdd(components, s, "8480-6", "Systolic blood pressure");
        tryAdd(components, d, "8462-4", "Diastolic blood pressure");
        if (components.length === 0) continue;
        const combined = { ...primary };
        combined.display = "Blood Pressure";
        combined.code = "";
        combined.order_code = "";
        combined.order_name = "Blood Pressure";
        combined.category = "vital-signs";
        combined.bp_components = components;
        combined.bp_panel_loinc = "85354-9";
        combined.value = void 0;
        combined.unit = void 0;
        passThrough.push(combined);
      }
    }
    return passThrough;
  }
  var URINE_MARKERS_RE = /尿液|尿道|尿沉渣|尿沈渣|尿生化|尿常規|尿液檢查|尿糖|尿蛋白|尿細胞|尿酮體?|尿膽紅素|尿膽素原|尿微量白蛋白|尿白蛋白|尿微白蛋白|小便|\(尿(?:液)?\)|urinaly|urinal|\burine\b|u-malb|u-acr|u-cre|u-mab|u-pcr|\(u\)/i;
  var OTHER_SPECIMEN_RULES = [
    // Bare "occult blood" is an analyte name, not a stool marker: urinalysis
    // legitimately reports an Occult blood member. Require an actual stool/fecal
    // signal (or the unambiguous Chinese 便潛血); iFOBT rows also derive Stool from
    // their resolved LOINC System.
    [/糞|便潛血|stool|fecal|faecal/i, "Stool"],
    [/痰|sputum/i, "Sputum"],
    [/腦脊液|腦脊髓|csf|cerebrospinal/i, "Cerebrospinal fluid"],
    [/胸水|肋膜|pleural|\(pl\)/i, "Pleural fluid"],
    [/腹水|ascites|peritoneal|\(asc\)/i, "Peritoneal fluid"],
    // A bare Chinese "抹片" means smear, not a body source. In particular,
    // 13025C 抗酸性濃縮抹片染色 is an acid-fast smear of an unspecified
    // specimen; treating every smear as cervical silently invented a source.
    [/子宮頸|陰道|cervical|pap\s*smear|vaginal/i, "Cervical/Vaginal"],
    [/關節液|synovial|joint\s*fluid/i, "Synovial fluid"],
    [/羊水|amniotic/i, "Amniotic fluid"],
    // Generic body-fluid evidence runs after every named fluid so the specific
    // specimen always wins. Catalog labels that merely say "blood and/or body
    // fluid" are filtered below: they name alternatives, not the submitted
    // specimen.
    [/體液|body\s*fluid/i, "Body fluid"],
    // Bone marrow SPECIMEN — but NOT the CBC-diff CELL NAMES that embed 骨髓:
    // 骨髓球 (myelocyte) / 前骨髓球 (promyelocyte) / 後骨髓球 (metamyelocyte) /
    // 骨髓芽球 (myeloblast) are immature granulocytes counted in PERIPHERAL BLOOD
    // (08013C CBC diff), not a bone-marrow draw. The greedy /骨髓/ mis-inferred
    // their specimen as Bone marrow, pairing a blood LOINC (740-1 Metamyelocytes
    // in Blood) with a Bone-marrow specimen — the exact contradiction the bridge
    // forbids (P10109 audit 2026-07-08). Negative lookahead excludes 骨髓 followed
    // by 球/芽 (cell-name suffixes) so real markers (骨髓 / 骨髓抽吸 / 骨髓穿刺 /
    // bone marrow aspirate) still resolve to Bone marrow, but 後骨髓球 falls to
    // its 08-chapter Blood default → 740-1 becomes specimen-consistent.
    [/骨髓(?!球|芽)|bone\s*marrow/i, "Bone marrow"]
  ];
  var BLOOD_OR_BODY_FLUID_CATALOG_RE = /血液\s*(?:及|或|與|[、/／])\s*體液|blood\s*(?:and|or|[&/])\s*body\s*fluid/i;
  function inferOtherSpecimen(blob) {
    for (const [pattern, label] of OTHER_SPECIMEN_RULES) {
      if (!pattern.test(blob)) continue;
      if (label === "Body fluid" && BLOOD_OR_BODY_FLUID_CATALOG_RE.test(blob)) continue;
      return label;
    }
    return null;
  }
  var EXPLICIT_BLOOD_SPECIMEN_RULES = [
    [/靜脈|静脉|\bvenous\b|\bvein\b/i, "Venous blood"],
    [/動脈|动脉|\barterial\b|\bartery\b/i, "Arterial blood"],
    [/毛細血管|微血管|\bcapillary\b/i, "Capillary blood"]
  ];
  function inferExplicitBloodSpecimen(blob) {
    const matches = collectExplicitBloodSpecimens(blob);
    return matches.size === 1 ? [...matches][0] : null;
  }
  function collectExplicitBloodSpecimens(blob) {
    const matches = /* @__PURE__ */ new Set();
    for (const [pattern, specimen] of EXPLICIT_BLOOD_SPECIMEN_RULES) {
      if (pattern.test(blob)) matches.add(specimen);
    }
    return matches;
  }
  var NHI_CODE_PREFIX_SPECIMEN = {
    "06": "Urine",
    // 06013C 尿生化檢查 / 06014C 尿沉渣 / urinalysis family
    "08": "Blood",
    // 08003C 血色素 / 08004C HCT / 08011C CBC / 08013C diff
    "11": "Blood"
    // 11001C ABO / 11003C RH / 11004C antibody — blood typing
    // NHI chapter 13 (microbiology — cultures + microscopy of secretions/
    // excreta, e.g. 13006C 排泄物/滲出物/分泌物之細菌顯微鏡檢查) is NOT one
    // specimen family: blood culture, urine culture, sputum, wound… It was
    // previously defaulted to "Blood", which mis-tagged secretion microscopy
    // as a blood specimen and (with the display-only LOINC match) routed a
    // Gram-stain pus-cell "1+(＞25/LPF)" row to the blood 770-8 Neutrophils
    // LOINC. No safe prefix default → omit it; display markers / null decide.
    // (2026-06-29) See _codeFamilyNotConfirmedBlood for the paired LOINC veto.
  };
  var NHI_CODE_SPECIMEN_OVERRIDE = {
    "07009C": "Stool",
    // 糞便一般檢查 — dedicated stool routine panel
    "09016C": "Urine",
    // 肌酐、尿 — Urine creatinine (the official urine-crea code)
    "09041B": "Blood",
    // 血液氣體分析; vessel is unspecified
    "08128B": "Bone marrow",
    "12129C": "Cerebrospinal fluid",
    "12172C": "Urine",
    "12191C": "Urine",
    "14065C": "Respiratory specimen",
    "14066C": "Respiratory specimen",
    "14084C": "Respiratory specimen",
    "30103B": "Tissue"
  };
  function nhiCodeSpecimen(code) {
    const c = String(code ?? "").trim().toUpperCase();
    if (!c) return null;
    if (c in NHI_CODE_SPECIMEN_OVERRIDE) return NHI_CODE_SPECIMEN_OVERRIDE[c] ?? null;
    const prefix = c.slice(0, 2);
    return NHI_CODE_PREFIX_SPECIMEN[prefix] ?? null;
  }
  function inferSpecimen(orderName, display, code, itemName = "") {
    const displayStr = String(display ?? "");
    const orderStr = String(orderName ?? "");
    const itemStr = String(itemName ?? "");
    if (URINE_MARKERS_RE.test(displayStr) || URINE_MARKERS_RE.test(itemStr)) return "Urine";
    const blob = `${orderStr} ${displayStr} ${itemStr}`.toLowerCase();
    const otherSpecimen = inferOtherSpecimen(blob);
    if (otherSpecimen) return otherSpecimen;
    const bloodSpecimen = inferExplicitBloodSpecimen(blob);
    if (bloodSpecimen) return bloodSpecimen;
    const codeDefault = nhiCodeSpecimen(code);
    if (codeDefault) return codeDefault;
    if (URINE_MARKERS_RE.test(orderStr)) return "Urine";
    return null;
  }
  var SPECIMEN_SPECIFIC_CODE = {
    "09041B": "Blood",
    // 血液氣體分析 — code says blood, NOT vessel-specific (v1.2.10;
    // was wrongly "Arterial blood". The catalog name is 「血液氣體分析」without 動脈/
    // 靜脈; blood gas is definitely blood → "Blood" is honest per-code evidence, but
    // arterial would over-claim. See the 09041B panel note in loinc-tables.ts).
    // 06001C 酸鹼度反應 pH is DELIBERATELY absent — the code is specimen-
    // ambiguous (urine OR body fluid, no display marker), so it is LOINC-less
    // (SPECIMEN_AMBIGUOUS_NO_LOINC_CODES) and must not claim a Urine specimen
    // either. A row WITH a real urine/body-fluid marker still gets its specimen
    // from evidenceSpecimen steps 1/5 (marker-based), which is correct evidence.
    "06009C": "Urine",
    // 尿沉渣鏡檢 panel
    "06012C": "Urine",
    // 尿液一般檢查 panel
    "06013C": "Urine",
    // 尿生化 panel
    "07009C": "Stool",
    // 糞便一般檢查 — code definition is stool-specific
    "09016C": "Urine",
    // 肌酸酐、尿 — dedicated urine creatinine
    "08128B": "Bone marrow",
    // 骨髓細胞形態判讀/分類 panel
    "12129C": "Cerebrospinal fluid",
    // 腦脊髓液快速測定
    "12172C": "Urine",
    // 尿中肺炎鏈球菌抗原
    "12191C": "Urine",
    // 尿液退伍軍人菌抗原
    "30103B": "Tissue",
    // PD-L1 immune stain; clone/scale remains unresolved
    // 12111C (微白蛋白 Microalbumin) is DELIBERATELY absent (audit 2026-07-13). It is
    // dominantly urine but the same code also carries CSF microalbumin, so a forced
    // "Urine" here would mis-specimen a CSF row. Specimen now derives from the
    // resolved LOINC's System — urine legs (14957-5 / 2161-8 / 14959-1) → Urine, a
    // CSF-marked row (→ 1746-7 via resolveMicroalbuminLoinc) → CSF. Both consistent.
    // Serous/joint-fluid analysis panels — the whole billing item is one fixed
    // specimen by definition, so the code-level specimen OUTRANKS an individual
    // member's LOINC System axis. Without this, a member whose only LOINC is the
    // GENERIC body-fluid code (e.g. synovial monocyte 26487-9 "…in Body fluid",
    // no synovial-specific analyte exists) would emit specimen "Body fluid", and a
    // physical-property member whose LOINC reads "… OF Synovial fluid" (not "in")
    // would emit NO specimen — both silently inconsistent with the panel's real
    // specimen (real P20105 16008C: appearance/color/viscosity blank + monocyte
    // Body fluid, 2026-07-13). Pleural 16003C already resolves via the 胸水
    // order_name marker (step 1); listing it here makes the specimen deterministic
    // at the code level even when the order_name text is absent. Step 1 (an
    // explicit per-row urine/other-fluid marker) still OUTRANKS this.
    "16003C": "Pleural fluid",
    // 胸水常規分析
    "16008C": "Synovial fluid"
    // 滑液常規分析
  };
  var BLOOD_EVIDENCE_RE = /血中|、\s*血|(?:\(|（)\s*(?:血|b|s)\s*(?:\)|）)|whole\s*blood|arterial\s*blood|venous\s*blood|capillary\s*blood/i;
  function specimenFromLoinc(loinc) {
    if (!loinc) return null;
    const d = LOINC_DISPLAY[loinc] ?? "";
    if (!d) return null;
    if (/\bUrine\b/i.test(d)) return "Urine";
    if (/(?:\b(?:in|of)\s+|-\s*)Arterial blood\b/i.test(d)) return "Arterial blood";
    if (/(?:\b(?:in|of)\s+|-\s*)Venous blood\b/i.test(d)) return "Venous blood";
    if (/(?:\b(?:in|of)\s+|-\s*)Capillary blood\b/i.test(d)) return "Capillary blood";
    if (/\bin Blood\b|\b(?:in|of)\s+(?:Arterial |Venous |Capillary |Mixed venous )?Blood\b|Red Blood Cells|-\s*Blood\b|Serum or Plasma|Platelet poor plasma|\bin (?:Serum|Plasma)\b/i.test(
      d
    ))
      return "Blood";
    if (/\b(?:in|of) Stool\b|Feces|gastrointestinal/i.test(d)) return "Stool";
    if (/Cerebral spinal fluid|\bin CSF\b/i.test(d)) return "Cerebrospinal fluid";
    if (/\bin Bone marrow\b/i.test(d)) return "Bone marrow";
    if (/\bin Tissue\b/i.test(d)) return "Tissue";
    if (/Respiratory system specimen|Upper respiratory specimen/i.test(d))
      return "Respiratory specimen";
    if (/\b(?:in|of) Pleural fluid\b/i.test(d)) return "Pleural fluid";
    if (/\b(?:in|of) Peritoneal fluid\b/i.test(d)) return "Peritoneal fluid";
    if (/\b(?:in|of) Synovial fluid\b/i.test(d)) return "Synovial fluid";
    if (/\b(?:in|of) Body fluid\b|\bBody fld\b/i.test(d)) return "Body fluid";
    return null;
  }
  var BLOOD_SOURCE_CHAPTERS = /* @__PURE__ */ new Set(["08", "11"]);
  function isBloodSourceCode(code) {
    if (!/^\d{5}[A-Za-z]$/.test(code)) return false;
    return BLOOD_SOURCE_CHAPTERS.has(code.slice(0, 2));
  }
  function evidenceSpecimen(orderName, display, code, loinc, itemName = "", groupSpecimen = null) {
    if (loinc === "8310-5") return null;
    const displayStr = String(display ?? "");
    const orderStr = String(orderName ?? "");
    const itemStr = String(itemName ?? "");
    if (URINE_MARKERS_RE.test(displayStr) || URINE_MARKERS_RE.test(itemStr)) return "Urine";
    const blob = `${orderStr} ${displayStr} ${itemStr}`.toLowerCase();
    const otherSpecimen = inferOtherSpecimen(blob);
    if (otherSpecimen) return otherSpecimen;
    const explicitBloodSpecimen = inferExplicitBloodSpecimen(blob);
    if (explicitBloodSpecimen) return explicitBloodSpecimen;
    if (groupSpecimen) return groupSpecimen;
    const c = String(code ?? "").trim().toUpperCase();
    if (c in SPECIMEN_SPECIFIC_CODE) return SPECIMEN_SPECIFIC_CODE[c] ?? null;
    const fromLoinc = specimenFromLoinc(loinc);
    if (fromLoinc) return fromLoinc;
    if (BLOOD_EVIDENCE_RE.test(`${orderStr} ${displayStr} ${itemStr}`)) return "Blood";
    if (URINE_MARKERS_RE.test(orderStr)) return "Urine";
    if (isBloodSourceCode(c)) return "Blood";
    return null;
  }
  var BLOOD_SPECIMENS = /* @__PURE__ */ new Set([
    "Blood",
    "Arterial blood",
    "Venous blood",
    "Capillary blood"
  ]);
  var BODY_FLUID_SPECIMENS = /* @__PURE__ */ new Set([
    "Body fluid",
    "Pleural fluid",
    "Peritoneal fluid",
    "Synovial fluid"
  ]);
  function specimensCompatible(evidence, loincSystem) {
    if (evidence === loincSystem) return true;
    if (BLOOD_SPECIMENS.has(evidence) && BLOOD_SPECIMENS.has(loincSystem)) return true;
    if (loincSystem === "Body fluid" && BODY_FLUID_SPECIMENS.has(evidence)) return true;
    if (loincSystem === "Respiratory specimen" && evidence === "Sputum") return true;
    return false;
  }
  function loincSpecimenConsistencyGuard(loinc, orderName, display, code, itemName) {
    if (!loinc) return loinc;
    const evidence = evidenceSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      String(code ?? ""),
      null,
      String(itemName ?? "")
    );
    const loincSystem = specimenFromLoinc(loinc);
    if (!evidence || !loincSystem) return loinc;
    return specimensCompatible(evidence, loincSystem) ? loinc : null;
  }
  var RATIO_TO_TIME_LOINC = {
    "6301-6": "5902-2",
    // INR → PT (Prothrombin time, sec)
    "63561-5": "14979-9",
    // APTT actual/normal ratio → APTT time (sec)
    "5894-1": "5902-2"
    // PT actual/Normal ratio → PT time (sec)
  };
  var TIME_UNIT_RE = /^(?:sec|s|seconds?|秒)$/i;
  function structuralLoincFix(loinc, rawUnit) {
    if (!loinc) return loinc;
    const sibling = RATIO_TO_TIME_LOINC[loinc];
    if (!sibling) return loinc;
    const u = String(rawUnit ?? "").trim();
    if (TIME_UNIT_RE.test(u)) {
      return sibling;
    }
    return loinc;
  }
  var LEUKOCYTE_RATIO_UCUM = /* @__PURE__ */ new Set(["%", "/100{WBCs}"]);
  var CELL_COUNT_PER_VOLUME_UCUM_RE = /^(?:10\*[346])?\/uL$/;
  function qualifiedCbcCellPropertyLoincFix(loinc, rawUnit) {
    if (loinc !== "19048-8" && loinc !== "13046-8") return loinc;
    const ucum = toUcum(String(rawUnit ?? ""));
    if (ucum && LEUKOCYTE_RATIO_UCUM.has(ucum)) return loinc;
    if (ucum && CELL_COUNT_PER_VOLUME_UCUM_RE.test(ucum)) {
      return loinc === "19048-8" ? "30392-5" : "26477-0";
    }
    return null;
  }
  var URINE_PROTEIN_QUALITATIVE_LOINC = "20454-5";
  var URINE_PROTEIN_QUANTITATIVE_LOINC = "2888-6";
  var URINE_PROTEIN_24H_LOINC = "2889-4";
  var URINE_PROTEIN_COMBINED_RE = /^(?:[\d.]+\+|trace|positive|negative|\+|-)\s*[(（]/i;
  var URINE_PROTEIN_NUMERIC_RE = /^[\d.]+$/;
  var URINE_PROTEIN_MASS_UNIT_RE = /^mg\s*\/\s*d\s*l$/i;
  var NHI_SOURCE_CHANNEL_SYSTEM = "http://nhi-fhir-bridge/nhi-source-channel";
  function appendNhiSourceChannelTag(resource, raw) {
    const code = String(raw.nhi_source_channel ?? "").trim().toUpperCase();
    if (!code) return;
    const displayName = String(raw.nhi_source_channel_name ?? "").trim();
    const tag = {
      system: NHI_SOURCE_CHANNEL_SYSTEM,
      code
    };
    if (displayName) tag.display = displayName;
    if (!resource.meta) resource.meta = { versionId: "1", source: "nhi-fhir-bridge/scraper" };
    if (!Array.isArray(resource.meta.tag)) resource.meta.tag = [];
    resource.meta.tag.push(tag);
  }
  var NHI_VISIT_DATE_SYSTEM = "http://nhi-fhir-bridge/nhi-visit-date";
  function appendNhiVisitDateTag(resource, raw) {
    const visitDate = String(raw.nhi_visit_date ?? "").trim();
    if (!visitDate) return;
    if (!resource.meta) resource.meta = { versionId: "1", source: "nhi-fhir-bridge/scraper" };
    if (!Array.isArray(resource.meta.tag)) resource.meta.tag = [];
    resource.meta.tag.push({
      system: NHI_VISIT_DATE_SYSTEM,
      code: visitDate
    });
  }
  function appendSourceProgramTag(resource, raw) {
    const program = String(raw.source_program ?? "").trim();
    if (!program) return;
    if (!resource.meta) resource.meta = { versionId: "1", source: "nhi-fhir-bridge/scraper" };
    if (!Array.isArray(resource.meta.tag)) resource.meta.tag = [];
    resource.meta.tag.push({
      system: "http://nhi-fhir-bridge/source-program",
      code: program
    });
  }
  function resolveHumanLabel(opts) {
    const { loincShortText, code, itemName, orderName, display, fallback, preferItemName } = opts;
    const item = (itemName ?? "").trim();
    const order = (orderName ?? "").trim();
    const disp = (display ?? "").trim();
    const itemCjk = cjkChars(item) > 0 ? item : "";
    const orderCjk = cjkChars(order) > 0 ? order : "";
    if (preferItemName && item) {
      return loincShortText || NHI_CODE_PANEL_NAME[code] || item || order || disp || fallback;
    }
    return loincShortText || NHI_CODE_PANEL_NAME[code] || itemCjk || orderCjk || item || order || disp || fallback;
  }
  function resolveObsCodeText(loinc, code, display, cleanMatch, itemName) {
    const shortTextAllowed = !!loinc && !!LOINC_SHORT_TEXT[loinc] && (!CBC_CANONICAL_TEXT_LOINCS.has(loinc) || cleanMatch);
    const shortText = shortTextAllowed && loinc ? LOINC_SHORT_TEXT[loinc] : void 0;
    return normalizeFullwidth(
      shortText || itemName?.trim() || display.trim() || NHI_CODE_PANEL_NAME[code] || "Unknown Lab"
    );
  }
  function urineProteinLoincFix(loinc, rawValue, rawUnit) {
    if (loinc !== URINE_PROTEIN_QUALITATIVE_LOINC) return loinc;
    const v = String(rawValue ?? "").trim();
    const u = String(rawUnit ?? "").trim();
    if (URINE_PROTEIN_COMBINED_RE.test(v)) {
      return URINE_PROTEIN_QUALITATIVE_LOINC;
    }
    if (URINE_PROTEIN_NUMERIC_RE.test(v) && URINE_PROTEIN_MASS_UNIT_RE.test(u)) {
      return URINE_PROTEIN_QUANTITATIVE_LOINC;
    }
    return URINE_PROTEIN_QUALITATIVE_LOINC;
  }
  var URINE_PROTEIN_MASS_VOLUME_UCUM_RE = /^(?:ug|mg|g)\/(?:mL|dL|L)$/;
  var URINE_PROTEIN_MASS_PER_DAY_RE = /^(?:u|m)?g\s*\/\s*(?:24\s*(?:h|hr|hrs|hour|hours)|d|day)$/i;
  function urineTotalProteinPropertyLoincFix(loinc, rawValue, rawUnit) {
    if (loinc !== URINE_PROTEIN_QUANTITATIVE_LOINC) return loinc;
    const unit = normalizeFullwidth(String(rawUnit ?? "")).trim();
    if (!tryParseQuantity(String(rawValue ?? ""), unit)) return null;
    if (URINE_PROTEIN_MASS_PER_DAY_RE.test(unit)) return URINE_PROTEIN_24H_LOINC;
    const ucum = toUcum(unit);
    return ucum && URINE_PROTEIN_MASS_VOLUME_UCUM_RE.test(ucum) ? URINE_PROTEIN_QUANTITATIVE_LOINC : null;
  }
  function urobilinogenUnitFix(loinc, rawUnit) {
    if (loinc !== "5818-0") return loinc;
    const unit = String(rawUnit ?? "").trim();
    return /(?:e\s*\.?\s*u|ehrlich)\s*\/\s*d\s*l/i.test(unit) ? "19161-9" : loinc;
  }
  var AMMONIA_MASS_LOINC = "22763-7";
  var AMMONIA_MOLAR_LOINC = "16362-6";
  var AMMONIA_MOLAR_UNIT_RE = /mol\s*\/\s*l/i;
  function ammoniaLoincFix(loinc, rawUnit) {
    if (loinc !== AMMONIA_MASS_LOINC) return loinc;
    const u = String(rawUnit ?? "").trim();
    if (AMMONIA_MOLAR_UNIT_RE.test(u)) return AMMONIA_MOLAR_LOINC;
    return AMMONIA_MASS_LOINC;
  }
  var LACTATE_SERUM_MOLAR = "2524-7";
  var LACTATE_SERUM_MASS = "14118-4";
  var LACTATE_CSF_MOLAR = "2520-5";
  var LACTATE_CSF_MASS = "27941-4";
  var LACTATE_MOLAR_UNIT_RE = /mol\s*\/\s*l/i;
  var LACTATE_MASS_UNIT_RE = /(?:mg|ug|µg|μg|g)\s*\/\s*(?:dl|l|ml)/i;
  function lactateLoincFix(loinc, code, display, orderName, itemName, rawUnit) {
    if (loinc !== LACTATE_SERUM_MOLAR && loinc !== LACTATE_SERUM_MASS) return loinc;
    if (String(code ?? "").trim() !== "09059B") return loinc;
    const unit = String(rawUnit ?? "").trim();
    const spec = inferSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      "",
      // marker-only: do not let an NHI chapter invent the specimen
      String(itemName ?? "")
    );
    const molar = LACTATE_MOLAR_UNIT_RE.test(unit);
    const mass = LACTATE_MASS_UNIT_RE.test(unit);
    if (spec === "Cerebrospinal fluid") {
      if (molar) return LACTATE_CSF_MOLAR;
      if (mass) return LACTATE_CSF_MASS;
      return null;
    }
    if (spec != null && spec !== "Blood") return null;
    if (mass) return LACTATE_SERUM_MASS;
    if (molar) return LACTATE_SERUM_MOLAR;
    return loinc;
  }
  var LDL_METHODLESS = "2089-1";
  var LDL_CALCULATED = "13457-7";
  var LDL_DIRECT = "18262-6";
  var LDL_DIRECT_RE = /\bdirect\b|直接(?:法|測定|檢測)?/i;
  var LDL_CALCULATED_RE = /\bcalc(?:ulated|ulation)?\b|\bfriedewald\b|計算(?:法|值)?/i;
  function ldlLoincFix(loinc, code, display, orderName, itemName) {
    const isLdl = String(code ?? "").trim() === "09044C" || loinc === LDL_METHODLESS || loinc === LDL_CALCULATED || loinc === LDL_DIRECT;
    if (!isLdl) return loinc;
    const text = normalizeFullwidth(
      `${String(display ?? "")} ${String(orderName ?? "")} ${String(itemName ?? "")}`
    );
    const direct = LDL_DIRECT_RE.test(text);
    const calculated = LDL_CALCULATED_RE.test(text);
    if (direct !== calculated) return direct ? LDL_DIRECT : LDL_CALCULATED;
    return LDL_METHODLESS;
  }
  var SERUM_SPE_LOINCS = /* @__PURE__ */ new Set([
    "24351-9",
    "2885-2",
    "2862-1",
    "2865-4",
    "2868-8",
    "2871-2",
    "2874-6",
    "1759-0"
  ]);
  function proteinElectrophoresisSpecimenFix(loinc, code, display, orderName, itemName) {
    if (String(code ?? "").trim() !== "09065B" || !loinc || !SERUM_SPE_LOINCS.has(loinc)) {
      return loinc;
    }
    const spec = inferSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      "",
      String(itemName ?? "")
    );
    return spec != null && spec !== "Blood" ? null : loinc;
  }
  var FLOW_PERCENT_AND_COUNT = [
    [/cd3\s*[-+]?\s*cd16\s*\+?\s*cd56|cd16\s*\+?\s*cd56|\bnk\s*cells?\b/i, "8112-5", "20402-4"],
    [/\bcd19\b/i, "8117-4", "8116-6"],
    [/\bcd8\b/i, "8101-8", "14135-8"],
    [/\bcd4\b/i, "8123-2", "24467-3"],
    [/\bcd3\b/i, "8124-0", "8122-4"]
  ];
  var FLOW_ABSOLUTE_UNIT_RE = /(?:cells?|#)\s*\/\s*(?:u|µ|μ)?l\b|\/\s*(?:u|µ|μ)l\b|cells?\s*per\s*(?:micro)?liter/i;
  function flowMarkerUnitFix(loinc, code, display, rawUnit) {
    if (String(code ?? "").trim() !== "12204B") return loinc;
    const text = normalizeFullwidth(String(display ?? ""));
    if (/cd4\s*\/\s*cd8|cd8\s*\/\s*cd4/i.test(text)) return "54218-3";
    const route = FLOW_PERCENT_AND_COUNT.find(([pattern]) => pattern.test(text));
    if (!route) return loinc;
    return FLOW_ABSOLUTE_UNIT_RE.test(String(rawUnit ?? "")) ? route[2] : route[1];
  }
  var FREE_T4_MASS_LOINC = "3024-7";
  var FREE_T4_MOLAR_LOINC = "14920-3";
  var FREE_T4_MOLAR_UNIT_RE = /mol\s*\/\s*l/i;
  function freeT4UnitFix(loinc, rawUnit) {
    if (loinc !== FREE_T4_MASS_LOINC) return loinc;
    const u = String(rawUnit ?? "").trim();
    return FREE_T4_MOLAR_UNIT_RE.test(u) ? FREE_T4_MOLAR_LOINC : FREE_T4_MASS_LOINC;
  }
  var ANTI_HBC_QUALITATIVE_LOINC = "13952-7";
  var ANTI_HBC_QUANTITATIVE_LOINC = "22316-4";
  var ANTI_HBC_QUANT_MARKER_RE = /\bcoi\b|cut\s*off\s*index|\bs\/?co\b|\bindex\b|定量|quant/i;
  var SIMPLE_NUMERIC_VALUE_RE = /^[<>]=?\s*-?\d+(?:,\d{3})*(?:\.\d+)?$/;
  function antiHbcLoincFix(loinc, rawValue, rawUnit, display, orderName, itemName = "") {
    if (loinc !== ANTI_HBC_QUALITATIVE_LOINC) return loinc;
    const value = normalizeFullwidth(String(rawValue ?? "")).trim();
    const unit = normalizeFullwidth(String(rawUnit ?? "")).trim();
    const haystack = normalizeFullwidth(
      `${String(display ?? "")} ${String(orderName ?? "")} ${String(itemName ?? "")} ${unit}`
    );
    if (ANTI_HBC_QUANT_MARKER_RE.test(haystack)) return ANTI_HBC_QUANTITATIVE_LOINC;
    if (SIMPLE_NUMERIC_VALUE_RE.test(value)) return ANTI_HBC_QUANTITATIVE_LOINC;
    return ANTI_HBC_QUALITATIVE_LOINC;
  }
  function normalizedLabEvidenceText(...parts) {
    return normalizeFullwidth(parts.map((part) => String(part ?? "")).join(" ")).toLowerCase();
  }
  var HDL_CHOLESTEROL_LOINC = "2085-9";
  var TOTAL_CHOL_HDL_RATIO_LOINC = "9830-1";
  var TOTAL_CHOL_HDL_RATIO_RE = /\bchol(?:esterol)?\s*\/\s*hdl(?:[\s-]*c)?\b|總膽固醇\s*\/\s*(?:高密度(?:脂蛋白)?膽固醇|hdl)/i;
  function cholesterolRatioLoincFix(loinc, code, display, orderName, itemName) {
    if (loinc !== HDL_CHOLESTEROL_LOINC || String(code ?? "").trim() !== "09043C") return loinc;
    const rowEvidence = normalizedLabEvidenceText(display, itemName).trim();
    const blob = rowEvidence || normalizedLabEvidenceText(orderName);
    return TOTAL_CHOL_HDL_RATIO_RE.test(blob) ? TOTAL_CHOL_HDL_RATIO_LOINC : loinc;
  }
  var CRP_LOINC = "1988-5";
  var HS_CRP_LOINC = "30522-7";
  var HS_CRP_MARKER_RE = /\bhs[\s.-]*crp\b|\bcrp\s*\(\s*hs\b|high[\s.-]*sensiti[^ ]*\s*(?:c[\s.-]*reactive\s*protein|crp)|高敏感(?:度|性)?.*crp|crp.*高敏感(?:度|性)?/i;
  function highSensitivityCrpLoincFix(loinc, code, display, orderName, itemName) {
    if (loinc !== CRP_LOINC || String(code ?? "").trim() !== "12015C") return loinc;
    const rowEvidence = normalizedLabEvidenceText(display, itemName).trim();
    const blob = rowEvidence || normalizedLabEvidenceText(orderName);
    return HS_CRP_MARKER_RE.test(blob) ? HS_CRP_LOINC : loinc;
  }
  var TOTAL_KAPPA_LAMBDA_RATIO_LOINC = "15189-4";
  var FREE_KAPPA_LOINC = "36916-5";
  var FREE_LAMBDA_LOINC = "33944-0";
  var FREE_KAPPA_LAMBDA_RATIO_LOINC = "48378-4";
  var FREE_LIGHT_CHAIN_MARKER_RE = /\bflc\b|\bfree(?:\s+(?:kappa|lambda))?\s+light\s+chains?\b|\b(?:kappa|lambda)\s+light\s+chains?\s*[,.-]?\s*free\b|\blight\s+chains?\s*[,.-]?\s*free\b/i;
  var FREE_LIGHT_CHAIN_RATIO_RE = /\bk\s*\/\s*l\b|\bkappa\s*\/\s*lambda\b|κ\s*\/\s*λ|\b(?:kappa|κ).*\b(?:lambda|λ).*\bratio\b/i;
  function freeLightChainLoincFix(loinc, code, display, orderName, itemName) {
    if (loinc !== TOTAL_KAPPA_LAMBDA_RATIO_LOINC || String(code ?? "").trim() !== "12160B") {
      return loinc;
    }
    const rowEvidence = normalizedLabEvidenceText(display, itemName).trim();
    const blob = rowEvidence || normalizedLabEvidenceText(orderName);
    if (!FREE_LIGHT_CHAIN_MARKER_RE.test(blob)) return loinc;
    if (FREE_LIGHT_CHAIN_RATIO_RE.test(blob)) return FREE_KAPPA_LAMBDA_RATIO_LOINC;
    if (/\bkappa\b|κ/i.test(blob)) return FREE_KAPPA_LOINC;
    if (/\blambda\b|λ/i.test(blob)) return FREE_LAMBDA_LOINC;
    return null;
  }
  var TROPONIN_I_LOINC = "10839-9";
  var HS_TROPONIN_I_LOINC = "89579-7";
  var HS_TROPONIN_T_LOINC = "67151-1";
  var HS_TROPONIN_T_MARKER_RE = /\bhs[\s.-]*(?:c[\s.-]*)?tn[\s.-]*t\b|\b(?:high[\s.-]*sensiti[^ ]*|hs)[\s.-]*(?:cardiac[\s.-]*)?troponin[\s.-]*t\b|高敏感(?:度|性)?.*(?:troponin|心肌旋轉蛋白)\s*t\b/i;
  var HS_TROPONIN_MARKER_RE = /高敏感|high[\s.-]*sensiti|\bhs[\s.-]*(?:c[\s.-]*)?t(?:roponin|[nr])/i;
  function hsTroponinFix(loinc, display) {
    if (loinc !== TROPONIN_I_LOINC) return loinc;
    const d = normalizeFullwidth(String(display ?? "")).toLowerCase();
    if (HS_TROPONIN_T_MARKER_RE.test(d)) return HS_TROPONIN_T_LOINC;
    return HS_TROPONIN_MARKER_RE.test(d) ? HS_TROPONIN_I_LOINC : loinc;
  }
  var FINGER_GLUCOSE_MARKER_RE = /finger\s*(?:sugar|stick)|fingerstick|glucometer|\bpoct\s*(?:glucose|sugar)|指尖血糖|末梢血糖/i;
  var GLUCOSE_MOLAR_UNIT_RE = /(?:mol|eq)\s*\/\s*l\b/i;
  var GLUCOSE_MASS_UNIT_RE = /(?:pg|ng|ug|mg|g)\s*\/\s*(?:dl|l|ml)\b/i;
  var TWO_HOUR_POST_MEAL_MARKER_RE = /飯後\s*兩\s*小時|餐後\s*兩\s*小時|\b2\s*(?:h|hr|hour|hours)\s*(?:post[\s-]*meal|after\s*(?:a\s*)?meal)\b/i;
  function twoHourPostMealGlucoseLoincFix(loinc, code, display, orderName, itemName, rawUnit) {
    if (loinc !== "2345-7" || String(code ?? "").trim() !== "09140C") return loinc;
    const blob = normalizedLabEvidenceText(display, orderName, itemName);
    if (!TWO_HOUR_POST_MEAL_MARKER_RE.test(blob)) return loinc;
    return GLUCOSE_MASS_UNIT_RE.test(normalizeFullwidth(String(rawUnit ?? ""))) ? "1521-4" : null;
  }
  function capillaryGlucoseLoincFix(loinc, code, display, orderName, itemName, rawUnit) {
    if (loinc !== "1558-6" && loinc !== "2345-7") return loinc;
    const blob = normalizeFullwidth(
      `${String(display ?? "")} ${String(orderName ?? "")} ${String(itemName ?? "")}`
    );
    if (!FINGER_GLUCOSE_MARKER_RE.test(blob)) return loinc;
    const unit = normalizeFullwidth(String(rawUnit ?? ""));
    const fasting = String(code ?? "").trim() === "09005C" || loinc === "1558-6";
    if (GLUCOSE_MOLAR_UNIT_RE.test(unit)) return fasting ? "14770-2" : "14743-9";
    if (GLUCOSE_MASS_UNIT_RE.test(unit)) return fasting ? "41604-0" : "41653-7";
    return null;
  }
  var FIT_MASS_CONC_UNIT_RE = /(?:pg|ng|ug|mg|g)\s*\/\s*(?:dl|l|ml|g)\b/i;
  function fitResultScaleLoincFix(loinc, code, value, rawUnit) {
    if (String(code ?? "").trim() !== "09134C" && loinc !== "58453-2") return loinc;
    const result = normalizeFullwidth(String(value ?? "")).trim();
    if (isQualitativeLabResultValue(result)) return "29771-3";
    if (tryParseQuantity(result, String(rawUnit ?? "")) != null && FIT_MASS_CONC_UNIT_RE.test(normalizeFullwidth(String(rawUnit ?? "")))) {
      return "58453-2";
    }
    return null;
  }
  var SERUM_TO_URINE_ELECTROLYTE = {
    "2951-2": "2955-3",
    // Sodium        Ser/Plas → Urine
    "2823-3": "2828-2",
    // Potassium     Ser/Plas → Urine
    "2075-0": "2078-4",
    // Chloride      Ser/Plas → Urine
    "3094-0": "3095-7",
    // Urea nitrogen Ser/Plas → Urine
    "2692-2": "2695-5",
    // Osmolality    Ser/Plas → Urine
    "19123-9": "19124-7"
    // Magnesium   Ser/Plas → Urine (spot/mass-volume)
  };
  var ELECTROLYTE_URINE_RE = /尿中|24小時尿|spot\s*urine|\bu-(?:na|k|cl|bun|urea|osm|mg)\b/i;
  var MAGNESIUM_MASS_TIME_UNIT_RE = /(?:mg|g)\s*\/\s*(?:24\s*h(?:r)?|d(?:ay)?)/i;
  function urineElectrolyteLoincFix(loinc, code, display, orderName, itemName = "", rawUnit = "") {
    const twin = loinc ? SERUM_TO_URINE_ELECTROLYTE[loinc] : void 0;
    if (!twin) return loinc;
    const disp = String(display ?? "");
    const item = String(itemName ?? "");
    const isUrine = inferSpecimen(String(orderName ?? ""), disp, String(code ?? ""), item) === "Urine" || ELECTROLYTE_URINE_RE.test(`${disp} ${item}`);
    if (!isUrine) return loinc;
    if (loinc === "19123-9" && URINE_24H_RE.test(`${String(orderName ?? "")} ${disp} ${item}`) && MAGNESIUM_MASS_TIME_UNIT_RE.test(String(rawUnit ?? ""))) {
      return "24447-5";
    }
    return twin;
  }
  var MAGNESIUM_MOLAR_OR_EQ_UNIT_RE = /(?:mol|eq)\s*\/\s*(?:l|24\s*h(?:r)?|d(?:ay)?)\b/i;
  var MAGNESIUM_24H_RATE_UNIT_RE = /(?:mol|eq)\s*\/\s*(?:24\s*h(?:r)?|d(?:ay)?)\b/i;
  function magnesiumUnitLoincFix(loinc, code, display, orderName, itemName, rawUnit) {
    if (!loinc || String(code ?? "").trim() !== "09046B") return loinc;
    const unit = normalizeFullwidth(String(rawUnit ?? ""));
    if (!MAGNESIUM_MOLAR_OR_EQ_UNIT_RE.test(unit)) return loinc;
    const displayText = String(display ?? "");
    const itemText = String(itemName ?? "");
    const blob = `${String(orderName ?? "")} ${displayText} ${itemText}`;
    const isUrine = inferSpecimen(String(orderName ?? ""), displayText, String(code ?? ""), itemText) === "Urine" || ELECTROLYTE_URINE_RE.test(`${displayText} ${itemText}`);
    if (!isUrine) return "2601-3";
    if (URINE_24H_RE.test(blob) && MAGNESIUM_24H_RATE_UNIT_RE.test(unit)) return "2599-9";
    return "2598-1";
  }
  var SERUM_TO_FLUID_CHEM = {
    "2345-7": {
      csf: "2342-4",
      pleural: "2346-5",
      peritoneal: "2347-3",
      bodyFluid: "2344-0"
    },
    // Glucose Ser/Plas
    "1558-6": {
      csf: "2342-4",
      pleural: "2346-5",
      peritoneal: "2347-3",
      bodyFluid: "2344-0"
    },
    // Fasting glucose Ser/Plas
    "2532-0": {
      csf: "2528-8",
      pleural: "2530-4",
      peritoneal: "2531-2",
      bodyFluid: "2529-6"
    },
    // LDH — Light's criteria
    // v1.2.9 — same 洞C class for more single-analyte dual-specimen codes: each
    // Path-A short-circuits to the SERUM LOINC before the specimen veto runs, so
    // a pleural/ascitic/CSF row shipped a Serum LOINC on a non-blood specimen.
    // Reroute to the WebFetch-verified (loinc.org 2.82) fluid twin. Amylase / AST /
    // cholesterol / TG DO have dedicated CSF codes (14389-1 / 1918-2 / 14439-4 /
    // 14446-9); only ALT has none, so its `csf` slot is omitted → CSF ALT ships
    // NHI-code-only (never the Body-fld code, which excludes CSF).
    "1751-7": {
      csf: "1746-7",
      pleural: "1748-3",
      peritoneal: "1749-1",
      bodyFluid: "1747-5"
    },
    // Albumin Ser/Plas (SAAG)
    // 101198-0 = Albumin Ser/Plas by Nephelometry (12112B). Same non-serum twins as
    // 1751-7 — LOINC has no nephelometry-specific fluid albumin, so a CSF/pleural/
    // ascitic nephelometry-albumin row reroutes to the methodless fluid twin (the
    // specimen axis matters more than the method for the reroute). 2026-07-13 Finding 3.
    "101198-0": {
      csf: "1746-7",
      pleural: "1748-3",
      peritoneal: "1749-1",
      bodyFluid: "1747-5"
    },
    // Albumin Ser/Plas Nephelometry
    "1798-8": {
      csf: "14389-1",
      pleural: "1796-2",
      peritoneal: "1797-0",
      bodyFluid: "1795-4"
    },
    // Amylase Ser/Plas
    "1920-8": {
      csf: "1918-2",
      pleural: "14409-7",
      peritoneal: "14410-5",
      bodyFluid: "1919-0"
    },
    // AST Ser/Plas
    "1742-6": { pleural: "54492-4", peritoneal: "54491-6", bodyFluid: "25302-1" },
    // ALT Ser/Plas — NO CSF-specific LOINC (25302-1 is Body fld, which EXCLUDES CSF) → CSF ships NHI-code-only
    "2093-3": {
      csf: "14439-4",
      pleural: "9618-0",
      peritoneal: "14441-0",
      bodyFluid: "12183-0"
    },
    // Cholesterol Ser/Plas
    "2571-8": {
      csf: "14446-9",
      pleural: "9619-8",
      peritoneal: "14447-7",
      bodyFluid: "12228-3"
    }
    // Triglyceride Ser/Plas
  };
  function fluidChemistryLoincFix(loinc, code, display, orderName, itemName = "") {
    const twin = loinc ? SERUM_TO_FLUID_CHEM[loinc] : void 0;
    if (!twin) return loinc;
    const spec = inferSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      String(code ?? ""),
      String(itemName ?? "")
    );
    if (spec == null || spec === "Blood" || spec === "Urine") return loinc;
    if (spec === "Cerebrospinal fluid") return twin.csf ?? null;
    if (spec === "Pleural fluid") return twin.pleural ?? twin.bodyFluid;
    if (spec === "Peritoneal fluid") return twin.peritoneal ?? twin.bodyFluid;
    return twin.bodyFluid;
  }
  var URINE_24H_RE = /24\s*h(?:r|rs|our|ours)?\b|24\s*小時|日尿|一日尿|全日尿/i;
  var ALB_MASS_TIME_UNIT_RE = /\b(?:mg|g)\s*\/\s*(?:24\s*h(?:r)?|d(?:ay)?|24\s*小時)\b/i;
  var ALB_MASS_VOL_UNIT_RE = /\b(?:mg|ug|µg|g)\s*\/\s*(?:dl|l|ml)\b/i;
  function albuminUrineLoincFix(loinc, _code, display, orderName, itemName = "", rawUnit = "") {
    if (loinc !== "1751-7" && loinc !== "101198-0") return loinc;
    const spec = inferSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      "",
      String(itemName ?? "")
    );
    if (spec !== "Urine") return loinc;
    const unit = String(rawUnit ?? "").trim();
    const blob = `${display} ${orderName} ${itemName}`;
    const isMassTime = ALB_MASS_TIME_UNIT_RE.test(unit);
    const isMassVol = ALB_MASS_VOL_UNIT_RE.test(unit);
    const is24h = URINE_24H_RE.test(blob) || isMassTime;
    if (is24h && isMassTime) return "1755-8";
    if (is24h && isMassVol) return "21059-1";
    if (isMassVol) return "1754-1";
    return null;
  }
  var AFP_ARBITRARY_UNIT_RE = /\b(?:k?iu|u)\s*\/\s*(?:ml|dl|l)\b|\[iu\]\s*\/\s*(?:ml|l)\b/i;
  function afpUnitFix(loinc, rawUnit) {
    if (loinc !== "1834-1") return loinc;
    if (AFP_ARBITRARY_UNIT_RE.test(String(rawUnit ?? "").trim())) return "19176-7";
    return loinc;
  }
  var TP_ANALYTE_RE = /全蛋白|total\s*protein|\btp\b/i;
  var TP_FLUID_RE = /胸水|pleural|\(pl\)|腹水|ascites|腹膜|peritoneal|體液|body\s*fluid/i;
  var TP_CSF_RE = /腦脊髓|\bcsf\b|\(csf\)/i;
  function totalProteinLoincFix(loinc, display, orderName, itemName) {
    if (loinc != null) return loinc;
    const analyte = normalizeFullwidth(`${String(display ?? "")} ${String(itemName ?? "")}`);
    if (!TP_ANALYTE_RE.test(analyte)) return loinc;
    const marks = normalizeFullwidth(
      `${String(orderName ?? "")} ${String(display ?? "")} ${String(itemName ?? "")}`
    );
    const spec = inferSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      "",
      String(itemName ?? "")
    );
    if (spec === "Pleural fluid") return "2882-9";
    if (spec === "Peritoneal fluid") return "2883-7";
    if (TP_CSF_RE.test(marks)) return "2880-3";
    if (TP_FLUID_RE.test(marks)) return "2881-1";
    if (URINE_MARKERS_RE.test(marks) || /\(u\)/i.test(marks)) return "2888-6";
    return "2885-2";
  }
  var VENOUS_BLOOD_GAS_TWINS = {
    "11558-4": "2746-6",
    // pH
    "11557-6": "2021-4",
    // pCO2
    "11556-8": "2705-2",
    // pO2
    "1959-6": "14627-4",
    // ordinary HCO3; SBC is split by row label below
    "20565-8": "2027-1",
    // total CO2: generic Blood -> Venous blood
    "11555-0": "1927-3",
    // base excess
    "20564-1": "2711-0"
    // oxygen saturation, method unspecified
  };
  var STANDARD_BASE_EXCESS_RE = /\bs[\s._-]*b[\s._-]*e\b|standard\s+base\s+excess/i;
  var STANDARD_BICARBONATE_RE = /\bs[\s._-]*b[\s._-]*c\b|standard\s+bicarbonate|bicarbonate\s+standard|hco3\s*(?:std|standard)/i;
  function bloodGasAdjustmentAxis(code, display, itemName) {
    if (String(code ?? "").trim() !== "09041B") return "";
    const rowLabel = normalizeFullwidth(`${String(display ?? "")} ${String(itemName ?? "")}`);
    if (STANDARD_BASE_EXCESS_RE.test(rowLabel)) return "standard-base-excess";
    if (STANDARD_BICARBONATE_RE.test(rowLabel)) return "standard-bicarbonate";
    return "";
  }
  function bloodGasVesselLoincFix(loinc, code, display, orderName, itemName, groupSpecimen) {
    if (String(code ?? "").trim() !== "09041B" || loinc == null) return loinc;
    const rowLabel = normalizeFullwidth(`${String(display ?? "")} ${String(itemName ?? "")}`);
    const isStandardBaseExcess = STANDARD_BASE_EXCESS_RE.test(rowLabel);
    const isStandardBicarbonate = STANDARD_BICARBONATE_RE.test(rowLabel);
    const specimen = groupSpecimen ?? inferSpecimen(
      String(orderName ?? ""),
      String(display ?? ""),
      "",
      // marker-only: do not let 09041B's generic Blood default decide vessel
      String(itemName ?? "")
    );
    if (specimen !== "Venous blood") {
      return isStandardBaseExcess || isStandardBicarbonate ? null : loinc;
    }
    if (isStandardBaseExcess) return "19237-7";
    if (isStandardBicarbonate) return "19232-8";
    return VENOUS_BLOOD_GAS_TWINS[loinc] ?? loinc;
  }
  function mapObservation(raw, patientId) {
    if (!raw || typeof raw !== "object") return null;
    const out = mapObservationsGrouped([raw], patientId);
    return out.find((r) => r.resourceType === "Observation") ?? null;
  }
  function buildBpPanelObservation(raw, patientId) {
    const date = raw.date ?? "";
    const hospital = raw.hospital ?? "";
    const bpValueKey = raw.bp_components.map((c) => `${c.loinc}:${c.value}`).join(",");
    const obsId = stableId(
      patientId,
      "obs",
      "BP_PANEL",
      date,
      hospital,
      String(raw.group_instance_key ?? ""),
      bpValueKey
    );
    const componentResources = [];
    for (const c of raw.bp_components) {
      const qty = {
        value: c.value,
        unit: c.unit || "mmHg",
        system: "http://unitsofmeasure.org",
        code: toUcum(c.unit) ?? "mm[Hg]"
      };
      componentResources.push({
        code: {
          coding: [{ system: "http://loinc.org", code: c.loinc, display: c.display }],
          text: c.display
        },
        valueQuantity: qty
      });
    }
    const bpObs = {
      resourceType: "Observation",
      id: obsId,
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      status: "final",
      category: [
        {
          coding: [
            {
              system: "http://terminology.hl7.org/CodeSystem/observation-category",
              code: "vital-signs",
              display: "Vital Signs"
            }
          ]
        }
      ],
      code: {
        coding: [
          {
            system: "http://loinc.org",
            code: raw.bp_panel_loinc ?? "85354-9",
            display: "Blood pressure panel"
          }
        ],
        text: "Blood Pressure"
      },
      subject: { reference: `Patient/${patientId}` },
      component: componentResources
    };
    if (date) bpObs.effectiveDateTime = fhirDateTime2(date);
    if (hospital) bpObs.performer = [{ display: hospital }];
    if (raw.group_instance_key) {
      bpObs.__nhiReportInstanceTime = String(raw.group_instance_key);
    }
    return bpObs;
  }
  function buildObservation(raw, patientId, panelCode, groupSpecimen = null) {
    if (raw.bp_components) return buildBpPanelObservation(raw, patientId);
    const display = raw.display || raw.code || "";
    const itemName = String(raw.item_name ?? "");
    const code = (panelCode ? String(panelCode) : "") || raw.order_code || raw.code || "";
    const value = raw.value;
    const interp = (raw.interpretation ?? "").toString().toLowerCase();
    const canonical = canonicalLabKey(display, code) || display;
    const repeatedSourceRow = repeatedSourceRowTerm(raw);
    const obsId = stableId(
      patientId,
      "obs",
      canonical,
      raw.date ?? "",
      raw.hospital ?? "",
      code,
      String(raw.value ?? ""),
      String(raw.unit ?? ""),
      String(raw.nhi_source_channel ?? ""),
      String(raw.group_instance_key ?? ""),
      String(raw.assay_method ?? ""),
      ...repeatedSourceRow ? [repeatedSourceRow] : []
    );
    const lookup = findLoincDetailed(code, display, String(raw.order_name ?? ""), itemName, value);
    let loinc = lookup.loinc;
    loinc = structuralLoincFix(loinc, raw.unit);
    loinc = qualifiedCbcCellPropertyLoincFix(loinc, raw.unit);
    loinc = flowMarkerUnitFix(loinc, code, display, raw.unit);
    loinc = urineProteinLoincFix(loinc, value, raw.unit);
    loinc = urobilinogenUnitFix(loinc, raw.unit);
    loinc = fitResultScaleLoincFix(loinc, code, value, raw.unit);
    loinc = ammoniaLoincFix(loinc, raw.unit);
    loinc = lactateLoincFix(loinc, code, display, raw.order_name, itemName, raw.unit);
    loinc = freeT4UnitFix(loinc, raw.unit);
    loinc = afpUnitFix(loinc, raw.unit);
    loinc = antiHbcLoincFix(loinc, value, raw.unit, display, raw.order_name, itemName);
    loinc = cholesterolRatioLoincFix(loinc, code, display, raw.order_name, itemName);
    loinc = highSensitivityCrpLoincFix(loinc, code, display, raw.order_name, itemName);
    loinc = freeLightChainLoincFix(loinc, code, display, raw.order_name, itemName);
    loinc = hsTroponinFix(loinc, display);
    loinc = ldlLoincFix(loinc, code, display, raw.order_name, itemName);
    loinc = capillaryGlucoseLoincFix(loinc, code, display, raw.order_name, itemName, raw.unit);
    loinc = twoHourPostMealGlucoseLoincFix(loinc, code, display, raw.order_name, itemName, raw.unit);
    loinc = urineElectrolyteLoincFix(loinc, code, display, raw.order_name, itemName, raw.unit);
    loinc = magnesiumUnitLoincFix(loinc, code, display, raw.order_name, itemName, raw.unit);
    loinc = fluidChemistryLoincFix(loinc, code, display, raw.order_name, itemName);
    loinc = proteinElectrophoresisSpecimenFix(loinc, code, display, raw.order_name, itemName);
    loinc = albuminUrineLoincFix(loinc, code, display, raw.order_name, itemName, raw.unit);
    loinc = totalProteinLoincFix(loinc, display, raw.order_name, itemName);
    loinc = urineTotalProteinPropertyLoincFix(loinc, value, raw.unit);
    loinc = bloodGasVesselLoincFix(loinc, code, display, raw.order_name, itemName, groupSpecimen);
    loinc = loincSpecimenConsistencyGuard(loinc, raw.order_name, display, code, itemName);
    const emittedLoinc = isPanelDefaultFallback(code, lookup) ? null : loinc;
    const catCode = raw.category || "laboratory";
    const CAT_DISPLAY = {
      laboratory: "Laboratory",
      "vital-signs": "Vital Signs",
      imaging: "Imaging",
      procedure: "Procedure",
      "social-history": "Social History",
      survey: "Survey",
      exam: "Exam",
      therapy: "Therapy",
      activity: "Activity"
    };
    const catDisplay = CAT_DISPLAY[catCode] ?? catCode.charAt(0).toUpperCase() + catCode.slice(1).toLowerCase();
    const resource = {
      resourceType: "Observation",
      id: obsId,
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      status: "final",
      category: [
        {
          coding: [
            {
              system: "http://terminology.hl7.org/CodeSystem/observation-category",
              code: catCode,
              display: catDisplay
            }
          ]
        }
      ],
      code: {
        // v0.11.9 (Category A): pass the panel-level NHI catalog name to
        // buildCodings so coding[nhi].display becomes the panel name (e.g.
        // "ABO血型測定檢驗") instead of the row-level LIS display ("血型
        // 鑑定"). Order: raw.order_name (scraper-provided NHI catalog
        // value) → NHI_CODE_PANEL_NAME override → fall back to display
        // via buildCodings.
        coding: buildCodings(
          code,
          display,
          emittedLoinc,
          String(raw.order_name ?? "") || NHI_CODE_PANEL_NAME[code] || void 0,
          itemName
        ),
        // v0.11.9 / v0.11.10 / v0.13: precedence (high → low):
        //   1. LOINC_SHORT_TEXT override — gated on cleanMatch for CBC
        //      LOINCs (CBC_CANONICAL_TEXT_LOINCS), always-on otherwise.
        //      See resolveObsCodeText() + findLoincDetailed() docstrings.
        //   2. NHI_CODE_PANEL_NAME override (when LIS ships a generic
        //      display under an NHI code that has a canonical specific
        //      name in the NHI catalog, e.g. 11001C "血型鑑定" →
        //      "ABO 血型測定" so SMART app can distinguish ABO/Rh/Antibody)
        //   3. Raw display (LIS-supplied analyte name) — also the
        //      fallback that preserves the v0.11.9 Bug 6 mis-tag canary
        //      when CBC LOINC is reached via path-C panel default.
        //   4. "Unknown Lab" sentinel
        // v0.11.10: normalizeFullwidth() applied so fullwidth ASCII chars
        // (e.g. 09099C 「心肌旋轉蛋白Ｉ」) become halfwidth in our label.
        text: resolveObsCodeText(loinc, code, display, lookup.cleanMatch, itemName)
      },
      subject: { reference: `Patient/${patientId}` }
    };
    if (raw.date) resource.effectiveDateTime = fhirDateTime2(raw.date);
    if (raw.hospital) resource.performer = [{ display: raw.hospital }];
    if (raw.group_instance_key) {
      resource.__nhiReportInstanceTime = String(raw.group_instance_key);
    }
    const assayMethod = String(raw.assay_method ?? "").trim();
    if (assayMethod) resource.method = { text: assayMethod };
    const specimen = evidenceSpecimen(
      raw.order_name,
      raw.display,
      raw.code,
      loinc,
      itemName,
      groupSpecimen
    );
    if (specimen) resource.specimen = { display: specimen };
    appendNhiSourceChannelTag(resource, raw);
    appendNhiVisitDateTag(resource, raw);
    appendSourceProgramTag(resource, raw);
    applyObservationValue(resource, raw, String(display), String(code), emittedLoinc);
    let _interpFromRange = null;
    if (raw.reference_range) {
      const rrs = parseRangeMulti(String(raw.reference_range), raw.unit ?? "");
      const realRanges = rrs.filter((r) => !r.interpretationText);
      if (realRanges.length > 0) resource.referenceRange = realRanges;
      const flagged = rrs.find((r) => r.interpretationText);
      if (flagged?.interpretationText) _interpFromRange = flagged.interpretationText;
    }
    const interpCodingResult = mapInterpretation(interp);
    if (interpCodingResult) {
      resource.interpretation = [{ coding: [interpCodingResult] }];
    } else if (_interpFromRange) {
      const coded = mapInterpretation(_interpFromRange.toLowerCase());
      resource.interpretation = coded ? [{ coding: [coded], text: _interpFromRange }] : [{ text: _interpFromRange }];
    }
    applyNhiAbnormalFlag(resource, raw);
    return resource;
  }
  var BLOOD_GAS_CORE_BY_LOINC = {
    "11558-4": "ph",
    "2746-6": "ph",
    "11557-6": "pco2",
    "2021-4": "pco2",
    "11556-8": "po2",
    "2705-2": "po2"
  };
  function resolveBloodGasGroupSpecimen(groupCodeStr, items) {
    if (groupCodeStr !== "09041B") return null;
    const coreSpecimens = /* @__PURE__ */ new Map();
    const everyExplicitVessel = /* @__PURE__ */ new Set();
    for (const item of items) {
      const display = String(item.display ?? item.code ?? "");
      const itemName = String(item.item_name ?? "");
      const orderName = String(item.order_name ?? "");
      const explicitMatches = collectExplicitBloodSpecimens(`${orderName} ${display} ${itemName}`);
      if (explicitMatches.size > 1) return null;
      for (const explicit of explicitMatches) everyExplicitVessel.add(explicit);
      const rowCode = String(item.__observation_panel_code ?? groupCodeStr);
      const loinc = findLoincDetailed(rowCode, display, orderName, itemName, item.value).loinc;
      const core = loinc ? BLOOD_GAS_CORE_BY_LOINC[loinc] : void 0;
      if (!core) continue;
      const specimen = inferSpecimen(orderName, display, "", itemName);
      if (!specimen || !BLOOD_SPECIMENS.has(specimen) || specimen === "Blood") return null;
      const prior = coreSpecimens.get(core);
      if (prior && prior !== specimen) return null;
      coreSpecimens.set(core, specimen);
    }
    if (coreSpecimens.size !== 3 || everyExplicitVessel.size !== 1) return null;
    const specimens = new Set(coreSpecimens.values());
    if (specimens.size !== 1) return null;
    return [...specimens][0] === "Venous blood" ? "Venous blood" : null;
  }
  var VERIFIED_MULTI_ANALYTE_DR_PARENT_LOINCS = /* @__PURE__ */ new Set([
    "24356-8",
    // Urinalysis complete panel (06012C only; never mixed 06013C by default)
    "24365-9",
    // Urinalysis microscopic panel
    "24351-9",
    // Protein electrophoresis panel, serum/plasma
    "34539-7",
    // Protein electrophoresis panel, urine
    "24352-7",
    // Protein electrophoresis panel, CSF
    "47286-0",
    // Bone marrow differential panel
    "50190-8",
    // Iron and iron-binding capacity panel
    "57778-3",
    // Free kappa + free lambda + free kappa/lambda ratio panel
    "57021-8",
    // CBC with automated differential panel
    "58410-2",
    // CBC without differential panel
    "80721-4",
    // T/B/NK lymphocyte subset panel
    "80381-7",
    // Influenza A+B antigen panel (exact member-set resolver below)
    "24339-4"
    // Gas panel - Venous blood (required core + allowed members below)
  ]);
  var VENOUS_GAS_REQUIRED_LOINCS = /* @__PURE__ */ new Set(["2746-6", "2021-4", "2705-2"]);
  var VENOUS_GAS_ALLOWED_LOINCS = /* @__PURE__ */ new Set([
    ...VENOUS_GAS_REQUIRED_LOINCS,
    "14627-4",
    "2027-1",
    "1927-3",
    "2711-0",
    "8310-5"
  ]);
  function permitsNonUnanimousDrLoinc(groupCodeStr, panelLoinc) {
    if (VERIFIED_MULTI_ANALYTE_DR_PARENT_LOINCS.has(panelLoinc)) return true;
    return exactCrossCodeRuleForGroup(groupCodeStr)?.reportLoinc === panelLoinc;
  }
  function summarizeDrMemberLoincs(obsResources) {
    const memberLoincs = obsResources.map(
      (o) => o.code?.coding?.find((c) => c?.system === LOINC)?.code
    );
    return {
      allCoded: memberLoincs.length > 0 && memberLoincs.every(Boolean),
      codes: new Set(memberLoincs.filter((l) => typeof l === "string"))
    };
  }
  function resolveDrPanelLoinc(groupCodeStr, obsResources, groupSpecimen = null) {
    let panelLoinc = NHI_TO_LOINC[groupCodeStr];
    const members = summarizeDrMemberLoincs(obsResources);
    const exactCrossCodeRule = exactCrossCodeRuleForGroup(groupCodeStr);
    if (exactCrossCodeRule && members.allCoded && members.codes.size === exactCrossCodeRule.memberLoincs.length && exactCrossCodeRule.memberLoincs.every((loinc) => members.codes.has(loinc))) {
      panelLoinc = exactCrossCodeRule.reportLoinc;
    }
    if (groupCodeStr === "09041B" && groupSpecimen === "Venous blood" && members.allCoded && [...VENOUS_GAS_REQUIRED_LOINCS].every((loinc) => members.codes.has(loinc)) && [...members.codes].every((loinc) => VENOUS_GAS_ALLOWED_LOINCS.has(loinc))) {
      panelLoinc = "24339-4";
    }
    const isInfluenzaOrder = groupCodeStr === "14065C" || groupCodeStr === "14066C";
    if (isInfluenzaOrder && members.allCoded && members.codes.size === 2 && members.codes.has("80382-5") && members.codes.has("80383-3")) {
      panelLoinc = "80381-7";
    } else if (!panelLoinc && members.allCoded && members.codes.size === 1) {
      panelLoinc = [...members.codes][0];
    }
    if (groupCodeStr === "12160B" && members.allCoded && members.codes.size === 3 && members.codes.has("36916-5") && members.codes.has("33944-0") && members.codes.has("48378-4")) {
      panelLoinc = "57778-3";
    }
    if (groupCodeStr === "09065B" && obsResources.length > 0) {
      const specimens = new Set(
        obsResources.map((o) => String(o.specimen?.display ?? "").trim()).filter((s) => s.length > 0)
      );
      if (specimens.size === 1) {
        const specimen = [...specimens][0];
        if (specimen === "Urine") panelLoinc = "34539-7";
        if (specimen === "Cerebrospinal fluid") panelLoinc = "24352-7";
      }
    }
    if (panelLoinc && members.allCoded && members.codes.size === 1) {
      const member = [...members.codes][0];
      const twins = SERUM_TO_FLUID_CHEM[panelLoinc];
      const isTwin = twins != null && (member === twins.csf || member === twins.bodyFluid || member === twins.pleural || member === twins.peritoneal);
      const panelSpecimen = specimenFromLoinc(panelLoinc);
      const memberSpecimen = specimenFromLoinc(member);
      const specimenDiffers = member !== panelLoinc && memberSpecimen != null && panelSpecimen != null && memberSpecimen !== panelSpecimen;
      const unanimousNonPanelReroute = member !== panelLoinc && !permitsNonUnanimousDrLoinc(groupCodeStr, panelLoinc);
      if (isTwin || specimenDiffers || unanimousNonPanelReroute) panelLoinc = member;
    }
    if (panelLoinc && !permitsNonUnanimousDrLoinc(groupCodeStr, panelLoinc) && (!members.allCoded || members.codes.size !== 1 || !members.codes.has(panelLoinc))) {
      panelLoinc = void 0;
    }
    if (panelLoinc) {
      const panelSystem = specimenFromLoinc(panelLoinc);
      const memberSpecimens = obsResources.map((o) => String(o.specimen?.display ?? "").trim()).filter((s) => s.length > 0);
      if (panelSystem && memberSpecimens.some((memberSpecimen) => !specimensCompatible(memberSpecimen, panelSystem))) {
        panelLoinc = void 0;
      }
    }
    return panelLoinc;
  }
  function resolveDrPanelTitle(groupCodeStr, orderName, deduped, panelLoinc) {
    const exactCrossCodeRule = exactCrossCodeRuleForGroup(groupCodeStr);
    if (exactCrossCodeRule && panelLoinc === exactCrossCodeRule.reportLoinc)
      return exactCrossCodeRule.reportTitle;
    const isExactMemberSetPanel = panelLoinc === "80381-7" || panelLoinc === "57778-3";
    const titleLoinc = isExactMemberSetPanel ? panelLoinc : NHI_TO_LOINC[groupCodeStr] ?? panelLoinc;
    const loincShortText = titleLoinc ? LOINC_SHORT_TEXT[titleLoinc] : void 0;
    if (deduped.length === 1) {
      const singleDisplay = deduped[0].display ?? "";
      const singleItemName = String(deduped[0].item_name ?? "");
      return resolveHumanLabel({
        loincShortText,
        code: groupCodeStr,
        itemName: singleItemName,
        orderName: orderName ?? void 0,
        display: singleDisplay,
        fallback: groupCodeStr,
        preferItemName: !panelLoinc
      });
    }
    const allSameAnalyte = !DISPLAY_FIRST_CODES.has(groupCodeStr);
    return (allSameAnalyte || isExactMemberSetPanel) && loincShortText || orderName || NHI_CODE_PANEL_NAME[groupCodeStr] || groupCodeStr;
  }
  function groupByOrderCode(cleaned, patientId) {
    let working = dedupeCrossFormat(cleaned);
    working = combineBpItems(working);
    const groups = /* @__PURE__ */ new Map();
    const keyMeta = /* @__PURE__ */ new Map();
    for (const raw of working) {
      const groupKeyCode = raw.__report_group_code || raw.order_code || raw.code || raw.display || "";
      const date = raw.date ?? "";
      const hospital = raw.hospital ?? "";
      const groupInstanceKey = String(raw.group_instance_key ?? "");
      const key = `${groupKeyCode}|${date}|${hospital}|${groupInstanceKey}`;
      const arr = groups.get(key);
      if (arr) arr.push(raw);
      else {
        groups.set(key, [raw]);
        keyMeta.set(key, {
          groupKeyCode: String(groupKeyCode),
          date,
          hospital,
          groupInstanceKey
        });
      }
    }
    const out = [];
    for (const [key, items] of groups.entries()) {
      const meta = keyMeta.get(key);
      const deduped = dedupePanelItems(items);
      const groupSpecimen = resolveBloodGasGroupSpecimen(String(meta.groupKeyCode), deduped);
      const obsResources = [];
      const seenObsIds = /* @__PURE__ */ new Set();
      for (const it of deduped) {
        const obs = buildObservation(
          it,
          patientId,
          String(it.__observation_panel_code ?? meta.groupKeyCode),
          groupSpecimen
        );
        if (!obs) continue;
        if (seenObsIds.has(obs.id)) continue;
        seenObsIds.add(obs.id);
        obsResources.push(obs);
      }
      if (obsResources.length === 0) continue;
      const isBpPanel = deduped.every((it) => it.bp_components || it.display === "Blood Pressure");
      if (isBpPanel) {
        out.push(...obsResources);
        continue;
      }
      const orderName = deduped.find((it) => it.order_name)?.order_name ?? null;
      const memberKeys = Array.from(
        new Set(
          deduped.filter((it) => it.display).map((it) => canonicalLabKey(it.display, String(meta.groupKeyCode)))
        )
      ).sort();
      const panelSignature = memberKeys.join(",") || String(meta.groupKeyCode);
      const drId = stableId(
        patientId,
        "DR",
        panelSignature,
        meta.date,
        meta.hospital,
        String(meta.groupKeyCode),
        meta.groupInstanceKey
      );
      const groupCodeStr = String(meta.groupKeyCode);
      const exactCrossCodeRule = exactCrossCodeRuleForGroup(groupCodeStr);
      const isMergedCrossCodeReport = exactCrossCodeRule != null;
      const drPanelLoinc = resolveDrPanelLoinc(groupCodeStr, obsResources, groupSpecimen);
      const panelTitle = resolveDrPanelTitle(groupCodeStr, orderName, deduped, drPanelLoinc);
      const drCodeSystem = NHI_LAB_CODE_RE.test(String(meta.groupKeyCode) ?? "") ? NHI_MEDICAL_ORDER_CODE : HIS_LOCAL_LAB_CODE;
      const drCodingDisplay = orderName || NHI_CODE_PANEL_NAME[groupCodeStr] || panelTitle;
      const drText = normalizeFullwidth(panelTitle);
      const drCodings = isMergedCrossCodeReport ? [] : [
        {
          system: drCodeSystem,
          code: String(meta.groupKeyCode) || "UNKNOWN",
          display: drCodingDisplay
        }
      ];
      if (drPanelLoinc && LOINC_DISPLAY[drPanelLoinc]) {
        drCodings.push({
          system: LOINC,
          code: drPanelLoinc,
          display: LOINC_DISPLAY[drPanelLoinc]
        });
      }
      const drMeta = {
        versionId: "1",
        source: "nhi-fhir-bridge/scraper"
      };
      if (exactCrossCodeRule) {
        const sourceOrders = deduped[0]?.__merged_source_orders ?? [];
        drMeta.tag = [
          ...sourceOrders.map((sourceOrder) => ({
            system: NHI_SOURCE_ORDER_CODE,
            code: String(sourceOrder.code ?? ""),
            ...sourceOrder.display ? { display: String(sourceOrder.display) } : {}
          })),
          {
            system: DEDUP_PROVENANCE,
            code: exactCrossCodeRule.dedupCode,
            display: exactCrossCodeRule.dedupDisplay
          }
        ];
      }
      const dr = {
        resourceType: "DiagnosticReport",
        id: drId,
        meta: drMeta,
        status: "final",
        category: [
          {
            coding: [
              {
                system: "http://terminology.hl7.org/CodeSystem/v2-0074",
                code: "LAB",
                display: "Laboratory"
              }
            ]
          }
        ],
        code: {
          coding: drCodings,
          text: drText
        },
        subject: { reference: `Patient/${patientId}` },
        result: obsResources.map((o) => ({ reference: `Observation/${o.id}` }))
      };
      if (meta.date) dr.effectiveDateTime = fhirDateTime2(meta.date);
      if (meta.hospital) dr.performer = [{ display: meta.hospital }];
      if (meta.groupInstanceKey) {
        dr.__nhiReportInstanceTime = meta.groupInstanceKey;
      }
      if (obsResources.length === 1 && obsResources[0]?.code) {
        const obs = obsResources[0];
        const obsLoinc = obs.code.coding?.find(
          (c) => c?.system === "http://loinc.org"
        )?.code;
        const panelLoinc = NHI_TO_LOINC[groupCodeStr];
        if (!obsLoinc || obsLoinc === panelLoinc) {
          obs.code.text = drText;
        }
      }
      out.push(dr);
      out.push(...obsResources);
    }
    return out;
  }
  function mapObservationsGrouped(rawItems, patientId) {
    const cleaned = filterLabRows(rawItems);
    const dedupedMeasurements = dedupeSameClinicalMeasurements(cleaned);
    const dedupedChannel = dedupNhiCrossChannelPairs(dedupedMeasurements);
    const mergedCrossCode = mergeExactDuplicateCrossCodeWorkups(dedupedChannel);
    return groupByOrderCode(mergedCrossCode, patientId);
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/procedure.ts
  function mapSystem3(systemHint) {
    const s = typeof systemHint === "string" ? systemHint.toLowerCase() : "";
    if (s.includes("snomed")) return SNOMED_CT;
    if (s.includes("nhi")) return NHI_MEDICAL_ORDER_CODE;
    if (s.includes("icd")) return ICD_10_PCS;
    return HIS_LOCAL_PROCEDURE_CODE;
  }
  function procedureId(patientId, codeKey, date, hospital, reasonKey, sourceRecordKey = "") {
    return stableId(patientId, codeKey, date, hospital, reasonKey, sourceRecordKey);
  }
  var PART_OF_LOOKUP_FIELD = "__nhiPartOfLookup";
  function procedureDay(resource) {
    return String(
      resource.performedDateTime ?? resource.performedPeriod?.start ?? ""
    ).slice(0, 10);
  }
  function procedureHospital(resource) {
    return String(resource.performer?.[0]?.actor?.display ?? "").trim();
  }
  function procedureReasonKey(resource) {
    for (const reason of resource.reasonCode ?? []) {
      for (const coding of reason?.coding ?? []) {
        const code = String(coding?.code ?? "").trim();
        if (code) return normalizeIcd10Cm(code);
      }
    }
    return "";
  }
  function procedureLookupKey(code, date, hospital, reasonKey) {
    return JSON.stringify([code, date, hospital, reasonKey]);
  }
  function procedureCodes(resource) {
    return (resource.code?.coding ?? []).map((coding) => String(coding?.code ?? "").trim()).filter(Boolean);
  }
  function resolveProcedureRemap(id, remap) {
    const visited = /* @__PURE__ */ new Set();
    let current = id;
    while (!visited.has(current)) {
      visited.add(current);
      const next = remap.get(current);
      if (!next) break;
      current = next;
    }
    return current;
  }
  function repairProcedurePartOf(resources, remap) {
    const procedureIds = /* @__PURE__ */ new Set();
    const candidatesByLookup = /* @__PURE__ */ new Map();
    for (const resource of resources) {
      if (resource.resourceType !== "Procedure" || !resource.id) continue;
      const id = String(resource.id);
      procedureIds.add(id);
      const date = procedureDay(resource);
      const hospital = procedureHospital(resource);
      const reasonKey = procedureReasonKey(resource);
      for (const code of procedureCodes(resource)) {
        const key = procedureLookupKey(code, date, hospital, reasonKey);
        const candidates = candidatesByLookup.get(key) ?? /* @__PURE__ */ new Set();
        candidates.add(id);
        candidatesByLookup.set(key, candidates);
      }
    }
    for (const resource of resources) {
      if (resource.resourceType !== "Procedure") continue;
      const lookup = resource[PART_OF_LOOKUP_FIELD];
      delete resource[PART_OF_LOOKUP_FIELD];
      const refs = Array.isArray(resource.partOf) ? resource.partOf : [];
      const repaired = [];
      for (const ref of refs) {
        const rawReference = String(ref?.reference ?? "");
        const referencedId = rawReference.replace(/^Procedure\//, "");
        const remappedId = resolveProcedureRemap(referencedId, remap);
        if (rawReference.startsWith("Procedure/") && remappedId !== String(resource.id ?? "") && procedureIds.has(remappedId)) {
          repaired.push({ reference: `Procedure/${remappedId}` });
          continue;
        }
        if (!lookup) continue;
        const key = procedureLookupKey(
          lookup.code,
          lookup.date,
          lookup.hospital,
          lookup.reasonKey
        );
        const candidates = [...candidatesByLookup.get(key) ?? []].filter((candidateId) => candidateId !== String(resource.id ?? ""));
        if (candidates.length === 1) {
          repaired.push({ reference: `Procedure/${candidates[0]}` });
        }
      }
      if (repaired.length > 0) {
        resource.partOf = repaired.filter(
          (ref, index, all) => all.findIndex((candidate) => candidate.reference === ref.reference) === index
        );
      } else {
        delete resource.partOf;
      }
    }
  }
  function mapProcedure(raw, patientId) {
    const note = (raw.note ?? "").trim();
    const bodySite = (raw.body_site ?? "").trim();
    const code = raw.code;
    if (!note && !bodySite && !code) return null;
    const display = raw.display ?? "Unknown Procedure";
    const displayZh = (raw.display_zh ?? "").trim() || display;
    const explicitSystem = String(raw.code_system_uri ?? "").trim();
    const explicitSystemVersion = String(raw.code_system_version ?? "").trim();
    const system = explicitSystem || mapSystem3(raw.system ?? "");
    const primary = system === ICD_10_PCS ? bilingualCoding(system, code || display, display, {
      lang: "zh-TW",
      content: raw.display_zh ?? ""
    }) : {
      system,
      ...explicitSystemVersion ? { version: explicitSystemVersion } : {},
      code: code || display,
      display
    };
    const coding = [primary];
    const code2 = raw.code2;
    if (code2) {
      coding.push(
        bilingualCoding(mapSystem3(raw.system2 ?? ""), code2, raw.display2 ?? code2, {
          lang: "zh-TW",
          content: raw.display2_zh ?? ""
        })
      );
    }
    const hospital = (raw.hospital ?? "").trim();
    const reasonKey = raw.reason_code ? normalizeIcd10Cm(String(raw.reason_code)) : "";
    const resource = {
      resourceType: "Procedure",
      id: procedureId(
        patientId,
        code || display,
        raw.date ?? "",
        hospital,
        reasonKey,
        String(raw.source_record_key ?? "")
      ),
      meta: { versionId: "1", source: "nhi-fhir-bridge/scraper" },
      status: raw.status ?? "completed",
      subject: { reference: `Patient/${patientId}` },
      code: { coding, text: displayZh }
    };
    if (raw.date && raw.end_date) {
      resource.performedPeriod = {
        start: String(raw.date),
        end: String(raw.end_date)
      };
    } else if (raw.date) {
      resource.performedDateTime = `${raw.date}T00:00:00+08:00`;
    }
    if (typeof raw.quantity === "number" && Number.isFinite(raw.quantity)) {
      resource.__nhiSourceQuantity = raw.quantity;
    }
    if (bodySite) {
      resource.bodySite = [{ text: bodySite }];
    }
    if (note) {
      resource.note = [{ text: note }];
    }
    const reasonEn = (raw.reason ?? "").trim();
    const reasonZh = (raw.reason_zh ?? "").trim();
    const reasonCodeRaw = (raw.reason_code ?? "").trim();
    if (reasonEn || reasonZh || reasonCodeRaw) {
      const rc = {};
      if (reasonCodeRaw) {
        const displayPlain = reasonEn.replace(new RegExp(`^${reasonCodeRaw}\\s+`), "").trim();
        const cd = {
          system: "http://hl7.org/fhir/sid/icd-10-cm",
          code: normalizeIcd10Cm(reasonCodeRaw)
        };
        const disp = displayPlain || reasonEn || reasonZh;
        if (disp) cd.display = disp;
        rc.coding = [cd];
      }
      const txt = reasonZh || reasonEn;
      if (txt) rc.text = txt;
      if (rc.coding || rc.text) resource.reasonCode = [rc];
    }
    if (hospital) {
      resource.performer = [{ actor: { display: hospital } }];
    }
    const partOfCode = (raw.part_of_code ?? "").trim();
    if (partOfCode) {
      const partOfSourceRecordKey = String(raw.part_of_source_record_key ?? "").trim();
      resource[PART_OF_LOOKUP_FIELD] = {
        code: partOfCode,
        date: String(raw.date ?? "").slice(0, 10),
        hospital,
        reasonKey
      };
      resource.partOf = [
        // Recompute the primary's id via the SAME key function as the id above
        // — a 次處置 shares its primary's hospital + 診斷 within one admission.
        {
          reference: `Procedure/${procedureId(
            patientId,
            partOfCode,
            raw.date ?? "",
            hospital,
            reasonKey,
            partOfSourceRecordKey
          )}`
        }
      ];
    }
    const encounterClass = (raw.encounter_class ?? "").trim();
    if (encounterClass) resource.__nhiVisitClass = encounterClass;
    return resource;
  }
  function dedupProcedures(resources) {
    const pcsCodes = (p) => (p.code?.coding ?? []).filter((c) => String(c?.system ?? "").includes("icd-10-pcs")).map((c) => String(c.code));
    const isPcsOnly = (p) => {
      const c = p.code?.coding ?? [];
      return c.length === 1 && String(c[0]?.system ?? "").includes("icd-10-pcs");
    };
    const hosp = (p) => p.performer?.[0]?.actor?.display ?? "";
    const day = (p) => String(p.performedDateTime ?? p.performedPeriod?.start ?? "").slice(0, 10);
    const claimant = /* @__PURE__ */ new Map();
    for (const p of resources) {
      if (p.resourceType !== "Procedure" || isPcsOnly(p)) continue;
      for (const code of pcsCodes(p)) claimant.set(`${hosp(p)}|${day(p)}|${code}`, p.id);
    }
    const remap = /* @__PURE__ */ new Map();
    const kept = resources.filter((p) => {
      if (p.resourceType !== "Procedure" || !isPcsOnly(p)) return true;
      for (const code of pcsCodes(p)) {
        const survivor = claimant.get(`${hosp(p)}|${day(p)}|${code}`);
        if (survivor && survivor !== p.id) {
          remap.set(p.id, survivor);
          return false;
        }
      }
      return true;
    });
    repairProcedurePartOf(kept, remap);
    return kept;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/dispatch.ts
  var LIST_HANDLERS = {
    observations: [mapObservation, "observations"],
    medications: [mapMedicationRequest, "medications"],
    conditions: [mapCondition, "conditions"],
    allergies: [mapAllergyIntolerance, "allergies"],
    diagnostic_reports: [mapDiagnosticReport, "diagnostic_reports"],
    procedures: [mapProcedure, "procedures"],
    encounters: [mapEncounter, "encounters"],
    immunizations: [mapImmunization, "immunizations"],
    care_plans: [mapCarePlan, "care_plans"],
    // 癌症篩檢 (IHKE3404) — dedicated mapper; qualitative bilingual result,
    // not a lab. One Observation per screening record (no panel grouping).
    cancer_screening: [mapCancerScreening, "cancer_screening"],
    // 出院病摘 (NHI IHKE3309S02/getxml) — DocumentReference carrying the
    // NHI-rendered HTML verbatim. One row per inpatient stay with
    // has_XML=Y. See document-reference.ts for the faithful-transport
    // rationale.
    document_references: [mapDischargeSummaryDocRef, "document_references"]
  };
  var GROUP_HANDLERS = {
    observations: mapObservationsGrouped,
    medications: mapMedicationsDedup
  };

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/link.ts
  var ENCOUNTER_LINKABLE = /* @__PURE__ */ new Set([
    "Observation",
    "MedicationRequest",
    "DiagnosticReport",
    "Procedure",
    "ServiceRequest",
    "Condition",
    "AllergyIntolerance"
  ]);
  function resourceDate(r) {
    for (const key of [
      "effectiveDateTime",
      "authoredOn",
      "performedDateTime",
      "onsetDateTime",
      "recordedDate",
      "issued",
      "occurrenceDateTime"
    ]) {
      const v = r[key];
      if (v) return String(v).slice(0, 10);
    }
    for (const key of ["effectivePeriod", "performedPeriod", "occurrencePeriod"]) {
      const period = r[key];
      if (period && typeof period === "object" && period.start) {
        return String(period.start).slice(0, 10);
      }
    }
    return "";
  }
  function resourceHospital(r) {
    for (const p of r.performer ?? []) {
      if (!p || typeof p !== "object") continue;
      if (typeof p.display === "string" && p.display) return p.display;
      const actor = p.actor;
      if (actor && typeof actor === "object" && typeof actor.display === "string" && actor.display) {
        return actor.display;
      }
    }
    const req = r.requester ?? {};
    if (req && typeof req === "object" && req.display) return req.display;
    return "";
  }
  function reasonCodeSet(r) {
    const out = /* @__PURE__ */ new Set();
    for (const rc of r.reasonCode ?? []) {
      for (const c of rc?.coding ?? []) {
        const code = c?.code ? String(c.code).replace(/[^A-Za-z0-9]/g, "").toUpperCase() : "";
        if (code) out.add(code);
      }
    }
    return out;
  }
  function medOrderCode(r) {
    const coding = r.medicationCodeableConcept?.coding;
    return Array.isArray(coding) ? String(coding[0]?.code ?? "").trim() : "";
  }
  function isImagingReport(r) {
    if (r.resourceType !== "DiagnosticReport") return false;
    for (const cc of r.category ?? []) {
      for (const c of cc.coding ?? []) {
        if (String(c?.code ?? "") === "RAD") return true;
      }
    }
    return false;
  }
  var NHI_ORDER_CODE_RE = /^\d{5}[A-Z]$/;
  function labOrderCodes(r) {
    const coding = r.code?.coding;
    const out = [];
    for (const c of Array.isArray(coding) ? coding : []) {
      const code = String(c?.code ?? "").trim();
      if (NHI_ORDER_CODE_RE.test(code)) out.push(code);
    }
    for (const tag of r.meta?.tag ?? []) {
      if (tag?.system !== NHI_SOURCE_ORDER_CODE) continue;
      const code = String(tag?.code ?? "").trim();
      if (NHI_ORDER_CODE_RE.test(code)) out.push(code);
    }
    return out;
  }
  function linkEncountersInResources(candidates, resources) {
    const visitClassByRes = /* @__PURE__ */ new Map();
    const rxCodesByEnc = /* @__PURE__ */ new Map();
    const labCodesByEnc = /* @__PURE__ */ new Map();
    const captureTransients = (r) => {
      if (!r) return;
      if (r.__nhiVisitClass !== void 0) {
        visitClassByRes.set(r, String(r.__nhiVisitClass));
        delete r.__nhiVisitClass;
      }
      if (Array.isArray(r.__rxOrderCodes)) {
        rxCodesByEnc.set(r, r.__rxOrderCodes);
        delete r.__rxOrderCodes;
      }
      if (Array.isArray(r.__labOrderCodes)) {
        labCodesByEnc.set(r, new Set(r.__labOrderCodes));
        delete r.__labOrderCodes;
      }
    };
    for (const r of resources) captureTransients(r);
    for (const e of candidates) captureTransients(e);
    if (candidates.length === 0) return;
    const exactIndex = /* @__PURE__ */ new Map();
    const impByHosp = /* @__PURE__ */ new Map();
    const rxIndex = /* @__PURE__ */ new Map();
    const byId = /* @__PURE__ */ new Map();
    for (const e of candidates) {
      if (e.resourceType !== "Encounter") continue;
      byId.set(e.id, e);
      const hosp = (e.serviceProvider ?? {}).display ?? "";
      const start = String((e.period ?? {}).start ?? "").slice(0, 10);
      if (!hosp || !start) continue;
      const key = `${hosp} ${start}`;
      const arr = exactIndex.get(key) ?? [];
      arr.push(e.id);
      exactIndex.set(key, arr);
      const cls = (e.class ?? {}).code ?? "";
      const rxCodes = rxCodesByEnc.get(e);
      if (rxCodes && rxCodes.length > 0) {
        const rxArr = rxIndex.get(key) ?? [];
        rxArr.push({ id: e.id, codes: new Set(rxCodes), isInpatient: cls === "IMP" });
        rxIndex.set(key, rxArr);
      }
      if (cls === "IMP") {
        const end = String((e.period ?? {}).end ?? "").slice(0, 10);
        if (end) {
          const list = impByHosp.get(hosp) ?? [];
          list.push([start, end, e.id]);
          impByHosp.set(hosp, list);
        }
      }
    }
    const labByHosp = /* @__PURE__ */ new Map();
    for (const e of candidates) {
      if (e.resourceType !== "Encounter") continue;
      const hosp = (e.serviceProvider ?? {}).display ?? "";
      const codes = labCodesByEnc.get(e);
      if (!hosp || !codes || codes.size === 0) continue;
      const arr = labByHosp.get(hosp) ?? [];
      arr.push({ id: e.id, codes });
      labByHosp.set(hosp, arr);
    }
    const IMAGING_LINK_MAX_GAP_DAYS = 30;
    const dayGap = (a, b) => Math.abs(Date.parse(a) - Date.parse(b)) / 864e5;
    const imagingOrderMatch = (r, hosp, examDate) => {
      const iCodes = labOrderCodes(r);
      if (iCodes.length === 0) return null;
      const hits = (labByHosp.get(hosp) ?? []).filter((e) => {
        if (!iCodes.some((c) => e.codes.has(c))) return false;
        const encDate = String((byId.get(e.id)?.period ?? {}).start ?? "").slice(0, 10);
        return !!encDate && dayGap(examDate, encDate) <= IMAGING_LINK_MAX_GAP_DAYS;
      });
      return hits.length === 1 ? hits[0].id : null;
    };
    if (exactIndex.size === 0 && impByHosp.size === 0) return;
    for (const r of resources) {
      if (!ENCOUNTER_LINKABLE.has(r.resourceType)) continue;
      if (r.encounter || r.context) continue;
      const visitClass = visitClassByRes.get(r);
      const hosp = resourceHospital(r);
      const date = resourceDate(r);
      if (!hosp || !date) continue;
      if (r.resourceType === "MedicationRequest") {
        const vp2 = r.dispenseRequest?.validityPeriod;
        const isInpatientCourse = !!(vp2?.start && vp2?.end);
        const rxAtKey = rxIndex.get(`${hosp} ${date}`) ?? [];
        const relevant = rxAtKey.filter((e) => isInpatientCourse ? e.isInpatient : !e.isInpatient);
        if (relevant.length > 0) {
          const oc = medOrderCode(r);
          const hits = oc ? relevant.filter((e) => e.codes.has(oc)) : [];
          if (hits.length === 1) r.encounter = { reference: `Encounter/${hits[0].id}` };
          continue;
        }
      }
      const matches = [...exactIndex.get(`${hosp} ${date}`) ?? []];
      if (matches.length === 0) {
        for (const [start, end, eid] of impByHosp.get(hosp) ?? []) {
          if (start <= date && date <= end) matches.push(eid);
        }
      }
      if (matches.length === 0) {
        if (isImagingReport(r)) {
          const eid = imagingOrderMatch(r, hosp, date);
          if (eid) r.encounter = { reference: `Encounter/${eid}` };
        }
        continue;
      }
      if (matches.length === 1) {
        r.encounter = { reference: `Encounter/${matches[0]}` };
        continue;
      }
      const cands = matches.map((id) => byId.get(id)).filter(Boolean);
      if (visitClass) {
        const classHits = cands.filter((e) => {
          const c = (e.class ?? {}).code;
          return visitClass === "IMP" ? c === "IMP" : c === "AMB" || c === "EMER";
        });
        if (classHits.length === 1) {
          r.encounter = { reference: `Encounter/${classHits[0].id}` };
          continue;
        }
      }
      const vp = (r.dispenseRequest ?? {}).validityPeriod;
      if (vp && vp.start && vp.end) {
        const vs = String(vp.start).slice(0, 10);
        const ve = String(vp.end).slice(0, 10);
        const periodHits = cands.filter(
          (e) => String((e.period ?? {}).start ?? "").slice(0, 10) === vs && String((e.period ?? {}).end ?? "").slice(0, 10) === ve
        );
        if (periodHits.length === 1) {
          r.encounter = { reference: `Encounter/${periodHits[0].id}` };
          continue;
        }
      }
      const rcodes = reasonCodeSet(r);
      if (rcodes.size > 0) {
        const dxHits = cands.filter((e) => {
          const ec = reasonCodeSet(e);
          for (const x of rcodes) if (ec.has(x)) return true;
          return false;
        });
        if (dxHits.length === 1) r.encounter = { reference: `Encounter/${dxHits[0].id}` };
        continue;
      }
      const lCodes = labOrderCodes(r);
      if (lCodes.length > 0) {
        const labHits = cands.filter((e) => {
          const set = labCodesByEnc.get(e);
          return !!set && lCodes.some((c) => set.has(c));
        });
        if (labHits.length === 1) {
          r.encounter = { reference: `Encounter/${labHits[0].id}` };
        } else if (labHits.length > 1) {
          const impInSpan = labHits.filter(
            (e) => (e.class ?? {}).code === "IMP" && String((e.period ?? {}).start ?? "").slice(0, 10) <= date && date <= String((e.period ?? {}).end ?? "").slice(0, 10)
          );
          if (impInSpan.length === 1) {
            r.encounter = { reference: `Encounter/${impInSpan[0].id}` };
          }
        }
      }
      if (!r.encounter && isImagingReport(r)) {
        const eid = imagingOrderMatch(r, hosp, date);
        if (eid) r.encounter = { reference: `Encounter/${eid}` };
      }
    }
  }
  function repairDocumentReferenceEncounters(candidates, resources) {
    const encounterIds = /* @__PURE__ */ new Set();
    const exactIndex = /* @__PURE__ */ new Map();
    const impByHosp = /* @__PURE__ */ new Map();
    for (const e of candidates) {
      if (e.resourceType !== "Encounter" || !e.id) continue;
      encounterIds.add(e.id);
      const hosp = (e.serviceProvider ?? {}).display ?? "";
      const start = String((e.period ?? {}).start ?? "").slice(0, 10);
      if (!hosp || !start) continue;
      const arr = exactIndex.get(`${hosp} ${start}`) ?? [];
      arr.push(e.id);
      exactIndex.set(`${hosp} ${start}`, arr);
      if ((e.class ?? {}).code === "IMP") {
        const end = String((e.period ?? {}).end ?? "").slice(0, 10);
        if (end) {
          const list = impByHosp.get(hosp) ?? [];
          list.push([start, end, e.id]);
          impByHosp.set(hosp, list);
        }
      }
    }
    for (const r of resources) {
      if (r.resourceType !== "DocumentReference") continue;
      const ctx = r.context;
      const ref = ctx?.encounter?.[0]?.reference;
      if (!ref) continue;
      if (encounterIds.has(String(ref).replace(/^Encounter\//, ""))) continue;
      const hosp = (r.custodian ?? {}).display ?? "";
      const date = String(ctx?.period?.start ?? "").slice(0, 10);
      const matches = hosp && date ? [...exactIndex.get(`${hosp} ${date}`) ?? []] : [];
      if (matches.length === 0 && hosp && date) {
        for (const [start, end, eid] of impByHosp.get(hosp) ?? []) {
          if (start <= date && date <= end) matches.push(eid);
        }
      }
      if (matches.length === 1) {
        ctx.encounter = [{ reference: `Encounter/${matches[0]}` }];
      } else {
        ctx.encounter = void 0;
      }
    }
  }
  function resolveSexStratifiedRanges(patient, resources) {
    if (!patient) return;
    const gender = String(patient.gender ?? "").toLowerCase();
    if (gender !== "male" && gender !== "female") return;
    for (const r of resources) {
      if (r.resourceType !== "Observation") continue;
      const rrs = r.referenceRange ?? [];
      if (rrs.length < 2) continue;
      let match = null;
      for (const entry of rrs) {
        for (const ap of entry.appliesTo ?? []) {
          for (const c of ap.coding ?? []) {
            if (String(c.code ?? "").toLowerCase() === gender) {
              match = entry;
              break;
            }
          }
          if (match) break;
        }
        if (match) break;
      }
      if (!match) continue;
      r.referenceRange = [match];
    }
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/assemble.ts
  var PAGE_TYPE_ORDER = [
    "encounters",
    "observations",
    "medications",
    "conditions",
    "allergies",
    "diagnostic_reports",
    "procedures",
    "immunizations",
    "care_plans",
    "cancer_screening",
    "document_references"
  ];
  function mapPageTypeItems(pageType, items, patientId) {
    const group = GROUP_HANDLERS[pageType];
    if (group) return group(items, patientId);
    const entry = LIST_HANDLERS[pageType];
    if (entry) {
      const [fn] = entry;
      return items.filter((it) => it && typeof it === "object").map((it) => fn(it, patientId)).filter((r) => r !== null);
    }
    return null;
  }

  // ../packages/fhir-mapper/vendor/nhi-fhir-bridge-mapper/src/bundle.ts
  var FHIR_RESOURCE_ID_RE = /^[A-Za-z0-9\-.]{1,64}$/;
  function isSafeFhirRestResourceId(value) {
    return typeof value === "string" && FHIR_RESOURCE_ID_RE.test(value) && value !== "." && value !== "..";
  }
  function makeAbsoluteBundleEntry(resource, fhirBaseUrl) {
    const base = String(fhirBaseUrl ?? "").replace(/\/+$/, "");
    const parsedBase = new URL(`${base}/`);
    if (parsedBase.protocol !== "http:" && parsedBase.protocol !== "https:") {
      throw new Error("FHIR Bundle base URL must use http or https");
    }
    const resourceType = resource?.resourceType;
    const id = resource?.id;
    if (typeof resourceType !== "string" || !resourceType || typeof id !== "string" || !id) {
      throw new Error("FHIR Bundle entries require resourceType and id");
    }
    if (!isSafeFhirRestResourceId(id)) {
      throw new Error("FHIR Bundle entry id is not safe for a REST fullUrl");
    }
    return {
      fullUrl: new URL(`${resourceType}/${id}`, parsedBase).toString(),
      resource
    };
  }

  // ../packages/fhir-mapper/src/medcloud-bundle.ts
  var MEDCLOUD_FHIR_SOURCE = "https://medcloud2.nhi.gov.tw/";
  var PORTABLE_FHIR_BASE_URL = "https://cloud-wildcatch.invalid/fhir";
  var BRIDGE_NAMESPACE = "https://cloud-wildcatch.invalid/fhir";
  var SOURCE_MODULE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/source-module`;
  var SOURCE_CAPTURE_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/sid/source-capture-artifact`;
  var ADAPTER_VERSION_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/adapter-version`;
  var DATA_CLASS_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/data-class`;
  var MODULE_COMPLETENESS_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/module-completeness`;
  var PROVIDER_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/sid/medcloud-provider`;
  var MASKED_TW_IDENTIFIER_SYSTEM = `${BRIDGE_NAMESPACE}/IdentifierSystem/masked-tw-national-id`;
  var DATASET_SCOPE_TAG_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/source-dataset-scope`;
  var CAPTURED_AT_TAG_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/source-captured-at`;
  var FHIR_DATA_OPERATION_SYSTEM = "http://terminology.hl7.org/CodeSystem/v3-DataOperation";
  var FHIR_PROVENANCE_PARTICIPANT_SYSTEM = "http://terminology.hl7.org/CodeSystem/provenance-participant-type";
  var LOCAL_MEDICAL_ORDER_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-local-medical-order`;
  var NHI_DENTAL_PROGRAM_CODE_SYSTEM2 = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-nhi-dental-program-service`;
  var LOCAL_MEDICATION_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-local-medication`;
  var NHI_VIEWER_REQUEST_EXTENSION_URL = `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-nhi-viewer-request`;
  var MEDCLOUD_INGREDIENT_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-drug-ingredient`;
  var MEDCLOUD_SCREENING_RESULT_CODE_SYSTEM = `${BRIDGE_NAMESPACE}/CodeSystem/medcloud-screening-result-code`;
  var WHO_ATC_CODE_SYSTEM = "http://www.whocc.no/atc";
  var MEDCLOUD_PAGE_TYPE_ORDER = [...PAGE_TYPE_ORDER, "service_requests"];
  var NHI_MEDICAL_ORDER_CODE_RE2 = /^\d{5}[A-Z]$/;
  var NHI_DRUG_CODE_RE = /^[A-Z][A-Z0-9]{9}$/;
  var CORE_MODULE_DATASET_SCOPES = {
    IMUE0060: "/imu/api/imue0060/imue0060s02/get-data",
    IMUE0008: "/imu/api/imue0008/imue0008s02/get-data",
    IMUE0130: "/imu/api/imue0130/imue0130s02/get-data",
    IMUE0030: "/imu/api/imue0030/imue0030s02/get-data",
    IMUE0010: "/imu/api/imue0010/imue0010s02/get-data",
    IMUE0070: "/imu/api/imue0070/imue0070s02/get-data",
    IMUE0080: "/imu/api/imue0080/imue0080s02/get-data",
    IMUE0120: "/imu/api/imue0120/imue0120s01/pres-med-day",
    IMUE0140: "/imu/api/imue0140/imue0140s01/hpa-data",
    IMUE0150: "/imu/api/imue0150/imue0150s01/hpa-data"
  };
  var SUPPORTED_PAGE_TYPES = /* @__PURE__ */ new Set([
    "observations",
    "medications",
    "diagnostic_reports",
    "procedures",
    "encounters",
    "document_references",
    "service_requests"
  ]);
  var VERIFIED_UCUM_CODES = /* @__PURE__ */ new Set([
    "1",
    "%",
    "[pH]",
    "Cel",
    "mm[Hg]",
    "s",
    "min",
    "h",
    "d",
    "cm",
    "kg",
    "kg/m2",
    "fL",
    "pg",
    "g/L",
    "g/dL",
    "mg/L",
    "mg/dL",
    "ug/L",
    "ug/dL",
    "ng/L",
    "ng/mL",
    "ng/dL",
    "pg/mL",
    "mg/g",
    "ug/mg{creat}",
    "mg/(24.h)",
    "g/(24.h)",
    "mol/L",
    "mmol/L",
    "umol/L",
    "nmol/L",
    "pmol/L",
    "meq/L",
    "U/L",
    "U/mL",
    "[iU]/L",
    "[iU]/mL",
    "m[iU]/L",
    "m[iU]/mL",
    "u[iU]/L",
    "u[iU]/mL",
    "/uL",
    "10*3/uL",
    "10*6/uL",
    "/100{WBCs}",
    "mL/min/{1.73_m2}",
    "mosm/kg"
  ]);
  function sourceModuleForRecord(record) {
    const sourceModule = String(record.sourceModule ?? "").trim().toUpperCase();
    if (!Object.prototype.hasOwnProperty.call(CORE_MODULE_DATASET_SCOPES, sourceModule)) {
      throw new Error(`Unsupported record sourceModule: ${sourceModule || "(empty)"}`);
    }
    return sourceModule;
  }
  var IncompleteModuleError = class extends Error {
    modules;
    constructor(modules) {
      super("FHIR Bundle blocked because every requested module failed");
      this.name = "IncompleteModuleError";
      this.modules = modules;
    }
  };
  function requirePatientContextHash(value) {
    const normalized = String(value ?? "").trim().toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(normalized)) {
      throw new Error("patientContextHash must be a 64-character hexadecimal HMAC/hash");
    }
    return normalized;
  }
  function requireFhirInstant(value, fieldName) {
    const normalized = String(value ?? "").trim();
    const match = /^(\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])T([01]\d|2[0-3]):([0-5]\d):([0-5]\d|60)(?:\.\d+)?(Z|[+-](?:0\d|1[0-3]):[0-5]\d|[+-]14:00)$/.exec(
      normalized
    );
    if (!match) {
      throw new Error(`${fieldName} must be a FHIR R4 instant with seconds and an explicit timezone`);
    }
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
    if (day > daysInMonth) {
      throw new Error(`${fieldName} must be a valid FHIR R4 instant`);
    }
    return normalized;
  }
  function requireRecordedInstant(value) {
    return requireFhirInstant(value, "generatedAt");
  }
  function requireCoreModuleStatuses(modules) {
    const expectedCount = Object.keys(CORE_MODULE_DATASET_SCOPES).length;
    if (modules.length !== expectedCount) {
      throw new Error(`Exactly ${expectedCount} core module statuses are required`);
    }
    const statuses = /* @__PURE__ */ new Map();
    for (const module of modules) {
      const sourceModule = String(module.sourceModule ?? "").trim().toUpperCase();
      if (!Object.prototype.hasOwnProperty.call(CORE_MODULE_DATASET_SCOPES, sourceModule)) {
        throw new Error(`Unsupported core module: ${sourceModule || "(empty)"}`);
      }
      const coreModule = sourceModule;
      if (statuses.has(coreModule)) {
        throw new Error(`Duplicate core module status: ${coreModule}`);
      }
      const expectedScope = CORE_MODULE_DATASET_SCOPES[coreModule];
      if (module.datasetScope !== expectedScope) {
        throw new Error(
          `Unexpected datasetScope for ${coreModule}; expected ${expectedScope}`
        );
      }
      if (!String(module.adapterVersion ?? "").trim()) {
        throw new Error(`adapterVersion is required for ${coreModule}`);
      }
      statuses.set(coreModule, module);
    }
    for (const sourceModule of Object.keys(CORE_MODULE_DATASET_SCOPES)) {
      if (!statuses.has(sourceModule)) {
        throw new Error(`Missing core module status: ${sourceModule}`);
      }
    }
    const failed3 = [...statuses.values()].filter(
      (module) => module.completeness === "failed"
    );
    if (failed3.length === expectedCount) throw new IncompleteModuleError(failed3);
    return statuses;
  }
  function requireSourceContext(records, sourceModule, status, patientContextHash) {
    if (records.length === 0) {
      throw new Error(`Cannot establish source context for empty ${sourceModule} records`);
    }
    const capturedAtValues = /* @__PURE__ */ new Set();
    for (const [index, record] of records.entries()) {
      const recordModule = String(record.sourceModule ?? "").trim().toUpperCase();
      if (recordModule !== sourceModule) {
        throw new Error(`${sourceModule} record ${index} has mismatched sourceModule`);
      }
      if (record.datasetScope !== status.datasetScope) {
        throw new Error(`${sourceModule} record ${index} has mismatched datasetScope`);
      }
      if (record.adapterVersion !== status.adapterVersion) {
        throw new Error(`${sourceModule} record ${index} has mismatched adapterVersion`);
      }
      if (String(record.patientContextHash ?? "").trim().toLowerCase() !== patientContextHash) {
        throw new Error(`${sourceModule} record ${index} has mismatched patientContextHash`);
      }
      capturedAtValues.add(
        requireFhirInstant(String(record.capturedAt ?? ""), `${sourceModule}.capturedAt`)
      );
    }
    if (capturedAtValues.size !== 1) {
      throw new Error(`${sourceModule} records must share one capturedAt instant`);
    }
    return {
      sourceModule,
      datasetScope: status.datasetScope,
      adapterVersion: status.adapterVersion,
      capturedAt: [...capturedAtValues][0]
    };
  }
  function buildPatient(patientContextHash, identity, maskNameEnabled = true) {
    const patient = {
      resourceType: "Patient",
      id: `mc-${patientContextHash.slice(0, 32)}`,
      meta: {
        source: MEDCLOUD_FHIR_SOURCE,
        tag: [
          {
            system: DATA_CLASS_SYSTEM,
            code: "clinical-reference",
            display: "MediCloud clinical reference data; not the legal medical record"
          }
        ]
      }
    };
    if (!identity) return patient;
    const rawIdentifier = String(identity.maskedId ?? "").trim().toUpperCase();
    const maskedIdentifier = (/^[A-Z][12]\d{8}$/.test(rawIdentifier) ? `${rawIdentifier.slice(0, 6)}XXXX` : rawIdentifier).replace(/[X*＊•●．・]/g, "X");
    if (maskedIdentifier) {
      patient.identifier = [
        {
          use: "secondary",
          system: MASKED_TW_IDENTIFIER_SYSTEM,
          value: maskedIdentifier
        }
      ];
    }
    const rawName = String(identity.name ?? "").trim();
    const outputName = maskNameEnabled ? maskName(rawName) : rawName;
    if (outputName) {
      patient.name = [{ use: maskNameEnabled ? "anonymous" : "official", text: outputName }];
    }
    patient.gender = ["male", "female", "other", "unknown"].includes(identity.gender) ? identity.gender : "unknown";
    if (/^\d{4}-\d{2}-\d{2}$/.test(identity.birthDate ?? "")) {
      patient.birthDate = maskNameEnabled ? identity.birthDate?.slice(0, 4) : identity.birthDate;
    }
    return patient;
  }
  function normalizedAtcCode(value, level) {
    const code = String(value ?? "").trim().toUpperCase();
    const pattern = level === 3 ? /^[A-Z]\d{2}$/ : level === 5 ? /^[A-Z]\d{2}[A-Z]{2}$/ : /^[A-Z]\d{2}[A-Z]{2}\d{2}$/;
    return pattern.test(code) ? code : null;
  }
  function appendMedicationSourceCodings(resource, item) {
    const atcLevels = [3, 5, 7].flatMap((level) => {
      const code = normalizedAtcCode(item[`atc${level}_code`], level);
      if (!code) return [];
      const display = level === 5 ? String(item.drug_class ?? "").trim() : "";
      return [{ level, code, display }];
    });
    const chemicalSubstance = atcLevels.find((atc) => atc.level === 7);
    if (chemicalSubstance) {
      const coding = resource.medicationCodeableConcept?.coding;
      if (Array.isArray(coding)) {
        coding.push({
          system: WHO_ATC_CODE_SYSTEM,
          code: chemicalSubstance.code,
          ...chemicalSubstance.display ? { display: chemicalSubstance.display } : {}
        });
      }
    }
    const extensions = Array.isArray(resource.extension) ? resource.extension : [];
    for (const atc of atcLevels) {
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-atc-level-${atc.level}`,
        valueCoding: {
          system: WHO_ATC_CODE_SYSTEM,
          code: atc.code,
          ...atc.display ? { display: atc.display } : {}
        }
      });
    }
    const validAtcCodes = new Set(atcLevels.map((atc) => atc.code));
    const sourceDrugClassTexts = /* @__PURE__ */ new Set();
    for (const level of [3, 5, 7]) {
      const raw = String(item[`atc${level}_code`] ?? "").trim();
      if (raw && !normalizedAtcCode(raw, level) && !validAtcCodes.has(raw.toUpperCase())) {
        sourceDrugClassTexts.add(raw);
      }
    }
    const sourceDrugClassName = String(item.drug_class ?? "").trim();
    if (sourceDrugClassName && !atcLevels.some((atc) => atc.display === sourceDrugClassName)) {
      sourceDrugClassTexts.add(sourceDrugClassName);
    }
    for (const sourceText of sourceDrugClassTexts) {
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-source-drug-class`,
        valueString: sourceText
      });
    }
    const sourceFacility = String(item.hospital ?? "").trim();
    if (sourceFacility) {
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-source-facility`,
        valueReference: { display: sourceFacility }
      });
    }
    const sourceSetting = String(item.source_setting ?? "").trim();
    if (sourceSetting) {
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-source-setting`,
        valueString: sourceSetting
      });
    }
    const ingredientCode = String(item.ingredient_code ?? "").trim();
    const ingredientName = String(item.ingredient_name ?? "").trim();
    if (ingredientCode || ingredientName) {
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-drug-ingredient`,
        valueCodeableConcept: {
          ...ingredientCode ? {
            coding: [
              {
                system: MEDCLOUD_INGREDIENT_CODE_SYSTEM,
                code: ingredientCode,
                ...ingredientName ? { display: ingredientName } : {}
              }
            ]
          } : {},
          ...ingredientName ? { text: ingredientName } : {}
        }
      });
    }
    const remainingDays = typeof item.remaining_days === "number" ? item.remaining_days : Number.NaN;
    if (Number.isFinite(remainingDays) && remainingDays >= 0) {
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-prescription-remaining-days`,
        valueQuantity: {
          value: remainingDays,
          unit: "days",
          system: "http://unitsofmeasure.org",
          code: "d"
        }
      });
      const notes = Array.isArray(resource.note) ? resource.note : [];
      notes.push({ text: `\u9580\u8A3A\u85E5\u54C1\u9918\u85E5\u65E5\u6578\uFF1A${remainingDays} \u5929` });
      resource.note = notes;
    }
    if (extensions.length > 0) resource.extension = extensions;
  }
  function redactMapperNarratives(pageType, item) {
    if (pageType === "document_references") {
      return { ...item, html: redactDemographicsInText(String(item.html ?? "")) };
    }
    if (pageType === "diagnostic_reports") {
      return {
        ...item,
        conclusion: redactDemographicsInText(String(item.conclusion ?? ""))
      };
    }
    return item;
  }
  function trustedNhiViewerUrl(value) {
    if (typeof value !== "string" || value.length === 0 || value.length > 1e5) {
      return void 0;
    }
    try {
      const url = new URL(value);
      const isNhiHostname = url.hostname === "nhi.gov.tw" || url.hostname.endsWith(".nhi.gov.tw");
      if (url.protocol !== "https:" || url.port || url.username || url.password || !isNhiHostname) {
        return void 0;
      }
      return url.toString();
    } catch {
      return void 0;
    }
  }
  function trustedNhiViewerRequest(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    const request = value;
    const stringPart = (part, maxLength) => typeof part === "string" && part.length <= maxLength && !/[\u0000-\u001f\u007f@]/u.test(part) ? part : void 0;
    const iplCaseSeqNo = stringPart(request.iplCaseSeqNo, 256);
    const readPos = stringPart(request.readPos, 128);
    const fileType = stringPart(request.fileType, 128);
    const fileQty = stringPart(request.fileQty, 32);
    const feeYm = stringPart(request.feeYm, 64);
    if (request.version !== 1 || request.procId !== "IMUE0130" || !iplCaseSeqNo || readPos === void 0 || !["", "Y"].includes(String(request.ordMark ?? "invalid")) || fileType === void 0 || fileQty === void 0 || feeYm === void 0) {
      return void 0;
    }
    return {
      version: 1,
      procId: "IMUE0130",
      iplCaseSeqNo,
      readPos,
      ordMark: String(request.ordMark),
      fileType,
      fileQty,
      feeYm
    };
  }
  function nhiViewerRequestExtension(request, patientContextHash) {
    const hash = String(patientContextHash ?? "").trim().toLowerCase();
    if (!/^[a-f0-9]{64}$/u.test(hash)) return void 0;
    const nested = [
      { url: "version", valueInteger: 1 },
      { url: "proc-id", valueCode: "IMUE0130" },
      { url: "patient-context-hash", valueString: hash },
      { url: "ipl-case-seq-no", valueString: request.iplCaseSeqNo }
    ];
    const optional = [
      ["read-pos", request.readPos],
      ["ord-mark", request.ordMark],
      ["file-type", request.fileType],
      ["file-qty", request.fileQty],
      ["fee-ym", request.feeYm]
    ];
    for (const [url, value] of optional) {
      if (String(value ?? "") !== "") nested.push({ url, valueString: String(value) });
    }
    return { url: NHI_VIEWER_REQUEST_EXTENSION_URL, extension: nested };
  }
  function mapMedcloudDiagnosticReports(items, patientId) {
    const resources = [];
    for (const item of items) {
      const viewerUrl = trustedNhiViewerUrl(item.viewerUrl);
      const viewerRequest = trustedNhiViewerRequest(item.viewerRequest);
      const conclusion = String(item.conclusion ?? "").trim();
      const mappingItem = (viewerUrl || viewerRequest) && !conclusion ? { ...item, conclusion: "NHI viewer link only" } : item;
      const resource = mapDiagnosticReport(mappingItem, patientId);
      if (!resource) continue;
      if ((viewerUrl || viewerRequest) && !conclusion) delete resource.conclusion;
      if (viewerUrl) {
        const presentedForm = Array.isArray(resource.presentedForm) ? resource.presentedForm : [];
        presentedForm.push({
          contentType: "text/html",
          url: viewerUrl,
          title: `${String(item.display ?? "\u5F71\u50CF")} \u2014 \u5065\u4FDD\u5F71\u50CF\u6AA2\u8996\u5668`
        });
        resource.presentedForm = presentedForm;
      }
      if (viewerRequest) {
        const sourceRecordKey = String(item.source_record_key ?? "").trim();
        if (!sourceRecordKey) {
          throw new Error("IMUE0130 viewer request requires source_record_key");
        }
        resource.id = stableId(
          patientId,
          "diagnostic-report-viewer",
          sourceRecordKey
        );
        const extension = nhiViewerRequestExtension(viewerRequest, item.patientContextHash);
        if (extension) {
          resource.extension = [
            ...Array.isArray(resource.extension) ? resource.extension : [],
            extension
          ];
        }
      }
      resources.push(resource);
    }
    return resources;
  }
  function mapMedcloudServiceRequest(item, patientId) {
    const code = String(item.code ?? "").trim().toUpperCase();
    const display = String(item.display ?? "").trim() || code;
    const sourceRecordKey = String(item.source_record_key ?? "").trim();
    if (!code && !display) return null;
    const serviceCategory = String(item.service_category ?? "other").trim().toLowerCase();
    const serviceCategoryText = serviceCategory === "laboratory" ? "\u6AA2\u9A57\u91AB\u56D1" : serviceCategory === "imaging" ? "\u5F71\u50CF\u6AA2\u67E5\u91AB\u56D1" : "\u6AA2\u67E5\u91AB\u56D1";
    const resource = {
      resourceType: "ServiceRequest",
      id: stableId(
        patientId,
        "service-request",
        sourceRecordKey || `${code}|${String(item.date ?? "")}|${String(item.hospital ?? "")}`
      ),
      meta: { source: MEDCLOUD_FHIR_SOURCE },
      status: "unknown",
      intent: "order",
      category: [{ text: serviceCategoryText }],
      code: {
        coding: [
          {
            system: LOCAL_MEDICAL_ORDER_CODE_SYSTEM,
            code: code || display,
            display
          }
        ],
        text: display
      },
      subject: { reference: `Patient/${patientId}` }
    };
    const encounterClass = String(item.encounter_class ?? "").trim().toUpperCase();
    if (["AMB", "EMER", "IMP"].includes(encounterClass)) {
      resource.__nhiVisitClass = encounterClass;
    }
    const date = String(item.date ?? "").trim();
    const endDate = String(item.end_date ?? "").trim();
    if (date && endDate && endDate !== date) {
      resource.occurrencePeriod = { start: date, end: endDate };
    } else if (date) {
      resource.occurrenceDateTime = date;
    }
    const hospital = String(item.hospital ?? "").trim();
    if (hospital) resource.performer = [{ display: hospital }];
    const reasonCode = String(item.reason_code ?? "").trim();
    const reasonText = String(item.reason_zh ?? "").trim();
    if (reasonCode || reasonText) {
      resource.reasonCode = [
        {
          ...reasonCode ? {
            coding: [
              {
                system: ICD_10_CM,
                code: normalizeIcd10Cm(reasonCode),
                ...reasonText ? { display: reasonText } : {}
              }
            ]
          } : {},
          ...reasonText ? { text: reasonText } : {}
        }
      ];
    }
    if (typeof item.quantity === "number" && Number.isFinite(item.quantity)) {
      resource.quantityQuantity = { value: item.quantity };
    }
    return resource;
  }
  function mapStandaloneObservations(items, patientId, sourceModule) {
    const resources = [];
    for (const item of items) {
      const resource = mapObservation(item, patientId);
      if (!resource) continue;
      const sourceRecordKey = String(item.source_record_key ?? "").trim();
      if (!sourceRecordKey) {
        throw new Error(`${sourceModule} observation record requires source_record_key`);
      }
      resource.id = stableId(
        patientId,
        "standalone-observation",
        sourceModule,
        sourceRecordKey,
        String(resource.id)
      );
      const cytopathicCode = String(item.cytopathic_code ?? "").trim();
      if (cytopathicCode) {
        const extensions = Array.isArray(resource.extension) ? resource.extension : [];
        extensions.push({
          url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-screening-cytopathic-code`,
          valueCoding: {
            system: MEDCLOUD_SCREENING_RESULT_CODE_SYSTEM,
            code: cytopathicCode.replace(/\s+/g, " "),
            display: cytopathicCode
          }
        });
        resource.extension = extensions;
      }
      resources.push(resource);
    }
    return resources;
  }
  function assembleMedcloudResources(patient, input, moduleStatuses, patientContextHash, maskNameEnabled) {
    for (const [pageType, items] of Object.entries(input)) {
      if ((items?.length ?? 0) > 0 && !SUPPORTED_PAGE_TYPES.has(pageType)) {
        throw new Error(`Unsupported MediCloud mapper page type: ${pageType}`);
      }
    }
    const recordCountByModule = /* @__PURE__ */ new Map();
    for (const items of Object.values(input)) {
      for (const item of items ?? []) {
        const sourceModule = sourceModuleForRecord(item);
        recordCountByModule.set(sourceModule, (recordCountByModule.get(sourceModule) ?? 0) + 1);
      }
    }
    for (const [sourceModule, status] of moduleStatuses) {
      const recordCount = recordCountByModule.get(sourceModule) ?? 0;
      if (status.completeness === "empty" && recordCount !== 0) throw new Error(`${sourceModule} is marked empty but contains mapper records`);
      if (status.completeness === "failed" && recordCount !== 0) throw new Error(`${sourceModule} is marked failed but contains mapper records`);
      if (status.completeness === "complete" && recordCount === 0) throw new Error(`${sourceModule} is marked complete but contains no mapper records`);
    }
    const all = [patient];
    const sourceContextByResource = /* @__PURE__ */ new Map();
    for (const pageType of MEDCLOUD_PAGE_TYPE_ORDER) {
      const items = input[pageType];
      if (!items || items.length === 0) continue;
      if (pageType === "medications") {
        for (const item of items) {
          const sourceModule = sourceModuleForRecord(item);
          const status = moduleStatuses.get(sourceModule);
          const sourceRecordKey = String(item.source_record_key ?? "").trim();
          if (!sourceRecordKey) {
            throw new Error("IMUE0008 medication record requires source_record_key");
          }
          const resource = mapMedicationRequest(item, String(patient.id));
          if (!resource) continue;
          appendMedicationSourceCodings(resource, item);
          resource.id = stableId(
            patientContextHash,
            "medication-request",
            sourceRecordKey,
            String(resource.id)
          );
          all.push(resource);
          sourceContextByResource.set(
            resource,
            requireSourceContext([item], sourceModule, status, patientContextHash)
          );
        }
        continue;
      }
      const itemsByModule = /* @__PURE__ */ new Map();
      for (const item of items) {
        const sourceModule = sourceModuleForRecord(item);
        const grouped = itemsByModule.get(sourceModule) ?? [];
        grouped.push(item);
        itemsByModule.set(sourceModule, grouped);
      }
      for (const [sourceModule, moduleItems] of itemsByModule) {
        const status = moduleStatuses.get(sourceModule);
        const mappingItems = maskNameEnabled ? moduleItems.map((item) => redactMapperNarratives(pageType, item)) : moduleItems;
        const mapped = pageType === "service_requests" ? mappingItems.map((item) => mapMedcloudServiceRequest(item, String(patient.id))).filter((resource) => resource !== null) : pageType === "observations" && (sourceModule === "IMUE0140" || sourceModule === "IMUE0150") ? mapStandaloneObservations(mappingItems, String(patient.id), sourceModule) : pageType === "diagnostic_reports" && sourceModule === "IMUE0130" ? mapMedcloudDiagnosticReports(mappingItems, String(patient.id)) : mapPageTypeItems(pageType, mappingItems, String(patient.id));
        if (!mapped) continue;
        const sourceContext = requireSourceContext(moduleItems, sourceModule, status, patientContextHash);
        for (const resource of mapped) {
          all.push(resource);
          sourceContextByResource.set(resource, sourceContext);
        }
      }
    }
    const merged = dedupEncountersPreferClass(all);
    const seen = /* @__PURE__ */ new Set();
    const unique = [];
    const collapsedByModule = /* @__PURE__ */ new Map();
    for (const resource of merged) {
      const key = `${resource.resourceType}/${resource.id}`;
      if (seen.has(key)) {
        const sourceModule = sourceContextByResource.get(resource)?.sourceModule;
        if (sourceModule) {
          const collapsed = collapsedByModule.get(sourceModule) ?? [];
          collapsed.push({
            resourceType: String(resource.resourceType ?? "unknown"),
            ...resource.id ? { id: String(resource.id) } : {}
          });
          collapsedByModule.set(sourceModule, collapsed);
        }
        continue;
      }
      seen.add(key);
      unique.push(resource);
    }
    const resources = dedupProcedures(unique);
    linkEncountersInResources(resources, resources);
    repairDocumentReferenceEncounters(resources, resources);
    resolveSexStratifiedRanges(patient, resources);
    return { resources, sourceContextByResource, collapsedByModule };
  }
  function canonicalOrganizationName(display) {
    const segments = display.split(";").map((segment) => segment.trim()).filter(Boolean);
    return segments[0] ?? display.trim();
  }
  function deterministicTextCompare(left, right) {
    return left < right ? -1 : left > right ? 1 : 0;
  }
  function collectOrganizationCandidates(input) {
    const candidates = /* @__PURE__ */ new Map();
    for (const items of Object.values(input)) {
      for (const item of items ?? []) {
        const identifier = String(
          item.hospital_id ?? item.hosp_id ?? item.provider_identifier ?? ""
        ).trim();
        const display = String(item.hospital ?? item.hosp ?? "").trim();
        if (!identifier && !display) continue;
        const name = canonicalOrganizationName(display);
        const key = identifier ? `id:${identifier}` : `display:${name}`;
        const candidate = candidates.get(key) ?? {
          ...identifier ? { identifier } : {},
          names: /* @__PURE__ */ new Set(),
          aliases: /* @__PURE__ */ new Set()
        };
        if (name) candidate.names.add(name);
        if (display) candidate.aliases.add(display);
        candidates.set(key, candidate);
      }
    }
    const identified = [...candidates.values()].filter((candidate) => candidate.identifier);
    const retained = [...identified];
    for (const candidate of candidates.values()) {
      if (candidate.identifier) continue;
      const matchingIdentified = identified.filter(
        (identifiedCandidate) => [...candidate.names].some((name) => identifiedCandidate.names.has(name))
      );
      if (matchingIdentified.length === 1) {
        for (const name of candidate.names) matchingIdentified[0].names.add(name);
        for (const alias of candidate.aliases) matchingIdentified[0].aliases.add(alias);
      } else if (matchingIdentified.length === 0) {
        retained.push(candidate);
      } else {
        for (const match of matchingIdentified) {
          for (const alias of candidate.aliases) match.aliases.add(alias);
        }
      }
    }
    return retained.map((candidate) => {
      const names = [...candidate.names].sort(
        (left, right) => left.length - right.length || deterministicTextCompare(left, right)
      );
      const aliases = [...candidate.aliases].sort(deterministicTextCompare);
      return {
        ...candidate.identifier ? { identifier: candidate.identifier } : {},
        ...names[0] ? { name: names[0] } : {},
        canonicalAliases: names.slice(1),
        aliases
      };
    }).sort((left, right) => deterministicTextCompare(
      left.identifier ?? left.name ?? "",
      right.identifier ?? right.name ?? ""
    ));
  }
  function buildOrganizations(input) {
    const resources = [];
    const displayIds = /* @__PURE__ */ new Map();
    for (const candidate of collectOrganizationCandidates(input)) {
      const identity = candidate.identifier || candidate.name;
      if (!identity) continue;
      const id = stableId("nhi-medcloud", "organization", identity);
      const resource = {
        resourceType: "Organization",
        id,
        meta: { source: MEDCLOUD_FHIR_SOURCE }
      };
      if (candidate.identifier) {
        resource.identifier = [
          {
            system: PROVIDER_IDENTIFIER_SYSTEM,
            value: candidate.identifier
          }
        ];
      }
      if (candidate.name) resource.name = candidate.name;
      if (candidate.canonicalAliases.length > 0) resource.alias = candidate.canonicalAliases;
      resources.push(resource);
      for (const display of /* @__PURE__ */ new Set([
        candidate.name ?? "",
        ...candidate.canonicalAliases,
        ...candidate.aliases
      ])) {
        if (!display) continue;
        const ids = displayIds.get(display) ?? /* @__PURE__ */ new Set();
        ids.add(id);
        displayIds.set(display, ids);
      }
    }
    const displayToReference = /* @__PURE__ */ new Map();
    for (const [display, ids] of displayIds) {
      if (ids.size === 1) displayToReference.set(display, `Organization/${[...ids][0]}`);
    }
    return { resources, displayToReference };
  }
  function linkOrganizations(resources, displayToReference) {
    const linkReference = (candidate) => {
      if (!candidate || typeof candidate !== "object") return;
      const target = candidate;
      if (typeof target.reference === "string" && target.reference) return;
      const display = String(target.display ?? "").trim();
      if (!display) return;
      const reference = displayToReference.get(display);
      if (reference) target.reference = reference;
    };
    for (const resource of resources) {
      if (Array.isArray(resource.performer)) {
        for (const performer of resource.performer) {
          linkReference(performer);
          linkReference(performer?.actor);
        }
      }
      if (Array.isArray(resource.extension)) {
        for (const extension of resource.extension) linkReference(extension?.valueReference);
      }
      if (resource.resourceType === "Encounter") linkReference(resource.serviceProvider);
      if (resource.resourceType === "DocumentReference") linkReference(resource.custodian);
    }
  }
  function clinicalDay(resource) {
    const value = resource.resourceType === "ServiceRequest" ? resource.occurrenceDateTime ?? resource.occurrencePeriod?.start : resource.effectiveDateTime ?? resource.effectivePeriod?.start;
    return typeof value === "string" ? value.slice(0, 10) : "";
  }
  function clinicalFacilityKey(resource) {
    for (const performer of resource.performer ?? []) {
      if (!performer || typeof performer !== "object") continue;
      const reference = String(performer.reference ?? "").trim();
      if (reference.startsWith("Organization/")) return `reference:${reference}`;
      const display = String(performer.display ?? "").trim();
      if (display) return `display:${display}`;
    }
    return "";
  }
  function sourceMedicalOrderCodes(resource) {
    const codes = /* @__PURE__ */ new Set();
    for (const coding of resource.code?.coding ?? []) {
      if (coding?.system !== NHI_MEDICAL_ORDER_CODE && coding?.system !== LOCAL_MEDICAL_ORDER_CODE_SYSTEM && coding?.system !== HIS_LOCAL_REPORT_CODE) continue;
      const code = String(coding.code ?? "").trim().toUpperCase();
      if (hasReasonableNhiMedicalOrderCode2(code)) codes.add(code);
    }
    return [...codes];
  }
  function orderResultLookupKeys(resource) {
    const day = clinicalDay(resource);
    const facility = clinicalFacilityKey(resource);
    if (!day || !facility) return [];
    return sourceMedicalOrderCodes(resource).map((code) => `${facility}|${day}|${code}`);
  }
  function isLaboratoryResult(resource) {
    if (resource.resourceType !== "Observation" && resource.resourceType !== "DiagnosticReport") {
      return false;
    }
    return (resource.category ?? []).some(
      (category) => (category.coding ?? []).some((coding) => {
        const code = String(coding.code ?? "").trim().toLowerCase();
        return code === "laboratory" || code === "lab";
      })
    );
  }
  function linkResultServiceRequests(resources, sourceContextByResource) {
    const requestsByKey = /* @__PURE__ */ new Map();
    for (const resource of resources) {
      if (resource.resourceType !== "ServiceRequest" || !resource.id || sourceContextByResource.get(resource)?.sourceModule !== "IMUE0010") continue;
      const reference = `ServiceRequest/${resource.id}`;
      for (const key of orderResultLookupKeys(resource)) {
        const references = requestsByKey.get(key) ?? /* @__PURE__ */ new Set();
        references.add(reference);
        requestsByKey.set(key, references);
      }
    }
    for (const resource of resources) {
      const sourceModule = sourceContextByResource.get(resource)?.sourceModule;
      const isLabResult = sourceModule === "IMUE0060" && isLaboratoryResult(resource);
      const isTextReport = sourceModule === "IMUE0130" && resource.resourceType === "DiagnosticReport";
      if (!isLabResult && !isTextReport) continue;
      const uniqueMatches = /* @__PURE__ */ new Set();
      for (const key of orderResultLookupKeys(resource)) {
        const candidates = requestsByKey.get(key);
        if (candidates?.size === 1) uniqueMatches.add([...candidates][0]);
      }
      if (uniqueMatches.size === 0) continue;
      const basedOn = Array.isArray(resource.basedOn) ? resource.basedOn : [];
      const existing = new Set(
        basedOn.map((reference) => String(reference?.reference ?? "")).filter(Boolean)
      );
      for (const reference of uniqueMatches) {
        if (existing.has(reference)) continue;
        basedOn.push({ reference });
        existing.add(reference);
      }
      resource.basedOn = basedOn;
    }
  }
  function isClinicalResource(resource) {
    return resource.resourceType === "Observation" || resource.resourceType === "MedicationRequest" || resource.resourceType === "DiagnosticReport" || resource.resourceType === "Procedure" || resource.resourceType === "Encounter" || resource.resourceType === "DocumentReference" || resource.resourceType === "ServiceRequest";
  }
  function buildNhiDentalProgramCodeSystem() {
    return {
      resourceType: "CodeSystem",
      id: "medcloud-nhi-dental-program-service",
      url: NHI_DENTAL_PROGRAM_CODE_SYSTEM2,
      version: "2024-03-01",
      name: "MedcloudNhiDentalProgramService",
      title: "MediCloud NHI dental care program service codes",
      status: "active",
      experimental: true,
      publisher: "medcloud2-FHIR-bridge",
      description: "Bridge terminology for NHI dental service codes used by dental care programs after their removal from the general medical-service payment standard.",
      caseSensitive: true,
      content: "complete",
      concept: [
        { code: "91090C", display: "\u9AD8\u98A8\u96AA\u75BE\u75C5\u60A3\u8005\u7259\u7D50\u77F3\u6E05\u9664-\u5168\u53E3" },
        { code: "P7301C", display: "\u9AD8\u9F72\u9F52\u7387\u60A3\u8005\u6C1F\u5316\u7269\u6CBB\u7642" },
        { code: "P7302C", display: "\u9F72\u9F52\u7D93\u9A57\u4E4B\u9AD8\u98A8\u96AA\u60A3\u8005\u6C1F\u5316\u7269\u6CBB\u7642" }
      ]
    };
  }
  function hasReasonableNhiMedicalOrderCode2(value) {
    return NHI_MEDICAL_ORDER_CODE_RE2.test(String(value ?? "").trim().toUpperCase());
  }
  function hasReasonableNhiDrugCode(value) {
    return NHI_DRUG_CODE_RE.test(String(value ?? "").trim().toUpperCase());
  }
  var AUDITED_NHI_PANEL_MEMBER_LOINCS = {
    // 09015C bills serum creatinine. Taiwan LIS rows piggyback calculated eGFR
    // under that order; the formula-bearing row text selects the LOINC upstream.
    "09015C": /* @__PURE__ */ new Set(["62238-1", "77147-7"])
  };
  function stripUnauditedLoincCodings(value) {
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      value.forEach(stripUnauditedLoincCodings);
      return;
    }
    const object = value;
    if (Array.isArray(object.coding)) {
      const auditedLoincs = /* @__PURE__ */ new Set();
      for (const coding of object.coding) {
        if (coding?.system === NHI_MEDICAL_ORDER_CODE && hasReasonableNhiMedicalOrderCode2(coding.code)) {
          const normalizedCode = String(coding.code).trim().toUpperCase();
          const audited = NHI_TO_LOINC[normalizedCode];
          if (audited) auditedLoincs.add(audited);
          AUDITED_NHI_PANEL_MEMBER_LOINCS[normalizedCode]?.forEach((loinc) => auditedLoincs.add(loinc));
        }
      }
      let removedLoinc = false;
      const filtered = object.coding.filter((coding) => {
        if (coding?.system !== LOINC) return true;
        const keep = auditedLoincs.has(String(coding.code ?? ""));
        if (!keep) removedLoinc = true;
        return keep;
      });
      if (filtered.length > 0) object.coding = filtered;
      else delete object.coding;
      if (removedLoinc) {
        const sourceDisplay = filtered.find(
          (coding) => coding?.system === HIS_LOCAL_LAB_CODE && typeof coding?.display === "string"
        )?.display ?? filtered.find(
          (coding) => coding?.system !== LOINC && typeof coding?.display === "string"
        )?.display;
        if (sourceDisplay) object.text = sourceDisplay;
      }
    }
    Object.values(object).forEach(stripUnauditedLoincCodings);
  }
  function decorateClinicalResource(resource, sourceModule, adapterVersion2) {
    if (resource.resourceType === "MedicationRequest" || resource.resourceType === "Observation" || resource.resourceType === "DiagnosticReport") {
      resource.status = "unknown";
    }
    if (resource.resourceType === "Procedure" && sourceModule !== "IMUE0030") {
      resource.status = "unknown";
    }
    if (resource.resourceType === "Procedure" && typeof resource.__nhiSourceQuantity === "number" && Number.isFinite(resource.__nhiSourceQuantity)) {
      const extensions = Array.isArray(resource.extension) ? resource.extension : [];
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-procedure-quantity`,
        valueQuantity: { value: resource.__nhiSourceQuantity }
      });
      resource.extension = extensions;
      delete resource.__nhiSourceQuantity;
    }
    if ((resource.resourceType === "Observation" || resource.resourceType === "DiagnosticReport") && typeof resource.__nhiReportInstanceTime === "string" && resource.__nhiReportInstanceTime) {
      const extensions = Array.isArray(resource.extension) ? resource.extension : [];
      extensions.push({
        url: `${BRIDGE_NAMESPACE}/StructureDefinition/medcloud-source-report-instance-time`,
        valueString: resource.__nhiReportInstanceTime
      });
      resource.extension = extensions;
      delete resource.__nhiReportInstanceTime;
    }
    if (resource.resourceType === "MedicationRequest") {
      resource.reportedBoolean = true;
      delete resource.category;
      delete resource.requester;
      if (resource.dispenseRequest && typeof resource.dispenseRequest === "object") {
        delete resource.dispenseRequest.validityPeriod;
        if (Object.keys(resource.dispenseRequest).length === 0) {
          delete resource.dispenseRequest;
        }
      }
    }
    for (const field of ["effectiveDateTime", "authoredOn", "performedDateTime"]) {
      const value = resource[field];
      if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}T00:00:00\+08:00$/.test(value)) {
        resource[field] = value.slice(0, 10);
      }
    }
    if (resource.resourceType === "DiagnosticReport") delete resource.issued;
    const quantity = resource.valueQuantity;
    if (quantity?.system === "http://unitsofmeasure.org" && typeof quantity.code === "string" && !VERIFIED_UCUM_CODES.has(quantity.code)) {
      delete quantity.system;
      delete quantity.code;
    }
    if (resource.resourceType === "Observation" || resource.resourceType === "DiagnosticReport") {
      stripUnauditedLoincCodings(resource);
    }
    const rewriteCodingSystems = (value) => {
      if (!value || typeof value !== "object") return;
      if (Array.isArray(value)) {
        value.forEach(rewriteCodingSystems);
        return;
      }
      const object = value;
      if (typeof object.system === "string") {
        if (typeof object.code === "string" && /^(?:SYN-|synthetic)/i.test(object.code)) {
          object.system = `${BRIDGE_NAMESPACE}/CodeSystem/synthetic-code`;
        } else if (object.system === NHI_MEDICAL_ORDER_CODE && !hasReasonableNhiMedicalOrderCode2(object.code)) {
          object.system = LOCAL_MEDICAL_ORDER_CODE_SYSTEM;
        } else if (object.system === NHI_DRUG_CODE && !hasReasonableNhiDrugCode(object.code)) {
          object.system = LOCAL_MEDICATION_CODE_SYSTEM;
        } else if (object.system.startsWith("https://nhi-fhir-bridge.local/")) {
          object.system = object.system.replace(
            "https://nhi-fhir-bridge.local",
            `${BRIDGE_NAMESPACE}/upstream-local`
          );
        } else if (object.system.startsWith("http://nhi-fhir-bridge/")) {
          object.system = object.system.replace("http://nhi-fhir-bridge", BRIDGE_NAMESPACE);
        }
      }
      Object.values(object).forEach(rewriteCodingSystems);
    };
    rewriteCodingSystems(resource);
    const previousMeta = resource.meta && typeof resource.meta === "object" ? resource.meta : {};
    delete previousMeta.versionId;
    const previousTags = Array.isArray(previousMeta.tag) ? previousMeta.tag : [];
    resource.meta = {
      ...previousMeta,
      source: MEDCLOUD_FHIR_SOURCE,
      tag: [
        ...previousTags,
        { system: SOURCE_MODULE_SYSTEM, code: sourceModule.toLowerCase() },
        { system: ADAPTER_VERSION_SYSTEM, code: adapterVersion2 },
        { system: DATA_CLASS_SYSTEM, code: "clinical-reference" }
      ]
    };
  }
  function buildProvenance(target, sourceContext, patientContextHash, runId, recorded) {
    const sourceCaptureOpaqueKey = stableId(
      patientContextHash,
      "source-capture-artifact",
      sourceContext.sourceModule,
      sourceContext.datasetScope,
      sourceContext.capturedAt
    );
    return {
      resourceType: "Provenance",
      id: stableId(
        patientContextHash,
        "provenance",
        runId,
        String(target.resourceType),
        String(target.id),
        sourceContext.adapterVersion,
        sourceCaptureOpaqueKey
      ),
      meta: {
        source: MEDCLOUD_FHIR_SOURCE,
        tag: [
          { system: SOURCE_MODULE_SYSTEM, code: sourceContext.sourceModule.toLowerCase() },
          { system: ADAPTER_VERSION_SYSTEM, code: sourceContext.adapterVersion },
          {
            system: DATASET_SCOPE_TAG_SYSTEM,
            code: stableId(sourceContext.sourceModule, sourceContext.datasetScope),
            display: sourceContext.datasetScope
          },
          {
            system: CAPTURED_AT_TAG_SYSTEM,
            code: sourceContext.capturedAt,
            display: "Source captured at"
          }
        ]
      },
      target: [{ reference: `${target.resourceType}/${target.id}` }],
      recorded,
      activity: {
        coding: [{ system: FHIR_DATA_OPERATION_SYSTEM, code: "CREATE", display: "create" }],
        text: `Transform ${sourceContext.sourceModule} reference data to FHIR R4`
      },
      agent: [
        {
          type: {
            coding: [
              {
                system: FHIR_PROVENANCE_PARTICIPANT_SYSTEM,
                code: "assembler",
                display: "Assembler"
              }
            ],
            text: "assembler"
          },
          // Keep transformation authorship in Provenance without emitting a
          // top-level Device. Downstream clinical summaries commonly interpret
          // every Device resource as equipment used by the patient.
          who: { display: "\u96F2\u7AEF\u61F7\u723E\u6293\u6293" }
        }
      ],
      entity: [
        {
          role: "source",
          what: {
            identifier: {
              system: SOURCE_CAPTURE_IDENTIFIER_SYSTEM,
              value: sourceCaptureOpaqueKey
            },
            display: `${sourceContext.sourceModule} capture artifact from ${sourceContext.datasetScope}`
          }
        }
      ]
    };
  }
  function resourceCounts(resources) {
    const counts = {};
    for (const resource of resources) {
      const type = String(resource.resourceType ?? "Unknown");
      counts[type] = (counts[type] ?? 0) + 1;
    }
    return counts;
  }
  function collectReferences(value, path = "$", out = []) {
    if (!value || typeof value !== "object") return out;
    if (Array.isArray(value)) {
      value.forEach((item, index) => collectReferences(item, `${path}[${index}]`, out));
      return out;
    }
    for (const [key, child] of Object.entries(value)) {
      const childPath = `${path}.${key}`;
      if (key === "reference" && typeof child === "string") out.push({ path: childPath, value: child });
      else collectReferences(child, childPath, out);
    }
    return out;
  }
  function collectFhirJsonStructureIssues(value, path, issues) {
    if (typeof value === "number" && !Number.isFinite(value)) {
      issues.push({
        code: "non-finite-number",
        message: "FHIR JSON numbers must be finite",
        path
      });
      return;
    }
    if (value === null) {
      issues.push({
        code: "null-element",
        message: "FHIR JSON elements must be omitted instead of null",
        path
      });
      return;
    }
    if (typeof value === "string" && value.length === 0) {
      issues.push({
        code: "empty-string",
        message: "FHIR primitive string values must not be empty",
        path
      });
      return;
    }
    if (Array.isArray(value)) {
      if (value.length === 0) {
        issues.push({
          code: "empty-array",
          message: "FHIR repeating elements must be omitted instead of emitted as an empty array",
          path
        });
        return;
      }
      value.forEach(
        (item, index) => collectFhirJsonStructureIssues(item, `${path}[${index}]`, issues)
      );
      return;
    }
    if (!value || typeof value !== "object") return;
    if (Object.keys(value).length === 0) {
      issues.push({
        code: "empty-object",
        message: "FHIR elements must contain a value, child property, or extension",
        path
      });
      return;
    }
    for (const [key, child] of Object.entries(value)) {
      collectFhirJsonStructureIssues(child, `${path}.${key}`, issues);
    }
  }
  function validateMedcloudBundle(bundle) {
    const issues = [];
    if (bundle.resourceType !== "Bundle" || bundle.type !== "collection") {
      issues.push({ code: "bundle-shape", message: "Expected a FHIR collection Bundle" });
    }
    const entries = Array.isArray(bundle.entry) ? bundle.entry : [];
    const resources = entries.map((entry) => entry?.resource).filter(Boolean);
    const keys = /* @__PURE__ */ new Set();
    const identityFirstIndex = /* @__PURE__ */ new Map();
    const fullUrlFirstIndex = /* @__PURE__ */ new Map();
    const patients = resources.filter((resource) => resource.resourceType === "Patient");
    if (patients.length !== 1) {
      issues.push({ code: "patient-isolation", message: `Expected one Patient, found ${patients.length}` });
    }
    for (const [index, entry] of entries.entries()) {
      const resource = entry?.resource;
      collectFhirJsonStructureIssues(resource, `$.entry[${index}].resource`, issues);
      if (!resource?.resourceType || !resource?.id) {
        issues.push({ code: "resource-identity", message: "Bundle entry lacks resourceType/id", path: `$.entry[${index}]` });
      } else {
        const key = `${resource.resourceType}/${resource.id}`;
        const firstIndex = identityFirstIndex.get(key);
        if (firstIndex !== void 0) {
          issues.push({
            code: "duplicate-resource-identity",
            message: `Duplicate resource identity ${key}; first seen at entry ${firstIndex}`,
            path: `$.entry[${index}].resource`
          });
        } else {
          identityFirstIndex.set(key, index);
          keys.add(key);
        }
      }
      const fullUrl = String(entry?.fullUrl ?? "");
      if (fullUrl) {
        const firstIndex = fullUrlFirstIndex.get(fullUrl);
        if (firstIndex !== void 0) {
          issues.push({
            code: "duplicate-full-url",
            message: `Duplicate Bundle.entry.fullUrl; first seen at entry ${firstIndex}`,
            path: `$.entry[${index}].fullUrl`
          });
        } else {
          fullUrlFirstIndex.set(fullUrl, index);
        }
      }
      try {
        const url = new URL(fullUrl);
        if (url.protocol !== "http:" && url.protocol !== "https:") {
          throw new Error("not exact HTTP(S)");
        }
        if (resource?.resourceType && resource?.id) {
          const expectedFullUrl = new URL(
            `${resource.resourceType}/${resource.id}`,
            `${PORTABLE_FHIR_BASE_URL}/`
          ).toString();
          if (fullUrl !== expectedFullUrl) {
            issues.push({
              code: "full-url-identity",
              message: `Bundle entry fullUrl does not match ${resource.resourceType}/${resource.id}`,
              path: `$.entry[${index}].fullUrl`
            });
          }
        }
      } catch {
        issues.push({ code: "full-url", message: "Bundle entry fullUrl must be absolute", path: `$.entry[${index}].fullUrl` });
      }
    }
    for (const reference of collectReferences(resources)) {
      if (reference.value.startsWith("#")) continue;
      if (/^[A-Za-z][A-Za-z0-9+.-]*:/.test(reference.value)) {
        try {
          const url = new URL(reference.value);
          if (url.protocol !== "http:" && url.protocol !== "https:") {
            throw new Error("unsupported reference protocol");
          }
        } catch {
          issues.push({ code: "invalid-reference", message: `Invalid absolute reference: ${reference.value}`, path: reference.path });
        }
        continue;
      }
      const localMatch = /^([A-Z][A-Za-z0-9]*)\/([A-Za-z0-9.-]{1,64})(?:\/_history\/[A-Za-z0-9.-]{1,64})?$/.exec(
        reference.value
      );
      if (!localMatch) {
        issues.push({ code: "invalid-reference", message: `Malformed local reference: ${reference.value}`, path: reference.path });
        continue;
      }
      const localKey = `${localMatch[1]}/${localMatch[2]}`;
      if (!keys.has(localKey)) {
        issues.push({ code: "broken-reference", message: `Unresolved local reference: ${reference.value}`, path: reference.path });
      }
    }
    const patientKey = patients[0] ? `Patient/${patients[0].id}` : null;
    if (patientKey) {
      for (const resource of resources) {
        const subject = resource?.subject?.reference ?? resource?.patient?.reference;
        if (typeof subject === "string" && subject.startsWith("Patient/") && subject !== patientKey) {
          issues.push({ code: "patient-isolation", message: `Resource references another patient: ${subject}` });
        }
      }
    }
    const provenanceTargets = new Set(
      resources.filter((resource) => resource.resourceType === "Provenance").flatMap((resource) => resource.target ?? []).map((target) => target?.reference).filter(Boolean)
    );
    for (const [index, resource] of resources.entries()) {
      if (!isClinicalResource(resource)) continue;
      const key = `${resource.resourceType}/${resource.id}`;
      if (!provenanceTargets.has(key)) {
        issues.push({
          code: "provenance-coverage",
          message: `Missing Provenance for ${key}`,
          path: `$.entry[${index}].resource`
        });
      }
    }
    return { valid: issues.length === 0, issues };
  }
  var MAX_BUNDLE_REPAIR_PASSES = 8;
  var UNRECOVERABLE_ISSUE_CODES = /* @__PURE__ */ new Set(["bundle-shape", "patient-isolation"]);
  var QUARANTINE_PROTECTED_RESOURCE_TYPES = /* @__PURE__ */ new Set(["Patient"]);
  function entryIndexFromIssuePath(path) {
    if (!path) return void 0;
    const match = /^\$(?:\.entry)?\[(\d+)\]/.exec(path);
    if (!match) return void 0;
    return Number(match[1]);
  }
  function resolveQuarantinedResources(issues, resources) {
    const quarantine = /* @__PURE__ */ new Map();
    for (const issue of issues) {
      if (UNRECOVERABLE_ISSUE_CODES.has(issue.code)) return void 0;
      const index = entryIndexFromIssuePath(issue.path);
      if (index === void 0) return void 0;
      const resource = resources[index];
      if (!resource) return void 0;
      if (QUARANTINE_PROTECTED_RESOURCE_TYPES.has(String(resource.resourceType ?? ""))) {
        return void 0;
      }
      const codes = quarantine.get(resource) ?? /* @__PURE__ */ new Set();
      codes.add(issue.code);
      quarantine.set(resource, codes);
    }
    return quarantine.size > 0 ? quarantine : void 0;
  }
  function pruneOrphanedProvenances(resources) {
    const survivingKeys = new Set(
      resources.filter((resource) => resource.resourceType && resource.id).map((resource) => `${resource.resourceType}/${resource.id}`)
    );
    return resources.filter((resource) => {
      if (resource.resourceType !== "Provenance") return true;
      const targets = Array.isArray(resource.target) ? resource.target : [];
      return targets.every((target) => survivingKeys.has(String(target?.reference ?? "")));
    });
  }
  function buildMedcloudBundle(input) {
    const patientContextHash = requirePatientContextHash(input.patientContextHash);
    const generatedAt = requireRecordedInstant(input.generatedAt);
    const runId = String(input.runId ?? "").trim();
    if (!runId) throw new Error("runId is required");
    const moduleStatuses = requireCoreModuleStatuses(input.modules);
    const maskNameEnabled = input.maskNameEnabled !== false;
    const patient = buildPatient(patientContextHash, input.patient, maskNameEnabled);
    const { resources: mapped, sourceContextByResource, collapsedByModule } = assembleMedcloudResources(
      patient,
      input.mapperInput,
      moduleStatuses,
      patientContextHash,
      maskNameEnabled
    );
    const { resources: organizations, displayToReference } = buildOrganizations(input.mapperInput);
    linkOrganizations(mapped, displayToReference);
    linkResultServiceRequests(mapped, sourceContextByResource);
    const provenances = [];
    for (const resource of mapped.slice(1)) {
      if (!isClinicalResource(resource)) continue;
      const sourceContext = sourceContextByResource.get(resource);
      if (!sourceContext) {
        throw new Error(`Missing source context for ${resource.resourceType}/${resource.id}`);
      }
      decorateClinicalResource(
        resource,
        sourceContext.sourceModule,
        sourceContext.adapterVersion
      );
      provenances.push(
        buildProvenance(
          resource,
          sourceContext,
          patientContextHash,
          runId,
          generatedAt
        )
      );
    }
    const includesNhiDentalProgramCode = mapped.some(
      (resource) => resource.code?.coding?.some(
        (coding) => coding.system === NHI_DENTAL_PROGRAM_CODE_SYSTEM2
      )
    );
    const expectedViewerRequestCount = (input.mapperInput.diagnostic_reports ?? []).filter(
      (item) => String(item.sourceModule ?? "").trim().toUpperCase() === "IMUE0130" && trustedNhiViewerRequest(item.viewerRequest) !== void 0
    ).length;
    const emittedViewerRequestCount = mapped.reduce(
      (count, resource) => count + (resource.resourceType === "DiagnosticReport" ? (Array.isArray(resource.extension) ? resource.extension : []).filter(
        (extension) => extension.url === NHI_VIEWER_REQUEST_EXTENSION_URL
      ).length : 0),
      0
    );
    if (emittedViewerRequestCount !== expectedViewerRequestCount) {
      throw new Error(
        `Viewer descriptor integrity check failed: expected ${expectedViewerRequestCount}, emitted ${emittedViewerRequestCount}`
      );
    }
    const workingModules = input.modules.map((module) => ({ ...module }));
    const statusBySourceModule = new Map(
      workingModules.map((module) => [
        String(module.sourceModule).trim().toUpperCase(),
        module
      ])
    );
    const initialResourceCountByModule = /* @__PURE__ */ new Map();
    for (const resource of mapped.slice(1)) {
      const context = sourceContextByResource.get(resource);
      if (!context) continue;
      initialResourceCountByModule.set(
        context.sourceModule,
        (initialResourceCountByModule.get(context.sourceModule) ?? 0) + 1
      );
    }
    const droppedResources = [];
    for (const [sourceModule, collapsedResources] of collapsedByModule) {
      const status = statusBySourceModule.get(sourceModule);
      const collapsed = collapsedResources.length;
      if (!status || collapsed <= 0) continue;
      status.droppedResourceCount = (status.droppedResourceCount ?? 0) + collapsed;
      status.warningCount = (status.warningCount ?? 0) + collapsed;
      if (status.completeness === "complete" || status.completeness === "empty") {
        status.completeness = "partial";
      }
      for (const resource of collapsedResources) {
        droppedResources.push({
          ...resource,
          sourceModule,
          issueCodes: ["duplicate-resource-identity"]
        });
      }
    }
    let workingResources = [
      mapped[0],
      ...organizations,
      ...includesNhiDentalProgramCode ? [buildNhiDentalProgramCodeSystem()] : [],
      ...mapped.slice(1),
      ...provenances
    ];
    let bundle;
    let validation;
    for (let repairPass = 0; ; repairPass++) {
      const hasIncompleteModule = workingModules.some(
        (module) => module.completeness === "partial" || module.completeness === "failed"
      );
      bundle = {
        resourceType: "Bundle",
        id: stableId(String(patient.id), "bundle", runId),
        type: "collection",
        timestamp: generatedAt,
        meta: {
          source: MEDCLOUD_FHIR_SOURCE,
          tag: [
            { system: DATA_CLASS_SYSTEM, code: "clinical-reference" },
            {
              system: DATA_CLASS_SYSTEM,
              code: hasIncompleteModule ? "partial-for-requested-modules" : "complete-for-requested-modules"
            },
            ...Object.keys(CORE_MODULE_DATASET_SCOPES).map(
              (sourceModule) => ({
                system: SOURCE_MODULE_SYSTEM,
                code: sourceModule.toLowerCase()
              })
            ),
            ...workingModules.map((module) => ({
              system: MODULE_COMPLETENESS_SYSTEM,
              code: `${module.sourceModule.toLowerCase()}-${module.completeness}`,
              display: `${module.sourceModule} ${module.completeness}`
            }))
          ]
        },
        entry: workingResources.map((resource) => makeAbsoluteBundleEntry(resource, PORTABLE_FHIR_BASE_URL))
      };
      validation = validateMedcloudBundle(bundle);
      if (validation.valid) break;
      const quarantine = repairPass < MAX_BUNDLE_REPAIR_PASSES ? resolveQuarantinedResources(validation.issues, workingResources) : void 0;
      if (!quarantine) {
        throw new Error(`Generated Bundle failed integrity checks: ${validation.issues.map((issue) => issue.code).join(", ")}`);
      }
      for (const [resource, issueCodes] of quarantine) {
        const context = sourceContextByResource.get(resource);
        droppedResources.push({
          resourceType: String(resource.resourceType ?? "unknown"),
          ...resource.id ? { id: String(resource.id) } : {},
          ...context ? { sourceModule: context.sourceModule } : {},
          issueCodes: [...issueCodes].sort()
        });
        if (!context) continue;
        const status = statusBySourceModule.get(context.sourceModule);
        if (!status) continue;
        status.droppedResourceCount = (status.droppedResourceCount ?? 0) + 1;
        status.warningCount = (status.warningCount ?? 0) + 1;
        const initialCount = initialResourceCountByModule.get(context.sourceModule) ?? 0;
        if (initialCount > 0 && status.droppedResourceCount >= initialCount) {
          status.completeness = "failed";
        } else if (status.completeness === "complete" || status.completeness === "empty") {
          status.completeness = "partial";
        }
      }
      workingResources = pruneOrphanedProvenances(
        workingResources.filter((resource) => !quarantine.has(resource))
      );
    }
    const failedAfterRepair = workingModules.filter((module) => module.completeness === "failed");
    if (failedAfterRepair.length === workingModules.length) {
      throw new IncompleteModuleError(failedAfterRepair);
    }
    for (const dropped of droppedResources) {
      if (!dropped.sourceModule) continue;
      const status = statusBySourceModule.get(dropped.sourceModule);
      if (!status) continue;
      status.issueCodes = [.../* @__PURE__ */ new Set([
        ...status.issueCodes ?? [],
        ...dropped.issueCodes
      ])].sort();
    }
    return {
      bundle,
      summary: {
        resourceCounts: resourceCounts(workingResources),
        moduleStatuses: workingModules.map((module) => ({ ...module })),
        warningCount: workingModules.reduce((sum, module) => sum + (module.warningCount ?? 0), 0),
        droppedResourceCount: droppedResources.length,
        droppedResources,
        validation
      }
    };
  }

  // src/source/medcloud.ts
  var MEDCLOUD_ORIGIN = "https://medcloud2.nhi.gov.tw";
  var MEDCLOUD_MODULES = MEDCLOUD_CLINICAL_MODULES;
  var MediCloudAcquisitionError = class extends Error {
    constructor(code, sourceModule) {
      super(code);
      this.code = code;
      this.sourceModule = sourceModule;
      this.name = "MediCloudAcquisitionError";
    }
    code;
    sourceModule;
  };
  var PATIENT_CONTEXT_HMAC_KEY = "cloud-wildcatch:patient-context-hmac-key-v1";
  var patientContextHmacKeyPromise = null;
  function randomPatientContextHmacKey() {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/u, "");
  }
  async function readOrCreatePatientContextHmacKey() {
    const stored = await chrome.storage.session.get(PATIENT_CONTEXT_HMAC_KEY);
    const existing = stored[PATIENT_CONTEXT_HMAC_KEY];
    if (typeof existing === "string" && /^[A-Za-z0-9_-]{43}$/u.test(existing)) {
      return existing;
    }
    const created = randomPatientContextHmacKey();
    await chrome.storage.session.set({ [PATIENT_CONTEXT_HMAC_KEY]: created });
    return created;
  }
  async function getPatientContextHmacKey() {
    if (!patientContextHmacKeyPromise) {
      const create = () => readOrCreatePatientContextHmacKey();
      const pending = typeof navigator !== "undefined" && navigator.locks ? navigator.locks.request(
        PATIENT_CONTEXT_HMAC_KEY,
        create
      ) : create();
      patientContextHmacKeyPromise = pending;
      void pending.catch(() => {
        patientContextHmacKeyPromise = null;
      });
    }
    return patientContextHmacKeyPromise;
  }
  async function probeMediCloudPatientInPage(origin, patientContextHmacKey) {
    if (location.origin !== origin || !location.pathname.startsWith("/imu/")) {
      return { ok: false, code: "NOT_MEDCLOUD" };
    }
    const readPatientIdentity = () => {
      let roots = Array.from(document.querySelectorAll(".member-info"));
      if (roots.length === 0) {
        roots = Array.from(document.querySelectorAll(
          ".patient-info, .patient-data, [class*='memberInfo'], [class*='patient-info']"
        ));
      }
      const candidates = roots.slice(0, 50).flatMap((root) => {
        const text = (value) => (value ?? "").replace(/\s+/g, " ").trim();
        const field = (selector) => text(root.querySelector(selector)?.textContent);
        const rootText = text(root.textContent);
        const idText = field(".idno") || rootText;
        const fullId2 = /\b[A-Z][12]\d{8}\b/i.exec(idText)?.[0] ?? "";
        const maskedId2 = /\b[A-Z][12]\d{2}[Xx*•●．・]{2,4}\d{2,4}/i.exec(idText)?.[0] ?? "";
        const idToken = (fullId2 || maskedId2).toUpperCase().replace(/[Xx*•●．・]/g, "X");
        if (!idToken) return [];
        const structuredName = field(".name");
        const name = structuredName ? text(structuredName.replace(/^(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*/, "")) : /(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*([^\s｜|,，;；]{2,8})/.exec(rootText)?.[1] ?? "";
        const structuredBirth = field(".birth");
        const birth2 = structuredBirth ? text(structuredBirth.replace(/^(?:出生年月日|出生日期|生日)\s*[:：]?\s*/, "")) : /(?:出生年月日|出生日期|生日)\s*[:：]?\s*(\d{2,4}[\/.\-年]\d{1,2}[\/.\-月]\d{1,2})/.exec(rootText)?.[1] ?? "";
        const structuredSex = field(".sex");
        const sex = structuredSex ? text(structuredSex.replace(/^(?:生理性別|性別)\s*[:：]?\s*/, "")) : /(?:生理性別|性別)\s*[:：]?\s*(男|女|其他|未知|male|female)/i.exec(rootText)?.[1] ?? "";
        const context = [idToken, name, birth2, sex].join("\n");
        return [{ context, idToken, name, birth: birth2, sex, visible: root.getClientRects().length > 0 }];
      });
      const preferred = candidates.some((candidate) => candidate.visible) ? candidates.filter((candidate) => candidate.visible) : candidates;
      const unique = new Map(preferred.map((candidate) => [candidate.context, candidate]));
      if (unique.size !== 1) return null;
      const identity2 = unique.values().next().value;
      if (!identity2) return null;
      return {
        context: identity2.context,
        idToken: identity2.idToken,
        name: identity2.name,
        birth: identity2.birth,
        sex: identity2.sex
      };
    };
    const identity = readPatientIdentity();
    if (!identity) return { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    let digest;
    try {
      const padded = patientContextHmacKey.replace(/-/g, "+").replace(/_/g, "/") + "=";
      const rawKey = Uint8Array.from(atob(padded), (character) => character.charCodeAt(0));
      if (rawKey.byteLength !== 32) throw new Error("invalid patient-context key");
      const key = await crypto.subtle.importKey(
        "raw",
        rawKey,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      digest = await crypto.subtle.sign(
        "HMAC",
        key,
        new TextEncoder().encode(`nhi-medcloud-patient-context-v1
${identity.context}`)
      );
    } catch {
      return { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    }
    const patientContextHash = Array.from(
      new Uint8Array(digest),
      (byte) => byte.toString(16).padStart(2, "0")
    ).join("");
    const fullId = /\b[A-Z][12]\d{8}\b/i.exec(identity.idToken)?.[0] ?? "";
    const privacySafeId = fullId ? `${fullId.slice(0, 6)}XXXX` : identity.idToken.replace(/X/g, "X");
    const maskedName = identity.name ? `${identity.name[0] ?? ""}O${identity.name.length > 2 ? identity.name.at(-1) ?? "" : ""}` : "";
    const maskedId = privacySafeId.replace(/X/g, "\u2022");
    const birth = /(\d{2,4})[\/.\-年](\d{1,2})[\/.\-月](\d{1,2})/.exec(identity.birth);
    let age = "";
    let birthDate = "";
    if (birth) {
      const yearToken = birth[1] ?? "";
      let year = Number(yearToken);
      if (yearToken.length <= 3 && year > 0) year += 1911;
      const month = Number(birth[2]);
      const day = Number(birth[3]);
      const candidate = new Date(Date.UTC(year, month - 1, day));
      if (candidate.getUTCFullYear() === year && candidate.getUTCMonth() + 1 === month && candidate.getUTCDate() === day) {
        const now = /* @__PURE__ */ new Date();
        let years = now.getFullYear() - year;
        if (now.getMonth() + 1 < month || now.getMonth() + 1 === month && now.getDate() < day) years -= 1;
        if (years >= 0 && years <= 150) {
          birthDate = `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
          age = `${years}\u6B72`;
        }
      }
    }
    const genderRaw = identity.sex.toLowerCase();
    const gender = genderRaw === "male" ? "\u7537" : genderRaw === "female" ? "\u5973" : genderRaw;
    const genderCode = genderRaw === "male" || genderRaw === "\u7537" || genderRaw === "\u7537\u6027" ? "male" : genderRaw === "female" || genderRaw === "\u5973" || genderRaw === "\u5973\u6027" ? "female" : genderRaw === "\u5176\u4ED6" ? "other" : "unknown";
    const display = [maskedName, age, gender, maskedId].filter(Boolean).join("  \xB7  ") || `\u75C5\u4EBA ${patientContextHash.slice(0, 8)}\u2026`;
    return {
      ok: true,
      patientContextHash,
      display,
      identity: {
        maskedId: privacySafeId,
        name: identity.name,
        ...birthDate ? { birthDate } : {},
        gender: genderCode
      }
    };
  }
  async function probeMediCloudPatient(tabId) {
    try {
      const patientContextHmacKey = await getPatientContextHmacKey();
      const results = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: probeMediCloudPatientInPage,
        args: [MEDCLOUD_ORIGIN, patientContextHmacKey]
      });
      return results[0]?.result ?? { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    } catch {
      return { ok: false, code: "PATIENT_CONTEXT_UNAVAILABLE" };
    }
  }
  async function captureMediCloudInPage(request) {
    const fail = (code, sourceModule) => ({
      ok: false,
      code,
      ...sourceModule && /^IMUE\d{4}$/.test(sourceModule) ? { sourceModule } : {}
    });
    if (location.origin !== request.origin || !location.pathname.startsWith("/imu/")) {
      return fail("NOT_MEDCLOUD");
    }
    const CAPTURE_REGISTRY_KEY = "__cloudWildcatchCaptureRegistryV1";
    const CLINICAL_RESPONSE_LIMIT_BYTES = 5e7;
    const MODULE_REQUEST_TIMEOUT_MS = 3e4;
    const VIEWER_REQUEST_TIMEOUT_MS = 15e3;
    const OVERALL_CAPTURE_TIMEOUT_MS = 3 * 6e4;
    const pageWindow = window;
    const registry = pageWindow[CAPTURE_REGISTRY_KEY] instanceof Map ? pageWindow[CAPTURE_REGISTRY_KEY] : /* @__PURE__ */ new Map();
    pageWindow[CAPTURE_REGISTRY_KEY] = registry;
    const supersededState = registry.get(request.runId);
    if (supersededState) {
      supersededState.cancelled = true;
      for (const controller of supersededState.controllers ?? []) controller.abort();
    }
    const captureState = {
      controllers: /* @__PURE__ */ new Set(),
      cancelled: false,
      completedModules: 0,
      totalModules: request.modules.length
    };
    registry.set(request.runId, captureState);
    const captureDeadline = Date.now() + OVERALL_CAPTURE_TIMEOUT_MS;
    const originalFetch = window.fetch;
    const boundedFetchText = async (input, init, timeoutMs, maxBytes) => {
      if (captureState.cancelled) throw new DOMException("Capture cancelled", "AbortError");
      const remainingMs = captureDeadline - Date.now();
      if (remainingMs <= 0) throw new DOMException("Capture deadline exceeded", "TimeoutError");
      const controller = new AbortController();
      captureState.controllers.add(controller);
      const timer = window.setTimeout(
        () => controller.abort(new DOMException("Request timed out", "TimeoutError")),
        Math.max(1, Math.min(timeoutMs, remainingMs))
      );
      try {
        const response = await originalFetch.call(window, input, {
          ...init,
          signal: controller.signal
        });
        const declaredLength = Number(response.headers.get("content-length"));
        if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
          controller.abort();
          return { status: response.status, ok: response.ok, text: "", tooLarge: true };
        }
        if (!response.body) {
          return { status: response.status, ok: response.ok, text: "", tooLarge: false };
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        const parts = [];
        let totalBytes = 0;
        while (true) {
          const chunk = await reader.read();
          if (chunk.done) break;
          totalBytes += chunk.value.byteLength;
          if (totalBytes > maxBytes) {
            await reader.cancel().catch(() => void 0);
            controller.abort();
            return { status: response.status, ok: response.ok, text: "", tooLarge: true };
          }
          parts.push(decoder.decode(chunk.value, { stream: true }));
        }
        parts.push(decoder.decode());
        return { status: response.status, ok: response.ok, text: parts.join(""), tooLarge: false };
      } finally {
        window.clearTimeout(timer);
        captureState.controllers.delete(controller);
      }
    };
    try {
      let patchedSetRequestHeader2 = function(name, value) {
        if (name.toLowerCase() === "authorization") captureAuthorization(value);
        originalSetRequestHeader.call(this, name, value);
      }, patchedFetch2 = function(input, init) {
        const headers = new Headers(input instanceof Request ? input.headers : void 0);
        new Headers(init?.headers).forEach((value, name) => headers.set(name, value));
        captureAuthorization(headers.get("authorization"));
        return originalFetch.call(window, input, init);
      };
      var patchedSetRequestHeader = patchedSetRequestHeader2, patchedFetch = patchedFetch2;
      const patientContextText = () => {
        let roots = Array.from(document.querySelectorAll(".member-info"));
        if (roots.length === 0) {
          roots = Array.from(document.querySelectorAll(
            ".patient-info, .patient-data, [class*='memberInfo'], [class*='patient-info']"
          ));
        }
        const candidates = roots.slice(0, 50).flatMap((root) => {
          const text = (value) => (value ?? "").replace(/\s+/g, " ").trim();
          const field = (selector) => text(root.querySelector(selector)?.textContent);
          const rootText = text(root.textContent);
          const idText = field(".idno") || rootText;
          const fullId = /\b[A-Z][12]\d{8}\b/i.exec(idText)?.[0] ?? "";
          const maskedId = /\b[A-Z][12]\d{2}[Xx*•●．・]{2,4}\d{2,4}/i.exec(idText)?.[0] ?? "";
          const idToken = (fullId || maskedId).toUpperCase().replace(/[Xx*•●．・]/g, "X");
          if (!idToken) return [];
          const structuredName = field(".name");
          const name = structuredName ? text(structuredName.replace(/^(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*/, "")) : /(?:病人姓名|姓名|就醫對象)\s*[:：]?\s*([^\s｜|,，;；]{2,8})/.exec(rootText)?.[1] ?? "";
          const structuredBirth = field(".birth");
          const birth = structuredBirth ? text(structuredBirth.replace(/^(?:出生年月日|出生日期|生日)\s*[:：]?\s*/, "")) : /(?:出生年月日|出生日期|生日)\s*[:：]?\s*(\d{2,4}[\/.\-年]\d{1,2}[\/.\-月]\d{1,2})/.exec(rootText)?.[1] ?? "";
          const structuredSex = field(".sex");
          const sex = structuredSex ? text(structuredSex.replace(/^(?:生理性別|性別)\s*[:：]?\s*/, "")) : /(?:生理性別|性別)\s*[:：]?\s*(男|女|其他|未知|male|female)/i.exec(rootText)?.[1] ?? "";
          const context = [idToken, name, birth, sex].join("\n");
          return [{ context, visible: root.getClientRects().length > 0 }];
        });
        const preferred = candidates.some((candidate) => candidate.visible) ? candidates.filter((candidate) => candidate.visible) : candidates;
        const unique = new Set(preferred.map((candidate) => candidate.context));
        return unique.size === 1 ? unique.values().next().value ?? null : null;
      };
      const patientContextKeyBytes = Uint8Array.from(
        atob(request.patientContextHmacKey.replace(/-/g, "+").replace(/_/g, "/") + "="),
        (character) => character.charCodeAt(0)
      );
      const patientContextKey = await crypto.subtle.importKey(
        "raw",
        patientContextKeyBytes,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      const hashContext = async (value) => {
        const bytes = new TextEncoder().encode(`nhi-medcloud-patient-context-v1
${value}`);
        const digest = await crypto.subtle.sign("HMAC", patientContextKey, bytes);
        return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
      };
      const contextBeforeText = patientContextText();
      if (!contextBeforeText) return fail("PATIENT_CONTEXT_UNAVAILABLE");
      const patientContextHash = await hashContext(contextBeforeText);
      const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
      let resolveAuthorization;
      let authorization = "";
      const authorizationPromise = new Promise((resolve) => {
        resolveAuthorization = resolve;
      });
      const captureAuthorization = (value) => {
        const candidate = typeof value === "string" ? value.trim() : "";
        if (!authorization && /^Bearer\s+\S+$/i.test(candidate)) {
          authorization = candidate;
          resolveAuthorization?.(candidate);
        }
      };
      const waitForAuthorization = async (timeoutMs) => {
        if (authorization) return authorization;
        return Promise.race([
          authorizationPromise,
          new Promise((resolve) => window.setTimeout(() => resolve(null), timeoutMs))
        ]);
      };
      const visibleRouteLinks = () => Array.from(document.querySelectorAll('a[href^="/imu/IMUE1000/"]')).filter(
        (anchor) => anchor.getClientRects().length > 0
      );
      let authorizationForRun = null;
      const originalPath = location.pathname;
      let changedRoute = false;
      const routePaths = Array.from(new Set(
        visibleRouteLinks().map((anchor) => new URL(anchor.href, location.href).pathname)
      ));
      const candidatePaths = [
        originalPath,
        ...routePaths.filter((path) => path !== originalPath)
      ].slice(0, 6);
      XMLHttpRequest.prototype.setRequestHeader = patchedSetRequestHeader2;
      window.fetch = patchedFetch2;
      try {
        for (const [index, routePath] of candidatePaths.entries()) {
          if (captureState.cancelled) break;
          const route = visibleRouteLinks().find(
            (anchor) => new URL(anchor.href, location.href).pathname === routePath
          );
          if (!route) continue;
          route.click();
          if (routePath !== originalPath) changedRoute = true;
          authorizationForRun = await waitForAuthorization(index === 0 ? 1500 : 2500);
          if (authorizationForRun) break;
        }
      } finally {
        XMLHttpRequest.prototype.setRequestHeader = originalSetRequestHeader;
        window.fetch = originalFetch;
        if (changedRoute) {
          visibleRouteLinks().find((anchor) => new URL(anchor.href, location.href).pathname === originalPath)?.click();
        }
      }
      if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
      if (!authorizationForRun) return fail("AUTHORIZATION_UNAVAILABLE");
      if (await hashContext(patientContextText() ?? "") !== patientContextHash) {
        return fail("PATIENT_CONTEXT_CHANGED");
      }
      if (request.viewerRequest) {
        if (request.viewerRequest.expectedPatientContextHash !== patientContextHash) {
          return fail("PATIENT_CONTEXT_CHANGED");
        }
        const descriptor = request.viewerRequest.descriptor;
        const safePart2 = (value, maxLength) => {
          if (typeof value !== "string" || value.length > maxLength) return null;
          if (/[\u0000-\u001f\u007f@]/u.test(value)) return null;
          return value;
        };
        const iplCaseSeqNo = safePart2(descriptor?.iplCaseSeqNo, 256);
        const readPos = safePart2(descriptor?.readPos, 128);
        const fileType = safePart2(descriptor?.fileType, 128);
        const fileQty = safePart2(descriptor?.fileQty, 32);
        const feeYm = safePart2(descriptor?.feeYm, 64);
        if (descriptor?.version !== 1 || descriptor?.procId !== "IMUE0130" || !iplCaseSeqNo || readPos === null || !["", "Y"].includes(descriptor?.ordMark ?? "invalid") || fileType === null || fileQty === null || feeYm === null) {
          return fail("VIEWER_REQUEST_INVALID");
        }
        const normalizeRocFeeYm = (value) => {
          const digits = value.replace(/\D/g, "");
          if (digits.length === 5) {
            const month = Number(digits.slice(3, 5));
            return month >= 1 && month <= 12 ? digits : "";
          }
          if (digits.length >= 6) {
            const year = Number(digits.slice(0, 4));
            const month = Number(digits.slice(4, 6));
            if (month < 1 || month > 12) return "";
            return year > 1911 ? `${year - 1911}${digits.slice(4, 6)}` : digits.slice(0, 5);
          }
          return "";
        };
        const basicFeeYmFromResponse = (value) => {
          const candidates = [value];
          const keys = [
            "body",
            "data",
            "value",
            "basic_fee_ym",
            "basicFeeYm",
            "fee_ym",
            "feeYm"
          ];
          for (let index = 0; index < candidates.length && index < 16; index += 1) {
            const candidate = candidates[index];
            if (typeof candidate === "string" || typeof candidate === "number") {
              const normalized = normalizeRocFeeYm(String(candidate));
              if (normalized) return normalized;
              continue;
            }
            if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue;
            const record = candidate;
            for (const key of keys) if (key in record) candidates.push(record[key]);
          }
          return "";
        };
        const isTrustedViewerUrl = (value) => {
          if (typeof value !== "string" || value.length === 0 || value.length > 1e5) return false;
          try {
            const viewerUrl = new URL(value);
            return viewerUrl.protocol === "https:" && viewerUrl.port === "" && viewerUrl.username === "" && viewerUrl.password === "" && (viewerUrl.hostname === "nhi.gov.tw" || viewerUrl.hostname.endsWith(".nhi.gov.tw"));
          } catch {
            return false;
          }
        };
        let basicFeeYm = "";
        try {
          const basicFeeResponse = await boundedFetchText(
            new URL("/imu/api/imuecommon/imuecommon/basic-fee-ym", request.origin).toString(),
            {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: { Accept: "application/json", Authorization: authorizationForRun }
            },
            VIEWER_REQUEST_TIMEOUT_MS,
            2e5
          );
          if (basicFeeResponse.status === 401 || basicFeeResponse.status === 403) {
            return fail("AUTHORIZATION_FAILED");
          }
          if (basicFeeResponse.tooLarge) return fail("RESPONSE_TOO_LARGE");
          const text = basicFeeResponse.text;
          let value = text;
          try {
            value = JSON.parse(text);
          } catch {
            value = text;
          }
          basicFeeYm = basicFeeYmFromResponse(value);
        } catch {
          basicFeeYm = "";
        }
        const rowFeeYm = normalizeRocFeeYm(feeYm);
        const ordMark = descriptor.ordMark === "Y" && (!basicFeeYm || !rowFeeYm || Number(rowFeeYm) <= Number(basicFeeYm)) ? "Y" : "";
        const clientData = [iplCaseSeqNo, readPos, ordMark, fileType, fileQty].join("@");
        for (let attempt = 0; attempt < 3; attempt += 1) {
          if (attempt > 0) await new Promise((resolve) => window.setTimeout(resolve, 750));
          if (await hashContext(patientContextText() ?? "") !== patientContextHash) {
            return fail("PATIENT_CONTEXT_CHANGED");
          }
          let response;
          try {
            response = await boundedFetchText(
              new URL("/imu/api/imuecommon/imuecommon/get-ctmri2", request.origin).toString(),
              {
                method: "POST",
                credentials: "include",
                cache: "no-store",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json;charset=UTF-8",
                  Authorization: authorizationForRun
                },
                body: JSON.stringify({ ProcID: descriptor.procId, ClientData: clientData })
              },
              VIEWER_REQUEST_TIMEOUT_MS,
              2e5
            );
          } catch {
            continue;
          }
          if (response.status === 401 || response.status === 403) {
            return fail("AUTHORIZATION_FAILED");
          }
          const text = response.text;
          if (response.ok && !response.tooLarge) {
            try {
              const parsed = JSON.parse(text);
              const viewerUrl = parsed.ctmri_url ?? parsed.body?.ctmri_url;
              if (isTrustedViewerUrl(viewerUrl)) {
                return {
                  ok: true,
                  capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
                  patientContextHash,
                  modules: [],
                  viewerUrl
                };
              }
            } catch {
            }
          }
          const retryable = response.ok || response.status === 408 || response.status === 425 || response.status === 429 || response.status >= 500;
          if (!retryable) break;
        }
        return fail("VIEWER_UNAVAILABLE");
      }
      const pad = (value) => String(value).padStart(2, "0");
      const now = /* @__PURE__ */ new Date();
      const clientDateTime = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
      const query = new URLSearchParams({ cli_datetime: clientDateTime, insert_log: "true" });
      const modules = [];
      for (const module of request.modules) {
        if (captureState.cancelled) return fail("CAPTURE_CANCELLED");
        captureState.completedModules = modules.length;
        const currentContext = patientContextText();
        if (!currentContext || await hashContext(currentContext) !== patientContextHash) {
          return fail("PATIENT_CONTEXT_CHANGED");
        }
        const url = new URL(module.datasetScope, request.origin);
        url.search = query.toString();
        let response;
        try {
          response = await boundedFetchText(
            url.toString(),
            {
              method: "GET",
              credentials: "include",
              cache: "no-store",
              headers: {
                Accept: "application/json",
                Authorization: authorizationForRun
              }
            },
            MODULE_REQUEST_TIMEOUT_MS,
            CLINICAL_RESPONSE_LIMIT_BYTES
          );
        } catch {
          modules.push({
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 0,
            body: ""
          });
          continue;
        }
        if (response.status === 401 || response.status === 403) {
          return fail("AUTHORIZATION_FAILED", module.sourceModule);
        }
        if (response.tooLarge) {
          modules.push({
            sourceModule: module.sourceModule,
            datasetScope: module.datasetScope,
            status: 413,
            body: ""
          });
          continue;
        }
        let body = response.text;
        if (module.sourceModule === "IMUE0070" && !response.ok) body = "";
        if (module.sourceModule === "IMUE0070" && response.ok) {
          try {
            const parsedBody = JSON.parse(body);
            const rows = Array.isArray(parsedBody.robject) ? parsedBody.robject : [];
            const documentJobs = rows.flatMap((row, rowIndex) => {
              const handle = typeof row?.mds_file === "string" ? row.mds_file.trim() : "";
              return handle ? [{ rowIndex, handle }] : [];
            });
            const documentRowIndexes = documentJobs.map(({ rowIndex }) => rowIndex);
            const documents = new Array(documentJobs.length);
            const SHOW_XML_CONCURRENCY = 3;
            const SHOW_XML_TIMEOUT_MS = 3e4;
            const documentState = { nextJobIndex: 0, fatalError: null };
            const stopDocumentFetches = (error) => {
              if (documentState.fatalError) return;
              documentState.fatalError = error;
              for (const controller of captureState.controllers) controller.abort();
            };
            const fetchDocumentWorker = async () => {
              while (!documentState.fatalError) {
                const jobIndex = documentState.nextJobIndex;
                documentState.nextJobIndex += 1;
                const job = documentJobs[jobIndex];
                if (!job) return;
                const currentContext2 = patientContextText();
                if (!currentContext2 || await hashContext(currentContext2) !== patientContextHash) {
                  stopDocumentFetches("PATIENT_CONTEXT_CHANGED");
                  return;
                }
                const detailNow = /* @__PURE__ */ new Date();
                const detailTimestamp = `${detailNow.getFullYear()}${pad(detailNow.getMonth() + 1)}${pad(detailNow.getDate())}${pad(detailNow.getHours())}${pad(detailNow.getMinutes())}${pad(detailNow.getSeconds())}${String(Math.floor(detailNow.getMilliseconds() / 10)).padStart(2, "0")}${String(detailNow.getMilliseconds()).padStart(3, "0")}`;
                try {
                  const detailResponse = await boundedFetchText(
                    new URL("/imu/api/imue0070/imue0070s01/show-xml", request.origin).toString(),
                    {
                      method: "POST",
                      credentials: "include",
                      cache: "no-store",
                      headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json;charset=UTF-8",
                        Authorization: authorizationForRun
                      },
                      body: JSON.stringify({ FileName: `${job.handle}@${detailTimestamp}` })
                    },
                    SHOW_XML_TIMEOUT_MS,
                    CLINICAL_RESPONSE_LIMIT_BYTES
                  );
                  if (detailResponse.status === 401 || detailResponse.status === 403) {
                    stopDocumentFetches("AUTHORIZATION_FAILED");
                    return;
                  }
                  if (detailResponse.tooLarge) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 413 };
                    continue;
                  }
                  const detailBody = detailResponse.text;
                  const contextAfterFetch = patientContextText();
                  if (!contextAfterFetch || await hashContext(contextAfterFetch) !== patientContextHash) {
                    stopDocumentFetches("PATIENT_CONTEXT_CHANGED");
                    return;
                  }
                  let html = "";
                  if (detailResponse.ok) {
                    try {
                      const detail = JSON.parse(detailBody);
                      const returnedHtml = typeof detail.html === "string" ? detail.html : detail.body?.html;
                      if (typeof returnedHtml === "string") html = returnedHtml;
                    } catch {
                      html = "";
                    }
                  }
                  documents[jobIndex] = {
                    rowIndex: job.rowIndex,
                    status: detailResponse.status,
                    ...html ? { html } : {}
                  };
                } catch {
                  if (!documentState.fatalError) {
                    documents[jobIndex] = { rowIndex: job.rowIndex, status: 0 };
                  }
                }
              }
            };
            const documentWorkerCount = Math.min(
              SHOW_XML_CONCURRENCY,
              documentJobs.length
            );
            await Promise.all(
              Array.from({ length: documentWorkerCount }, () => fetchDocumentWorker())
            );
            if (documentState.fatalError) {
              return fail(documentState.fatalError, module.sourceModule);
            }
            for (const row of rows) {
              row.mds_file = null;
              row.mds_pdf_file = null;
            }
            parsedBody._cloudWildcatchDocumentsAttempted = true;
            parsedBody._cloudWildcatchDocumentRowIndexes = documentRowIndexes;
            parsedBody._cloudWildcatchDocuments = documents.filter(
              (document2) => document2 !== void 0
            );
            body = JSON.stringify(parsedBody);
            if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
              modules.push({
                sourceModule: module.sourceModule,
                datasetScope: module.datasetScope,
                status: 413,
                body: ""
              });
              continue;
            }
          } catch {
            return fail("RESPONSE_SHAPE_INVALID", module.sourceModule);
          }
        }
        if (module.sourceModule === "IMUE0130" && response.ok) {
          try {
            const parsedBody = JSON.parse(body);
            const rows = Array.isArray(parsedBody.robject) ? parsedBody.robject : [];
            const rowIndexes = rows.map((row, rowIndex) => row?.ctmri_mark === "Y" ? rowIndex : -1).filter((rowIndex) => rowIndex >= 0).slice(0, 200);
            const sourceValue = (value) => value === null || value === void 0 ? "" : String(value);
            const viewerRequests = rowIndexes.flatMap((rowIndex) => {
              const row = rows[rowIndex] ?? {};
              const iplCaseSeqNo = sourceValue(row.ipl_case_seq_no).trim();
              if (!iplCaseSeqNo) return [];
              return [{
                rowIndex,
                descriptor: {
                  version: 1,
                  procId: "IMUE0130",
                  iplCaseSeqNo,
                  readPos: sourceValue(row.read_pos),
                  ordMark: row.ord_mark === "Y" ? "Y" : "",
                  fileType: sourceValue(row.file_type),
                  fileQty: sourceValue(row.file_qty),
                  feeYm: sourceValue(row.fee_ym)
                }
              }];
            });
            const descriptorRowCount = rowIndexes.filter(
              (rowIndex) => sourceValue(rows[rowIndex]?.ipl_case_seq_no).trim() !== ""
            ).length;
            if (viewerRequests.length !== descriptorRowCount) {
              return fail("RESPONSE_SHAPE_INVALID", module.sourceModule);
            }
            parsedBody._cloudWildcatchViewerRequestsAttempted = true;
            parsedBody._cloudWildcatchViewerRequestRowIndexes = rowIndexes;
            parsedBody._cloudWildcatchViewerRequests = viewerRequests;
            body = JSON.stringify(parsedBody);
            if (new TextEncoder().encode(body).byteLength > CLINICAL_RESPONSE_LIMIT_BYTES) {
              modules.push({
                sourceModule: module.sourceModule,
                datasetScope: module.datasetScope,
                status: 413,
                body: ""
              });
              continue;
            }
          } catch {
          }
        }
        modules.push({
          sourceModule: module.sourceModule,
          datasetScope: module.datasetScope,
          status: response.status,
          body
        });
      }
      const contextAfterText = patientContextText();
      if (!contextAfterText || await hashContext(contextAfterText) !== patientContextHash) {
        return fail("PATIENT_CONTEXT_CHANGED");
      }
      return {
        ok: true,
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        patientContextHash,
        modules
      };
    } finally {
      for (const controller of captureState.controllers) controller.abort();
      if (registry.get(request.runId) === captureState) registry.delete(request.runId);
    }
  }
  function cancelMediCloudCaptureInPage(runId) {
    const registry = window["__cloudWildcatchCaptureRegistryV1"];
    if (!(registry instanceof Map)) return;
    const state = registry.get(runId);
    if (!state) return;
    state.cancelled = true;
    for (const controller of state.controllers ?? []) controller.abort();
  }
  function readMediCloudCaptureProgressInPage(runId) {
    const registry = window["__cloudWildcatchCaptureRegistryV1"];
    if (!(registry instanceof Map)) return null;
    const state = registry.get(runId);
    if (!state) return null;
    const completedModules = Number(state.completedModules);
    const totalModules = Number(state.totalModules);
    if (!Number.isInteger(completedModules) || !Number.isInteger(totalModules)) return null;
    return { completedModules, totalModules };
  }
  async function readMediCloudCaptureProgress(tabId, runId) {
    if (!runId) return null;
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: readMediCloudCaptureProgressInPage,
        args: [runId]
      });
      const progress = results[0]?.result;
      if (!progress) return null;
      const totalModules = Math.max(0, progress.totalModules);
      return {
        totalModules,
        completedModules: Math.min(Math.max(0, progress.completedModules), totalModules)
      };
    } catch {
      return null;
    }
  }
  async function cancelMediCloudCapture(tabId, runId) {
    if (!runId) return;
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      world: "MAIN",
      func: cancelMediCloudCaptureInPage,
      args: [runId]
    }).catch(() => void 0);
  }
  async function mintMediCloudViewerUrl(tabId, expectedPatientContextHash, descriptor) {
    let results;
    try {
      const patientContextHmacKey = await getPatientContextHmacKey();
      results = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: captureMediCloudInPage,
        args: [{
          origin: MEDCLOUD_ORIGIN,
          runId: crypto.randomUUID(),
          patientContextHmacKey,
          modules: [],
          viewerRequest: { expectedPatientContextHash, descriptor }
        }]
      });
    } catch {
      throw new MediCloudAcquisitionError("CAPTURE_INJECTION_FAILED");
    }
    const result = results[0]?.result;
    if (!result) throw new MediCloudAcquisitionError("CAPTURE_RESULT_MISSING");
    if (!result.ok) throw new MediCloudAcquisitionError(result.code, result.sourceModule);
    if (result.patientContextHash !== expectedPatientContextHash) {
      throw new MediCloudAcquisitionError("PATIENT_CONTEXT_CHANGED");
    }
    try {
      const viewerUrl = new URL(result.viewerUrl ?? "");
      const trustedHost = viewerUrl.hostname === "nhi.gov.tw" || viewerUrl.hostname.endsWith(".nhi.gov.tw");
      if (viewerUrl.protocol !== "https:" || viewerUrl.port || viewerUrl.username || viewerUrl.password || !trustedHost) {
        throw new Error("untrusted viewer URL");
      }
      return viewerUrl.toString();
    } catch {
      throw new MediCloudAcquisitionError("VIEWER_UNAVAILABLE");
    }
  }
  async function loadMediCloudEnvelopes(tabId, runId) {
    let executionResults;
    try {
      const patientContextHmacKey = await getPatientContextHmacKey();
      executionResults = await chrome.scripting.executeScript({
        target: { tabId, frameIds: [0] },
        world: "MAIN",
        func: captureMediCloudInPage,
        args: [
          {
            origin: MEDCLOUD_ORIGIN,
            runId,
            patientContextHmacKey,
            modules: MEDCLOUD_MODULES.map(({ sourceModule, datasetScope }) => ({
              sourceModule,
              datasetScope
            }))
          }
        ]
      });
    } catch {
      throw new MediCloudAcquisitionError("CAPTURE_INJECTION_FAILED");
    }
    const capture = executionResults[0]?.result;
    if (!capture) throw new MediCloudAcquisitionError("CAPTURE_RESULT_MISSING");
    if (!capture.ok) throw new MediCloudAcquisitionError(capture.code, capture.sourceModule);
    return capture.modules.map((module) => {
      const candidate = {
        schemaVersion: "1.0.0",
        sourceSystem: "nhi-medcloud",
        sourceModule: module.sourceModule,
        datasetScope: module.datasetScope,
        adapterVersion: MEDCLOUD_ADAPTER_VERSION,
        runId,
        capturedAt: capture.capturedAt,
        completeness: module.status >= 200 && module.status < 300 ? "complete" : "failed",
        patientContextHash: capture.patientContextHash,
        payload: { status: module.status, body: module.body }
      };
      try {
        return SourceEnvelopeSchema.parse(candidate);
      } catch {
        throw new MediCloudAcquisitionError("SOURCE_ENVELOPE_INVALID", module.sourceModule);
      }
    });
  }

  // src/pipeline.ts
  var SYNTHETIC_PATIENT_CONTEXT_HASH = "c10d".repeat(16);
  var PatientContextChangedError = class extends Error {
    constructor() {
      super("Patient context changed during the run; no Bundle was produced");
      this.name = "PatientContextChangedError";
    }
  };
  var PipelineStageError = class extends Error {
    constructor(code, sourceModule) {
      super(code);
      this.code = code;
      this.sourceModule = sourceModule;
      this.name = "PipelineStageError";
    }
    code;
    sourceModule;
  };
  function moduleStatus(result) {
    const warningCounts = result.warnings.reduce((counts, warning) => {
      counts[warning.code] = (counts[warning.code] ?? 0) + 1;
      return counts;
    }, {});
    const warningLocations = [...new Map(result.warnings.map((warning) => {
      const location2 = {
        code: warning.code,
        path: warning.path,
        ...warning.field ? { field: warning.field } : {}
      };
      return [`${location2.code}|${location2.path}|${location2.field ?? ""}`, location2];
    })).values()];
    return {
      sourceModule: result.sourceModule,
      datasetScope: result.datasetScope,
      completeness: result.completeness,
      adapterVersion: result.adapterVersion,
      warningCount: result.warnings.length,
      sourceRecordCount: result.records.length,
      ...Object.keys(warningCounts).length > 0 ? { warningCounts } : {},
      ...warningLocations.length > 0 ? { warningLocations } : {},
      ...result.error?.code ? { errorCode: result.error.code } : {}
    };
  }
  function requireDatasetScope(envelope, expectedScope) {
    if (envelope.datasetScope !== expectedScope) {
      throw new Error(
        `Unexpected datasetScope for ${envelope.sourceModule}; expected ${expectedScope}`
      );
    }
  }
  function adaptSourceEnvelope(envelope) {
    const context = {
      capturedAt: envelope.capturedAt,
      patientContextHash: envelope.patientContextHash,
      adapterVersion: envelope.adapterVersion
    };
    switch (envelope.sourceModule) {
      case IMUE0060_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0060_DATASET_SCOPE);
        return adaptImue0060Response(envelope.payload, context);
      case IMUE0008_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0008_DATASET_SCOPE);
        return adaptImue0008Response(envelope.payload, context);
      case IMUE0130_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0130_DATASET_SCOPE);
        return adaptImue0130Response(envelope.payload, context);
      case IMUE0030_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0030_DATASET_SCOPE);
        return adaptImue0030Response(envelope.payload, context);
      case IMUE0010_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0010_DATASET_SCOPE);
        return adaptImue0010Response(envelope.payload, context);
      case IMUE0120_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0120_DATASET_SCOPE);
        return adaptImue0120Response(envelope.payload, context);
      case IMUE0140_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0140_DATASET_SCOPE);
        return adaptImue0140Response(envelope.payload, context);
      case IMUE0070_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0070_DATASET_SCOPE);
        return adaptImue0070Response(envelope.payload, context);
      case IMUE0080_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0080_DATASET_SCOPE);
        return adaptImue0080Response(envelope.payload, context);
      case IMUE0150_SOURCE_MODULE:
        requireDatasetScope(envelope, IMUE0150_DATASET_SCOPE);
        return adaptImue0150Response(envelope.payload, context);
      default:
        throw new Error(`No adapter registered for ${String(envelope.sourceModule)}`);
    }
  }
  var MODULE_FALLBACKS = {
    [IMUE0060_SOURCE_MODULE]: { datasetScope: IMUE0060_DATASET_SCOPE, pageType: "observations" },
    [IMUE0008_SOURCE_MODULE]: { datasetScope: IMUE0008_DATASET_SCOPE, pageType: "medications" },
    [IMUE0130_SOURCE_MODULE]: { datasetScope: IMUE0130_DATASET_SCOPE, pageType: "diagnostic_reports" },
    [IMUE0030_SOURCE_MODULE]: { datasetScope: IMUE0030_DATASET_SCOPE, pageType: "procedures" },
    [IMUE0010_SOURCE_MODULE]: { datasetScope: IMUE0010_DATASET_SCOPE, pageType: "service_requests" },
    [IMUE0120_SOURCE_MODULE]: { datasetScope: IMUE0120_DATASET_SCOPE, pageType: "medications" },
    [IMUE0140_SOURCE_MODULE]: { datasetScope: IMUE0140_DATASET_SCOPE, pageType: "observations" },
    [IMUE0070_SOURCE_MODULE]: { datasetScope: IMUE0070_DATASET_SCOPE, pageType: "encounters" },
    [IMUE0080_SOURCE_MODULE]: { datasetScope: IMUE0080_DATASET_SCOPE, pageType: "procedures" },
    [IMUE0150_SOURCE_MODULE]: { datasetScope: IMUE0150_DATASET_SCOPE, pageType: "observations" }
  };
  function failedModuleResult(envelope) {
    const fallback = MODULE_FALLBACKS[envelope.sourceModule];
    if (!fallback) return void 0;
    return {
      sourceSystem: "nhi-medcloud",
      sourceModule: envelope.sourceModule,
      datasetScope: fallback.datasetScope,
      adapterVersion: envelope.adapterVersion,
      capturedAt: envelope.capturedAt,
      patientContextHash: envelope.patientContextHash,
      pageType: fallback.pageType,
      completeness: "failed",
      warnings: [
        {
          code: "invalid-response",
          severity: "error",
          path: "$",
          message: "Adapter raised an unexpected error; this module was skipped so the other modules can still be delivered."
        }
      ],
      records: [],
      error: {
        code: "ADAPTER_EXCEPTION",
        message: "Adapter raised an unexpected error for this module."
      }
    };
  }
  function buildFromEnvelopes(envelopes, options) {
    if (envelopes.length === 0) throw new PipelineStageError("NO_MODULE_DATA");
    const patientContextHash = envelopes[0]?.patientContextHash ?? "";
    if (envelopes.some((envelope) => envelope.patientContextHash !== patientContextHash)) {
      throw new PatientContextChangedError();
    }
    const results = envelopes.map((envelope) => {
      try {
        return adaptSourceEnvelope(envelope);
      } catch {
        const fallback = failedModuleResult(envelope);
        if (!fallback) {
          throw new PipelineStageError("MODULE_ADAPTATION_FAILED", envelope.sourceModule);
        }
        return fallback;
      }
    });
    try {
      return buildMedcloudBundle({
        patientContextHash,
        runId: options.runId,
        generatedAt: options.generatedAt,
        patient: options.patientIdentity,
        maskNameEnabled: options.maskNameEnabled,
        mapperInput: toNhiMapperInput(results),
        modules: results.map(moduleStatus)
      });
    } catch (error) {
      if (error?.name === "IncompleteModuleError") throw error;
      throw new PipelineStageError("FHIR_MAPPING_FAILED");
    }
  }
  function toRawCapturePayload(envelopes, maskedId) {
    const first = envelopes[0];
    if (!first) return void 0;
    return {
      patient: maskedId || `context-${first.patientContextHash.slice(0, 12)}`,
      capturedAt: first.capturedAt,
      endpoints: Object.fromEntries(envelopes.map((envelope) => [
        envelope.datasetScope,
        {
          status: envelope.payload.status,
          body: typeof envelope.payload.body === "string" ? envelope.payload.body : JSON.stringify(envelope.payload.body)
        }
      ]))
    };
  }
  async function runMediCloudPipeline(options) {
    const envelopes = await loadMediCloudEnvelopes(options.tabId, options.runId);
    if (options.expectedPatientContextHash && envelopes[0]?.patientContextHash !== options.expectedPatientContextHash) {
      throw new PatientContextChangedError();
    }
    return {
      ...buildFromEnvelopes(envelopes, options),
      rawCapture: toRawCapturePayload(envelopes, options.patientIdentity?.maskedId ?? "")
    };
  }

  // src/module-labels.ts
  var MEDCLOUD_MODULE_LABELS = Object.fromEntries(
    MEDCLOUD_CLINICAL_MODULES.map((module) => [module.sourceModule, module.label])
  );
  function incompleteModuleLabels(moduleStatuses, limit = 3) {
    const labels = (moduleStatuses ?? []).filter((module) => module.completeness === "partial" || module.completeness === "failed").map((module) => MEDCLOUD_MODULE_LABELS[module.sourceModule] ?? module.sourceModule);
    if (labels.length === 0) return "";
    if (labels.length <= limit) return labels.join("\u3001");
    return `${labels.slice(0, limit).join("\u3001")} \u7B49 ${labels.length} \u9805`;
  }

  // src/popup-model.ts
  function buildMedcloudFilename(maskedId, capturedAt, version, partial = false) {
    const pad = (value) => String(value).padStart(2, "0");
    const capturedDate = `${capturedAt.getFullYear()}${pad(capturedAt.getMonth() + 1)}${pad(capturedAt.getDate())}`;
    const rawId = String(maskedId ?? "").trim().toUpperCase();
    const privacySafeId = /^[A-Z][12]\d{8}$/.test(rawId) ? `${rawId.slice(0, 6)}XXXX` : rawId;
    const normalizedId = privacySafeId.trim().replace(/[Xx*＊•●．・]/g, "X");
    const safeId = (normalizedId || "unknown").replace(/[^A-Za-z0-9_-]/g, "_");
    const safeVersion = String(version || "unknown").replace(/[^A-Za-z0-9._-]/g, "_");
    return `medcloud-${safeId}-${capturedDate}-v${safeVersion}${partial ? "-partial" : ""}.json`;
  }
  function buildMedcloudRawFilename(maskedId, capturedAt, version) {
    return buildMedcloudFilename(maskedId, capturedAt, version).replace(/^medcloud-/, "medcloud-raw-");
  }
  var RESOURCE_LABELS = {
    Patient: "\u75C5\u4EBA\u8CC7\u6599",
    Encounter: "\u5C31\u91AB\u7D00\u9304",
    Condition: "\u8A3A\u65B7\u7D00\u9304",
    Observation: "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C",
    DiagnosticReport: "\u6AA2\u67E5\u5831\u544A",
    ServiceRequest: "\u6AA2\u67E5\u5B89\u6392",
    ImagingStudy: "\u5F71\u50CF\u6AA2\u67E5",
    MedicationRequest: "\u7528\u85E5\u7D00\u9304",
    MedicationDispense: "\u9818\u85E5\u7D00\u9304",
    Procedure: "\u8655\u7F6E\u7D00\u9304",
    DocumentReference: "\u75C5\u6B77\u6458\u8981",
    AllergyIntolerance: "\u904E\u654F\u7D00\u9304",
    Immunization: "\u9810\u9632\u63A5\u7A2E",
    Organization: "\u91AB\u7642\u9662\u6240",
    Provenance: "\u8CC7\u6599\u4F86\u6E90\u7D00\u9304"
  };
  var DETAIL_LABEL_ORDER = [
    "\u75C5\u4EBA\u8CC7\u6599",
    "\u5C31\u91AB\u7D00\u9304",
    "\u8A3A\u65B7\u7D00\u9304",
    "\u6AA2\u67E5\u6AA2\u9A57\u7D50\u679C",
    "\u6AA2\u67E5\u5831\u544A",
    "\u6AA2\u67E5\u5B89\u6392",
    "\u5F71\u50CF\u6AA2\u67E5",
    "\u7528\u85E5\u7D00\u9304",
    "\u9818\u85E5\u7D00\u9304",
    "\u8655\u7F6E\u7D00\u9304",
    "\u75C5\u6B77\u6458\u8981",
    "\u904E\u654F\u7D00\u9304",
    "\u9810\u9632\u63A5\u7A2E",
    "\u91AB\u7642\u9662\u6240",
    "\u8CC7\u6599\u4F86\u6E90\u7D00\u9304",
    "\u5176\u4ED6\u8CC7\u6599"
  ];
  var ERROR_REASON = {
    HTTP_0: "\u4F86\u6E90\u7AEF\u9EDE\u6C92\u6709\u56DE\u61C9",
    HTTP_413: "\u4F86\u6E90\u56DE\u61C9\u8D85\u904E\u53EF\u5B89\u5168\u8655\u7406\u7684\u5927\u5C0F",
    INVALID_JSON: "\u4F86\u6E90\u56DE\u50B3\u5167\u5BB9\u4E0D\u662F\u6709\u6548 JSON",
    INVALID_RESPONSE: "\u4F86\u6E90\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u7248\u672C\u4E0D\u7B26",
    NO_VALID_ROWS: "\u4F86\u6E90\u5217\u5168\u90E8\u4E0D\u7B26\u5408\u76EE\u524D\u652F\u63F4\u683C\u5F0F",
    ADAPTER_EXCEPTION: "\u6A21\u7D44\u8F49\u63DB\u7A0B\u5F0F\u767C\u751F\u4F8B\u5916"
  };
  var WARNING_REASON = {
    "http-error": () => "\u4F86\u6E90\u7AEF\u9EDE\u53D6\u5F97\u5931\u6557",
    "invalid-json": () => "\u4F86\u6E90\u56DE\u50B3\u5167\u5BB9\u4E0D\u662F\u6709\u6548 JSON",
    "invalid-response": () => "\u4F86\u6E90\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u7248\u672C\u4E0D\u7B26",
    "invalid-row": (count) => `${count} \u500B\u4F86\u6E90\u6B04\u4F4D\u4E0D\u7B26\u5408\u76EE\u524D\u652F\u63F4\u683C\u5F0F`,
    "unknown-field": (count) => `\u4F86\u6E90\u51FA\u73FE ${count} \u500B\u5C1A\u672A\u652F\u63F4\u7684\u65B0\u6B04\u4F4D\uFF08\u5DF2\u5FFD\u7565\uFF09`,
    "invalid-date": (count) => `${count} \u500B\u65E5\u671F\u7121\u6CD5\u8FA8\u8B58`,
    "missing-clinical-content": (count) => `${count} \u7B46\u7F3A\u5C11\u53EF\u8F49\u63DB\u7684\u81E8\u5E8A\u5167\u5BB9`
  };
  var FHIR_ISSUE_REASON = {
    "duplicate-resource-identity": "\u8F49\u63DB\u5F8C\u767C\u751F\u91CD\u8907\u8CC7\u6E90\u8B58\u5225",
    "unresolved-reference": "FHIR \u8CC7\u6E90\u542B\u7121\u6CD5\u89E3\u6790\u7684\u53C3\u7167",
    "duplicate-full-url": "FHIR Bundle \u51FA\u73FE\u91CD\u8907 fullUrl",
    "resource-identity-mismatch": "FHIR resource id \u8207 fullUrl \u4E0D\u4E00\u81F4"
  };
  function positiveInteger(value) {
    return Number.isInteger(value) && Number(value) > 0 ? Number(value) : 0;
  }
  function moduleReason(module) {
    const dropped = positiveInteger(module.droppedResourceCount);
    const errorCode = typeof module.errorCode === "string" ? module.errorCode : "";
    if (errorCode) return ERROR_REASON[errorCode] ?? `\u6A21\u7D44\u8655\u7406\u5931\u6557\uFF08${errorCode}\uFF09`;
    if (dropped > 0) {
      const issueReason = (module.issueCodes ?? []).map((code) => FHIR_ISSUE_REASON[code]).find(Boolean);
      return `${dropped} \u7B46\u8F49\u63DB\u5F8C\u672A\u7D0D\u5165${issueReason ? `\uFF1A${issueReason}` : ""}`;
    }
    const warnings = Object.entries(module.warningCounts ?? {}).filter(([, count]) => positiveInteger(count) > 0).sort(([left], [right]) => left.localeCompare(right));
    const actionableWarning = warnings.map(([code, count]) => WARNING_REASON[code]?.(positiveInteger(count))).find(Boolean);
    if (actionableWarning) return actionableWarning;
    const warningCount = positiveInteger(module.warningCount);
    if (warningCount > 0) return `\u6709 ${warningCount} \u500B\u683C\u5F0F\u8B66\u544A`;
    return module.completeness === "failed" ? "\u6B64\u6A21\u7D44\u6C92\u6709\u7522\u751F\u53EF\u7528\u8CC7\u6599" : "\u6B64\u6A21\u7D44\u8CC7\u6599\u4E0D\u5B8C\u6574";
  }
  function moduleDiagnostic(module) {
    const parts = [module.sourceModule, module.completeness.toUpperCase()];
    const records = positiveInteger(module.sourceRecordCount);
    if (records > 0) parts.push(`RECORDS=${records}`);
    if (module.errorCode) parts.push(`ERROR=${module.errorCode}`);
    const warnings = Object.entries(module.warningCounts ?? {}).filter(([, count]) => positiveInteger(count) > 0).sort(([left], [right]) => left.localeCompare(right)).map(([code, count]) => `${code}:${positiveInteger(count)}`);
    if (warnings.length > 0) parts.push(`WARN=${warnings.join(",")}`);
    const dropped = positiveInteger(module.droppedResourceCount);
    if (dropped > 0) parts.push(`DROPPED=${dropped}`);
    if (module.issueCodes?.length) parts.push(`ISSUE=${[...module.issueCodes].sort().join(",")}`);
    return parts.join(" | ");
  }
  function incompleteModuleDetails(moduleStatuses, droppedResources = []) {
    return (moduleStatuses ?? []).filter(
      (module) => module.completeness === "partial" || module.completeness === "failed"
    ).map((module) => {
      const sourceWarnings = (module.warningLocations ?? []).map((warning) => {
        const documentRow = /^_cloudWildcatchDocuments\[(\d+)\]\.html$/.exec(warning.path);
        const sourceRow = /^robject\[(\d+)\](?:\.(.+))?$/.exec(warning.path);
        const label = documentRow ? `\u4F86\u6E90\u7B2C ${Number(documentRow[1]) + 1} \u7B46\uFF08robject[${documentRow[1]}]\uFF09\uFF1A\u672A\u5EFA\u7ACB DocumentReference` : sourceRow ? `\u4F86\u6E90\u7B2C ${Number(sourceRow[1]) + 1} \u7B46\uFF08robject[${sourceRow[1]}]\uFF09${sourceRow[2] ? `\u6B04\u4F4D ${sourceRow[2]}` : ""}` : `\u4F86\u6E90\u4F4D\u7F6E ${warning.path}${warning.field ? `\uFF08\u6B04\u4F4D ${warning.field}\uFF09` : ""}`;
        return {
          kind: "source",
          label,
          diagnostic: `${warning.code} | PATH=${warning.path}`
        };
      });
      const dropped = droppedResources.filter((resource) => resource.sourceModule === module.sourceModule).map((resource) => ({
        kind: "resource",
        label: `${resource.resourceType}/${resource.id ?? "(\u7121 ID)"}`,
        diagnostic: [...resource.issueCodes].sort().join(",")
      }));
      return {
        sourceModule: module.sourceModule,
        label: MEDCLOUD_MODULE_LABELS[module.sourceModule] ?? module.sourceModule,
        completeness: module.completeness,
        reason: moduleReason(module),
        diagnostic: moduleDiagnostic(module),
        affectedRecords: [...sourceWarnings, ...dropped]
      };
    });
  }
  function presentBundleSummary(summary) {
    const resourceEntries = Object.entries(summary.resourceCounts).filter(([, count]) => Number.isFinite(count) && count > 0).sort(([left], [right]) => left.localeCompare(right));
    const totalResources = resourceEntries.reduce((sum, [, count]) => sum + count, 0);
    const detailCountByLabel = /* @__PURE__ */ new Map();
    for (const [resourceType, count] of resourceEntries) {
      const label = RESOURCE_LABELS[resourceType] ?? "\u5176\u4ED6\u8CC7\u6599";
      detailCountByLabel.set(label, (detailCountByLabel.get(label) ?? 0) + count);
    }
    const detailRows = DETAIL_LABEL_ORDER.filter((label) => detailCountByLabel.has(label)).map((label) => ({ label, count: detailCountByLabel.get(label) }));
    const incompleteModuleCount = summary.moduleStatuses.filter(
      (module) => module.completeness === "partial" || module.completeness === "failed"
    ).length;
    const droppedResourceCount = Number.isFinite(summary.droppedResourceCount) ? Math.max(0, Number(summary.droppedResourceCount)) : 0;
    const baseNote = "\u4ECD\u53EF\u4E0B\u8F09\u6216\u65BC MediPrisma \u67E5\u770B\uFF1B\u6A94\u6848\u6703\u4FDD\u7559\u300C\u8CC7\u6599\u4E0D\u5B8C\u6574\u300D\u6A19\u8A18\uFF0C\u4F7F\u7528\u6642\u8ACB\u56DE\u539F\u59CB\u7CFB\u7D71\u6838\u5C0D\u7F3A\u6F0F\u5167\u5BB9\u3002";
    const incompleteModules = incompleteModuleDetails(summary.moduleStatuses, summary.droppedResources);
    const problemScope = incompleteModules.length > 0 ? `\u554F\u984C\u4F86\u6E90\uFF1A${incompleteModules.map((module) => module.label).join("\u3001")}\u3002` : "";
    return {
      canDownload: summary.validation.valid,
      hasIncompleteModules: incompleteModuleCount > 0 || droppedResourceCount > 0,
      incompleteModuleCount,
      droppedResourceCount,
      totalResources,
      summaryText: `\u5171 ${totalResources} \u7B46\u5065\u5EB7\u7D00\u9304`,
      completenessNote: `${problemScope}${droppedResourceCount > 0 ? `\u5176\u4E2D ${droppedResourceCount} \u7B46\u56E0\u683C\u5F0F\u7121\u6CD5\u8F49\u63DB\u800C\u672A\u7D0D\u5165\u3002` : ""}${baseNote}`,
      incompleteModules,
      detailRows
    };
  }
  function acquisitionErrorMessage(error) {
    const candidate = error;
    const code = typeof candidate?.code === "string" ? candidate.code : "";
    const name = typeof candidate?.name === "string" ? candidate.name : "";
    const sourceModule = typeof candidate?.sourceModule === "string" && /^IMUE\d{4}$/.test(candidate.sourceModule) ? candidate.sourceModule : "";
    const modulePrefix = sourceModule ? `${sourceModule} ` : "";
    const diagnostic = (value) => `\uFF08\u932F\u8AA4\u4EE3\u78BC\uFF1A${value}\uFF09`;
    switch (code) {
      case "NOT_MEDCLOUD":
        return "\u76EE\u524D\u5206\u9801\u4E0D\u662F\u96F2\u7AEF\u75C5\u6B77\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u5F8C\u518D\u8A66\u3002";
      case "PATIENT_CONTEXT_UNAVAILABLE":
        return `\u9801\u9762\u5DF2\u958B\u555F\uFF0C\u4F46\u5C1A\u672A\u5075\u6E2C\u5230\u552F\u4E00\u7684\u76EE\u524D\u75C5\u4EBA ${diagnostic(code)}\uFF1B\u8ACB\u78BA\u8A8D\u8B80\u5361\u5B8C\u6210\u4E14\u75C5\u4EBA\u8CC7\u6599\u5DF2\u986F\u793A\u3002`;
      case "PATIENT_CONTEXT_CHANGED":
        return `\u53D6\u5F97\u671F\u9593\u75C5\u4EBA\u5DF2\u5207\u63DB ${diagnostic(code)}\uFF1B\u672C\u6B21\u7D50\u679C\u5DF2\u4F5C\u5EE2\uFF0C\u8ACB\u78BA\u8A8D\u75C5\u4EBA\u5F8C\u91CD\u8A66\u3002`;
      case "AUTHORIZATION_UNAVAILABLE":
        return `\u5DF2\u5075\u6E2C\u5230\u76EE\u524D\u75C5\u4EBA\uFF0C\u4F46\u9801\u9762\u6C92\u6709\u9001\u51FA\u53EF\u4F9B\u64F7\u53D6\u7684 API \u6388\u6B0A ${diagnostic(code)}\u3002\u9019\u4E0D\u4EE3\u8868\u672A\u767B\u5165\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u96F2\u7AEF\u75C5\u6B77\uFF0C\u6216\u5148\u5207\u63DB\u4EFB\u4E00\u75C5\u6B77\u529F\u80FD\u5F8C\u518D\u8A66\u3002`;
      case "AUTHORIZATION_FAILED":
        return `${modulePrefix}\u5065\u4FDD API \u62D2\u7D55\u76EE\u524D\u6388\u6B0A ${diagnostic(code)}\u3002\u9801\u9762\u53EF\u80FD\u4ECD\u986F\u793A\u5DF2\u767B\u5165\uFF1B\u8ACB\u5148\u91CD\u65B0\u6574\u7406\uFF0C\u82E5\u4ECD\u5931\u6557\u518D\u91CD\u65B0\u767B\u5165\u3002`;
      case "RESPONSE_SHAPE_INVALID":
        return `${modulePrefix}\u56DE\u50B3\u683C\u5F0F\u8207\u76EE\u524D\u652F\u63F4\u683C\u5F0F\u4E0D\u7B26 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u6A21\u7D44\u540D\u7A31\u3002`;
      case "CAPTURE_INJECTION_FAILED":
        return `\u64F4\u5145\u529F\u80FD\u7121\u6CD5\u5728\u76EE\u524D\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\u555F\u52D5\u64F7\u53D6\u7A0B\u5F0F ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u8A72\u5206\u9801\u5F8C\u518D\u8A66\u3002`;
      case "CAPTURE_RESULT_MISSING":
        return `\u96F2\u7AEF\u75C5\u6B77\u5206\u9801\u6C92\u6709\u56DE\u50B3\u64F7\u53D6\u7D50\u679C ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u5206\u9801\u8207\u64F4\u5145\u529F\u80FD\u5F8C\u518D\u8A66\u3002`;
      case "CAPTURE_FAILED":
        return `${modulePrefix}\u8CC7\u6599\u8ACB\u6C42\u672A\u5B8C\u6210 ${diagnostic(code)}\uFF1B\u8ACB\u78BA\u8A8D\u7DB2\u8DEF\u8207\u5206\u9801\u4ECD\u958B\u555F\u5F8C\u518D\u8A66\u3002`;
      case "SOURCE_ENVELOPE_INVALID":
        return `${modulePrefix}\u8CC7\u6599\u5C01\u88DD\u9A57\u8B49\u5931\u6557 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u6A21\u7D44\u540D\u7A31\u3002`;
      case "NO_MODULE_DATA":
        return `\u96F2\u7AEF\u75C5\u6B77\u6C92\u6709\u56DE\u50B3\u4EFB\u4F55\u53EF\u8655\u7406\u6A21\u7D44 ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u5F8C\u91CD\u8A66\u3002`;
      case "MODULE_ADAPTATION_FAILED":
        return `${modulePrefix}\u8CC7\u6599\u8F49\u63DB\u5931\u6557 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u8207\u6A21\u7D44\u540D\u7A31\u3002`;
      case "FHIR_MAPPING_FAILED":
        return `FHIR \u7D44\u88DD\u6216\u5B8C\u6574\u6027\u6AA2\u67E5\u5931\u6557 ${diagnostic(code)}\uFF1B\u9019\u4E0D\u662F\u767B\u5165\u554F\u984C\uFF0C\u8ACB\u56DE\u5831\u6B64\u932F\u8AA4\u4EE3\u78BC\u3002`;
      case "ALL_MODULES_FAILED":
        return `\u6240\u6709\u96F2\u7AEF\u75C5\u6B77\u6A21\u7D44\u90FD\u6C92\u6709\u53D6\u5F97\u53EF\u7528\u8CC7\u6599 ${diagnostic(code)}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u5F8C\u91CD\u8A66\uFF0C\u82E5\u6301\u7E8C\u767C\u751F\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u3002`;
      default:
        if (name === "PatientContextChangedError") {
          return `\u53D6\u5F97\u671F\u9593\u75C5\u4EBA\u5DF2\u5207\u63DB ${diagnostic("PATIENT_CONTEXT_CHANGED")}\uFF1B\u672C\u6B21\u7D50\u679C\u5DF2\u4F5C\u5EE2\uFF0C\u8ACB\u78BA\u8A8D\u75C5\u4EBA\u5F8C\u91CD\u8A66\u3002`;
        }
        if (name === "IncompleteModuleError") {
          const moduleCount = Array.isArray(candidate?.modules) ? candidate.modules.length : 0;
          const scope = moduleCount > 0 ? `\u5168\u90E8 ${moduleCount} \u500B` : "\u6240\u6709";
          return `${scope}\u96F2\u7AEF\u75C5\u6B77\u6A21\u7D44\u90FD\u6C92\u6709\u53D6\u5F97\u53EF\u7528\u8CC7\u6599 ${diagnostic("ALL_MODULES_FAILED")}\uFF1B\u8ACB\u91CD\u65B0\u6574\u7406\u5F8C\u91CD\u8A66\u3002`;
        }
        return `\u80CC\u666F\u8655\u7406\u767C\u751F\u672A\u5206\u985E\u932F\u8AA4 ${diagnostic("BACKGROUND_JOB_FAILED")}\uFF1B\u9019\u4E0D\u4EE3\u8868\u672A\u767B\u5165\uFF0C\u8ACB\u91CD\u65B0\u6574\u7406\u5206\u9801\u5F8C\u518D\u8A66\uFF0C\u82E5\u6301\u7E8C\u767C\u751F\u8ACB\u56DE\u5831\u6B64\u4EE3\u78BC\u3002`;
    }
  }

  // src/mediprisma.ts
  var MEDIPRISMA_APP_URL = "https://mediprisma.tw/app/";
  var MEDIPRISMA_APP_PATHS = ["/app", "/app/"];
  var MEDIPRISMA_IMPORT_INPUT_SELECTOR = '[data-testid="import-bundle-input"]';
  var MEDIPRISMA_IMPORT_SETTLED_EVENT = "mediprisma:local-bundle-change-settled";
  var MEDIPRISMA_PAGE_READY_TIMEOUT_MS = 3e4;
  var MEDIPRISMA_INPUT_TIMEOUT_MS = 2e4;
  var MEDIPRISMA_IMPORT_TIMEOUT_MS = 18e4;
  var MEDCLOUD_ORIGIN2 = "https://medcloud2.nhi.gov.tw";
  var MEDIPRISMA_SITE_PATTERN = /^[a-z0-9][a-z0-9_-]{0,31}$/i;
  var MEDIPRISMA_CONTROL_PARAMS = /* @__PURE__ */ new Set(["medcloud2", "site"]);
  function grantsMediPrismaAppAccess(matchPattern) {
    if (matchPattern === "<all_urls>") return true;
    const parsed = /^(\*|https):\/\/(\*|(?:\*\.)?mediprisma\.tw)(\/[^\s]*)$/.exec(matchPattern);
    if (!parsed) return false;
    const pathPattern = parsed[3] ?? "";
    const matcher = new RegExp(
      `^${pathPattern.split("*").map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*")}$`
    );
    return MEDIPRISMA_APP_PATHS.some((path) => matcher.test(path));
  }
  function buildMediPrismaAppUrlFromMediCloud(rawSourceUrl) {
    try {
      const source = new URL(rawSourceUrl);
      if (source.origin !== MEDCLOUD_ORIGIN2 || !source.pathname.startsWith("/imu/") || source.searchParams.getAll("type").length !== 1 || source.searchParams.get("type")?.toLowerCase() !== "icc" || source.searchParams.getAll("medcloud2").length !== 1 || source.searchParams.get("medcloud2") !== "auto") {
        return MEDIPRISMA_APP_URL;
      }
      const target = new URL(MEDIPRISMA_APP_URL);
      target.searchParams.set("medcloud2", "auto");
      const sites = source.searchParams.getAll("site");
      const site = sites.length === 1 ? sites[0]?.trim() : void 0;
      if (site && MEDIPRISMA_SITE_PATTERN.test(site)) {
        target.searchParams.set("site", site.toLowerCase());
      }
      return target.toString();
    } catch {
      return MEDIPRISMA_APP_URL;
    }
  }
  function isAllowedMediPrismaAppUrl(raw) {
    try {
      const url = new URL(raw ?? "");
      if (url.origin === "https://mediprisma.tw" && (url.pathname === "/app" || url.pathname === "/app/") && url.hash === "") {
        const keys = [];
        url.searchParams.forEach((_value, key) => keys.push(key));
        if (keys.some((key) => !MEDIPRISMA_CONTROL_PARAMS.has(key))) return false;
        if (keys.length === 0) return true;
        const modes = url.searchParams.getAll("medcloud2");
        const sites = url.searchParams.getAll("site");
        return modes.length === 1 && modes[0] === "auto" && sites.length <= 1 && (sites.length === 0 || MEDIPRISMA_SITE_PATTERN.test(sites[0] ?? ""));
      }
      return false;
    } catch {
      return false;
    }
  }
  function isStandaloneMediPrismaUrl(raw, expectedAppUrl = MEDIPRISMA_APP_URL) {
    if (!isAllowedMediPrismaAppUrl(raw) || !isAllowedMediPrismaAppUrl(expectedAppUrl)) {
      return false;
    }
    const current = new URL(raw);
    const expected = new URL(expectedAppUrl);
    return current.origin === expected.origin && ["/app", "/app/"].includes(current.pathname) && current.searchParams.get("medcloud2") === expected.searchParams.get("medcloud2") && current.searchParams.get("site") === expected.searchParams.get("site");
  }
  function startMediPrismaImport(payload) {
    const showFailure = (message) => {
      document.getElementById("cloud-wildcatch-mediprisma-handoff-error")?.remove();
      const notice = document.createElement("div");
      notice.id = "cloud-wildcatch-mediprisma-handoff-error";
      notice.setAttribute("role", "alert");
      notice.textContent = `\u96F2\u7AEF\u61F7\u723E\u6293\u6293\uFF1A${message}`;
      Object.assign(notice.style, {
        position: "fixed",
        top: "16px",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: "2147483647",
        maxWidth: "min(560px, calc(100vw - 32px))",
        padding: "12px 16px",
        border: "1px solid #fecaca",
        borderRadius: "10px",
        background: "#fff7ed",
        color: "#9a3412",
        font: "14px/1.5 system-ui, sans-serif",
        boxShadow: "0 8px 24px rgba(0,0,0,.16)"
      });
      document.body.appendChild(notice);
    };
    const failure = (code, message) => {
      return Object.assign(new Error(message), { code });
    };
    const waitForInput = async () => {
      const existing = document.querySelector(payload.inputSelector);
      if (existing) return existing;
      return new Promise((resolve, reject) => {
        let settled = false;
        const observer = new MutationObserver(() => {
          const input = document.querySelector(payload.inputSelector);
          if (input) finish(input);
        });
        const finish = (input, error) => {
          if (settled) return;
          settled = true;
          observer.disconnect();
          clearTimeout(timer);
          if (error) reject(error);
          else if (input) resolve(input);
        };
        const timer = window.setTimeout(
          () => finish(void 0, failure("IMPORT_INPUT_MISSING", "\u627E\u4E0D\u5230 MediPrisma \u7684\u5065\u5EB7\u7D00\u9304\u532F\u5165\u5143\u4EF6")),
          payload.inputTimeoutMs
        );
        observer.observe(document.documentElement, { childList: true, subtree: true });
      });
    };
    const waitForImport = () => {
      return new Promise((resolve, reject) => {
        let settled = false;
        const cleanup = () => {
          window.removeEventListener(payload.settledEvent, onSettled);
          clearTimeout(timer);
        };
        const finish = (error) => {
          if (settled) return;
          settled = true;
          cleanup();
          if (error) reject(error);
          else resolve();
        };
        const onSettled = () => finish();
        const timer = window.setTimeout(
          () => finish(failure("IMPORT_TIMEOUT", "MediPrisma \u532F\u5165\u903E\u6642")),
          payload.importTimeoutMs
        );
        window.addEventListener(payload.settledEvent, onSettled, { once: true });
      });
    };
    void (async () => {
      const currentUrl = new URL(location.href);
      const expectedUrl = new URL(payload.appUrl);
      if (currentUrl.origin !== expectedUrl.origin || !["/app", "/app/"].includes(currentUrl.pathname) || currentUrl.search !== expectedUrl.search || currentUrl.hash !== "") {
        throw failure("IMPORT_CONTEXT_INVALID", "\u9801\u9762\u4F86\u6E90\u4E0D\u7B26\uFF0C\u5DF2\u505C\u6B62\u50B3\u9001\u5065\u5EB7\u7D00\u9304");
      }
      const input = await waitForInput();
      const file = new File([payload.json], payload.filename, {
        type: "application/fhir+json"
      });
      const transfer = new DataTransfer();
      transfer.items.add(file);
      const imported = waitForImport();
      input.files = transfer.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      await imported;
      payload.json = "";
      await chrome.runtime.sendMessage({
        type: payload.settledMessageType,
        runId: payload.runId,
        handoffToken: payload.handoffToken,
        ok: true
      });
    })().catch(async (error) => {
      payload.json = "";
      const code = error && typeof error === "object" && "code" in error && [
        "IMPORT_CONTEXT_INVALID",
        "IMPORT_INPUT_MISSING",
        "IMPORT_TIMEOUT",
        "IMPORT_FAILED"
      ].includes(String(error.code)) ? String(error.code) : "IMPORT_FAILED";
      const detail = error instanceof Error ? error.message : "\u7121\u6CD5\u5728 MediPrisma \u67E5\u770B";
      showFailure(`${detail}\u3002\u8ACB\u56DE\u5230\u300C\u96F2\u7AEF\u61F7\u723E\u6293\u6293\u300D\u4E0B\u8F09\u5065\u5EB7\u7D00\u9304\u6A94\u5F8C\u624B\u52D5\u532F\u5165\u3002`);
      await chrome.runtime.sendMessage({
        type: payload.settledMessageType,
        runId: payload.runId,
        handoffToken: payload.handoffToken,
        ok: false,
        errorCode: code
      }).catch(() => void 0);
    });
    return { started: true };
  }

  // src/background-job.ts
  var BACKGROUND_JOB_STATUS_KEY = "cloud-wildcatch:medcloud-job-status-v1";
  var BACKGROUND_JOB_REQUEST_KEY = "cloud-wildcatch:medcloud-job-request-v1";
  var BACKGROUND_JOB_RESULT_KEY = "cloud-wildcatch:medcloud-job-result-v1";
  var BACKGROUND_RESULT_ENCRYPTION_KEY = "cloud-wildcatch:result-encryption-key-v1";
  var START_BACKGROUND_JOB = "medcloud:start-background-job";
  var MARK_BACKGROUND_JOB_DOWNLOADED = "medcloud:mark-background-job-downloaded";
  var CLEAR_BACKGROUND_JOB = "medcloud:clear-background-job";
  var ARM_MEDIPRISMA_HANDOFF = "medcloud:arm-mediprisma-handoff";
  var DISARM_MEDIPRISMA_HANDOFF = "medcloud:disarm-mediprisma-handoff";
  var OPEN_PENDING_BUNDLE_IN_MEDIPRISMA = "medcloud:open-pending-bundle-in-mediprisma";
  var MEDIPRISMA_HANDOFF_SETTLED = "medcloud:mediprisma-handoff-settled";
  var START_ONE_CLICK_FLOW = "medcloud:start-one-click-flow";
  var GET_ONE_CLICK_FLOW_STATE = "medcloud:get-one-click-flow-state";
  var ONE_CLICK_FLOW_STATE_CHANGED = "medcloud:one-click-flow-state-changed";
  var BACKGROUND_RESULT_TTL_MS = 60 * 60 * 1e3;
  var BACKGROUND_JOB_RECOVERY_WINDOW_MS = 10 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isBackgroundJobRequest(value) {
    if (!isRecord(value) || !isRecord(value.patientIdentity)) return false;
    const identity = value.patientIdentity;
    return typeof value.runId === "string" && value.runId.length >= 8 && Number.isInteger(value.tabId) && Number(value.tabId) > 0 && typeof value.generatedAt === "string" && !Number.isNaN(Date.parse(value.generatedAt)) && typeof value.expectedPatientContextHash === "string" && /^[a-f0-9]{64}$/i.test(value.expectedPatientContextHash) && typeof value.maskNameEnabled === "boolean" && value.includeImagingViewerLinks === true && typeof identity.maskedId === "string" && typeof identity.name === "string" && (identity.birthDate === void 0 || typeof identity.birthDate === "string") && ["male", "female", "other", "unknown"].includes(String(identity.gender)) && (value.deliveryMode === void 0 || ["manual", "mediprisma"].includes(String(value.deliveryMode))) && (value.mediprismaAppUrl === void 0 || typeof value.mediprismaAppUrl === "string" && isAllowedMediPrismaAppUrl(value.mediprismaAppUrl));
  }
  function isBackgroundJobMessage(value) {
    if (!isRecord(value) || typeof value.type !== "string") return false;
    if (value.type === START_BACKGROUND_JOB) return isBackgroundJobRequest(value.payload);
    if (value.type === MARK_BACKGROUND_JOB_DOWNLOADED || value.type === ARM_MEDIPRISMA_HANDOFF) {
      return typeof value.runId === "string" && value.runId.length >= 8;
    }
    if (value.type === CLEAR_BACKGROUND_JOB) {
      return value.runId === void 0 || typeof value.runId === "string";
    }
    if (value.type === DISARM_MEDIPRISMA_HANDOFF || value.type === OPEN_PENDING_BUNDLE_IN_MEDIPRISMA || value.type === START_ONE_CLICK_FLOW || value.type === GET_ONE_CLICK_FLOW_STATE) {
      return true;
    }
    if (value.type === MEDIPRISMA_HANDOFF_SETTLED) {
      return typeof value.runId === "string" && value.runId.length >= 8 && typeof value.handoffToken === "string" && value.handoffToken.length >= 16 && typeof value.ok === "boolean" && (value.errorCode === void 0 || [
        "IMPORT_CONTEXT_INVALID",
        "IMPORT_INPUT_MISSING",
        "IMPORT_TIMEOUT",
        "IMPORT_FAILED"
      ].includes(String(value.errorCode)));
    }
    return false;
  }
  function isBackgroundJobStatus(value) {
    if (!isRecord(value)) return false;
    return value.schemaVersion === 1 && typeof value.runId === "string" && ["running", "complete", "error", "downloaded", "handed-off"].includes(String(value.phase)) && typeof value.patientContextHash === "string" && typeof value.startedAt === "number" && typeof value.updatedAt === "number" && (value.completedAt === void 0 || typeof value.completedAt === "number" && Number.isFinite(value.completedAt)) && typeof value.message === "string" && typeof value.hasResult === "boolean" && typeof value.includeImagingViewerLinks === "boolean" && (value.tabId === void 0 || Number.isInteger(value.tabId) && Number(value.tabId) > 0) && (value.deliveryMode === void 0 || ["manual", "mediprisma"].includes(String(value.deliveryMode))) && (value.downloadedAt === void 0 || typeof value.downloadedAt === "number" && Number.isFinite(value.downloadedAt)) && (value.handedOffAt === void 0 || typeof value.handedOffAt === "number" && Number.isFinite(value.handedOffAt)) && (value.resultBytes === void 0 || Number.isInteger(value.resultBytes) && Number(value.resultBytes) >= 0) && (value.moduleProgress === void 0 || isRecord(value.moduleProgress) && Number.isInteger(value.moduleProgress.completed) && Number(value.moduleProgress.completed) >= 0 && Number.isInteger(value.moduleProgress.total) && Number(value.moduleProgress.total) >= 0 && Number(value.moduleProgress.completed) <= Number(value.moduleProgress.total));
  }
  function isBackgroundJobResult(value) {
    if (!isRecord(value)) return false;
    const hasCommonFields = typeof value.runId === "string" && typeof value.patientContextHash === "string" && typeof value.generatedAt === "number" && typeof value.expiresAt === "number" && typeof value.filename === "string";
    if (!hasCommonFields) return false;
    if (value.schemaVersion === 1) return "bundle" in value;
    const hasValidUncompressedSize = Number.isInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) >= 0;
    if (value.schemaVersion === 2) {
      return value.encoding === "gzip-base64" && typeof value.data === "string" && value.data.length > 0 && hasValidUncompressedSize;
    }
    if (value.schemaVersion === 3) return value.schemaVersion === 3 && value.encoding === "gzip" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && hasValidUncompressedSize;
    return value.schemaVersion === 4 && value.encoding === "gzip+aes-gcm" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && value.iv instanceof ArrayBuffer && value.iv.byteLength === 12 && hasValidUncompressedSize && (value.rawCapture === void 0 || isEncodedRawCapture(value.rawCapture));
  }
  function isEncodedRawCapture(value) {
    if (!isRecord(value)) return false;
    return value.encoding === "gzip+aes-gcm" && value.data instanceof ArrayBuffer && value.data.byteLength > 0 && value.iv instanceof ArrayBuffer && value.iv.byteLength === 12 && Number.isInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) >= 0 && typeof value.filename === "string" && value.filename.length > 0;
  }
  function runningJobStatus(request, startedAt = Date.now(), recovered = false) {
    return {
      schemaVersion: 1,
      runId: request.runId,
      phase: "running",
      patientContextHash: request.expectedPatientContextHash,
      startedAt,
      updatedAt: Date.now(),
      message: recovered ? "\u6B63\u5728\u7E7C\u7E8C\u53D6\u5F97\u96F2\u7AEF\u75C5\u6B77\u8CC7\u6599\u2026" : runningJobElapsedMessage(startedAt, startedAt),
      hasResult: false,
      tabId: request.tabId,
      deliveryMode: request.deliveryMode ?? "manual",
      includeImagingViewerLinks: request.includeImagingViewerLinks
    };
  }
  function runningJobElapsedMessage(startedAt, now = Date.now(), moduleProgress) {
    const elapsedSeconds = Number.isFinite(startedAt) && Number.isFinite(now) ? Math.max(0, Math.floor((now - startedAt) / 1e3)) : 0;
    const progress = moduleProgress && Number.isInteger(moduleProgress.total) && moduleProgress.total > 0 && Number.isInteger(moduleProgress.completed) ? `\uFF08${Math.min(Math.max(0, moduleProgress.completed), moduleProgress.total)}/${moduleProgress.total} \u9805\uFF09` : "";
    return `\u6B63\u5728\u53D6\u5F97\u8CC7\u6599 ${elapsedSeconds} \u79D2${progress}\uFF0C\u53EF\u95DC\u9589\u8996\u7A97\u3002`;
  }
  function safeDiagnosticCode(value) {
    return value && /^[A-Z][A-Z0-9_]{2,63}$/.test(value) ? value : void 0;
  }
  function backgroundErrorLabel(errorCode) {
    if (errorCode?.startsWith("AUTHORIZATION_")) {
      return "API \u6388\u6B0A\u8B80\u53D6\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66";
    }
    if (errorCode?.startsWith("PATIENT_CONTEXT_")) {
      return "\u75C5\u4EBA\u72C0\u614B\u5DF2\u8B8A\u66F4\uFF0C\u9EDE\u6B64\u91CD\u8A66";
    }
    if (errorCode?.startsWith("CAPTURE_") || errorCode === "NOT_MEDCLOUD" || errorCode === "NO_MODULE_DATA") {
      return "\u96F2\u7AEF\u8CC7\u6599\u8B80\u53D6\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66";
    }
    if (errorCode?.startsWith("RESPONSE_") || errorCode === "SOURCE_ENVELOPE_INVALID" || errorCode === "MODULE_ADAPTATION_FAILED" || errorCode === "FHIR_MAPPING_FAILED" || errorCode === "ALL_MODULES_FAILED" || errorCode === "RESULT_INVALID") {
      return "\u8CC7\u6599\u683C\u5F0F\u8655\u7406\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66";
    }
    if (errorCode === "RESULT_STORAGE_FAILED") {
      return "\u7D50\u679C\u66AB\u5B58\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66";
    }
    return "\u80CC\u666F\u8655\u7406\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66";
  }
  function oneClickFlowState(status, tabId, now = Date.now()) {
    if (!status) {
      return {
        phase: "idle",
        label: "\u4E00\u9375\u9001\u5230 MediPrisma",
        detail: "\u53D6\u5F97\u76EE\u524D\u75C5\u4EBA\u7684\u96F2\u7AEF\u75C5\u6B77\uFF0C\u4E26\u5728 MediPrisma \u958B\u555F\u3002",
        canStart: true
      };
    }
    if (status.tabId !== tabId) {
      if (status.phase === "running") {
        return {
          phase: "error",
          label: "\u53E6\u4E00\u500B\u5206\u9801\u6B63\u5728\u8655\u7406",
          detail: "\u8ACB\u7B49\u5F85\u76EE\u524D\u7684\u96F2\u7AEF\u75C5\u6B77\u5DE5\u4F5C\u5B8C\u6210\u5F8C\u518D\u8A66\u3002",
          canStart: false
        };
      }
      return {
        phase: "idle",
        label: "\u4E00\u9375\u9001\u5230 MediPrisma",
        detail: "\u53D6\u5F97\u76EE\u524D\u75C5\u4EBA\u7684\u96F2\u7AEF\u75C5\u6B77\uFF0C\u4E26\u5728 MediPrisma \u958B\u555F\u3002",
        canStart: true
      };
    }
    if (status.phase === "running") {
      const elapsedMessage = runningJobElapsedMessage(
        status.startedAt,
        now,
        status.moduleProgress
      );
      return {
        phase: "running",
        label: elapsedMessage.replace("\uFF0C\u53EF\u95DC\u9589\u8996\u7A97\u3002", "\u2026"),
        detail: elapsedMessage,
        canStart: false
      };
    }
    if (status.phase === "complete" && status.hasResult) {
      if (status.errorCode === "MEDIPRISMA_HANDOFF_FAILED") {
        return {
          phase: "error",
          label: "\u958B\u555F\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66",
          detail: status.message,
          canStart: true,
          diagnosticCode: status.errorCode
        };
      }
      if (status.deliveryMode === "mediprisma") {
        return {
          phase: "opening",
          label: "\u6B63\u5728\u958B\u555F MediPrisma\u2026",
          detail: status.message,
          canStart: false
        };
      }
      return {
        phase: "ready",
        label: "\u5065\u5EB7\u7D00\u9304\u5DF2\u5B8C\u6210\uFF0C\u9EDE\u6B64\u958B\u555F",
        detail: status.message,
        canStart: true
      };
    }
    if (status.phase === "handed-off") {
      return {
        phase: "done",
        label: "\u5DF2\u9001\u5230 MediPrisma",
        detail: status.message,
        canStart: true
      };
    }
    if (status.phase === "error") {
      return {
        phase: "error",
        label: backgroundErrorLabel(status.errorCode),
        detail: status.message,
        canStart: true,
        diagnosticCode: safeDiagnosticCode(status.errorCode)
      };
    }
    return {
      phase: "idle",
      label: "\u4E00\u9375\u9001\u5230 MediPrisma",
      detail: status.message,
      canStart: true
    };
  }
  function isExpiredResult(result, now = Date.now()) {
    return result.expiresAt <= now;
  }
  function hasAvailableBackgroundResult(status) {
    return status.hasResult && ["complete", "downloaded", "handed-off"].includes(status.phase);
  }
  function downloadedJobStatus(status, downloadedAt = Date.now()) {
    if (!hasAvailableBackgroundResult(status)) return null;
    return {
      ...status,
      phase: "downloaded",
      updatedAt: downloadedAt,
      downloadedAt,
      message: "\u6A94\u6848\u4E0B\u8F09\u5DF2\u958B\u59CB\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u518D\u6B21\u4E0B\u8F09\u6216\u5728 MediPrisma \u67E5\u770B\u3002",
      hasResult: true
    };
  }
  function isRecoverableJob(status, request, now = Date.now()) {
    return status.phase === "running" && status.runId === request.runId && status.patientContextHash === request.expectedPatientContextHash && status.includeImagingViewerLinks === request.includeImagingViewerLinks && now - status.updatedAt <= BACKGROUND_JOB_RECOVERY_WINDOW_MS;
  }

  // src/background-result-storage.ts
  var RESULT_DATABASE_NAME = "cloud-wildcatch-background-results-v1";
  var RESULT_DATABASE_VERSION = 1;
  var RESULT_STORE_NAME = "results";
  var CURRENT_RESULT_KEY = "current";
  var databasePromise = null;
  function bytesToBase642(bytes) {
    const chunkSize = 32768;
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
    }
    return btoa(binary);
  }
  function base64ToBytes2(value) {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }
  async function runEncryptionKey(runId) {
    const stored = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
    const keyRecord = stored[BACKGROUND_RESULT_ENCRYPTION_KEY];
    if (isSessionEncryptionKey(keyRecord) && keyRecord.runId === runId) {
      const existing = base64ToBytes2(keyRecord.rawKey);
      const existingBuffer = new ArrayBuffer(existing.byteLength);
      new Uint8Array(existingBuffer).set(existing);
      return crypto.subtle.importKey(
        "raw",
        existingBuffer,
        { name: "AES-GCM" },
        true,
        ["encrypt", "decrypt"]
      );
    }
    const encryptionKey = await crypto.subtle.generateKey(
      { name: "AES-GCM", length: 256 },
      true,
      ["encrypt", "decrypt"]
    );
    const rawKey = new Uint8Array(await crypto.subtle.exportKey("raw", encryptionKey));
    await chrome.storage.session.set({
      [BACKGROUND_RESULT_ENCRYPTION_KEY]: {
        schemaVersion: 1,
        runId,
        rawKey: bytesToBase642(rawKey)
      }
    });
    return encryptionKey;
  }
  async function encodeBackgroundBundle(bundle, runId) {
    const json = JSON.stringify(bundle);
    if (typeof json !== "string") throw new Error("\u5065\u5EB7\u7D00\u9304\u7121\u6CD5\u5E8F\u5217\u5316");
    return encodeBackgroundText(json, runId);
  }
  async function encodeBackgroundText(json, runId) {
    const uncompressedBytes = new TextEncoder().encode(json).byteLength;
    const compressedStream = new Blob([json]).stream().pipeThrough(new CompressionStream("gzip"));
    const compressed = await new Response(compressedStream).arrayBuffer();
    const encryptionKey = await runEncryptionKey(runId);
    const ivBytes = crypto.getRandomValues(new Uint8Array(12));
    const iv = new ArrayBuffer(ivBytes.byteLength);
    new Uint8Array(iv).set(ivBytes);
    const data = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: ivBytes },
      encryptionKey,
      compressed
    );
    return {
      encoding: "gzip+aes-gcm",
      data,
      iv,
      uncompressedBytes
    };
  }
  async function decodeBackgroundBundle(result) {
    if (result.schemaVersion === 1) return JSON.stringify(result.bundle);
    let compressedBuffer;
    if (result.schemaVersion === 2) {
      const compressed = base64ToBytes2(result.data);
      compressedBuffer = new ArrayBuffer(compressed.byteLength);
      new Uint8Array(compressedBuffer).set(compressed);
    } else if (result.schemaVersion === 3) {
      compressedBuffer = result.data;
    } else {
      const stored = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
      const keyRecord = stored[BACKGROUND_RESULT_ENCRYPTION_KEY];
      if (!isSessionEncryptionKey(keyRecord) || keyRecord.runId !== result.runId) {
        throw new Error("\u9019\u6B21\u5065\u5EB7\u7D00\u9304\u7684\u66AB\u5B58\u89E3\u5BC6\u91D1\u9470\u5DF2\u5931\u6548");
      }
      const rawKey = base64ToBytes2(keyRecord.rawKey);
      const rawKeyBuffer = new ArrayBuffer(rawKey.byteLength);
      new Uint8Array(rawKeyBuffer).set(rawKey);
      const encryptionKey = await crypto.subtle.importKey(
        "raw",
        rawKeyBuffer,
        { name: "AES-GCM" },
        false,
        ["decrypt"]
      );
      compressedBuffer = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: new Uint8Array(result.iv) },
        encryptionKey,
        result.data
      );
    }
    const json = await new Response(
      new Blob([compressedBuffer]).stream().pipeThrough(new DecompressionStream("gzip"))
    ).text();
    const actualBytes = new TextEncoder().encode(json).byteLength;
    if (actualBytes !== result.uncompressedBytes) {
      throw new Error("\u66AB\u5B58\u5065\u5EB7\u7D00\u9304\u5927\u5C0F\u4E0D\u7B26");
    }
    if (result.schemaVersion !== 4) JSON.parse(json);
    return json;
  }
  function openResultDatabase() {
    if (databasePromise) return databasePromise;
    const opening = new Promise((resolve, reject) => {
      const request = indexedDB.open(RESULT_DATABASE_NAME, RESULT_DATABASE_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(RESULT_STORE_NAME)) {
          database.createObjectStore(RESULT_STORE_NAME, { keyPath: "key" });
        }
      };
      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => {
          database.close();
          databasePromise = null;
        };
        resolve(database);
      };
      request.onerror = () => reject(request.error ?? new Error("\u7121\u6CD5\u958B\u555F\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593"));
      request.onblocked = () => reject(new Error("\u75C5\u6B77\u66AB\u5B58\u7A7A\u9593\u6B63\u5728\u66F4\u65B0\uFF0C\u8ACB\u7A0D\u5F8C\u518D\u8A66"));
    }).catch((error) => {
      databasePromise = null;
      throw error;
    });
    databasePromise = opening;
    return opening;
  }
  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u64CD\u4F5C\u5931\u6557"));
    });
  }
  function transactionComplete(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u5931\u6557"));
      transaction.onabort = () => reject(transaction.error ?? new Error("\u75C5\u6B77\u66AB\u5B58\u4EA4\u6613\u5DF2\u4E2D\u6B62"));
    });
  }
  async function writeBackgroundResult(result) {
    const database = await openResultDatabase();
    const transaction = database.transaction(RESULT_STORE_NAME, "readwrite");
    transaction.objectStore(RESULT_STORE_NAME).put({
      key: CURRENT_RESULT_KEY,
      result
    });
    await transactionComplete(transaction);
  }
  async function readBackgroundResult(runId) {
    const database = await openResultDatabase();
    const transaction = database.transaction(RESULT_STORE_NAME, "readonly");
    const completed = transactionComplete(transaction);
    const record = await requestResult(
      transaction.objectStore(RESULT_STORE_NAME).get(CURRENT_RESULT_KEY)
    );
    await completed;
    if (!record || !isStoredResultRecord(record)) return null;
    if (runId && record.result.runId !== runId) return null;
    return record.result;
  }
  async function clearExpiredBackgroundResult(now = Date.now()) {
    const record = await readBackgroundResult();
    if (!record || record.expiresAt > now) return false;
    await clearBackgroundResults(record.runId);
    return true;
  }
  async function clearBackgroundResults(runId) {
    const database = await openResultDatabase();
    const transaction = database.transaction(RESULT_STORE_NAME, "readwrite");
    const completed = transactionComplete(transaction);
    const store = transaction.objectStore(RESULT_STORE_NAME);
    if (runId) {
      const record = await requestResult(store.get(CURRENT_RESULT_KEY));
      if (!record || !isStoredResultRecord(record) || record.result.runId === runId) {
        store.delete(CURRENT_RESULT_KEY);
      }
    } else {
      store.clear();
    }
    await completed;
    const stored = await chrome.storage.session.get(BACKGROUND_RESULT_ENCRYPTION_KEY);
    const keyRecord = stored[BACKGROUND_RESULT_ENCRYPTION_KEY];
    if (!runId || !isSessionEncryptionKey(keyRecord) || keyRecord.runId === runId) {
      await chrome.storage.session.remove(BACKGROUND_RESULT_ENCRYPTION_KEY);
    }
  }
  function isStoredResultRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    if (record.key !== CURRENT_RESULT_KEY) return false;
    return isBackgroundJobResult(record.result);
  }
  function isSessionEncryptionKey(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return record.schemaVersion === 1 && typeof record.runId === "string" && typeof record.rawKey === "string" && record.rawKey.length > 0;
  }

  // src/mediprisma-handoff.ts
  var MEDIPRISMA_HANDOFF_INTENT_KEY = "cloud-wildcatch:mediprisma-handoff-intent-v1";
  var MEDIPRISMA_HANDOFF_EXPIRY_ALARM = "medcloud-mediprisma-handoff-expiry";
  var MEDIPRISMA_HANDOFF_INTENT_TTL_MS = 2 * 60 * 1e3;
  var MEDIPRISMA_IMPORT_INTENT_TTL_MS = MEDIPRISMA_IMPORT_TIMEOUT_MS + 6e4;
  var MEDIPRISMA_COMPLETED_INTENT_TTL_MS = 1e4;
  var handoffInFlight = null;
  function isIntent(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const record = value;
    return record.schemaVersion === 1 && ["armed", "running", "importing", "completed"].includes(String(record.state)) && typeof record.runId === "string" && typeof record.expiresAt === "number" && (record.tabId === void 0 || Number.isInteger(record.tabId)) && (record.handoffToken === void 0 || typeof record.handoffToken === "string") && (record.appUrl === void 0 || typeof record.appUrl === "string" && isAllowedMediPrismaAppUrl(record.appUrl));
  }
  async function readIntent() {
    const stored = await chrome.storage.session.get(MEDIPRISMA_HANDOFF_INTENT_KEY);
    const intent = stored[MEDIPRISMA_HANDOFF_INTENT_KEY];
    return isIntent(intent) ? intent : null;
  }
  async function writeIntent(intent) {
    await chrome.storage.session.set({ [MEDIPRISMA_HANDOFF_INTENT_KEY]: intent });
    await chrome.alarms.create(MEDIPRISMA_HANDOFF_EXPIRY_ALARM, {
      when: intent.expiresAt
    });
  }
  async function clearUnsafePendingResult(runId) {
    await clearBackgroundResults(runId).catch(() => void 0);
    await chrome.storage.session.remove([
      BACKGROUND_JOB_STATUS_KEY,
      BACKGROUND_JOB_REQUEST_KEY,
      BACKGROUND_JOB_RESULT_KEY,
      MEDIPRISMA_HANDOFF_INTENT_KEY
    ]);
  }
  async function assertCurrentMediCloudPatient(status) {
    if (!status.tabId) {
      await clearUnsafePendingResult(status.runId);
      throw new Error("\u7121\u6CD5\u78BA\u8A8D\u539F\u59CB MediCloud \u5206\u9801\uFF1B\u5065\u5EB7\u7D00\u9304\u5DF2\u6E05\u9664");
    }
    const probe = await probeMediCloudPatient(status.tabId).catch(() => null);
    if (probe?.ok && probe.patientContextHash === status.patientContextHash) return;
    await clearUnsafePendingResult(status.runId);
    throw new Error("\u76EE\u524D\u75C5\u4EBA\u5DF2\u6539\u8B8A\u6216\u7121\u6CD5\u78BA\u8A8D\uFF1B\u524D\u4E00\u4F4D\u75C5\u4EBA\u7684\u5065\u5EB7\u7D00\u9304\u5DF2\u6E05\u9664");
  }
  async function currentPendingStoredResult(runId) {
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const status = stored[BACKGROUND_JOB_STATUS_KEY];
    const result = await readBackgroundResult(runId);
    if (!isBackgroundJobStatus(status) || status.runId !== runId || !hasAvailableBackgroundResult(status) || !isBackgroundJobResult(result) || result.runId !== runId || result.patientContextHash !== status.patientContextHash || isExpiredResult(result)) {
      if (isBackgroundJobStatus(status) || isBackgroundJobResult(result)) {
        await clearUnsafePendingResult(runId);
      }
      throw new Error("\u76EE\u524D\u6C92\u6709\u53EF\u4F9B MediPrisma \u67E5\u770B\u4E14\u4ECD\u6709\u6548\u7684\u5065\u5EB7\u7D00\u9304");
    }
    await assertCurrentMediCloudPatient(status);
    return { status, result };
  }
  async function currentPendingResult(runId) {
    const { status, result } = await currentPendingStoredResult(runId);
    return {
      status,
      filename: result.filename.endsWith(".json") ? result.filename : "medcloud-fhir-bundle.json",
      json: await decodeBackgroundBundle(result)
    };
  }
  function includesMediPrismaHostPermission(permissions) {
    return (permissions.origins ?? []).some((origin) => grantsMediPrismaAppAccess(origin));
  }
  async function armMediPrismaHandoff(runId, options = {}) {
    const now = options.now ?? Date.now();
    const appUrl = options.appUrl ?? MEDIPRISMA_APP_URL;
    if (!isAllowedMediPrismaAppUrl(appUrl)) {
      throw new Error("MediPrisma \u76EE\u6A19\u7DB2\u5740\u4E0D\u7B26");
    }
    await currentPendingStoredResult(runId);
    const current = await readIntent();
    if (current && current.runId === runId && current.expiresAt > now && (current.state === "running" || current.state === "importing")) {
      return;
    }
    await writeIntent({
      schemaVersion: 1,
      state: "armed",
      runId,
      appUrl,
      expiresAt: now + MEDIPRISMA_HANDOFF_INTENT_TTL_MS
    });
  }
  async function disarmMediPrismaHandoff() {
    const intent = await readIntent();
    if (intent?.state === "importing") return;
    await chrome.storage.session.remove(MEDIPRISMA_HANDOFF_INTENT_KEY);
  }
  async function waitForTabComplete(tabId, timeoutMs = MEDIPRISMA_PAGE_READY_TIMEOUT_MS) {
    const current = await chrome.tabs.get(tabId);
    if (current.status === "complete") return;
    await new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        clearTimeout(timer);
      };
      const finish = (error) => {
        if (settled) return;
        settled = true;
        cleanup();
        if (error) reject(error);
        else resolve();
      };
      const onUpdated = (updatedId, changeInfo) => {
        if (updatedId === tabId && changeInfo.status === "complete") finish();
      };
      const timer = setTimeout(
        () => finish(new Error("MediPrisma \u9801\u9762\u8F09\u5165\u903E\u6642")),
        timeoutMs
      );
      chrome.tabs.onUpdated.addListener(onUpdated);
    });
  }
  async function updatePendingStatus(runId, message, errorCode) {
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const status = stored[BACKGROUND_JOB_STATUS_KEY];
    if (!isBackgroundJobStatus(status) || status.runId !== runId || !hasAvailableBackgroundResult(status)) {
      return;
    }
    await chrome.storage.session.set({
      [BACKGROUND_JOB_STATUS_KEY]: {
        ...status,
        phase: "complete",
        updatedAt: Date.now(),
        message,
        errorCode
      }
    });
  }
  async function startHandoff(runId, appUrl) {
    const pending = await currentPendingResult(runId);
    const tab = await chrome.tabs.create({ url: appUrl, active: false });
    if (tab.id == null) throw new Error("\u7121\u6CD5\u5EFA\u7ACB MediPrisma \u5206\u9801");
    const tabId = tab.id;
    try {
      await waitForTabComplete(tabId);
      const readyTab = await chrome.tabs.get(tabId);
      if (!isStandaloneMediPrismaUrl(readyTab.url, appUrl)) {
        throw new Error("MediPrisma \u5206\u9801\u5DF2\u96E2\u958B\u672C\u5730\u532F\u5165\u9996\u9801\uFF0C\u5DF2\u505C\u6B62\u50B3\u9001\u5065\u5EB7\u7D00\u9304");
      }
      await assertCurrentMediCloudPatient(pending.status);
      const handoffToken = crypto.randomUUID();
      await writeIntent({
        schemaVersion: 1,
        state: "importing",
        runId,
        tabId,
        handoffToken,
        appUrl,
        expiresAt: Date.now() + MEDIPRISMA_IMPORT_INTENT_TTL_MS
      });
      const payload = {
        runId,
        handoffToken,
        filename: pending.filename,
        json: pending.json,
        appUrl,
        inputSelector: MEDIPRISMA_IMPORT_INPUT_SELECTOR,
        settledEvent: MEDIPRISMA_IMPORT_SETTLED_EVENT,
        inputTimeoutMs: MEDIPRISMA_INPUT_TIMEOUT_MS,
        importTimeoutMs: MEDIPRISMA_IMPORT_TIMEOUT_MS,
        settledMessageType: MEDIPRISMA_HANDOFF_SETTLED
      };
      const injection = await chrome.scripting.executeScript({
        target: { tabId },
        world: "ISOLATED",
        func: startMediPrismaImport,
        args: [payload]
      });
      if (!injection.some((item) => item.result?.started === true)) {
        throw new Error("MediPrisma \u532F\u5165\u7A0B\u5F0F\u672A\u555F\u52D5");
      }
      await chrome.tabs.update(tabId, { active: true });
      return { tabId };
    } catch (error) {
      await chrome.storage.session.remove(MEDIPRISMA_HANDOFF_INTENT_KEY).catch(() => void 0);
      await updatePendingStatus(
        runId,
        "\u7121\u6CD5\u5728 MediPrisma \u958B\u555F\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002",
        "MEDIPRISMA_HANDOFF_FAILED"
      ).catch(() => void 0);
      await chrome.tabs.update(tabId, { active: true }).catch(() => void 0);
      throw error;
    }
  }
  function resumeArmedMediPrismaHandoff(now = Date.now()) {
    if (handoffInFlight) return handoffInFlight;
    const task = (async () => {
      const intent = await readIntent();
      if (!intent || intent.expiresAt <= now) {
        await chrome.storage.session.remove(MEDIPRISMA_HANDOFF_INTENT_KEY);
        if (intent && intent.state !== "completed") {
          await updatePendingStatus(
            intent.runId,
            "MediPrisma \u67E5\u770B\u8981\u6C42\u5DF2\u903E\u6642\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u91CD\u8A66\u6216\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002",
            "MEDIPRISMA_HANDOFF_FAILED"
          ).catch(() => void 0);
        }
        throw new Error("MediPrisma \u67E5\u770B\u8981\u6C42\u5DF2\u5931\u6548\uFF0C\u8ACB\u91CD\u65B0\u6309\u4E00\u6B21\u6309\u9215");
      }
      if ((intent.state === "importing" || intent.state === "completed") && typeof intent.tabId === "number") {
        await chrome.tabs.update(intent.tabId, { active: true }).catch(() => void 0);
        return { tabId: intent.tabId };
      }
      await writeIntent({
        ...intent,
        state: "running",
        expiresAt: now + MEDIPRISMA_HANDOFF_INTENT_TTL_MS
      });
      return startHandoff(intent.runId, intent.appUrl ?? MEDIPRISMA_APP_URL);
    })();
    const tracked = task.finally(() => {
      if (handoffInFlight === tracked) handoffInFlight = null;
    });
    handoffInFlight = tracked;
    return tracked;
  }
  function senderMatchesIntent(sender, intent) {
    return intent.state === "importing" && typeof intent.tabId === "number" && sender.tab?.id === intent.tabId && (sender.frameId === void 0 || sender.frameId === 0) && isStandaloneMediPrismaUrl(sender.url, intent.appUrl ?? MEDIPRISMA_APP_URL);
  }
  async function settleMediPrismaHandoff(message, sender, now = Date.now()) {
    const intent = await readIntent();
    if (!intent || intent.expiresAt <= now || intent.runId !== message.runId || intent.handoffToken !== message.handoffToken || !senderMatchesIntent(sender, intent)) {
      throw new Error("MediPrisma \u532F\u5165\u5B8C\u6210\u8A0A\u606F\u8207\u76EE\u524D\u5DE5\u4F5C\u4E0D\u7B26");
    }
    if (!message.ok) {
      await chrome.storage.session.remove(MEDIPRISMA_HANDOFF_INTENT_KEY);
      await updatePendingStatus(
        message.runId,
        "MediPrisma \u672A\u5B8C\u6210\u532F\u5165\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002",
        "MEDIPRISMA_HANDOFF_FAILED"
      );
      return "failed";
    }
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const status = stored[BACKGROUND_JOB_STATUS_KEY];
    const result = await readBackgroundResult(message.runId);
    if (!isBackgroundJobStatus(status) || status.runId !== message.runId || !hasAvailableBackgroundResult(status) || !isBackgroundJobResult(result) || result.runId !== message.runId) {
      throw new Error("MediPrisma \u532F\u5165\u5B8C\u6210\u6642\uFF0C\u539F\u59CB\u5065\u5EB7\u7D00\u9304\u5DF2\u4E0D\u5B58\u5728");
    }
    await chrome.storage.session.set({
      [BACKGROUND_JOB_STATUS_KEY]: {
        ...status,
        phase: "handed-off",
        updatedAt: now,
        handedOffAt: now,
        message: "\u5DF2\u5728 MediPrisma \u958B\u555F\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u518D\u6B21\u67E5\u770B\u6216\u4E0B\u8F09\u3002",
        hasResult: true
      },
      [MEDIPRISMA_HANDOFF_INTENT_KEY]: {
        schemaVersion: 1,
        state: "completed",
        runId: message.runId,
        tabId: intent.tabId,
        appUrl: intent.appUrl,
        expiresAt: now + MEDIPRISMA_COMPLETED_INTENT_TTL_MS
      }
    });
    return "complete";
  }
  async function sweepMediPrismaHandoffIntent(now = Date.now()) {
    const intent = await readIntent();
    if (!intent || intent.expiresAt > now) return;
    await chrome.storage.session.remove(MEDIPRISMA_HANDOFF_INTENT_KEY);
    if (intent.state === "completed") return;
    await updatePendingStatus(
      intent.runId,
      "MediPrisma \u672A\u56DE\u5831\u532F\u5165\u7D50\u679C\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u53EF\u91CD\u8A66\u6216\u4E0B\u8F09\u5F8C\u624B\u52D5\u532F\u5165\u3002",
      "MEDIPRISMA_HANDOFF_FAILED"
    ).catch(() => void 0);
  }

  // src/imaging-viewer.ts
  function mintFailure(error) {
    if (error instanceof MediCloudAcquisitionError) {
      if (error.code === "AUTHORIZATION_UNAVAILABLE" || error.code === "AUTHORIZATION_FAILED") {
        return { ok: false, code: "SESSION_EXPIRED" };
      }
      if (error.code === "PATIENT_CONTEXT_CHANGED" || error.code === "PATIENT_CONTEXT_UNAVAILABLE" || error.code === "NOT_MEDCLOUD") {
        return { ok: false, code: "PATIENT_MISMATCH" };
      }
      if (error.code === "VIEWER_REQUEST_INVALID") {
        return { ok: false, code: "INVALID_REQUEST" };
      }
    }
    return { ok: false, code: "VIEWER_UNAVAILABLE" };
  }
  async function openNhiViewerFromMediPrisma(message, dependencies) {
    const tabs = (await dependencies.queryMediCloudTabs()).filter(
      (tab) => Number.isInteger(tab.id) && Number(tab.id) > 0
    );
    if (tabs.length === 0) return { ok: false, code: "MEDCLOUD_TAB_NOT_FOUND" };
    const probes = await Promise.all(tabs.map(async (tab) => ({
      tab,
      probe: await dependencies.probePatient(tab.id)
    })));
    const matches = probes.filter(
      (candidate) => candidate.probe.ok && candidate.probe.patientContextHash.toLowerCase() === message.patientContextHash.toLowerCase()
    );
    if (matches.length === 0) return { ok: false, code: "PATIENT_MISMATCH" };
    const selected = matches.find((candidate) => candidate.tab.active) ?? matches[0];
    if (!selected) return { ok: false, code: "PATIENT_MISMATCH" };
    let viewerUrl;
    try {
      viewerUrl = await dependencies.mintViewerUrl(
        selected.tab.id,
        message.patientContextHash,
        message.descriptor
      );
    } catch (error) {
      return mintFailure(error);
    }
    try {
      await dependencies.openTab(viewerUrl);
    } catch {
      return { ok: false, code: "OPEN_FAILED" };
    }
    return { ok: true };
  }

  // src/mediprisma-viewer-protocol.ts
  var OPEN_NHI_VIEWER = "medcloud:open-nhi-viewer";
  function isRecord2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function safePart(value, maxLength) {
    return typeof value === "string" && value.length <= maxLength && !/[\u0000-\u001f\u007f@]/u.test(value);
  }
  function isNhiImagingViewerRequestDescriptor(value) {
    if (!isRecord2(value)) return false;
    return value.version === 1 && value.procId === "IMUE0130" && safePart(value.iplCaseSeqNo, 256) && value.iplCaseSeqNo.length > 0 && safePart(value.readPos, 128) && (value.ordMark === "" || value.ordMark === "Y") && safePart(value.fileType, 128) && safePart(value.fileQty, 32) && safePart(value.feeYm, 64);
  }
  function isRequestId(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{8,128}$/u.test(value);
  }
  function isPatientContextHash(value) {
    return typeof value === "string" && /^[a-f0-9]{64}$/iu.test(value);
  }
  function isOpenNhiViewerRuntimeMessage(value) {
    return isRecord2(value) && value.type === OPEN_NHI_VIEWER && isRequestId(value.requestId) && isPatientContextHash(value.patientContextHash) && isNhiImagingViewerRequestDescriptor(value.descriptor);
  }

  // src/winforms-url-automation.ts
  var WINFORMS_PATIENT_WAIT_TIMEOUT_MS = 3e4;
  var WINFORMS_PATIENT_RETRY_INTERVAL_MS = 500;
  var MEDCLOUD_HOST = "medcloud2.nhi.gov.tw";
  var MEDIPRISMA_HOST = "mediprisma.tw";
  function isWinFormsCloseSignalUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      return url.hostname === MEDCLOUD_HOST && url.searchParams.get("medcloud2") === "close";
    } catch {
      return false;
    }
  }
  function isManagedClinicalTabUrl(rawUrl) {
    if (!rawUrl) return false;
    try {
      const url = new URL(rawUrl);
      return url.hostname === MEDCLOUD_HOST || url.hostname === MEDIPRISMA_HOST || url.hostname.endsWith(`.${MEDIPRISMA_HOST}`);
    } catch {
      return false;
    }
  }
  async function closeManagedClinicalTabs(triggerTabId, tabsApi = chrome.tabs) {
    const tabs = await tabsApi.query({});
    const tabIds = tabs.filter((tab) => tab.id !== void 0 && isManagedClinicalTabUrl(tab.url)).map((tab) => tab.id);
    if (!tabIds.includes(triggerTabId)) tabIds.push(triggerTabId);
    if (tabIds.length > 0) await tabsApi.remove(tabIds);
  }
  async function waitForMediCloudPatient(tabId, probe, options = {}) {
    const timeoutMs = options.timeoutMs ?? WINFORMS_PATIENT_WAIT_TIMEOUT_MS;
    const retryIntervalMs = options.retryIntervalMs ?? WINFORMS_PATIENT_RETRY_INTERVAL_MS;
    const now = options.now ?? Date.now;
    const sleep = options.sleep ?? ((delayMs) => new Promise(
      (resolve) => setTimeout(resolve, delayMs)
    ));
    const deadline = now() + timeoutMs;
    let attempt = 0;
    while (now() < deadline) {
      const patient = await probe(tabId);
      if (patient.ok || patient.code === "NOT_MEDCLOUD") return patient;
      attempt += 1;
      const backoff = attempt <= 6 ? 1 : attempt <= 12 ? 2 : 4;
      await sleep(retryIntervalMs * backoff);
    }
    return probe(tabId);
  }

  // src/background.ts
  var KEEPALIVE_ALARM = "medcloud-background-job-keepalive";
  var RESULT_SWEEP_ALARM = "medcloud-background-result-sweep";
  var RESULT_EXPIRY_ALARM_PREFIX = "medcloud-background-result-expiry:";
  var LEGACY_DATA_CONSENT_STORAGE_KEY = "cloud-wildcatch:data-consent";
  var CAPTURE_PROGRESS_POLL_MS = 2e3;
  function resultExpiryAlarmName(runId) {
    return `${RESULT_EXPIRY_ALARM_PREFIX}${runId}`;
  }
  var activeRunId = "";
  var activeJob = null;
  var jobStarting = false;
  var viewerOpenInFlight = false;
  function oneClickError(label, detail, canStart = true) {
    return { phase: "error", label, detail, canStart };
  }
  function isTrustedMediCloudSender(sender) {
    if (sender.tab?.id == null || sender.frameId !== void 0 && sender.frameId !== 0) {
      return false;
    }
    try {
      const url = new URL(sender.url ?? sender.tab.url ?? "");
      return url.origin === MEDCLOUD_ORIGIN && url.pathname.startsWith("/imu/");
    } catch {
      return false;
    }
  }
  function isTrustedMediPrismaSender(sender) {
    if (sender.tab?.id == null || sender.frameId !== void 0 && sender.frameId !== 0) {
      return false;
    }
    try {
      const url = new URL(sender.url ?? sender.tab.url ?? "");
      return url.origin === "https://mediprisma.tw" && (url.pathname === "/app" || url.pathname === "/app/") && url.hash === "";
    } catch {
      return false;
    }
  }
  async function storedStatus() {
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    return isBackgroundJobStatus(stored[BACKGROUND_JOB_STATUS_KEY]) ? stored[BACKGROUND_JOB_STATUS_KEY] : null;
  }
  async function oneClickStateForTab(tabId) {
    return oneClickFlowState(await storedStatus(), tabId);
  }
  async function notifyOneClickState(tabId) {
    const state = await oneClickStateForTab(tabId);
    await chrome.tabs.sendMessage(tabId, {
      type: ONE_CLICK_FLOW_STATE_CHANGED,
      state
    }).catch(() => void 0);
  }
  function safeErrorMessage(error) {
    const candidate = error;
    const rawCode = candidate?.code;
    const code = typeof rawCode === "string" && /^[A-Z][A-Z0-9_]{2,63}$/.test(rawCode) ? rawCode : candidate?.name === "PatientContextChangedError" ? "PATIENT_CONTEXT_CHANGED" : candidate?.name === "IncompleteModuleError" ? "ALL_MODULES_FAILED" : "BACKGROUND_JOB_FAILED";
    if (code === "RESULT_STORAGE_FAILED") {
      return {
        code,
        message: "\u7121\u6CD5\u4FDD\u7559\u9019\u6B21\u5065\u5EB7\u7D00\u9304\uFF1B\u8ACB\u78BA\u8A8D\u96FB\u8166\u78C1\u789F\u7A7A\u9593\u5145\u8DB3\u5F8C\u91CD\u8A66\u3002"
      };
    }
    if (code === "RESULT_INVALID") {
      return {
        code,
        message: "\u8CC7\u6599\u6AA2\u67E5\u672A\u901A\u904E\uFF0C\u672A\u7522\u751F\u53EF\u4E0B\u8F09\u6A94\u6848\u3002"
      };
    }
    return {
      code,
      message: acquisitionErrorMessage(error)
    };
  }
  async function setBadge(text, color) {
    try {
      await chrome.action.setBadgeText({ text });
      if (color) await chrome.action.setBadgeBackgroundColor({ color });
    } catch {
    }
  }
  async function statusForRun(runId) {
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const candidate = stored[BACKGROUND_JOB_STATUS_KEY];
    return isBackgroundJobStatus(candidate) && candidate.runId === runId ? candidate : null;
  }
  async function publishCaptureProgress(request, isStale) {
    const progress = await readMediCloudCaptureProgress(request.tabId, request.runId);
    const status = await statusForRun(request.runId);
    if (!status || status.phase !== "running") return;
    const moduleProgress = progress && progress.totalModules > 0 ? { completed: progress.completedModules, total: progress.totalModules } : status.moduleProgress;
    const now = Date.now();
    if (isStale()) return;
    await chrome.storage.session.set({
      [BACKGROUND_JOB_STATUS_KEY]: {
        ...status,
        updatedAt: now,
        ...moduleProgress ? { moduleProgress } : {},
        message: runningJobElapsedMessage(status.startedAt, now, moduleProgress)
      }
    });
    await notifyOneClickState(request.tabId);
  }
  async function runBackgroundJob(request) {
    let captureFinished = false;
    const progressTimer = setInterval(() => {
      void publishCaptureProgress(request, () => captureFinished).catch(() => void 0);
    }, CAPTURE_PROGRESS_POLL_MS);
    const stopProgress = () => {
      captureFinished = true;
      clearInterval(progressTimer);
    };
    try {
      const response = await runMediCloudPipeline({
        tabId: request.tabId,
        runId: request.runId,
        generatedAt: request.generatedAt,
        expectedPatientContextHash: request.expectedPatientContextHash,
        maskNameEnabled: request.maskNameEnabled,
        patientIdentity: request.patientIdentity
      });
      stopProgress();
      const current = await statusForRun(request.runId);
      if (!current || current.phase !== "running") return;
      const presentation = presentBundleSummary(response.summary);
      if (!presentation.canDownload) throw Object.assign(new Error("RESULT_INVALID"), { code: "RESULT_INVALID" });
      const encodedBundle = await encodeBackgroundBundle(response.bundle, request.runId);
      const completedAt = Date.now();
      const filename = buildMedcloudFilename(
        request.patientIdentity.maskedId,
        new Date(request.generatedAt),
        chrome.runtime.getManifest().version,
        presentation.hasIncompleteModules
      );
      const incompleteLabels = incompleteModuleLabels(response.summary.moduleStatuses);
      const completionMessage = presentation.hasIncompleteModules ? [
        incompleteLabels ? `\u90E8\u5206\u8CC7\u6599\u672A\u5B8C\u6574\u53D6\u5F97\uFF08${incompleteLabels}\uFF09` : presentation.incompleteModuleCount > 0 ? `\u90E8\u5206\u8CC7\u6599\u672A\u5B8C\u6574\u53D6\u5F97\uFF08${presentation.incompleteModuleCount} \u9805\uFF09` : "\u90E8\u5206\u8CC7\u6599\u672A\u5B8C\u6574\u53D6\u5F97",
        presentation.droppedResourceCount > 0 ? `\uFF0C\u53E6\u6709 ${presentation.droppedResourceCount} \u7B46\u683C\u5F0F\u7121\u6CD5\u8F49\u63DB` : "",
        "\uFF0C\u4ECD\u53EF\u4E0B\u8F09\u6216\u67E5\u770B"
      ].join("") : "\u8CC7\u6599\u5DF2\u6E96\u5099\u5B8C\u6210";
      const encodedRawCapture = response.rawCapture ? await encodeBackgroundText(JSON.stringify(response.rawCapture, null, 2), request.runId).then((encoded) => ({
        ...encoded,
        filename: buildMedcloudRawFilename(
          request.patientIdentity.maskedId,
          new Date(response.rawCapture.capturedAt),
          chrome.runtime.getManifest().version
        )
      })).catch(() => void 0) : void 0;
      const storedResult = {
        schemaVersion: 4,
        runId: request.runId,
        patientContextHash: request.expectedPatientContextHash,
        generatedAt: completedAt,
        expiresAt: completedAt + BACKGROUND_RESULT_TTL_MS,
        filename,
        ...encodedBundle,
        ...encodedRawCapture ? { rawCapture: encodedRawCapture } : {}
      };
      const completedStatus = {
        ...current,
        phase: "complete",
        updatedAt: completedAt,
        completedAt,
        message: request.deliveryMode === "mediprisma" ? `${completionMessage}\uFF0C\u6B63\u5728\u958B\u555F MediPrisma\u2026` : completionMessage,
        hasResult: true,
        filename,
        resultBytes: encodedBundle.uncompressedBytes,
        summary: response.summary,
        errorCode: void 0
      };
      const stillRunning = await statusForRun(request.runId);
      if (!stillRunning || stillRunning.phase !== "running") {
        await clearBackgroundResults(request.runId).catch(() => void 0);
        return;
      }
      try {
        await writeBackgroundResult(storedResult);
        if (!await statusForRun(request.runId)) {
          await clearBackgroundResults(request.runId).catch(() => void 0);
          return;
        }
        await chrome.storage.session.set({
          [BACKGROUND_JOB_STATUS_KEY]: completedStatus
        });
        await chrome.alarms.create(resultExpiryAlarmName(request.runId), {
          when: storedResult.expiresAt
        });
      } catch {
        await clearBackgroundResults(request.runId).catch(() => void 0);
        throw Object.assign(new Error("RESULT_STORAGE_FAILED"), { code: "RESULT_STORAGE_FAILED" });
      }
      await chrome.storage.session.remove(BACKGROUND_JOB_REQUEST_KEY);
      await setBadge("\u2713", "#047857");
      await notifyOneClickState(request.tabId);
      if (request.deliveryMode === "mediprisma") {
        try {
          await armMediPrismaHandoff(request.runId, { appUrl: request.mediprismaAppUrl });
          await resumeArmedMediPrismaHandoff();
        } catch {
          await markMediPrismaHandoffFailed(request.runId);
        }
        await notifyOneClickState(request.tabId);
      }
    } catch (error) {
      const current = await statusForRun(request.runId);
      if (!current || current.phase !== "running") return;
      const safe = safeErrorMessage(error);
      await Promise.all([
        clearBackgroundResults(request.runId).catch(() => void 0),
        chrome.storage.session.remove([BACKGROUND_JOB_RESULT_KEY, BACKGROUND_JOB_REQUEST_KEY])
      ]);
      await chrome.storage.session.set({
        [BACKGROUND_JOB_STATUS_KEY]: {
          ...current,
          phase: "error",
          updatedAt: Date.now(),
          message: safe.message,
          hasResult: false,
          errorCode: safe.code
        }
      });
      await setBadge("!", "#b91c1c");
      await notifyOneClickState(request.tabId);
    } finally {
      stopProgress();
    }
  }
  async function markMediPrismaHandoffFailed(runId) {
    const status = await statusForRun(runId);
    if (!status || status.phase !== "complete" || !status.hasResult) return;
    await chrome.storage.session.set({
      [BACKGROUND_JOB_STATUS_KEY]: {
        ...status,
        updatedAt: Date.now(),
        message: "\u7121\u6CD5\u5728 MediPrisma \u958B\u555F\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u4FDD\u7559\uFF0C\u9EDE\u53F3\u5074 Logo \u53EF\u91CD\u8A66\u3002",
        errorCode: "MEDIPRISMA_HANDOFF_FAILED"
      }
    });
  }
  async function beginBackgroundJob(request, options = {}) {
    if (activeJob || jobStarting) return false;
    jobStarting = true;
    try {
      const status = runningJobStatus(request, options.startedAt, options.recovered);
      const previousResult = await readBackgroundResult().catch(() => null);
      if (previousResult && previousResult.runId === request.runId) {
        await clearBackgroundResults(request.runId);
      }
      await chrome.storage.session.remove([
        BACKGROUND_JOB_RESULT_KEY,
        MEDIPRISMA_HANDOFF_INTENT_KEY
      ]);
      const persistedRequest = {
        ...request,
        patientIdentity: { maskedId: "", name: "", gender: "unknown" }
      };
      await chrome.storage.session.set({
        [BACKGROUND_JOB_REQUEST_KEY]: persistedRequest,
        [BACKGROUND_JOB_STATUS_KEY]: status
      });
      await setBadge("\u2026", "#2563eb");
      activeRunId = request.runId;
      activeJob = runBackgroundJob(request);
      const release = () => {
        if (activeRunId === request.runId) {
          activeRunId = "";
          activeJob = null;
        }
      };
      void activeJob.then(release, release);
      await notifyOneClickState(request.tabId);
      return true;
    } finally {
      jobStarting = false;
    }
  }
  async function markDownloaded(runId) {
    const status = await statusForRun(runId);
    if (!status) return false;
    const downloaded = downloadedJobStatus(status);
    if (!downloaded) return false;
    await chrome.storage.session.set({
      [BACKGROUND_JOB_STATUS_KEY]: downloaded
    });
    await setBadge("");
    if (status.tabId) await notifyOneClickState(status.tabId);
    return true;
  }
  async function clearJob(runId) {
    const previous = await storedStatus();
    if (runId) {
      const status = await statusForRun(runId);
      if (!status) return false;
    }
    if (activeJob && (!runId || runId === activeRunId)) {
      if (previous?.tabId && activeRunId) {
        await cancelMediCloudCapture(previous.tabId, activeRunId);
      }
    }
    await clearBackgroundResults(runId);
    if (runId ?? previous?.runId) {
      await chrome.alarms.clear(resultExpiryAlarmName(runId ?? previous.runId));
    }
    await chrome.storage.session.remove([
      BACKGROUND_JOB_STATUS_KEY,
      BACKGROUND_JOB_REQUEST_KEY,
      BACKGROUND_JOB_RESULT_KEY,
      MEDIPRISMA_HANDOFF_INTENT_KEY
    ]);
    await setBadge("");
    if (previous?.tabId) await notifyOneClickState(previous.tabId);
    return true;
  }
  async function startOneClickFlow(tabId, mediCloudUrl) {
    const mediprismaAppUrl = buildMediPrismaAppUrlFromMediCloud(mediCloudUrl);
    const includeImagingViewerLinks = true;
    const patient = await waitForMediCloudPatient(tabId, probeMediCloudPatient);
    if (!patient.ok) {
      return patient.code === "NOT_MEDCLOUD" ? oneClickError(
        "\u76EE\u524D\u4E0D\u662F\u96F2\u7AEF\u75C5\u6B77\u9801\u9762",
        "\u8ACB\u56DE\u5230\u5065\u4FDD\u91AB\u7642\u8CC7\u8A0A\u96F2\u7AEF\u67E5\u8A62\u7CFB\u7D71\u7684\u75C5\u4EBA\u9801\u9762\u5F8C\u518D\u8A66\u3002"
      ) : oneClickError(
        "\u75C5\u4EBA\u5075\u6E2C\u903E\u6642",
        `\u7B49\u5F85 ${WINFORMS_PATIENT_WAIT_TIMEOUT_MS / 1e3} \u79D2\u5F8C\u4ECD\u672A\u5075\u6E2C\u5230\u75C5\u4EBA\uFF1B\u8ACB\u78BA\u8A8D\u8B80\u5361\u3001\u767B\u5165\u8207\u76EE\u524D\u75C5\u4EBA\u8CC7\u6599\u5DF2\u986F\u793A\uFF0C\u518D\u9EDE\u4E00\u6B21 Logo\u3002`
      );
    }
    const stored = await chrome.storage.session.get(BACKGROUND_JOB_STATUS_KEY);
    const status = isBackgroundJobStatus(stored[BACKGROUND_JOB_STATUS_KEY]) ? stored[BACKGROUND_JOB_STATUS_KEY] : null;
    if (status?.phase === "running") {
      if (status.tabId === tabId && status.patientContextHash === patient.patientContextHash) {
        return oneClickFlowState(status, tabId);
      }
      return oneClickError(
        "\u53E6\u4E00\u500B\u75C5\u6B77\u6B63\u5728\u8655\u7406",
        "\u8ACB\u7B49\u5F85\u76EE\u524D\u7684\u5DE5\u4F5C\u5B8C\u6210\uFF1B\u64F7\u53D6\u671F\u9593\u4E0D\u6703\u6DF7\u7528\u4E0D\u540C\u75C5\u4EBA\u7684\u8CC7\u6599\u3002",
        false
      );
    }
    const result = status ? await readBackgroundResult(status.runId) : null;
    const canReuseResult = Boolean(
      status && hasAvailableBackgroundResult(status) && status.tabId === tabId && status.patientContextHash === patient.patientContextHash && status.includeImagingViewerLinks === includeImagingViewerLinks && isBackgroundJobResult(result) && result.runId === status.runId && result.patientContextHash === patient.patientContextHash && !isExpiredResult(result)
    );
    if (status && canReuseResult) {
      const openingStatus = {
        ...status,
        phase: "complete",
        deliveryMode: "mediprisma",
        updatedAt: Date.now(),
        message: "\u8CC7\u6599\u5DF2\u6E96\u5099\u5B8C\u6210\uFF0C\u6B63\u5728\u958B\u555F MediPrisma\u2026",
        errorCode: void 0
      };
      await chrome.storage.session.set({
        [BACKGROUND_JOB_STATUS_KEY]: openingStatus
      });
      await notifyOneClickState(tabId);
      try {
        await armMediPrismaHandoff(status.runId, { appUrl: mediprismaAppUrl });
        await resumeArmedMediPrismaHandoff();
      } catch {
        await markMediPrismaHandoffFailed(status.runId);
      }
      await notifyOneClickState(tabId);
      return oneClickStateForTab(tabId);
    }
    const request = {
      tabId,
      runId: crypto.randomUUID(),
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      expectedPatientContextHash: patient.patientContextHash,
      maskNameEnabled: true,
      includeImagingViewerLinks,
      patientIdentity: patient.identity,
      deliveryMode: "mediprisma",
      mediprismaAppUrl
    };
    const accepted = await beginBackgroundJob(request);
    if (!accepted) {
      return oneClickError(
        "\u76EE\u524D\u5DF2\u6709\u5DE5\u4F5C\u6B63\u5728\u8655\u7406",
        "\u8ACB\u7B49\u5F85\u5B8C\u6210\u5F8C\u518D\u8A66\u3002",
        false
      );
    }
    return oneClickStateForTab(tabId);
  }
  async function recoverStoredJob() {
    const stored = await chrome.storage.session.get([
      BACKGROUND_JOB_STATUS_KEY,
      BACKGROUND_JOB_REQUEST_KEY,
      BACKGROUND_JOB_RESULT_KEY
    ]);
    const status = stored[BACKGROUND_JOB_STATUS_KEY];
    const request = stored[BACKGROUND_JOB_REQUEST_KEY];
    const legacyResult = stored[BACKGROUND_JOB_RESULT_KEY];
    if (isBackgroundJobResult(legacyResult)) {
      if (legacyResult.schemaVersion === 4) {
        await writeBackgroundResult(legacyResult);
      }
      await chrome.storage.session.remove(BACKGROUND_JOB_RESULT_KEY);
    }
    if (!isBackgroundJobStatus(status)) {
      await Promise.all([
        clearBackgroundResults(),
        chrome.storage.session.remove([
          BACKGROUND_JOB_REQUEST_KEY,
          BACKGROUND_JOB_RESULT_KEY,
          MEDIPRISMA_HANDOFF_INTENT_KEY
        ])
      ]);
      return;
    }
    const result = await readBackgroundResult(status.runId);
    if (result && isExpiredResult(result)) {
      await clearJob(result.runId);
      return;
    }
    if (hasAvailableBackgroundResult(status) && !result) {
      await Promise.all([
        clearBackgroundResults(status.runId),
        chrome.storage.session.remove(BACKGROUND_JOB_REQUEST_KEY)
      ]);
      await chrome.storage.session.set({
        [BACKGROUND_JOB_STATUS_KEY]: {
          ...status,
          phase: "error",
          updatedAt: Date.now(),
          message: "\u66AB\u5B58\u7684\u5065\u5EB7\u7D00\u9304\u5DF2\u4E0D\u5B58\u5728\uFF0C\u8ACB\u91CD\u65B0\u53D6\u5F97\u3002",
          hasResult: false,
          errorCode: "BACKGROUND_RESULT_MISSING"
        }
      });
      return;
    }
    if (status.phase !== "running") {
      await chrome.storage.session.remove(BACKGROUND_JOB_REQUEST_KEY);
      return;
    }
    if (!isBackgroundJobRequest(request) || !isRecoverableJob(status, request)) {
      const safeStatus = {
        ...status,
        phase: "error",
        updatedAt: Date.now(),
        message: "\u8CC7\u6599\u53D6\u5F97\u4E2D\u65B7\uFF0C\u8ACB\u56DE\u5230\u96F2\u7AEF\u75C5\u6B77\u91CD\u65B0\u53D6\u5F97\u3002",
        hasResult: false,
        errorCode: "BACKGROUND_JOB_INTERRUPTED"
      };
      await Promise.all([
        clearBackgroundResults(status.runId),
        chrome.storage.session.remove([BACKGROUND_JOB_REQUEST_KEY, BACKGROUND_JOB_RESULT_KEY])
      ]);
      await chrome.storage.session.set({ [BACKGROUND_JOB_STATUS_KEY]: safeStatus });
      await setBadge("!", "#b91c1c");
      return;
    }
    const patient = await probeMediCloudPatient(request.tabId);
    if (!patient.ok || patient.patientContextHash !== request.expectedPatientContextHash) {
      await clearJob(request.runId);
      return;
    }
    await beginBackgroundJob(
      { ...request, patientIdentity: patient.identity },
      { recovered: true, startedAt: status.startedAt }
    );
  }
  var backgroundInitialization = (async () => {
    await chrome.storage.local.remove(LEGACY_DATA_CONSENT_STORAGE_KEY).catch(() => void 0);
    await chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
    await recoverStoredJob();
    await sweepMediPrismaHandoffIntent();
  })().catch(() => void 0);
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    if (message && typeof message === "object" && !Array.isArray(message) && message.type === OPEN_NHI_VIEWER) {
      if (!isTrustedMediPrismaSender(sender) || !isOpenNhiViewerRuntimeMessage(message)) {
        sendResponse({ ok: false, code: "INVALID_REQUEST" });
        return false;
      }
      if (viewerOpenInFlight) {
        sendResponse({ ok: false, code: "REQUEST_IN_PROGRESS" });
        return false;
      }
      viewerOpenInFlight = true;
      void openNhiViewerFromMediPrisma(message, {
        queryMediCloudTabs: () => chrome.tabs.query({
          url: `${MEDCLOUD_ORIGIN}/imu/*`
        }),
        probePatient: probeMediCloudPatient,
        mintViewerUrl: mintMediCloudViewerUrl,
        openTab: (url) => chrome.tabs.create({ url, active: true })
      }).then(sendResponse).catch(() => {
        sendResponse({ ok: false, code: "VIEWER_UNAVAILABLE" });
      }).finally(() => {
        viewerOpenInFlight = false;
      });
      return true;
    }
    if (!isBackgroundJobMessage(message)) return false;
    if (message.type === START_ONE_CLICK_FLOW || message.type === GET_ONE_CLICK_FLOW_STATE) {
      if (!isTrustedMediCloudSender(sender)) {
        sendResponse({
          ok: false,
          state: oneClickError(
            "\u9801\u9762\u4F86\u6E90\u4E0D\u7B26",
            "\u4E00\u9375\u6D41\u7A0B\u53EA\u80FD\u5F9E\u5065\u4FDD\u96F2\u7AEF\u75C5\u6B77\u7684\u4E3B\u9801\u9762\u555F\u52D5\u3002",
            false
          )
        });
        return false;
      }
      const tabId = sender.tab.id;
      const mediCloudUrl = sender.url ?? sender.tab.url ?? "";
      const task = backgroundInitialization.then(
        () => message.type === START_ONE_CLICK_FLOW ? startOneClickFlow(tabId, mediCloudUrl) : oneClickStateForTab(tabId)
      );
      void task.then((state) => sendResponse({ ok: true, state })).catch(() => sendResponse({
        ok: false,
        state: oneClickError(
          "\u7121\u6CD5\u555F\u52D5\u4E00\u9375\u6D41\u7A0B",
          "\u8ACB\u91CD\u65B0\u6574\u7406\u96F2\u7AEF\u75C5\u6B77\u5F8C\u518D\u8A66\uFF1B\u5DF2\u5B8C\u6210\u7684\u5065\u5EB7\u7D00\u9304\u4ECD\u6703\u4FDD\u7559\u3002"
        )
      }));
      return true;
    }
    if (message.type === START_BACKGROUND_JOB) {
      void backgroundInitialization.then(async () => {
        const accepted = await beginBackgroundJob(message.payload);
        return { accepted, code: accepted ? void 0 : "JOB_RUNNING" };
      }).then(({ accepted, code }) => sendResponse({ ok: accepted, code })).catch(() => sendResponse({ ok: false, code: "BACKGROUND_STORAGE_FAILED" }));
      return true;
    }
    if (message.type === MARK_BACKGROUND_JOB_DOWNLOADED) {
      void backgroundInitialization.then(() => markDownloaded(message.runId)).then((ok) => sendResponse({ ok })).catch(() => sendResponse({ ok: false }));
      return true;
    }
    if (message.type === CLEAR_BACKGROUND_JOB) {
      void backgroundInitialization.then(() => clearJob(message.runId)).then((ok) => sendResponse({ ok })).catch(() => sendResponse({ ok: false }));
      return true;
    }
    if (message.type === ARM_MEDIPRISMA_HANDOFF) {
      void backgroundInitialization.then(() => armMediPrismaHandoff(message.runId)).then(() => sendResponse({ ok: true })).catch(() => sendResponse({
        ok: false,
        error: "\u76EE\u524D\u6C92\u6709\u53EF\u4F9B MediPrisma \u67E5\u770B\u4E14\u4ECD\u6709\u6548\u7684\u5065\u5EB7\u7D00\u9304\u3002"
      }));
      return true;
    }
    if (message.type === DISARM_MEDIPRISMA_HANDOFF) {
      void backgroundInitialization.then(() => disarmMediPrismaHandoff()).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
      return true;
    }
    if (message.type === OPEN_PENDING_BUNDLE_IN_MEDIPRISMA) {
      void backgroundInitialization.then(() => resumeArmedMediPrismaHandoff()).then(({ tabId }) => sendResponse({ ok: true, tabId })).catch(() => sendResponse({
        ok: false,
        error: "\u7121\u6CD5\u5728 MediPrisma \u958B\u555F\uFF1B\u9019\u6B21\u8CC7\u6599\u4ECD\u53EF\u4E0B\u8F09\u3002"
      }));
      return true;
    }
    if (message.type === MEDIPRISMA_HANDOFF_SETTLED) {
      void backgroundInitialization.then(() => settleMediPrismaHandoff(message, sender)).then(async (result) => {
        if (result === "complete") await setBadge("");
        const status = await statusForRun(message.runId);
        if (status?.tabId) await notifyOneClickState(status.tabId);
        sendResponse({ ok: true });
      }).catch(() => sendResponse({ ok: false }));
      return true;
    }
    return false;
  });
  chrome.permissions.onAdded.addListener((permissions) => {
    if (!includesMediPrismaHostPermission(permissions)) return;
    void backgroundInitialization.then(() => resumeArmedMediPrismaHandoff()).catch(() => void 0);
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name.startsWith(RESULT_EXPIRY_ALARM_PREFIX)) {
      const runId = alarm.name.slice(RESULT_EXPIRY_ALARM_PREFIX.length);
      void backgroundInitialization.then(async () => {
        const result = await readBackgroundResult(runId);
        if (isBackgroundJobResult(result) && isExpiredResult(result)) {
          await clearJob(runId);
        }
        await clearExpiredBackgroundResult();
      });
    }
    if (alarm.name === KEEPALIVE_ALARM && activeRunId) {
      void statusForRun(activeRunId).then((status) => {
        if (status?.phase === "running") {
          return chrome.storage.session.set({
            [BACKGROUND_JOB_STATUS_KEY]: { ...status, updatedAt: Date.now() }
          });
        }
      });
    }
    if (alarm.name === MEDIPRISMA_HANDOFF_EXPIRY_ALARM) {
      void backgroundInitialization.then(async () => {
        await sweepMediPrismaHandoffIntent();
        const status = await storedStatus();
        if (status?.tabId) await notifyOneClickState(status.tabId);
      });
    }
    if (alarm.name === RESULT_SWEEP_ALARM) {
      void backgroundInitialization.then(() => recoverStoredJob());
      void backgroundInitialization.then(() => sweepMediPrismaHandoffIntent());
      void backgroundInitialization.then(() => clearExpiredBackgroundResult());
    }
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (!changeInfo.url || !isWinFormsCloseSignalUrl(changeInfo.url)) return;
    void closeManagedClinicalTabs(tabId).catch(() => void 0);
  });
  void chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 }).catch(() => void 0);
  void chrome.alarms.create(RESULT_SWEEP_ALARM, { periodInMinutes: 10 }).catch(() => void 0);
})();
/*! Bundled license information:

js-sha1/src/sha1.js:
  (*
   * [js-sha1]{@link https://github.com/emn178/js-sha1}
   *
   * @version 0.7.0
   * @author Chen, Yi-Cyuan [emn178@gmail.com]
   * @copyright Chen, Yi-Cyuan 2014-2024
   * @license MIT
   *)
*/
